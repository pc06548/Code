package controllers

import cats.effect.IO
import org.mockito.ArgumentMatchers
import org.mockito.Mockito.when
import org.scalatestplus.mockito.MockitoSugar.mock
import org.scalatestplus.play.PlaySpec
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers.{status, stubControllerComponents, _}
import repositories.Ballot
import services.{BallotService, LoginService}

import scala.concurrent.Future

class BallotControllerTest extends PlaySpec {

  val loginServiceMock = mock[LoginService]
  val ballotServiceMock = mock[BallotService]

  val controller = new BallotController(loginServiceMock, ballotServiceMock, stubControllerComponents())

  "BallotControllerTest" should {

    "should return ok on creating ballot" in {

      when(loginServiceMock.auth(ArgumentMatchers.any())).thenReturn(Some(1L))
      when(ballotServiceMock.addBallot(
        Ballot(0,1,1))).thenReturn(IO.pure(Some(1L)))

      val resultF: Future[Result] = controller.purchaseBallot(1L).apply(FakeRequest()
        .withHeaders("Authorization" -> "xyz"))

      assert(status(resultF) == NO_CONTENT)
    }

    "should return not found if on ballot serivce not able to create ballot" in {

      when(loginServiceMock.auth(ArgumentMatchers.any())).thenReturn(Some(1L))
      when(ballotServiceMock.addBallot(
        Ballot(0,1,1))).thenReturn(IO.pure(None))

      val resultF: Future[Result] = controller.purchaseBallot(1L).apply(FakeRequest()
        .withHeaders("Authorization" -> "xyz"))

      assert(status(resultF) == NOT_FOUND)
    }

    "should return 500 on error while creating ballot" in {

      when(loginServiceMock.auth(ArgumentMatchers.any())).thenReturn(Some(1L))
      when(ballotServiceMock.addBallot(
        Ballot(0,1,1))).thenReturn(IO.raiseError(new Exception("random error")))

      val resultF: Future[Result] = controller.purchaseBallot(1L).apply(FakeRequest()
        .withHeaders("Authorization" -> "xyz"))

      assert(status(resultF) == INTERNAL_SERVER_ERROR)
    }

    "should return ballots get request" in {

      when(loginServiceMock.auth(ArgumentMatchers.any())).thenReturn(Some(1L))
      when(ballotServiceMock.getBallotForUser(1, 1)).thenReturn(IO.pure(
        List(Ballot(1,1,1))
      ))

      val resultF: Future[Result] = controller.getBallots(1L).apply(FakeRequest()
        .withHeaders("Authorization" -> "xyz"))

      assert(status(resultF) == OK)
      assert(contentAsString(resultF) == """[{"id":1,"lotteryId":1,"userId":1}]""")

    }
  }
}

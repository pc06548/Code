package endpoints

import cats.effect.IO
import controllers.LotteryController
import dtos.AddLotteryRequest
import org.mockito.ArgumentMatchers
import org.mockito.Mockito.when
import org.scalatestplus.mockito.MockitoSugar.mock
import org.scalatestplus.play.PlaySpec
import play.api.libs.json.Json
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers.{status, stubControllerComponents, _}
import repositories.Lottery
import services.{LoginService, LotteryService}

import scala.concurrent.Future

class LotteryControllerTest extends PlaySpec {

  val loginServiceMock = mock[LoginService]
  val lotteryServiceMock = mock[LotteryService]

  val controller = new LotteryController(loginServiceMock, lotteryServiceMock, stubControllerComponents())

  "LotteryControllerTest" should {

    "should return ok on creating lottery" in {

      when(loginServiceMock.auth(ArgumentMatchers.any())).thenReturn(Some(1L))
      when(lotteryServiceMock.addLottery(
        Lottery(0,
          "5k-win",
          AddLotteryRequest.dateTimeFormatter.parse("2021-01-01T00:00:00Z").getTime,
          AddLotteryRequest.dateTimeFormatter.parse("3021-05-10T18:19:00Z").getTime))).thenReturn(IO.pure(1L))

      val resultF: Future[Result] = controller.addLottery.apply(FakeRequest()
          .withHeaders("Authorization" -> "xyz")
        .withJsonBody(Json.parse(
          """
          |{
          |    "name": "5k-win",
          |    "startDate": "2021-01-01T00:00:00Z",
          |    "endDate": "3021-05-10T18:19:00Z"
          |}
          |""".stripMargin)))

      assert(status(resultF) == NO_CONTENT)
    }

    "should return 500 on error while creating lottery" in {

      when(loginServiceMock.auth(ArgumentMatchers.any())).thenReturn(Some(1L))
      when(lotteryServiceMock.addLottery(
        Lottery(0,
          "5k-win",
          AddLotteryRequest.dateTimeFormatter.parse("2021-01-01T00:00:00Z").getTime,
          AddLotteryRequest.dateTimeFormatter.parse("3021-05-10T18:19:00Z").getTime))).thenReturn(IO.raiseError(new Exception("random error")))

      val resultF: Future[Result] = controller.addLottery.apply(FakeRequest()
        .withHeaders("Authorization" -> "xyz")
        .withJsonBody(Json.parse(
          """
            |{
            |    "name": "5k-win",
            |    "startDate": "2021-01-01T00:00:00Z",
            |    "endDate": "3021-05-10T18:19:00Z"
            |}
            |""".stripMargin)))

      assert(status(resultF) == INTERNAL_SERVER_ERROR)
    }

    "should return 401 on auth error" in {

      when(loginServiceMock.auth(ArgumentMatchers.any())).thenReturn(None)

      val resultF: Future[Result] = controller.addLottery.apply(FakeRequest()
        .withHeaders("Authorization" -> "xyz")
        .withJsonBody(Json.parse(
          """
            |{
            |    "name": "5k-win",
            |    "startDate": "2021-01-01T00:00:00Z",
            |    "endDate": "3021-05-10T18:19:00Z"
            |}
            |""".stripMargin)))

      assert(status(resultF) == UNAUTHORIZED)
    }

    "should return bad request on wrong input" in {

      when(loginServiceMock.auth(ArgumentMatchers.any())).thenReturn(Some(1L))

      val resultF: Future[Result] = controller.addLottery.apply(FakeRequest()
        .withHeaders("Authorization" -> "xyz")
        .withJsonBody(Json.parse(
          """
            |{
            |    "name": "5k-win",
            |    "startDate": "2021-01-01T00:00:00Z",
            |    "endDate": "3021-05-10T18:19:00"
            |}
            |""".stripMargin)))

      assert(status(resultF) == BAD_REQUEST)
    }


    "should return lotteries on getting lottery" in {

      when(lotteryServiceMock.getLotteries()).thenReturn(IO.pure(List(
        Lottery(1,
          "5k-win",
          AddLotteryRequest.dateTimeFormatter.parse("2021-01-01T00:00:00Z").getTime,
          AddLotteryRequest.dateTimeFormatter.parse("3021-05-10T18:19:00Z").getTime,
          Some(1)
        ),
        Lottery(2,
          "5k-win2",
          AddLotteryRequest.dateTimeFormatter.parse("2021-01-01T00:00:00Z").getTime,
          AddLotteryRequest.dateTimeFormatter.parse("3021-05-10T18:19:00Z").getTime)
      )))

      val resultF: Future[Result] = controller.getLotteries.apply(FakeRequest())

      assert(status(resultF) == OK)
      assert(contentAsString(resultF) == """[{"id":1,"name":"5k-win","startDate":1609455600000,"endDate":33177572340000,"winner":1},{"id":2,"name":"5k-win2","startDate":1609455600000,"endDate":33177572340000}]""")
    }
  }
}

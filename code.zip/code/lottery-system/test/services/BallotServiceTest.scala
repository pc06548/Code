package services

import cats.effect.IO
import org.scalatest.{FunSpec, Matchers}
import org.scalatestplus.mockito.MockitoSugar.mock
import repositories.{Ballot, BallotRepository, Lottery, LotteryRepository}
import org.mockito.Mockito.when

class BallotServiceTest extends FunSpec with Matchers {

  val ballotRepo = mock[BallotRepository]
  val lotteryRepo = mock[LotteryRepository]

  val service = new BallotService(ballotRepo, lotteryRepo)

  describe("BallotServiceTest") {

    it ("should not create ballot when lottery is expired") {
      when(lotteryRepo.getLottery(1)).thenReturn(IO.pure(
        Some(Lottery(1, "something", 1609455600000L, 1609455600000L))))
      service.addBallot(Ballot(1, 1, 1)).unsafeRunSync() should be (None)
    }

    it ("should not create ballot when lottery is not found") {
      when(lotteryRepo.getLottery(1)).thenReturn(IO.pure(None))
      service.addBallot(Ballot(1, 1, 1)).unsafeRunSync() should be (None)
    }
  }
}

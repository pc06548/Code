package streaming

import akka.actor.ActorSystem
import akka.testkit.{TestActorRef, TestKit}
import cats.effect.IO
import dtos.AddLotteryRequest
import org.mockito.Mockito.{verify, when}
import org.scalatest.FunSpecLike
import org.scalatestplus.mockito.MockitoSugar.mock
import repositories.{Ballot, BallotRepository, Lottery, LotteryRepository}
import services.{DecideWinner, LotteryEventClusterSingletonActor, RegisterLottery}


class LotteryEventServiceTest extends TestKit(ActorSystem("actor-test-system")) with FunSpecLike {

  describe("LotteryEventServiceTest") {

    val ballotRepo = mock[BallotRepository]
    val lotteryRepo = mock[LotteryRepository]

    it("should handle decide winner event") {

      val lottery = Lottery(1,
        "5k-win",
        AddLotteryRequest.dateTimeFormatter.parse("2021-01-01T00:00:00Z").getTime,
        AddLotteryRequest.dateTimeFormatter.parse("3021-05-10T18:19:00Z").getTime,
        Some(1)
      )

      // start a stream
      when(ballotRepo.getBallots(1)).thenReturn(IO.pure(List(
        Ballot(1, 1 ,1)
      )))

      when(lotteryRepo.getLotteries()).thenReturn(IO.pure(List()))
      when(lotteryRepo.updateWinner(1, 1)).thenReturn(IO(()))

      val actorRef = TestActorRef(new LotteryEventClusterSingletonActor(lotteryRepo, ballotRepo))

      actorRef ! DecideWinner(lottery)
      Thread.sleep(500)
      verify(ballotRepo).getBallots(1)
      verify(lotteryRepo).updateWinner(1, 1)
    }
  }

}

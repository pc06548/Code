CREATE TABLE IF NOT EXISTS login (
    id serial primary key,
    user_name text UNIQUE NOT NULL,
    password text NOT NULL
);

CREATE TABLE IF NOT EXISTS lottery (
    id serial primary key,
    name text UNIQUE NOT NULL,
    start_date bigint NOT NULL,
    end_date bigint NOT NULL,
    winner bigint
);

CREATE TABLE IF NOT EXISTS ballot (
    id serial primary key,
    lottery_id integer REFERENCES lottery,
    user_id  integer REFERENCES login
);
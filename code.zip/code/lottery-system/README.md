# Lottery System API

### Stack
* Scala
* Sbt
* Play
* Docker
* Postgres

### Run
`docker-compose up`

### Endpoints
Endpoint | Type | Body
--- | --- | --- 
/sign-up | POST | {"userName": "prashant",   "password": "prashant"}
/login | POST | {"userName": "prashant",   "password": "prashant"}
/lottery | POST | { "name": "5k-win", "startDate": "2021-01-01T00:00:00Z",  "endDate": "2021-05-09T18:19:00Z"   }
/lottery | GET | -
/lottery/<lottery-id>/ballot | POST | -
/lottery/<lottery-id>/ballot | GET | -


### Design
```
Scala Play backend API for Lottery system.
Application has crud operations for User, Lottery and ballot management.
Please find the postman collection 'lottery-system.postman_collection.json'
Database schema is in conf/db.
I have used actor scheduler to handle event triggers for Winner.
It populates the existing lotteries from DB on start and decides any pending winner
or schedules winner event for active lotteries.

User once signed up / logged in, gets a JWT token back with header 'bat'.
Pass this as Authorization header for user specific endpoints.

Database interactions are handled with slick. 
```

### Improvements
* Each lottery needs to be created manually now, by calling endpoint. 
For Scheduling request a job configuration system needs to be added.
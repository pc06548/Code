package services

import akka.actor.ActorRef
import javax.inject.{Inject, Named}
import repositories.{Lottery, LotteryRepository}

class LotteryService @Inject()(repo: LotteryRepository,
                               @Named("lottery-event-actor") lotteryEventActor: ActorRef) {

  def addLottery(lottery: Lottery) = {
    repo.addLottery(lottery).map(id => {
      lotteryEventActor ! RegisterLottery(lottery.copy(id = id))
      id
    })
  }

  def getLotteries() =
    repo.getLotteries()
}

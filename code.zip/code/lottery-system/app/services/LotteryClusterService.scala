package services

import javax.inject.Inject
import repositories.{Lottery, LotteryRepository}

class LotteryClusterService @Inject()(repo: LotteryRepository, lotteryActorComponent: ActorComponent) {

  def addLottery(lottery: Lottery) = {
    repo.addLottery(lottery).map(id => {
      lotteryActorComponent.lotteryEventActorProxy ! RegisterLottery(lottery.copy(id = id))
      id
    })
  }

  def getLotteries() =
    repo.getLotteries()
}

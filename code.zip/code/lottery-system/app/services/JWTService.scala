package services

import java.util.Date
import java.util.UUID.randomUUID

import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import config.AppConstants
import org.slf4j.LoggerFactory

import scala.util._


object JWTService {

  def getUUID = {
    randomUUID().toString
  }

  private val logger = LoggerFactory.getLogger(this.getClass)
  def createTokenForLogin(userId: Long): Option[String] = {
    Try {
      JWT.create().withIssuer("auth0")
        .withClaim("userId", userId.toString)
        .withClaim("token", getUUID)
        .withExpiresAt(new Date(System.currentTimeMillis() + 1296000000))
        .sign(Algorithm.HMAC256(AppConstants.JwtSecretKey))
    } match {
      case Success(value) => Some(value)
      case Failure(ex) =>
        logger.error(s"Error creating jwt token with exception: ${ex.getMessage}")
        None
    }
  }

  def verify(token: String): Boolean = {
     Try {
       val algorithm = Algorithm.HMAC256(AppConstants.JwtSecretKey)
       val verifier = JWT.require(algorithm).withIssuer("auth0").build()
       verifier.verify(token)
     } match {
       case Success(_) => true
       case Failure(_) => false
     }
  }

  def decode(token: String): Option[Long] = {
    Try {
      val decodedJwt = JWT.decode(token)
      decodedJwt.getClaim("userId").asString().toLong
    } match {
      case Success(value)=> Some(value)
      case Failure(ex) =>
        logger.error(s"Error decoding jwt token. Exception: ${ex.getMessage}")
        None
    }
  }
}

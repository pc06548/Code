package services

import java.util.Date

import cats.effect.IO
import javax.inject.Inject
import repositories.{Ballot, BallotRepository, Lottery, LotteryRepository}

class BallotService @Inject()(repo: BallotRepository,
                              lotteryRepo: LotteryRepository
                             ) {

  def addBallot(ballot: Ballot): IO[Option[Long]] = {
    for {
      lotteryO <- lotteryRepo.getLottery(ballot.lotteryId)
      ballotIdO <- lotteryO match {
        case Some(lottery) =>
          if(isValidLottery(lottery))
            repo.addBallot(ballot).map(Some(_))
          else IO.pure(None)
        case None => IO.pure(None)
      }
    } yield {
      ballotIdO
    }
  }

  private def isValidLottery(lottery: Lottery) = {
    val today = new Date()
    val start = new Date(lottery.startDate)
    val end = new Date(lottery.endDate)
    (today.after(start) || today == start) && today.before(end)
  }

  def getBallotForALottery(lotteryId: Long) = repo.getBallots(lotteryId)

  def getBallotForUser(lotteryId: Long, userId: Long): IO[List[Ballot]] = repo.getBallotsForUser(lotteryId, userId)
}

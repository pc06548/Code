package services

import java.util.Date

import akka.actor.{Actor, ActorSystem, PoisonPill, Props}
import akka.cluster.singleton.{ClusterSingletonManager, ClusterSingletonManagerSettings, ClusterSingletonProxy, ClusterSingletonProxySettings}
import cats.effect.IO
import cats.implicits._
import com.typesafe.scalalogging.StrictLogging
import javax.inject.{Inject, Singleton}
import repositories.{BallotRepository, Lottery, LotteryRepository}

import scala.concurrent.ExecutionContextExecutor
import scala.concurrent.duration._
import scala.util.Random

class LotteryEventClusterSingletonActor @Inject()(lotteryRepository: LotteryRepository,
                                                  ballotRepository: BallotRepository) extends Actor with StrictLogging {

  val random = new Random

  implicit val ex: ExecutionContextExecutor = context.dispatcher

  implicit val contextShift = IO.contextShift(ex)

  override def preStart(): Unit = {
    logger.info("Initializing lottery event actor")
    (for {
      activeLotteries <- lotteryRepository.getLotteries().map(_.filterNot(_.winner.isDefined))
      _               <- activeLotteries.map(lottery => {
                          val today = new Date()
                          val lotteryEndDate = new Date(lottery.endDate)
                            if (lotteryEndDate.before(today)) {
                              IO.fromFuture(IO(decideWinner(lottery)))
                            } else {
                              IO.pure(scheduleWinnerEvent(lottery))
                            }
                          }).sequence
    } yield {
    }).unsafeToFuture()
      .recover {
        case e =>
          logger.error(s"Error while initializing lottery event actor. $e")
      }
  }

  override def receive: Receive = {
    case DecideWinner(lottery) =>
      decideWinner(lottery)

    case RegisterLottery(lottery) =>
      scheduleWinnerEvent(lottery)
  }

  private def decideWinner(lottery: Lottery)= {
    logger.info(s"Deciding winner for ${lottery.name}")
    (for {
      latestWinStatus  <- lotteryRepository.getLottery(lottery.id).map(_.flatMap(_.winner))
      ballotsO         <- if(latestWinStatus.isEmpty) {
                            ballotRepository.getBallots(lottery.id).map(Some(_))
                          } else {
                            IO.pure(None)
                          }
      winnerO          =  ballotsO.map(ballots => if(ballots.isEmpty) {
                              -1
                            } else {
                              ballotsO.get(random.nextInt(ballots.length)).userId
                            })

      _                <- winnerO.map(winner =>
                          lotteryRepository.updateWinner(lottery.id, winner)).getOrElse(IO.unit)
    } yield {

    }).unsafeToFuture()
      .recover {
        case e =>
          logger.error(s"Error while deciding winner for ${lottery.name}. $e")
      }
  }

  private def scheduleWinnerEvent(lottery: Lottery) = {
    val today = new Date()
    val delay = (lottery.endDate - today.getTime)/1000
    if (delay > 0) {
      logger.info(s"Scheduling lottery winner event for ${lottery.name} after $delay seconds")
      context.system.scheduler.scheduleOnce(delay seconds, self, DecideWinner(lottery))(context.dispatcher)
    } else {
      self ! DecideWinner(lottery)
    }
  }
}

@Singleton
class ActorComponent @Inject()(lotteryRepository: LotteryRepository, ballotRepository: BallotRepository, actorSystem: ActorSystem) {

  actorSystem.actorOf(
    ClusterSingletonManager.props(
      singletonProps = Props(new LotteryEventClusterSingletonActor(lotteryRepository, ballotRepository)),
      terminationMessage = PoisonPill,
      ClusterSingletonManagerSettings(actorSystem)
    ), "lotteryActor"
  )

  val lotteryEventActorProxy = actorSystem.actorOf(
    ClusterSingletonProxy.props(
      singletonManagerPath = "/user/lotteryActor",
      settings = ClusterSingletonProxySettings(actorSystem)),
    name = "lotteryEventProxy")

}
package services

import cats.effect.IO
import javax.inject.Inject
import repositories.LoginRepository

class LoginService @Inject()(repo: LoginRepository) {

  def signUp(userName: String, password: String): IO[Option[String]] = {
    repo.createAndGetLoginId(userName, password) map( userId =>
      JWTService.createTokenForLogin(userId))
  }

  def login(userName: String, password: String): IO[Option[String]] = {
    repo.validateAndGetLoginId(userName, password).map(_.flatMap(userId => JWTService.createTokenForLogin(userId)))
  }

  def auth(bat: String): Option[Long] = {
    JWTService.verify(bat) match {
      case true =>
        JWTService.decode(bat)
      case false =>
        None
    }
  }
}

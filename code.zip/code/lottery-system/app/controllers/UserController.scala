package controllers

import constants.ErrorMessages
import dtos.UserLoginUpRequest
import javax.inject.Inject
import play.api.mvc.ControllerComponents
import services.LoginService

import scala.concurrent.Future


class UserController @Inject()(loginService: LoginService, controllerComponent: ControllerComponents)
  extends BaseController(loginService, controllerComponent) {

  def signUp = Action.async {
    request => {
      (for {
        json <- request.body.asJson
        signUpRequest <- UserLoginUpRequest.createFromJson(json)
      } yield {
        loginService.signUp(signUpRequest.userName, signUpRequest.password).map(r => r match {
          case Some(bat) => NoContent.withBat(bat)
          case None => NotFound
        }).unsafeToFuture().withErrorHandling(s"Error while sign up ${signUpRequest.userName}")
      }).getOrElse(Future.successful(BadRequest(ErrorMessages.BAD_REQUEST_PARAMS_JSON)))
    }
  }

  def login = Action.async {
    request => {
      (for {
        json <- request.body.asJson
        loginRequest <- UserLoginUpRequest.createFromJson(json)
      } yield {
        loginService.login(loginRequest.userName, loginRequest.password).map(r => r match {
          case Some(bat) => NoContent.withBat(bat)
          case None =>  Unauthorized(ErrorMessages.INCORRECT_USERNAME_PASSWORD_JSON)
        }).unsafeToFuture().withErrorHandling(s"Error while login ${loginRequest.userName}")
      }).getOrElse(Future.successful(BadRequest(ErrorMessages.BAD_REQUEST_PARAMS_JSON)))
    }
  }

}

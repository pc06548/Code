package controllers

import controllers.utils.ResponseHelper
import javax.inject.{Inject, _}
import play.action.Authorization
import play.api.libs.json.{JsValue, Json}
import play.api.mvc.{ControllerComponents, _}
import services.LoginService


@Singleton
class BaseController @Inject()(loginServiceP: LoginService,
                               controllerComponent: ControllerComponents) extends AbstractController(controllerComponent)
  with Authorization with ResponseHelper {

  override def loginService: LoginService = loginServiceP
  override def cc: ControllerComponents = controllerComponent

  def bat(bat: String): JsValue ={
    Json.parse(s""" {"bat" : "${bat}" } """)
  }

  implicit class RichResult (result: Result) {
    def withBat(bat: String) =  result.withHeaders("bat" -> s"${bat}")
  }
}


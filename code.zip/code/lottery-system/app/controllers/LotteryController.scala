package controllers

import constants.ErrorMessages
import dtos.AddLotteryRequest
import javax.inject.Inject
import play.api.libs.json.Json
import play.api.mvc.ControllerComponents
import repositories.Lottery
import services.{LoginService, LotteryService}

import scala.concurrent.Future

class LotteryController @Inject()(loginService: LoginService,
                                  lotteryService: LotteryService,
                                   controllerComponent: ControllerComponents)
  extends BaseController(loginService, controllerComponent) {


  def addLottery = Authenticate.async {
    request => {
      (for {
        json <- request.body.asJson
        addRequest <- AddLotteryRequest.createFromJson(json)
      } yield {
        lotteryService.addLottery(Lottery(0, addRequest.name, addRequest.startDate, addRequest.endDate))
          .map(_ => NoContent).unsafeToFuture().withErrorHandling(s"Error adding new lottery ${addRequest.name}")
      }).getOrElse(Future.successful(BadRequest(ErrorMessages.BAD_REQUEST_PARAMS_JSON)))
    }
  }

  def getLotteries = Action.async {
    lotteryService.getLotteries()
      .map(lotteries => Ok(Json.toJson(lotteries.map(_.toJson)))).unsafeToFuture().withErrorHandling(s"Error getting lotteries")
  }


}
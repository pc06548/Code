package controllers

import javax.inject.Inject
import play.api.libs.json.Json
import play.api.mvc.ControllerComponents
import repositories.Ballot
import services.{BallotService, LoginService}

class BallotController @Inject() (loginService: LoginService,
                         ballotService: BallotService,
                         controllerComponent: ControllerComponents)
  extends BaseController(loginService, controllerComponent) {

  def purchaseBallot(lotteryId: Long) = Authenticate.async {
    request => {
      ballotService.addBallot(Ballot(0, lotteryId, request.userId))
        .map(idO =>
          if (idO.isDefined) NoContent
          else NotFound
        ).unsafeToFuture().withErrorHandling(s"Error getting ballot for lottery: ${lotteryId} and user: ${request.userId}")
    }
  }

  def getBallots(lotteryId: Long)= Authenticate.async {
    request => {
      ballotService.getBallotForUser(lotteryId, request.userId)
        .map(ballots => Ok(Json.toJson(ballots.map(_.toJson)))).unsafeToFuture().withErrorHandling(s"Error getting ballot for lottery: ${lotteryId} and user: ${request.userId}")
    }
  }
}
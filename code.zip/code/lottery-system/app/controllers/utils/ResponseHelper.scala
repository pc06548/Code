package controllers.utils

import akka.util.ByteString
import com.typesafe.scalalogging.StrictLogging
import play.api.http.HttpEntity
import play.api.mvc.{ResponseHeader, Result}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

trait ResponseHelper extends StrictLogging {

  implicit class HandleErrorInFutureResult(response: Future[Result]) {
    def withErrorHandling(message: String = ""): Future[Result] = {
      response.recoverWith {
        case ex =>
          logger.error(s"$message: $ex")
          Future.successful(
            Result(
              header = ResponseHeader(500, Map.empty),
              body = HttpEntity.Strict(ByteString(s"""{ "Error": "$message" }"""), Some("application/json"))
            )
          )
      }
    }
  }
}
package repositories

import cats.effect
import config.SqlConnectionManager
import play.api.libs.json.{JsValue, Json}

case class Ballot(id: Long, lotteryId: Long, userId: Long) {
  private implicit val implicitWrites = Json.writes[Ballot]

  def toJson: JsValue = Json.toJson(this)
}

class BallotRepository extends SqlConnectionManager {
  import ctx._

  val querySchema = quote(query[Ballot])

  def getBallotsForUser(lotteryId: Long, userId: Long): effect.IO[List[Ballot]] = {
    cats.effect.IO(ctx.run(quote {
      querySchema.filter(e => e.lotteryId == lift(lotteryId) && e.userId == lift(userId))
    }))
  }

  def getBallots(lotteryId: Long): effect.IO[List[Ballot]] = {
    cats.effect.IO(ctx.run(quote {
      querySchema.filter(e => e.lotteryId == lift(lotteryId))
    }))
  }

  def addBallot(ballot: Ballot): effect.IO[Long] = {
    cats.effect.IO(ctx.run(quote {
      querySchema.insert(lift(ballot)).returningGenerated(_.id)
    }))
  }
}

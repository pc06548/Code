package repositories

import cats.effect
import config.SqlConnectionManager
import play.api.libs.json.{JsValue, Json}

case class Lottery(id: Long, name: String, startDate: Long, endDate: Long, winner: Option[Long] = None) {
  private implicit val implicitWrites = Json.writes[Lottery]

  def toJson: JsValue = Json.toJson(this)
}

class LotteryRepository extends SqlConnectionManager {

  import ctx._

  val querySchema = quote(query[Lottery])

  def addLottery(lottery: Lottery): effect.IO[Long] = {
    cats.effect.IO(ctx.run(quote {
      querySchema.insert(lift(lottery)).returningGenerated(_.id)
    }))
  }

  def getLotteries(): effect.IO[List[Lottery]] = {
    cats.effect.IO(ctx.run(quote {
      querySchema
    }))
  }

  def getLottery(lotteryId: Long): effect.IO[Option[Lottery]] = {
    cats.effect.IO(ctx.run(quote {
      querySchema.filter(e => e.id == lift(lotteryId))
    })).map(_.headOption)
  }

  def updateWinner(lotteryId: Long, userId: Long): effect.IO[Any] = {
    cats.effect.IO(ctx.run(quote {
      querySchema.filter(p => p.id == lift(lotteryId)).update(_.winner -> lift(Option(userId)))
    }))
  }
}

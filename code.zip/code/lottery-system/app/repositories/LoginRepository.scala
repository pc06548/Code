package repositories

import config.SqlConnectionManager

case class Login(id: Long, userName: String, password: String)

class LoginRepository extends SqlConnectionManager {

  import ctx._

  val querySchema = quote(query[Login])

  def createAndGetLoginId(userName: String, password: String): cats.effect.IO[Long] = {
    cats.effect.IO(ctx.run(quote {
      querySchema.insert(lift(Login(0, userName, password))).returningGenerated(_.id)
    }))
  }


  def validateAndGetLoginId(userName: String, password: String): cats.effect.IO[Option[Long]] = {
    cats.effect.IO(ctx.run(quote {
      querySchema.filter(e => e.userName == lift(userName) && e.password == lift(password))
    }).headOption.map(_.id))
  }
}

package config

import io.getquill.{PostgresJdbcContext, SnakeCase}


trait SqlConnectionManager {

  lazy val ctx = new PostgresJdbcContext(SnakeCase, "ctx")

}
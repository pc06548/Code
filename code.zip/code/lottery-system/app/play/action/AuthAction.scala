package play.action

import com.typesafe.scalalogging.StrictLogging
import play.api.http.HeaderNames
import play.api.mvc._
import services.LoginService

import scala.concurrent.{ExecutionContext, Future}

case class UserRequest[A](request: Request[A], bat: String = "", userId: Long) extends WrappedRequest[A](request)

trait Authorization extends StrictLogging {
  def loginService : LoginService

  def cc: ControllerComponents

  def Authenticate: ActionBuilder[UserRequest, AnyContent] = new ActionBuilder[UserRequest,AnyContent] {
    override protected def executionContext: ExecutionContext = cc.executionContext
    override def parser: BodyParser[AnyContent] = cc.parsers.defaultBodyParser

    // Called when a request is invoked. Validate bearer token for request to proceed
    override def invokeBlock[A](request: Request[A], block: UserRequest[A] => Future[Result]): Future[Result] =
      extractBearerToken(request) map { token => {
        loginService.auth(token) match {
          case Some(userId) => { // token was valid - proceed!
            block(UserRequest(request, token, userId))
          }
          case None => Future.successful(Results.Unauthorized) // token was invalid - return 401
        }
        }
      } getOrElse Future.successful(Results.NotFound)   // no token was sent - return 404
  }

  private def extractBearerToken[A](request: Request[A]): Option[String] =
    request.headers.get(HeaderNames.AUTHORIZATION)
}

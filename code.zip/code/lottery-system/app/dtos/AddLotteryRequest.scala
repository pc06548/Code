package dtos

import java.text.SimpleDateFormat
import java.util.Date

import play.api.libs.json.{JsValue, Json}

import scala.util.Try

case class AddLotteryRequest(name: String, startDate: Long, endDate: Long)

object AddLotteryRequest {
  private implicit val implicitLoginRequestReads = Json.reads[AddLotteryRequest]

  val dateTimeFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")

  def createFromJson(json: JsValue): Option[AddLotteryRequest] = {
    val now = new Date()
    Try {
      val name = (json \ "name").as[String]
      val startDate = dateTimeFormatter.parse((json \ "startDate").as[String])
      val endDate: Date = dateTimeFormatter.parse((json \ "endDate").as[String])
      if (now.after(endDate)) {
        throw new RuntimeException("End time expired already")
      } else
        AddLotteryRequest(name, startDate.getTime, endDate.getTime)
    }.toOption
  }

}

package dtos

import play.api.libs.json.{JsValue, Json}

import scala.util.Try

case class UserLoginUpRequest(userName: String, password: String)

object UserLoginUpRequest {
  private implicit val implicitLoginRequestReads = Json.reads[UserLoginUpRequest]

  def createFromJson(json: JsValue): Option[UserLoginUpRequest] = Try(Some(json.as[UserLoginUpRequest])).getOrElse(None)
}

docker system prune -f
sbt dist
set -x
rm -r artifact
unzip -d artifact target/universal/*.zip
mv artifact/*/* artifact/
rm artifact/bin/*.bat
mv artifact/bin/* artifact/bin/start
docker build -t lottery-system_application .
docker-compose up
# BETest

## Why?

We are interested in your skills as a developer. As part of our assessment, we want to see your code.

## Instructions

In this repo, you'll find two files, Workbook2.csv and Workbook2.prn. These files need to be converted to a HTML format by the code you deliver. Please consider your work as a proof of concept for a system that can keep track of credit limits from several sources.

This repository is created specially for you, so you can push anything you like. Please update this README to provide instructions, notes and/or comments for us.

## The Constraints

Please complete the test within 5 business days. Use either Java, Scala or Kotlin. Use any libs / tools you like.

## Questions?

If you have any questions please send an email to DL-eCG-NL-assessment@ebay.com.

## Finished?

Please send an email to DL-eCG-NL-assessment@ebay.com let us know you're done.

Good Luck!

# SOLUTION

### Technical choices
Scala, Sbt, Play, Akka stream

### Run Instructions - 
Make sure sbt is installed on the machine.

Execute ```sbt run``` from project root. It will start play application.

Sample URL 1 - localhost:9000/credit-limit/Workbook2.csv

Sample URL 2 - localhost:9000/credit-limit/Workbook2.prn

### Description
If the specified file is present in the location path then it will create an Akka stream source from it.

Using this source a chunked response of play framework is returned.

Choices made are to support streaming of large files.

There is no formatting implemented on HTML or even on the data parsing. This decision is taken looking at the problem statement.

Future improvements can be of processing and filtering applied to data.

### Code & Tests
Code is in ```app``` directory. Sources package has a file stream and generic streaming object.

web package has the controller with the endpoint.

Tests are in ```test``` directory and can be executed with ```sbt test``` from root.


Copyright (C) 2001 - 2020 by Marktplaats BV an Ebay company. All rights reserved.

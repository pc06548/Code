package processing

import akka.NotUsed
import akka.stream.scaladsl.Flow
import akka.util.ByteString
import domain.CreditLimit
import org.apache.commons.csv.{CSVFormat, CSVParser}

import scala.collection.JavaConverters._
import scala.util.Try

object CreditLimitFlow {

  def mapBinaryToCreditLimit: Flow[ByteString, List[CreditLimit], NotUsed] =
    Flow[ByteString].map(byteString => {
      val parser = CSVParser.parse(byteString.utf8String, CSVFormat.DEFAULT)
      parser.getRecords.asScala.toList.flatMap(record => {
        Try {
          CreditLimit(record.get(0), record.get(1), record.get(2), record.get(3), record.get(4).toDouble, record.get(5))
        } toOption
      })

    })

  def mapCreditLimitToCsvBinary: Flow[List[CreditLimit], ByteString, NotUsed] =
    Flow[List[CreditLimit]].map(creditLimits => {
      ByteString(creditLimits.map(_.csvString).mkString("\n"))
    })
}

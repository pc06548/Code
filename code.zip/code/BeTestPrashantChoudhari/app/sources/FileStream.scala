package sources

import java.nio.file.{Files, Paths}

import akka.stream.IOResult
import akka.stream.scaladsl.{FileIO, Framing, Source}
import akka.util.ByteString

import scala.concurrent.Future
import scala.util.Try

object FileStream extends Stream[String, ByteString, Future[IOResult]] {

  override def read(filePath: String): Try[Source[ByteString, Future[IOResult]]] = {
    Try {
      val file = Paths.get(filePath)
      if(Files.notExists(file))
        throw new Exception("File does not exists!")
      else
        FileIO.fromPath(file).via(Framing.delimiter(ByteString("\n"), 4000, true))
    }
  }

}

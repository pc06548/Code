package sources

import akka.stream.scaladsl.Source

import scala.util.Try

trait Stream[In, Out, MaterializedValue] {
  def read(input: In): Try[Source[Out, MaterializedValue]]
}
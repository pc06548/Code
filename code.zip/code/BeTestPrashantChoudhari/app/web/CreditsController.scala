package web

import akka.actor.ActorSystem
import akka.stream.ActorMaterializer
import akka.util.Timeout
import javax.inject.Inject
import play.api.mvc.{AbstractController, ControllerComponents}
import sources.FileStream

import scala.concurrent.duration._
import scala.util.{Failure, Success}

class CreditsController @Inject()(controllerComponents: ControllerComponents) extends AbstractController(controllerComponents)  {
  implicit val timeout = Timeout(15 seconds)
  implicit val system = ActorSystem("credits-controller")
  implicit val materializer = ActorMaterializer()

  def getFile(filePath: String) = Action {
    FileStream.read(filePath) match {
      case Success(content) => Ok.chunked(content).as("text/html")
      case Failure(exception) => NotFound(exception.getMessage).as("text/html")
    }
  }

}

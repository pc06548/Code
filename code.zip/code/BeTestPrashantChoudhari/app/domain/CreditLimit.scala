package domain

case class CreditLimit(name: String, address: String, postCode: String, phone: String, creditLimit: Double, birthDay: String) {
  def csvString = s""" "$name", "$address", "$postCode", "$phone", $creditLimit, $birthDay """
}

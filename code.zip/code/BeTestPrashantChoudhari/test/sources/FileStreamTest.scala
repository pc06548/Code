package sources

import org.scalatest.{FunSpec, Matchers}

class FileStreamTest extends FunSpec with Matchers {

  describe("FileStreamTest") {

    it("should return failure when file is not present") {
      FileStream.read("random").isFailure should be(true)
    }

    it("should return source when file is present") {
      FileStream.read("Workbook2.csv").isSuccess should be(true)
    }
  }

}

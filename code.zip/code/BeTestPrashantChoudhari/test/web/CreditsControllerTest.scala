package web

import org.scalatestplus.play.PlaySpec
import org.scalatestplus.play.guice.GuiceOneAppPerSuite
import play.api.inject.guice.GuiceApplicationBuilder
import play.api.mvc.{ControllerComponents, Result}
import play.api.test.Helpers.{status, _}
import play.api.test.{FakeRequest, Injecting}

import scala.concurrent.Future

class CreditsControllerTest extends PlaySpec with Injecting with GuiceOneAppPerSuite {

  implicit lazy override val app: play.api.Application = new GuiceApplicationBuilder().configure().build()
  implicit lazy val materializer = app.materializer

  val controller = new CreditsController(inject[ControllerComponents])
  "CreditsControllerTest" should {

    "should return ok response with file content when it is present" in {
      val resultF: Future[Result] = controller.getFile("Workbook2.csv").apply(FakeRequest())
      assert(status(resultF) == OK)
      assert(contentAsString(resultF) contains  "Name,Address,Postcode,Phone,Credit Limit,Birthday\n\"Johnson, John\",Voorstraat 32,3122gg,020 3849381,10000,01/01/1987\n\"Anderson, Paul\",Dorpsplein 3A,4532 AA,030 3458986,109093,03/12/1965\n\"Wicket, Steve\",Mendelssohnstraat 54d,3423 ba,0313-398475,934,03/06/1964\n\"Benetar, Pat\",Driehoog 3zwart,2340 CC,06-28938945,54,04/09/1964\n\"Gibson, Mal\",Vredenburg 21,3209 DD,06-48958986,54.5,09/11/1978\n\"Friendly, User\",Sint Jansstraat 32,4220 EE,0885-291029,63.6,10/08/1980\n\"Smith, John\",B�rkestra�e 32,87823,+44 728 889838,9898.3,20/09/1999")
    }

    "should return not found response if file is not present" in {
      val resultF: Future[Result] = controller.getFile("Workbook4.csv").apply(FakeRequest())
      assert(status(resultF) == NOT_FOUND)
    }
  }
}

#!/bin/sh
port_val="-Dhttp.port=8080"
randomNumber=$RANDOM
full_name="-DfullName=fullName-$randomNumber"
user_id="-DuserId=userId-$randomNumber"
while getopts "p:f:u:" option; do
  case $option in
    p ) port_number=$OPTARG
    port_val="-Dhttp.port=$port_number"
    ;;
    f ) f_n=$OPTARG
    full_name="-DfullName=$f_n"
    ;;
    u ) u_i=$OPTARG
    user_id="-DuserId=$u_i"
    ;;
  esac
done
echo Starting server on $port_val $full_name $user_id
rm spaceship-1.0.0/RUNNING_PID
./spaceship-1.0.0/bin/spaceship $port_val -Dplay.http.secret.key=5X1vhb0cZHAamkeNwY3NEg=1 $full_name $user_id
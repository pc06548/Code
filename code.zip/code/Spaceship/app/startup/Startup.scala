package startup

import java.net.InetAddress

import akka.actor.{ActorSystem, Props}
import models.{Player, SpaceshipProtocol}
import services.GamePlayActor

object Globals {
  val port = getSystemProperty("http.port").getOrElse("9000").toInt
  val localhost: InetAddress = InetAddress.getLocalHost
  val localIpAddress: String = localhost.getHostAddress

  val fullName = getSystemProperty("fullName").getOrElse("Player-1")
  val userId = getSystemProperty("userId").getOrElse("userId-1")

  private val actorSystem = ActorSystem()
  val SelfPlayer = Player(fullName, userId, SpaceshipProtocol(localIpAddress, port))
  val GameControl = actorSystem.actorOf(Props(new GamePlayActor()), "GamePlayActor")

  private def getSystemProperty(property: String) = {
    Option(System.getProperty(property))
  }
}
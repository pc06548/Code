package models

import scala.collection.mutable.ListBuffer

object Spaceships {

  val Winger0 = ListBuffer(
    ListBuffer('*','.','*'),
    ListBuffer('*','.','*'),
    ListBuffer('.','*','.'),
    ListBuffer('*','.','*'),
    ListBuffer('*','.','*'))

  val Winger90 = ListBuffer(
    ListBuffer('*','*','.','*','*'),
    ListBuffer('.','.','*','.','.'),
    ListBuffer('*','*','.','*','*'))

  val Winger180 = Winger0

  val Winger270 = Winger90

  val Angle0 = ListBuffer(
    ListBuffer('*','.','.'),
    ListBuffer('*','.','.'),
    ListBuffer('*','.','.'),
    ListBuffer('*','*','*'))

  val Angle90 = ListBuffer(
    ListBuffer('*','*','*','*'),
    ListBuffer('*','.','.','.'),
    ListBuffer('*','.','.','.'))

  val Angle180 = ListBuffer(
    ListBuffer('*','*','*'),
    ListBuffer('.','.','*'),
    ListBuffer('.','.','*'),
    ListBuffer('.','.','*'))

  val Angle270 = ListBuffer(
    ListBuffer('*','.','.','.'),
    ListBuffer('*','.','.','.'),
    ListBuffer('*','*','*','*'))


  val AClass0 = ListBuffer(
    ListBuffer('.','*','.'),
    ListBuffer('*','.','*'),
    ListBuffer('*','*','*'),
    ListBuffer('*','.','*'))

  val AClass90 = ListBuffer(
    ListBuffer('*','*','*','.'),
    ListBuffer('.','*','.','*'),
    ListBuffer('*','*','*','.'))

  val AClass180 = ListBuffer(
    ListBuffer('*','.','*'),
    ListBuffer('*','*','*'),
    ListBuffer('*','.','*'),
    ListBuffer('.','*','.'))

  val AClass270 = ListBuffer(
    ListBuffer('.','*','*','*'),
    ListBuffer('*','.','*','.'),
    ListBuffer('.','*','*','*'))

  val BClass0 = ListBuffer(
    ListBuffer('*','*','.'),
    ListBuffer('*','.','*'),
    ListBuffer('*','*','.'),
    ListBuffer('*','.','*'),
    ListBuffer('*','*','.'))

  val BClass90 = ListBuffer(
    ListBuffer('*','*','*','*','*'),
    ListBuffer('*','.','*','.','*'),
    ListBuffer('.','*','.','*','.'))

  val BClass180 = ListBuffer(
    ListBuffer('.','*','*'),
    ListBuffer('*','.','*'),
    ListBuffer('.','*','*'),
    ListBuffer('*','.','*'),
    ListBuffer('.','*','*'))

  val BClass270 = ListBuffer(
    ListBuffer('.','*','.','*','.'),
    ListBuffer('*','.','*','.','*'),
    ListBuffer('*','*','*','*','*'))

  val SClass0 = ListBuffer(
    ListBuffer('.','*','*','.'),
    ListBuffer('*','.','.','.'),
    ListBuffer('.','*','*','.'),
    ListBuffer('.','.','.','*'),
    ListBuffer('.','*','*','.'))

  val SClass90 = ListBuffer(
    ListBuffer('.','.','.','*','.'),
    ListBuffer('*','.','*','.','*'),
    ListBuffer('*','.','*','.','*'),
    ListBuffer('.','*','.','.','.'))

  val SClass180 = SClass0

  val SClass270 = SClass90

}

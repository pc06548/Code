package models

import play.api.libs.json.JsonNaming.SnakeCase
import play.api.libs.json.{JsValue, Json, JsonConfiguration}

import scala.util.Try

case class SpaceshipProtocol(hostname: String, port: Int)

case class Player(fullName: String, userId: String, spaceshipProtocol: SpaceshipProtocol)

object Player {
  implicit val config = JsonConfiguration(SnakeCase)

  private implicit val implicitSpaceShipProtocolReads = Json.reads[SpaceshipProtocol]
  private implicit val implicitPlayerReads = Json.reads[Player]

  def createFromJson(json: JsValue): Option[Player] = Try(Some(json.as[Player])).getOrElse(None)
}
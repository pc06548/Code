package models

import rules.Rules
import startup.Globals._

import scala.collection.mutable.ListBuffer

case class Game(opponent: Player, turnToSet: String = "", rules: Rules) {
  private val SelfGrid = Grid()
  private val OpponentGrid = Grid()
  private var gameFinished = false
  private var Turn = if (turnToSet != "") turnToSet else if(scala.util.Random.nextInt(2) == 0) SelfPlayer.userId else opponent.userId
  private var AutoPilot = false
  private val AutoPilotSalvo = ListBuffer[String]()
  private var GameWonBy: String = ""


  SelfGrid.plot()

  def selfGrid: Grid = SelfGrid.clone()
  def opponentGrid: Grid = OpponentGrid.clone()
  def turn: String = Turn
  def autoPilot: Boolean = AutoPilot
  private def setTurn = Turn = rules.changeTurn(this)
  def isLastSelfShipDestroyed():Boolean = SelfGrid.isLastShipDestroyed()
  def gameWonBy: String = GameWonBy

  def acceptShots(shots: Shots): Either[String, Seq[String]] = {
    val shotsWithIndex: Seq[(Int, Int)] = shots.salvo.flatMap(shot => rules.tryToGetShotInInt(shot))
    if(shotsWithIndex.size != shots.salvo.size) {
      Left("Error parsing shots")
    } else {
      setTurn
      Right(shotsWithIndex.map(rowColumn => {
        val row = rowColumn._1
        val column = rowColumn._2
        SelfGrid.array(row)(column) match {
          case '*' =>
            SelfGrid.array(row)(column) = 'X'
            if (SelfGrid.isShipDestroyed(row, column)) {
              if (SelfGrid.isLastShipDestroyed())
                gameFinished = true
                GameWonBy = opponent.userId
                "kill"
            }
            else "hit"
          case '-' => "miss"
          case 'X' => "miss"
          case '.' =>
            SelfGrid.array(row)(column) = '-'
            "miss"
        }
      }))
    }
  }

  def updateOpponentShots(shotAndResults: scala.collection.immutable.Map[String, String], gameFinishedProp: Boolean = false) {
    if (gameFinishedProp) {
      gameFinished = true
      GameWonBy = SelfPlayer.userId
    }
    setTurn
    shotAndResults.foreach(shotAndResult => {
      val shot = shotAndResult._1
      val result = shotAndResult._2
      val rowColumn = shot.split('x').map(_.trim)
      val row = java.lang.Integer.decode(s"0x${rowColumn(0)}")
      val column = java.lang.Integer.decode(s"0x${rowColumn(1)}")
      if (row < 16 && column < 16) {
        result match {
          case "hit" | "kill" => OpponentGrid.array(row)(column) = 'X'
          case "miss" => OpponentGrid.array(row)(column) = '-'
        }
      }
    })
  }

  def turnAutoPilotOn = {
    this.AutoPilot = true
    setAutoPilotSalvo
  }

  private def setAutoPilotSalvo = {
    this.AutoPilotSalvo ++= ListBuffer("0x0","0x1","0x2","0x3","0x4","0x5","0x6","0x7","0x8","0x9","0xA","0xB","0xC","0xD","0xE","0xF","1x0","1x1","1x2","1x3","1x4","1x5","1x6","1x7","1x8","1x9","1xA","1xB","1xC","1xD","1xE","1xF","2x0","2x1","2x2","2x3","2x4","2x5","2x6","2x7","2x8","2x9","2xA","2xB","2xC","2xD","2xE","2xF","3x0","3x1","3x2","3x3","3x4","3x5","3x6","3x7","3x8","3x9","3xA","3xB","3xC","3xD","3xE","3xF","4x0","4x1","4x2","4x3","4x4","4x5","4x6","4x7","4x8","4x9","4xA","4xB","4xC","4xD","4xE","4xF","5x0","5x1","5x2","5x3","5x4","5x5","5x6","5x7","5x8","5x9","5xA","5xB","5xC","5xD","5xE","5xF","6x0","6x1","6x2","6x3","6x4","6x5","6x6","6x7","6x8","6x9","6xA","6xB","6xC","6xD","6xE","6xF","7x0","7x1","7x2","7x3","7x4","7x5","7x6","7x7","7x8","7x9","7xA","7xB","7xC","7xD","7xE","7xF","8x0","8x1","8x2","8x3","8x4","8x5","8x6","8x7","8x8","8x9","8xA","8xB","8xC","8xD","8xE","8xF","9x0","9x1","9x2","9x3","9x4","9x5","9x6","9x7","9x8","9x9","9xA","9xB","9xC","9xD","9xE","9xF","Ax0","Ax1","Ax2","Ax3","Ax4","Ax5","Ax6","Ax7","Ax8","Ax9","AxA","AxB","AxC","AxD","AxE","AxF","Bx0","Bx1","Bx2","Bx3","Bx4","Bx5","Bx6","Bx7","Bx8","Bx9","BxA","BxB","BxC","BxD","BxE","BxF","Cx0","Cx1","Cx2","Cx3","Cx4","Cx5","Cx6","Cx7","Cx8","Cx9","CxA","CxB","CxC","CxD","CxE","CxF","Dx0","Dx1","Dx2","Dx3","Dx4","Dx5","Dx6","Dx7","Dx8","Dx9","DxA","DxB","DxC","DxD","DxE","DxF","Ex0","Ex1","Ex2","Ex3","Ex4","Ex5","Ex6","Ex7","Ex8","Ex9","ExA","ExB","ExC","ExD","ExE","ExF","Fx0","Fx1","Fx2","Fx3","Fx4","Fx5","Fx6","Fx7","Fx8","Fx9","FxA","FxB","FxC","FxD","FxE","FxF")
  }

  def nextShotsFromAutoPilotSalvo: List[String] = {
    val salvoIndices = getUniqueRandomNumbersWithInRange(rules.maxShotsAllowed, AutoPilotSalvo.length)
    salvoIndices.map(i => AutoPilotSalvo.remove(i))
  }

  /**
    *
    * @param count: is the number of random numbers to return
    * @param range: is the upper limit to consider while producing the random numbers.
    *             e.g. if range = 10, it will create random number between range 0(inclusive) to 10(exclusive).
    * @return list of count number of random numbers within the range (exclusive)
    *         list is sorted in desc order
    *         if range is less than count which means the numbers to produce is more than the range, it will return list of size range.
    *         e.g.: count = 5 and range = 3, output will be List(2,1,0)
    */
  private def getUniqueRandomNumbersWithInRange(count: Int, range: Int): List[Int] = {
    if (range < count)
      getUniqueRandomNumbersR(List.empty, range, range).sorted.reverse
    else
      getUniqueRandomNumbersR(List.empty, count, range).sorted.reverse
  }

  private def getUniqueRandomNumbersR(result: List[Int], count: Int, range: Int): List[Int] = {
    if (count == result.length) result
    else {
      val random = scala.util.Random.nextInt(range)
      getUniqueRandomNumbersR((random :: result).distinct, count, range)
    }
  }

  def isGameFinished= gameFinished
}

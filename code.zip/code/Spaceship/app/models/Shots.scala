package models

import com.typesafe.scalalogging.StrictLogging
import play.api.libs.json.JsonNaming.SnakeCase
import play.api.libs.json.{JsValue, Json, JsonConfiguration}

import scala.util.Try


case class Shots(salvo: List[String]) extends StrictLogging {
  private implicit val implicitShotsWrites = Json.writes[Shots]
  def toJson: JsValue = Json.toJson(this)
}

object Shots {
  implicit val config = JsonConfiguration(SnakeCase)
  private implicit val implicitShotsReads = Json.reads[Shots]

  def createFromJson(json: JsValue): Option[Shots] = {
    Try(Some(json.as[Shots])).getOrElse(None)
  }
}
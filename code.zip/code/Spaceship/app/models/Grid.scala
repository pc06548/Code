package models

import scala.collection.mutable.{ListBuffer, Set}
import Spaceships._
import com.typesafe.scalalogging.StrictLogging

case class Position(row: Int, column: Int, types: String, spaceShip: ListBuffer[ListBuffer[Char]])

case class Grid() extends StrictLogging {

  val array = ListBuffer.empty[ListBuffer[Char]]
  List.range(0,16).map(_ => array += ListBuffer.fill(16)('.'))

  override def clone(): Grid = {
    val grid = Grid()
    List.range(0,16).reverse.map(grid.array.remove(_))
    List.range(0,16).map(i => grid.array += this.array(i))
    List.range(0, positions.length).map(i => grid.positions += this.positions(i))
    grid
  }

  val positions = ListBuffer.empty[Position]

  private var shipsDestroyed = Set.empty[String]

  private val spaceShipsMap = Map(
    "Winger0"-> Winger0, "Winger90"-> Winger90, "Winger180"-> Winger180, "Winger270"-> Winger270,
    "Angle0"-> Angle0, "Angle90"-> Angle90, "Angle180"-> Angle180, "Angle270"-> Angle270,
    "AClass0"-> AClass0, "AClass90"-> AClass90, "AClass180"-> AClass180, "AClass270"-> AClass270,
    "BClass0"-> BClass0, "BClass90"-> BClass90, "BClass180"-> BClass180, "BClass270"-> BClass270,
    "SClass0"-> SClass0, "SClass90"-> SClass90, "SClass180"-> SClass180, "SClass270"-> SClass270)

  def plot() = {
    predictNextR(ListBuffer("Winger", "Angle", "AClass", "BClass", "SClass"))
    logger.info("Plotting success!")
  }

  private def predictNextR(spaceShips: ListBuffer[String]): Unit = {
    val r = scala.util.Random
    if (spaceShips.isEmpty) return
    val rotation = (r.nextInt(4)*90).toString
    val spaceShipClass = spaceShips(r.nextInt(spaceShips.length))
    val spaceShip = spaceShipsMap(spaceShipClass+rotation)
    val rowLength = spaceShip.size
    val columnLength = spaceShip.head.size
    val row = r.nextInt(16 - rowLength)

    val columnList = List.range(0, 16 - columnLength).filter(columnIndex => {
      !(for {
        r <- List.range(row, row + rowLength)
        c <- List.range(columnIndex, columnIndex + columnLength)
      } yield {
        array(r)(c) == '.'
      }).exists(!_)
    })

    if (columnList.nonEmpty) {
      val column = columnList.slice(r.nextInt(columnList.size), columnList.size).headOption
      for {
        r <- List.range(row, row + rowLength)
        c <- List.range(column.get, column.get + columnLength)
      } yield {
        array(r)(c) = spaceShip(r-row)(c-column.get)
      }
      positions += Position(row, column.get, spaceShipClass+rotation, spaceShip)
      predictNextR(spaceShips - spaceShipClass)
    } else {
      println("Failed to plot: "+spaceShipClass+rotation+" at row: "+row+". Going for re-attempt")
      predictNextR(spaceShips)
    }
  }

  def getListStringRepresentation():List[String] = {
    array.toList.map(_.toList.mkString(""))
  }

  def isShipDestroyed(row: Int, column: Int): Boolean = {
    positions.map(position => {
      // check if this point is on this spaceship
      if(position.row <= row && row < position.row + position.spaceShip.size && position.column <= column && column < position.column + position.spaceShip.head.size && position.spaceShip(row - position.row)(column - position.column) == '*') {
        // if yes check if the ship is destroyed
        if(isShipDestroyedR(0, 0, position)){
          logger.info(s"Ship destroyed by attack at: ${row}:${column}. Ship: ${position}. Number of ships destroyed so far: ${shipsDestroyed.size}")
          return true
        }
      }
    })
    false
  }

  private def isShipDestroyedR(rowI: Int, colI:Int, position: Position): Boolean = {
    if (position.spaceShip(rowI)(colI) == '*' && array(position.row + rowI)(position.column + colI) != 'X') false
    else if(colI < position.spaceShip.head.size - 1) isShipDestroyedR(rowI, colI + 1, position)
    else if(rowI < position.spaceShip.size - 1) isShipDestroyedR(rowI + 1, 0, position)
    else {
      shipsDestroyed += position.types
      true
    }
  }

  def isLastShipDestroyed() = shipsDestroyed.size == 5
}
package rules

import models.{Game, Shots}

import scala.util.Try

trait Rules {
  def changeTurn(game: Game): String
  val maxShotsAllowed: Int
  def isShotsValid(shots: Shots): Boolean

  def tryToGetShotInInt(shot: String):Option[(Int, Int)] = {
    val rowColumn = shot.split('x').map(_.trim)
    if(rowColumn.size == 2) {
      Try {
        val row = java.lang.Integer.decode(s"0x${rowColumn(0)}")
        val column = java.lang.Integer.decode(s"0x${rowColumn(1)}")
        if (row < 16 && column < 16) {
          Some((row.toInt, column.toInt))
        } else None
      }.getOrElse(None)
    } else None
  }
}

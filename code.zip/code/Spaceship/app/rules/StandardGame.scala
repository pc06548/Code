package rules
import models.{Game, Shots}
import startup.Globals.SelfPlayer

case class StandardGame() extends Rules {
  override def changeTurn(game: Game): String = if (game.turn == game.opponent.userId) SelfPlayer.userId else game.opponent.userId

  override val maxShotsAllowed: Int = 5

  override def isShotsValid(shots: Shots): Boolean = {
    shots.salvo.size <= maxShotsAllowed && !shots.salvo.exists(shot => !tryToGetShotInInt(shot).isDefined)
  }
}

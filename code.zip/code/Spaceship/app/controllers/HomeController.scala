package controllers

import akka.pattern.ask
import akka.util.Timeout
import javax.inject.{Inject, Singleton}
import models.Game
import play.api.mvc.{AbstractController, ControllerComponents}
import services.GetGamesAction
import startup.Globals._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._

@Singleton
class HomeController @Inject()(controllerComponents: ControllerComponents) extends AbstractController(controllerComponents) {
  implicit val timeout = Timeout(15 seconds)

  def index = Action.async {
    (ask(GameControl, GetGamesAction).mapTo[Map[String, Game]]).map(games => Ok(views.html.home(games.keySet.toList, SelfPlayer)))
  }
}
package controllers

import akka.pattern.ask
import akka.util.Timeout
import javax.inject.Inject
import models.Game
import play.api.mvc.{AbstractController, ControllerComponents}
import services.GetGameAction
import startup.Globals._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.concurrent.duration._

class VisualController @Inject()(controllerComponents: ControllerComponents) extends AbstractController(controllerComponents) {
  implicit val timeout = Timeout(5 seconds)

  def viewGame(gameId: String) = Action(parse.anyContent).async {
    val gameF: Future[Option[Game]] = ask(GameControl, GetGameAction(gameId)).mapTo[Option[Game]]
    gameF.map(gameO => {
      gameO match {
        case Some(game) => {
          Ok(views.html.game(gameId, game, SelfPlayer))
        }
        case None => {
          NotFound(s"Game not found for gameId: ${gameId}")
        }
      }
    }).recover { case t => {
      println(t)
      InternalServerError("Something went wrong")
    }
    }
  }
}
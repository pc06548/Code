package controllers

import akka.pattern.ask
import akka.util.Timeout
import com.typesafe.scalalogging.StrictLogging
import javax.inject.Inject
import models.{Player, Shots}
import play.api.libs.json.JsonNaming.SnakeCase
import play.api.libs.json.{JsValue, Json, JsonConfiguration}
import play.api.libs.ws.WSClient
import play.api.mvc._
import services.{AcceptShotsAction, AcceptShotsActionResponse, NewGameAcceptAction, NewGameAcceptActionResponse}
import startup.Globals._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.concurrent.duration._

class ProtocolController @Inject()(controllerComponents: ControllerComponents, ws: WSClient) extends AbstractController(controllerComponents) with StrictLogging {
  implicit val timeout = Timeout(15 seconds)

  def newGame() = Action(parse.anyContent).async {
    logger.info(s"Request received newGame")
    request:Request[AnyContent] => {
      for {
        json <- request.body.asJson
        opponent <- Player.createFromJson(json)
      } yield {
        if(opponent.userId == SelfPlayer.userId) {
          logger.error("Opponent and self user id can not be same")
          Future.successful(BadRequest("Bad Request"))
        } else {
          val gameIdAndTurnF: Future[NewGameAcceptActionResponse] = ask(GameControl, NewGameAcceptAction(opponent)).mapTo[NewGameAcceptActionResponse]
          gameIdAndTurnF.map(gameIdAndTurn => {
            val response = NewGameResponse(SelfPlayer.userId, SelfPlayer.fullName, gameIdAndTurn.gameId, gameIdAndTurn.turn)
            Ok(response.toJson)
          }).recover { case t => {
            println(t)
            InternalServerError("Something went wrong")
          }
          }
        }
      }
    }.getOrElse(Future.successful(BadRequest("Bad Request")))
  }

  def acceptShot(gameId: String) = Action(parse.anyContent).async {
    logger.info(s"Request received acceptShot for gameId: ${gameId}")
    request:Request[AnyContent] => {
      for {
        json <- request.body.asJson
        shots <- Shots.createFromJson(json)
      } yield {
        val shotResultAndTurnOrWonF: Future[AcceptShotsActionResponse] = ask(GameControl, AcceptShotsAction(gameId, shots, ws)).mapTo[AcceptShotsActionResponse]

        shotResultAndTurnOrWonF.map(prepareAcceptShotResponse(_, shots))
          .recover { case t => {
            logger.error("Error in acceptShot: ", t)
            InternalServerError("Something went wrong")
          }
        }
      }
    }.getOrElse({
      logger.error("Error in request body: ", request.body)
      Future.successful(BadRequest("Bad Request with wrong body"))
    })
  }

  def prepareAcceptShotResponse(shotResultAndTurnOrWon: AcceptShotsActionResponse, shots: Shots): Result = {
    shotResultAndTurnOrWon match {
      case AcceptShotsActionResponse(Right(shotsResult), Left(turn)) => {
        logger.info("Sending acceptShot response with turn")
        Ok(AcceptShotResponse(shots.salvo, shotsResult, turn).toJson)
      }
      case AcceptShotsActionResponse(Right(shotsResult), Right(won)) => {
        logger.info("Sending acceptShot response with who won")
        Ok(AcceptShotResponse(shots.salvo, shotsResult, won, true).toJson)
      }
      case AcceptShotsActionResponse(Left(msg), _) if (msg == "Game Over") => NotFound(msg)
      case AcceptShotsActionResponse(Left(msg), _) => BadRequest(msg)
    }
  }
}

case class NewGameResponse(userId: String, fullName: String, gameId: String, starting: String) {
  implicit val config = JsonConfiguration(SnakeCase)
  private implicit val implicitNewGameResponseWrites = Json.writes[NewGameResponse]

  def toJson: JsValue = Json.toJson(this)
}


case class AcceptShotResponse(shots: Seq[String], shotResults: Seq[String], turn: String, won: Boolean = false) {
  implicit val config = JsonConfiguration(SnakeCase)

  def toJson: JsValue = {
    val shotResultJsonString = ((shots zip shotResults).map{case (shot, result) => s""" "${shot}":"${result}" """}).mkString(",")
    val turnOrWonJsonString = if (won) s""" "won": "${turn}" """ else s""" "player_turn": "${turn}" """
    Json.parse(
      s"""
        |{ "salvo": { ${shotResultJsonString} }, "game": { $turnOrWonJsonString } }
    """.stripMargin)
  }
}
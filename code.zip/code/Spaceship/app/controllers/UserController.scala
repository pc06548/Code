package controllers

import akka.pattern.ask
import akka.util.Timeout
import com.typesafe.scalalogging.StrictLogging
import javax.inject.Inject
import models.{Game, Shots, SpaceshipProtocol}
import play.api.libs.json.JsonNaming.SnakeCase
import play.api.libs.json.{JsValue, Json, JsonConfiguration}
import play.api.libs.ws.WSClient
import play.api.mvc.{AbstractController, AnyContent, ControllerComponents, Request}
import services._
import startup.Globals._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.concurrent.duration._
import scala.util.Try

class UserController @Inject()(controllerComponents: ControllerComponents, ws: WSClient) extends AbstractController(controllerComponents) with StrictLogging {
  implicit val timeout = Timeout(15 seconds)

  def challengeForNewGame() = Action(parse.anyContent).async {
    logger.info(s"Request received challengeForNewGame")
    request:Request[AnyContent] => {
      for {
        json <- request.body.asJson
        newGameReq <- NewGameRequest.createFromJson(json)
      } yield {
        if(newGameReq.spaceshipProtocol.port == port && (newGameReq.spaceshipProtocol.hostname == "localhost" || newGameReq.spaceshipProtocol.hostname == localIpAddress)) {
          logger.error(s"Can not challenge to self")
          Future.successful(BadRequest("Invalid input"))
        } else {
          val responseF: Future[NewGameRequestActionResponse] = ask(GameControl, NewGameRequestAction(newGameReq, ws)).mapTo[NewGameRequestActionResponse]
          responseF.map(response => {
            response.eitherJsValueOrError match {
              case Right(result) => SeeOther(s"/xl-spaceship/user/game/${(result \ "game_id").as[String]}")
              case Left(msg) => InternalServerError(msg)
            }
          }).recover { case t => {
            logger.error("Error: ", t)
            InternalServerError("Something went wrong")
          }
          }
        }
      }
    }.getOrElse {
      logger.error("Received body: ", request.body.asText)
      Future.successful(BadRequest("Bad Request"))
    }
  }

  def fireShot(gameId: String) = Action(parse.anyContent).async {
    logger.info(s"Request received fireShot for gameId: ${gameId}")
    request:Request[AnyContent] => {
      for {
        json <- request.body.asJson
        shots <- Shots.createFromJson(json)
      } yield {
        val responseF: Future[FireShotsActionResponse] = ask(GameControl, FireShotsAction(gameId, shots, ws)).mapTo[FireShotsActionResponse]
        responseF.map(response => {
          response.eitherJsValueOrError match {
            case Right(shotsResult) => Ok(shotsResult)
            case Left(msg) if msg == "Game Over" => NotFound(msg)
            case Left(msg) if msg == "Invalid Shots" => {
              logger.error(s"Invalid input received: ${request.body.asText}")
              BadRequest(msg)
            }
            case Left(msg) => InternalServerError(msg)
          }
        }).recover { case t => {
          logger.error("Error: ", t)
          InternalServerError("Something went wrong")
        }
        }
      }
    }.getOrElse(Future.successful(BadRequest("Invalid input")))
  }

  def viewGameStatus(gameId: String) = Action(parse.anyContent).async {
    logger.info(s"Request received viewGameStatus for gameId: ${gameId}")
    val gameF: Future[Option[Game]] = ask(GameControl, GetGameAction(gameId)).mapTo[Option[Game]]
    gameF.map(gameO => {
      gameO match {
        case Some(game) => {
          val response = GetGameResponse(UserIdAndBoard(SelfPlayer.userId, game.selfGrid.getListStringRepresentation),
            UserIdAndBoard(game.opponent.userId, game.opponentGrid.getListStringRepresentation()),
            PlayerTurn(game.turn))
          Ok(response.toJson)
        }
        case None => {
          NotFound(s"Game not found for gameId: ${gameId}")
        }
      }
    }).recover { case t => {
      logger.error("Error: ", t)
      InternalServerError("Something went wrong")
    }
    }
  }

  def autoPilot(gameId: String) = Action(parse.anyContent).async {
    logger.info(s"Request received auto pilot for gameId: ${gameId}")
    val responseF: Future[SetAutoPilotModeOnActionResponse] = ask(GameControl, SetAutoPilotModeOnAction(gameId)).mapTo[SetAutoPilotModeOnActionResponse]
    responseF.map(response => {
      response.failureOrSuccess match {
        case Right(()) =>
          Ok("Auto Pilot Turned On")
        case Left(_) => {
          NotFound(s"Game not found for gameId: ${gameId}")
        }
      }
    }).recover { case t => {
      logger.error("Error: ", t)
      InternalServerError("Something went wrong")
    }
    }
  }
}

case class UserIdAndBoard(userId: String, board: List[String])
case class PlayerTurn(playerTurn: String)
case class GetGameResponse(self: UserIdAndBoard, opponent: UserIdAndBoard, game: PlayerTurn) {
  implicit val config = JsonConfiguration(SnakeCase)
  private implicit val implicitUserIdAndBoardWrites = Json.writes[UserIdAndBoard]
  private implicit val implicitPlayerTurnWrites = Json.writes[PlayerTurn]
  private implicit val implicitGetGameResponseWrites = Json.writes[GetGameResponse]

  def toJson: JsValue = Json.toJson(this)
}

case class NewGameRequest(spaceshipProtocol: SpaceshipProtocol, rules: String)


object NewGameRequest {
  implicit val config = JsonConfiguration(SnakeCase)
  private implicit val implicitSpaceshipProtocolReads = Json.reads[SpaceshipProtocol]
  private implicit val implicitNewGameRequestReads = Json.reads[NewGameRequest]

  def createFromJson(json: JsValue): Option[NewGameRequest] = Try(Some(json.as[NewGameRequest])).getOrElse(None)
}
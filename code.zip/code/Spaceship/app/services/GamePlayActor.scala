package services

import akka.actor.Actor
import com.typesafe.scalalogging.StrictLogging
import controllers.NewGameRequest
import models.{Game, Player, Shots}
import play.api.libs.json.{JsValue, Json}
import play.api.libs.ws.{WSClient, WSResponse}
import rules.StandardGame
import startup.Globals._

import scala.collection.mutable.Map
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class GamePlayActor() extends Actor with StrictLogging {

  private val games = Map.empty[String, Game]

  private val nextRandomGameId = scala.util.Random

  override def receive: Receive = {

    case NewGameRequestAction(newGameRequest, ws) => {
      val senderParent = sender
      val responseF = sendNewGameRequest(newGameRequest, ws)
      responseF.map(response => {
        logger.info("New game response received!")
        if (response.status == 200) {
          val responseJson = response.json
          val gameId = (responseJson \ "game_id").as[String]
          if(games.contains(gameId)) {
            logger.error(s"$gameId already exists! Can not accept the new game with same GameId")
            senderParent ! NewGameRequestActionResponse(Left(s"$gameId already exists! Can not accept the new game with same GameId"))
          } else {
            val opponent = Player((responseJson \ "full_name").as[String], (responseJson \ "user_id").as[String], newGameRequest.spaceshipProtocol)
            val newGame = Game(opponent, (responseJson \ "starting").as[String], StandardGame())
            games.put(gameId, newGame)
            logger.info(s"Game created on self end also with game-id ${gameId}")
            senderParent ! NewGameRequestActionResponse(Right(response.json))
          }
        } else {
          senderParent ! NewGameRequestActionResponse(Left("Something went wrong: "+response.body))
        }
      })
    }

    case NewGameAcceptAction(opponent) => {
      val gameId = s"match-${nextRandomGameId.nextInt(1000000)}"
      val newGame = Game(opponent =  opponent, rules = StandardGame())
      games.put(gameId, newGame)
      sender ! NewGameAcceptActionResponse(gameId, newGame.turn)
    }

    case GetGamesAction =>
      sender ! games.toMap

    case GetGameAction(gameId) =>
      sender ! games.get(gameId)

    case FireShotsAction(gameId, shots, ws) => {
      games.get(gameId).map(game => {
        if(!game.rules.isShotsValid(shots)) {
          sender ! Left("Invalid Shots")
        }
        if(game.isGameFinished) {
          sender ! Left("Game Over")
        } else if(game.turn != SelfPlayer.userId) {
          logger.error(s"Its ${game.turn}'s turn")
          sender ! FireShotsActionResponse(Left("Not your turn"))
        } else {
          val senderA = sender
          sendAcceptShotsRequest(gameId, game, shots, ws).map(response => {
            if (response.status == 200) {
              val shotsAndResult = (response.json \ "salvo").as[scala.collection.immutable.Map[String, String]]
              val isGameFinished = (response.json \ "game" \ "won").asOpt[String].map(_ => true).getOrElse(false)
              game.updateOpponentShots(shotsAndResult, isGameFinished)
              logger.info(s"Received response and updated opponents grid in self, isGameFinished: "+ isGameFinished)
              senderA ! FireShotsActionResponse(Right(response.json))
            } else {
              senderA ! FireShotsActionResponse(Left("Something went wrong: " + response.body))
            }
          })
        }
      })
    }


    case AcceptShotsAction(gameId, shots, ws) => {
      games.get(gameId).map(game => {
        if(!game.rules.isShotsValid(shots)) {
          sender ! AcceptShotsActionResponse(Left("Invalid Shots"), Left(game.turn))
        }
        if(game.isGameFinished) {
          sender ! AcceptShotsActionResponse(Left("Game Over"), Left(game.turn))
        }
        else if (game.turn == game.opponent.userId) {
          val shotResult = game.acceptShots(shots)
          logger.info("Shots accepted and updated successfully. ShotResult: " + shotResult + ". isLastShipDestroyed: "+ game.isLastSelfShipDestroyed)
          if(shotResult.isRight) {
            if (game.isLastSelfShipDestroyed)
              sender ! AcceptShotsActionResponse(Right(shotResult.right.get), Right(game.opponent.userId))
            else {
              sender ! AcceptShotsActionResponse(Right(shotResult.right.get), Left(game.turn))
              // if autopilot mode is on then it will attempt to fire a shot
              handleAutoPilotMode(gameId, game, ws)
            }
          } else  {
            AcceptShotsActionResponse(Left(shotResult.left.get), Left(game.turn))
          }
        } else {
          sender ! AcceptShotsActionResponse(Left("Not your turn"), Left(game.turn))
        }
      }).getOrElse(sender ! AcceptShotsActionResponse(Left(s"No game with ${gameId}"), Left("")))
    }

    case SetAutoPilotModeOnAction(gameId) => {
      games.get(gameId).map(game => {
        game.turnAutoPilotOn
        sender ! SetAutoPilotModeOnActionResponse(Right())
      }).getOrElse(sender ! SetAutoPilotModeOnActionResponse(Left(s"No game with ${gameId}")))
    }

    case _ => println("Bad command")
  }

  private def sendNewGameRequest(newGameRequest: NewGameRequest, ws: WSClient): Future[WSResponse] = {
    val request = ws.url(s"http://${newGameRequest.spaceshipProtocol.hostname}:${newGameRequest.spaceshipProtocol.port}/xl-spaceship/protocol/game/new")
    logger.info("Sending new game request: "+request.url)
    val json = Json.parse(
      s"""
         |{
         |"user_id": "${SelfPlayer.userId}", "full_name": "${SelfPlayer.fullName}", "spaceship_protocol": {
         |"hostname": "${SelfPlayer.spaceshipProtocol.hostname}",
         |"port": ${SelfPlayer.spaceshipProtocol.port} }
         |}
        """.stripMargin)

    request.addHttpHeaders("Accept" -> "application/json")
      .addHttpHeaders("Content-Type" -> "application/json")
      .post(json)
  }

  private def sendAcceptShotsRequest(gameId: String, game: Game, shots: Shots, ws: WSClient): Future[WSResponse] = {
    val request = ws.url(s"http://${game.opponent.spaceshipProtocol.hostname}:${game.opponent.spaceshipProtocol.port}/xl-spaceship/protocol/game/$gameId")
    logger.info("Sending accept shot request: " + request.url)
    request.addHttpHeaders("Accept" -> "application/json")
      .addHttpHeaders("Content-Type" -> "application/json")
      .post(shots.toJson)
  }

  // this is called in case of auto pilot
  private def sendFireShotRequest(gameId: String, shots: Shots, ws: WSClient): Future[WSResponse] = {
    val request = ws.url(s"http://${SelfPlayer.spaceshipProtocol.hostname}:${SelfPlayer.spaceshipProtocol.port}/xl-spaceship/user/game/$gameId/fire")
    logger.info("Sending fire shot request: " + request.url)
    request.addHttpHeaders("Accept" -> "application/json")
      .addHttpHeaders("Content-Type" -> "application/json")
      .post(shots.toJson)
  }

  private def handleAutoPilotMode(gameId: String, game: Game, ws: WSClient) = {
    if (game.autoPilot) {
      sendFireShotRequest(gameId, Shots(game.nextShotsFromAutoPilotSalvo), ws)
    }
  }
}

object GetGamesAction
case class GetGameAction(gameId: String)

case class NewGameAcceptAction(opponent: Player)
case class NewGameAcceptActionResponse(gameId: String, turn: String)

case class NewGameRequestAction(newGameRequest: NewGameRequest, ws: WSClient)

/**
  *
  * @param eitherJsValueOrError: Either: Left - Error or Right - Response JsValue from accept new game response from other player
  */
case class NewGameRequestActionResponse(eitherJsValueOrError: Either[String, JsValue])

case class AcceptShotsAction(gameId: String, shots: Shots, ws: WSClient)

/**
  *
  * @param shotsResult: Either: Left - Error or Right - Response JsValue of shots response as miss or kill or hit
  * @param turnOrWon: Either: Left - Based on shotsResult param's left, it returns left information of whose turn it is
  *                 Right - It also returns turn only when the game is over.
  */
case class AcceptShotsActionResponse(shotsResult: Either[String, Seq[String]], turnOrWon: Either[String, String])

case class FireShotsAction(gameId: String, shots: Shots, ws: WSClient)

/**
  *
  * @param eitherJsValueOrError: Either: Left - Error when fails to fire a shot. Right - shot result as JsValue containing whose turn or if the game is over
  */
case class FireShotsActionResponse(eitherJsValueOrError: Either[String, JsValue])

case class SetAutoPilotModeOnAction(gameId: String)
case class SetAutoPilotModeOnActionResponse(failureOrSuccess: Either[String, Unit])
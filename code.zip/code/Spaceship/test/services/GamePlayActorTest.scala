package services

import akka.actor.{ActorSystem, Props}
import akka.pattern.ask
import akka.testkit.{TestActorRef, TestKit}
import akka.util.Timeout
import controllers.NewGameRequest
import models.{Game, Player, Shots, SpaceshipProtocol}
import org.mockito.Mockito.when
import org.mockito.{ArgumentCaptor, ArgumentMatchers, Mockito}
import org.scalatest.{AsyncWordSpecLike, BeforeAndAfterEach}
import org.scalatestplus.mockito.MockitoSugar
import play.api.libs.json.{JsValue, Json}
import play.api.libs.ws.{WSClient, WSRequest, WSResponse}

import scala.concurrent.Future
import startup.Globals._

import scala.concurrent.duration._


class GamePlayActorTest extends TestKit(ActorSystem("MySpec")) with MockitoSugar with AsyncWordSpecLike with BeforeAndAfterEach {
  implicit val timeout = Timeout(5 seconds)
  val wsClientMock = mock[WSClient]
  val props = Props.create(classOf[GamePlayActor])
  val gamePlayActorRef = TestActorRef.create(system, props,"GamePlayActor1")

  override protected def beforeEach(): Unit = {
    Mockito.reset(wsClientMock)
  }
  "GamePlayActor" should {

    "send request of accept new game on receiving NewGameRequestAction message and create game on self and test FireShotsAction message and update opponent grid" in {
      val newGameRequest = NewGameRequest(SpaceshipProtocol("127.0.0.1", 9001), "Standard")
      val requestMock = mock[WSRequest]
      val responseMock = mock[WSResponse]

      // test new game request action
      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.addHttpHeaders(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.post[JsValue](Json.parse(s"""{
                                                  |"user_id": "${SelfPlayer.userId}", "full_name": "${SelfPlayer.fullName}", "spaceship_protocol": {
                                                  |"hostname": "${SelfPlayer.spaceshipProtocol.hostname}",
                                                  |"port": ${SelfPlayer.spaceshipProtocol.port} }
                                                  |}""".stripMargin))).thenReturn(Future.successful(responseMock))
      when(responseMock.json).thenReturn(Json.parse(s"""{
                                                      |"user_id": "xebialabs-1",
                                                      |"full_name": "Assessment Player", "game_id": "match-1",
                                                      |"starting": "${SelfPlayer.userId}"
                                                      |}""".stripMargin))
      when(responseMock.status).thenReturn(200)

      val newGame = NewGameRequestAction(newGameRequest, wsClientMock)
      ask(gamePlayActorRef, GetGamesAction).mapTo[Map[String, Game]].map(games => {
        assert(games.size == 0)
      })
      ask(gamePlayActorRef, newGame).flatMap(_ => {
        ask(gamePlayActorRef, GetGamesAction).mapTo[Map[String, Game]].map(games => {
          assert(games.size == 1)
          assert(games.contains("match-1") == true)
        })
        // test fire shot
        when(requestMock.post[JsValue](Json.parse(s"""{
                                                     |"salvo": ["0x0"]
                                                     |}""".stripMargin))).thenReturn(Future.successful(responseMock))
        when(responseMock.json).thenReturn(Json.parse(s"""{
                                                         |"salvo": {
                                                         |"0x0": "hit"},
                                                         |"game": {
                                                         |"player_turn": "player-1" }
                                                         |}""".stripMargin))
        when(responseMock.status).thenReturn(200)

        val fireShotAction = FireShotsAction("match-1", Shots(List("0x0")), wsClientMock)

        ask(gamePlayActorRef, fireShotAction).flatMap(_ => {
          ask(gamePlayActorRef, GetGamesAction).mapTo[Map[String, Game]].map(games => {
            assert(games.head._2.opponentGrid.array.head.head == 'X')
          })
        })
      })
    }

    "create new game on receiving NewGameAcceptAction message and test accept shots and update self grid on receiving AcceptShotsAction message" in {
      val newGame = NewGameAcceptAction(Player("fullName", "userId", SpaceshipProtocol("hostName", 3000)))
      ask(gamePlayActorRef, GetGamesAction).mapTo[Map[String, Game]].map(games => {
        assert(games.size == 1)
      })
      gamePlayActorRef ! newGame
      ask(gamePlayActorRef, GetGamesAction).mapTo[Map[String, Game]].flatMap(games => {
        assert(games.size == 2)

        val acceptShotsAction = AcceptShotsAction(games.keys.last, Shots(List("0x0")), wsClientMock)
        ask(gamePlayActorRef, acceptShotsAction).mapTo[AcceptShotsActionResponse].map(acceptShotsActionResponse => {
          // this assertion is about possible three values either a hit or miss or not your turn
          assert((acceptShotsActionResponse == AcceptShotsActionResponse(Right(List("miss")), Left("userId-1"))) || (acceptShotsActionResponse == AcceptShotsActionResponse(Right(List("hit")), Left("userId-1"))) || (acceptShotsActionResponse == AcceptShotsActionResponse(Left("Not your turn"),Left("userId-1"))))
        })
      })
    }

    "set auto pilot mode for game on receiving SetAutoPilotModeOnAction message" in {
      ask(gamePlayActorRef, GetGamesAction).mapTo[Map[String, Game]].flatMap(games => {
        assert(games.size == 2)
        assert(!games.head._2.autoPilot)

        val setAutoPilotModeOnAction = SetAutoPilotModeOnAction(games.head._1)
        ask(gamePlayActorRef, setAutoPilotModeOnAction).mapTo[SetAutoPilotModeOnActionResponse].map(autoPilotModeOnActionResponse => {
          assert(autoPilotModeOnActionResponse.failureOrSuccess.isRight)
          assert(games.head._2.autoPilot)
        })
      })
    }

    "return error with game id not found while setting auto pilot mode for non existing game id on receiving SetAutoPilotModeOnAction message" in {
      val setAutoPilotModeOnAction = SetAutoPilotModeOnAction("invalid_game_id")
      ask(gamePlayActorRef, setAutoPilotModeOnAction).mapTo[SetAutoPilotModeOnActionResponse].map(autoPilotModeOnActionResponse => {
        assert(autoPilotModeOnActionResponse.failureOrSuccess.isLeft)
        assert(autoPilotModeOnActionResponse.failureOrSuccess.left.get == "No game with invalid_game_id")
      })
    }
  }
}

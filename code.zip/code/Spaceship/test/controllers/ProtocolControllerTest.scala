package controllers

import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import play.api.libs.json.Json
import play.api.libs.ws.WSClient
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers._

import scala.concurrent.Future

class ProtocolControllerTest extends PlaySpec with MockitoSugar {
  val wsClientMock = mock[WSClient]

  val controller = new ProtocolController(stubControllerComponents(), wsClientMock)
  var gameId = ""
  "ProtocolControllerTest" should {

    "return ok with new game id" in {
      val resultF: Future[Result] = controller.newGame().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{
          |"user_id": "xebialabs-1", "full_name": "XebiaLabs Opponent", "spaceship_protocol": {
          |"hostname": "127.0.0.1",
          |"port": 9001 }
          |}
          |""".stripMargin)))
      assert(status(resultF) == OK)
      gameId = (Json.parse(contentAsString(resultF)) \ "game_id").as[String]
      assert(contentAsString(resultF) contains  """{"user_id":"userId-1","full_name":"Player-1","game_id":"match""")
      assert(contentAsString(resultF) contains  """","starting":"""")
    }

    "return bad request with wrong request" in {
      val resultF: Future[Result] = controller.newGame().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{
          |"user_id": "xebialabs-1", "full_name": "XebiaLabs Opponent", "spaceship_protocol": {
          |"hostname": "127.0.0.1"}
          |}
          |""".stripMargin)))
      assert(status(resultF) == BAD_REQUEST)
      assert(contentAsString(resultF) contains  "Bad Request")
    }

    "return response of a accept shot" in {
      val resultF: Future[Result] = controller.acceptShot(gameId).apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{
          |"salvo": ["0x0", "8x4", "DxA", "AxA", "7xF"]
          |}
          |""".stripMargin)))
      if(status(resultF) == BAD_REQUEST)
        assert(contentAsString(resultF) contains  "Not your turn")
      else assert(status(resultF) == OK)
    }

    "return bad request as response of accept shot with wrong body" in {
      val resultF: Future[Result] = controller.acceptShot(gameId).apply(FakeRequest().withJsonBody(Json.parse(
        """{}""".stripMargin)))
      assert(status(resultF) == BAD_REQUEST)
      assert(contentAsString(resultF) contains  "Bad Request")
    }

    "return response of a fire shot with who won" in {
      val resultF: Future[Result] = controller.acceptShot(gameId).apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{
          | "salvo": ["0x0", "8x4", "DxA", "AxA", "7xF"]
          |}
          |""".stripMargin)))
      if(status(resultF) == BAD_REQUEST)
        assert(contentAsString(resultF) contains  "Not your turn")
      else assert(status(resultF) == OK)
    }
  }
}
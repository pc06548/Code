package controllers

import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers._

import scala.concurrent.Future

class HomeControllerTest extends PlaySpec with MockitoSugar {

  val controller = new HomeController(stubControllerComponents())

  "HomeControllerTest" should {

    "should return ok response for index" in {
      val resultF: Future[Result] = controller.index().apply(FakeRequest())
      assert(status(resultF) == OK)
    }
  }
}
package controllers

import org.scalatest.BeforeAndAfterAll
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import play.api.libs.json.Json
import play.api.libs.ws.WSClient
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers._

import scala.concurrent.Future

class UserControllerTest extends PlaySpec with MockitoSugar with BeforeAndAfterAll {

  val wsClientMock = mock[WSClient]

  val controller = new UserController(stubControllerComponents(), wsClientMock)
  var gameId = ""

  override protected def beforeAll(): Unit = {
    setup()
  }

  "UserControllerTest" should {

    "should return ok with game status" in {
      val resultF: Future[Result] = controller.viewGameStatus(gameId).apply(FakeRequest())
      assert(status(resultF) == OK)
      assert(contentAsString(resultF) contains  """{"self":{"user_id":"userId-1","board":[""")
      assert(contentAsString(resultF) contains  ""","opponent":{"user_id":"xebialabs-1","board":["""")
      assert(contentAsString(resultF) contains  """]},"game":{"player_turn":"""")
    }

    "should return not found with game status" in {
      val resultF: Future[Result] = controller.viewGameStatus("match-2").apply(FakeRequest())
      assert(status(resultF) == NOT_FOUND)
      assert(contentAsString(resultF) contains  "Game not found for gameId: match-2")
    }
  }

  def setup() = {
    // create a game
    val controller = new ProtocolController(stubControllerComponents(), wsClientMock)
    val resultF: Future[Result] = controller.newGame().apply(FakeRequest().withJsonBody(Json.parse(
      """
        |{
        |"user_id": "xebialabs-1", "full_name": "XebiaLabs Opponent", "spaceship_protocol": {
        |"hostname": "127.0.0.1",
        |"port": 9001 }
        |}
        |""".stripMargin)))
    assert(status(resultF) == OK)
    gameId = (Json.parse(contentAsString(resultF)) \ "game_id").as[String]
  }
}
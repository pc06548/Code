package models

import models.Spaceships._
import org.scalatest.{FunSpec, Matchers}
import org.scalatestplus.mockito.MockitoSugar
import play.api.libs.json.Json

import scala.collection.mutable.ListBuffer

class GridTest extends FunSpec with MockitoSugar with Matchers {
  describe("GridTest") {
    val grid = Grid()
    List.range(0,16).reverse.map(grid.array.remove(_))
    grid.array += "**.**...........".toCharArray.to[ListBuffer]
    grid.array += "..*.............".toCharArray.to[ListBuffer]
    grid.array += "**.**....***....".toCharArray.to[ListBuffer]
    grid.array += "..........*.*...".toCharArray.to[ListBuffer]
    grid.array += ".........***....".toCharArray.to[ListBuffer]
    grid.array += "................".toCharArray.to[ListBuffer]
    grid.array += "................".toCharArray.to[ListBuffer]
    grid.array += "............***.".toCharArray.to[ListBuffer]
    grid.array += ".......**.....*.".toCharArray.to[ListBuffer]
    grid.array += "......*.*.....*.".toCharArray.to[ListBuffer]
    grid.array += ".......**.....*.".toCharArray.to[ListBuffer]
    grid.array += "......*.*.......".toCharArray.to[ListBuffer]
    grid.array += "......***.......".toCharArray.to[ListBuffer]
    grid.array += "...*.*.*........".toCharArray.to[ListBuffer]
    grid.array += "...*.*.*........".toCharArray.to[ListBuffer]
    grid.array += "....*...........".toCharArray.to[ListBuffer]

    grid.positions += Position(0, 0, "Winger90", Winger90)
    grid.positions += Position(2, 9, "AClass90", AClass90)
    grid.positions += Position(7, 12, "Angle180", Angle180)
    grid.positions += Position(12, 3, "SClass90", SClass90)
    grid.positions += Position(8, 6, "BClass180", BClass180)

    it("should return false if the ship is not destroyed") {
      grid.isShipDestroyed(13,5) should be(false)
    }

    it("should return true if the ship is destroyed") {
      grid.array(12) = "......XX*.......".toCharArray.to[ListBuffer]
      grid.array(13) = "...X.X.X........".toCharArray.to[ListBuffer]
      grid.array(14) = "...X.X.X........".toCharArray.to[ListBuffer]
      grid.array(15) = "....X...........".toCharArray.to[ListBuffer]
      grid.isShipDestroyed(12,6) should be(true)
      grid.isShipDestroyed(12,7) should be(false)
    }

    it("should check if all ships are destroyed") {
      grid.isLastShipDestroyed() should be(false)
      List.range(0,16).reverse.map(grid.array.remove(_))
      grid.array += "XX.XX...........".toCharArray.to[ListBuffer]
      grid.array += "..X.............".toCharArray.to[ListBuffer]
      grid.array += "XX.XX....XXX....".toCharArray.to[ListBuffer]
      grid.array += "..........X.X...".toCharArray.to[ListBuffer]
      grid.array += ".........XXX....".toCharArray.to[ListBuffer]
      grid.array += "................".toCharArray.to[ListBuffer]
      grid.array += "................".toCharArray.to[ListBuffer]
      grid.array += "............XXX.".toCharArray.to[ListBuffer]
      grid.array += ".......XX.....X.".toCharArray.to[ListBuffer]
      grid.array += "......X.X.....X.".toCharArray.to[ListBuffer]
      grid.array += ".......XX.....X.".toCharArray.to[ListBuffer]
      grid.array += "......X.X.......".toCharArray.to[ListBuffer]
      grid.array += "......XXX.......".toCharArray.to[ListBuffer]
      grid.array += "...X.X.X........".toCharArray.to[ListBuffer]
      grid.array += "...X.X.X........".toCharArray.to[ListBuffer]
      grid.array += "....X...........".toCharArray.to[ListBuffer]

      grid.isShipDestroyed(0,0) should be(true)
      grid.isShipDestroyed(2,9) should be(true)
      grid.isShipDestroyed(7,12) should be(true)
      grid.isShipDestroyed(13,3) should be(true)
      grid.isShipDestroyed(13,3) should be(true)
      grid.isLastShipDestroyed() should be(false)
      grid.isShipDestroyed(8,7) should be(true)
      grid.isLastShipDestroyed() should be(true)
    }

    it("do it") {

      val sms =
        """{
          |"data":[
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "ASOM",
          |"twilioSkills": [
          |"ZAP.ASOM_Sparen_Spin_MSG",
          |"ZAP.ASOM_Incassovolmachten_MSG",
          |"ZAP.ASOM_Rechtsvorm_Spin_MSG",
          |"ZAP.ASOM_Sparen_Levensloop_MSG",
          |"ZAP.ASOM_WV_En_Mach_MSG",
          |"ZAP.ASOM_Sparen_Complex_MSG",
          |"ZAP.ASOM_Sparen_Eenvoudig_MSG",
          |"ZAP.ASOM_Fallback_MSG",
          |"ZAP.ASOM_Betaalrek_Uitval_MSG",
          |"ZAP.ASOM_Rechtsvorm_Spoed_MSG",
          |"ZAP.ASOM_Print_kantoor_MSG",
          |"ZAP.ASOM_Sparen_Pensioen_MSG",
          |"ZAP.ASOM_Betaalrek_Openen_MSG",
          |"ZAP.ASOM_Sparen_Rechtspos_MSG",
          |"ZAP.ASOM_Sparen_Oud_Prod_MSG",
          |"ZAP.ASOM_Adressen_MSG",
          |"ZAP.ASOM_Caseturning18_MSG",
          |"ZAP.ASOM_Betaalrek_Uit_CS_MSG",
          |"ZAP.ASOM_Spec_Bezorgd_MSG",
          |"ZAP.ASOM_Persoonsgeg_Wijz_MSG",
          |"ZAP.ASOM_Afschriften_MSG",
          |"ZAP.ASOM_FEBO_MSG",
          |"ZAP.ASOM_KING_MSG",
          |"ZAP.ASOM_Rechtsvorm_Regu_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Alarmlijn",
          |"twilioSkills": [
          |"ZAP.Alarmlijn_Spoed.0",
          |"ZAP.Alarmlijn.0",
          |"ZAP.Alarmlijn_Spoed.1",
          |"ZAP.Alarmlijn.1",
          |"ZAP.Alarmlijn.Teleopti"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "B&SLK",
          |"twilioSkills": []
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Beslagen",
          |"twilioSkills": [
          |"ZAP.RR-Beslagen.0",
          |"ZAP.RR-Beslagen.1"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Beslagen en Faillissementen",
          |"twilioSkills": [
          |"ZAP.BenF_Spoed_meerdere_MSG",
          |"ZAP.BenF_Deblokkades_MSG",
          |"ZAP.BenF_Screenen_MSG",
          |"ZAP.BenF_Fallback_MSG",
          |"ZAP.BenF_Meerdere_opheffen_MSG",
          |"ZAP.BenF_Faill_Spoed_MSG",
          |"ZAP.BenF_Deel_af_boeking_MSG",
          |"ZAP.BenF_Afdracht_MSG",
          |"ZAP.BenF_Deel_af_vrijgeven_MSG",
          |"ZAP.BenF_Faill_Beheer_MSG",
          |"ZAP.BenF_Fail_Spin_MSG",
          |"ZAP.BenF_Totaal_afdracht_MSG",
          |"ZAP.BenF_Meerdere_afdracht_MSG",
          |"ZAP.BenF_Betekeningen_MSG",
          |"ZAP.BenF_Faill_Opheffingen_MSG",
          |"ZAP.BenF_Besl_Opheffing_MSG",
          |"ZAP.BenF_Diversen_MSG",
          |"ZAP.BenF_Beslagen_Spin_MSG",
          |"ZAP.BenF_Klachten_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Betaalpassen",
          |"twilioSkills": [
          |"ZAP.Betaalpassen.TeleOpti",
          |"ZAP.Betaalpassen.0",
          |"ZAP.Betaalpassen.1"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Betalen Experience",
          |"twilioSkills": [
          |"ZAP.Kansrijk_Doorverbinden.1",
          |"ZAP.Leven.1",
          |"ZAP.Betalen_Betalen.0",
          |"ZAP.Betalen_Betalen.1",
          |"ZAP.Betalen_Rest.0",
          |"ZAP.Leven.0",
          |"ZAP.Betalen_Rest.1",
          |"ZAP.Kansrijk.0",
          |"ZAP.Studenten.1",
          |"ZAP.Kansrijk.1",
          |"ZAP.Sparen.1",
          |"ZAP.Studenten.0",
          |"ZAP.Kansrijk_Doorverbinden.0",
          |"ZAP.Sparen.0",
          |"ZAP.Betalen_Opheffen.0",
          |"ZAP.Betalen_Opheffen.1"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Betalen KC Only",
          |"twilioSkills": [
          |"ZAP.Webhelp_Navraag_MING.0",
          |"ZAP.Betalen.0",
          |"ZAP.BetalenTBIC.0",
          |"ZAP.BetalenAfschriften.1",
          |"ZAP.Webhelp_Ervaren_Medewrkr.1",
          |"ZAP.BetalenAfschriften.0",
          |"ZAP.BetalenSparenIVR.0",
          |"ZAP.Rentepunten.1",
          |"ZAP.BetalenSparenIVR.1",
          |"ZAP.Rentepunten.0",
          |"ZAP.Webhelp_Navraag_MING.1",
          |"ZAP.Webhelp_Ervaren_Medewrkr.0",
          |"ZAP.BetalenTBIC.1",
          |"ZAP.Betalen.1"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Betalen KIA",
          |"twilioSkills": [
          |"ZAP.KIA_Opzeggen_MING_MSG",
          |"ZAP.KIA_Koerier_Handeling2_MSG",
          |"ZAP.KIA_Koerier_Buitenland_MSG",
          |"ZAP.KIA_Koerier_IAS_MSG",
          |"ZAP.KIA_Incident_Vragen_MSG",
          |"ZAP.KIA_Incident_MING_Z_MSG",
          |"ZAP.KIA_Incident_MING_P_MSG",
          |"ZAP.KIA_Koerier_Binnenland_MSG",
          |"ZAP.KIA_Incident_Spoed_MSG",
          |"ZAP.KIA_Koerier_Stap2_MSG",
          |"ZAP.KIA_Fallback_MSG",
          |"ZAP.KIA_Koerier_Scanner_MSG",
          |"ZAP.KIA_Incident_Mobiel_P_MSG",
          |"ZAP.KIA_Verw_Boekhoudpak_MSG",
          |"ZAP.KIA_Incident_Mobiel_Z_MSG",
          |"ZAP.KIA_Koerier_Ontvangst_MSG",
          |"ZAP.KIA_Incident_Terugkop_MSG",
          |"ZAP.KIA_Koerier_Extrainfo_MSG",
          |"ZAP.KIA_Algemeen_Spin_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Betalen en SLK",
          |"twilioSkills": [
          |"ZAP.BSLK_Mach_Aanmelden_MSG",
          |"ZAP.BSLK_Open_Rek_Uitval_MSG",
          |"ZAP.BSLK_OVS_Nw_ZStap2_MSG",
          |"ZAP.BSLK_OVS_Oud_IAV_ZAK_MSG",
          |"ZAP.BSLK_Incasso_MSG",
          |"ZAP.BSLK_Convenanten_Spin_MSG",
          |"ZAP.BSLK_Koppelen_MSG",
          |"ZAP.BSLK_OVS_Oud_Spin_MSG",
          |"ZAP.BSLK_Restsaldo_Ver_MSG",
          |"ZAP.BSLK_OVS_Oud_ZStap1_MSG",
          |"ZAP.BSLK_Ontdubbelen_MSG",
          |"ZAP.BSLK_OVS_Nw_PStap1_MSG",
          |"ZAP.BSLK_Wereldbetalingen_MSG",
          |"ZAP.BSLK_OVS_Nw_Gew_Voorl_MSG",
          |"ZAP.BSLK_OVS_Oud_PStap1_MSG",
          |"ZAP.BSLK_Machtigingen_Spin_MSG",
          |"ZAP.SLK-Particulieren.1",
          |"ZAP.BSLK_Deblokkeren_MING_MSG",
          |"ZAP.BSLK_OVS_Nw_Spin_MSG",
          |"ZAP.BSLK_Opheffen_Part_MSG",
          |"ZAP.BSLK_OVS_Nw_ZStap1_MSG",
          |"ZAP.BSLK_Convenanten_MSG",
          |"ZAP.BSLK_Fallback_MSG",
          |"ZAP.BSLK_Mach_Aanmeld_Fiat_MSG",
          |"ZAP.BSLK_Open_Kop_Spin_MSG",
          |"ZAP.BSLK_OVS_Nw_Nood_Nieuw_MSG",
          |"ZAP.BSLK_OVS_Nw_Nood_Voorl_MSG",
          |"ZAP.BSLK_Mach_Afmelden_MSG",
          |"ZAP.BSLK_Controleren_MSG",
          |"ZAP.BSLK_OVS_Oud_ZStap2_MSG",
          |"ZAP.BSLK_Betpas_Saldolijn_MSG",
          |"ZAP.BSLK_KYC_Outreach_MSG",
          |"ZAP.SLK-WijzigenEnBetaalpas.0",
          |"ZAP.BSLK_Hypotheken_MSG",
          |"ZAP.SLK-WijzigenEnBetaalpas.1",
          |"ZAP.BSLK_Herstel_ouderrol_MSG",
          |"ZAP.BSLK_OVboekjes_MSG",
          |"ZAP.SLK-Opheffen.0",
          |"ZAP.BSLK_Recht_van_verzet_MSG",
          |"ZAP.BSLK_RGB_SPIN_MSG",
          |"ZAP.BSLK_OVS_Oud_POV_MSG",
          |"ZAP.BSLK_Openen_Algemeen_MSG",
          |"ZAP.BSLK_Openen_Koppelen_MSG",
          |"ZAP.BSLK_OVS_Oud_PStap2_MSG",
          |"ZAP.BSLK_Lijstopdrachten_MSG",
          |"ZAP.BSLK_Convenant_Beheer_MSG",
          |"ZAP.BSLK_Koppelen_Fiat_MSG",
          |"ZAP.BSLK_SEPA_MSG",
          |"ZAP.BSLK_IBP_Migratie_MSG",
          |"ZAP.BSLK_Openen_Kop_Fiat_MSG",
          |"ZAP.BSLK_Studenten_MSG",
          |"ZAP.SLK-Particulieren.0",
          |"ZAP.BSLK_Betaalpas_MSG",
          |"ZAP.SLK-Opheffen.1",
          |"ZAP.BSLK_OVS_Nw_PStap2_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Bewinden",
          |"twilioSkills": []
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Bewindvoering",
          |"twilioSkills": [
          |"ZAP.RR-Bewinden.1",
          |"ZAP.Bewind_Cur_Nieuw_MSG",
          |"ZAP.RR-Bewinden.0",
          |"ZAP.Bewind_Cur_Bee_MSG",
          |"ZAP.Bewind_Cur_MSG",
          |"ZAP.Bewind_Cur_IBP_MSG",
          |"ZAP.Bewind_Cur_Specials_MSG",
          |"ZAP.Bewind_Fallback_MSG",
          |"ZAP.Bewind_Spo_MSG",
          |"ZAP.Bewind_Testamentair_MSG",
          |"ZAP.Bewind_Spin_MSG",
          |"ZAP.Bewind_Kla_MSG",
          |"ZAP.Bewind_Cur_Eenvoudig_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients ART",
          |"twilioSkills": [
          |"ZAP.Zakelijk_ART.0",
          |"ZAP.Zakelijk_ART.1"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Basis",
          |"twilioSkills": [
          |"ZAP.Zakelijk_Basis.1",
          |"ZAP.Zakelijk_iDeal.1",
          |"ZAP.Zakelijk_iDeal.0",
          |"ZAP.Zakelijk_Basis.0"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Beheer",
          |"twilioSkills": []
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Beheer en IBP",
          |"twilioSkills": [
          |"ZAP.ZBI_Bankverk_SBV_MSG",
          |"ZAP.ZBI_G_Beheer_Fiat_Dag2_MSG",
          |"ZAP.ZBI_Ophef_Dag4_Fiat_OP_MSG",
          |"ZAP.ZBI_Naam_Wijz_MSG",
          |"ZAP.ZBI_G_Open_Verw_Dag1_MSG",
          |"ZAP.ZBI_G_Beheer_Fiat_Dag1_MSG",
          |"ZAP.ZBI_OAC_Screening_MSG",
          |"ZAP.ZBI_Waterspin_VVR_MSG",
          |"ZAP.ZBI_G_Beheer_Verw_Dag1_MSG",
          |"ZAP.ZBI_VV_Ophef_Verw_Dag1_MSG",
          |"ZAP.ZBI_Ophef_URS_Algemeen_MSG",
          |"ZAP.ZBI_VV_Open_Fiat_Dag1_MSG",
          |"ZAP.ZBI_Ophef_Dag1_Verw_OP_MSG",
          |"ZAP.ZBI_Ophef_Dag6_Verw_OP_MSG",
          |"ZAP.ZBI_IBP_Wijzigen_MSG",
          |"ZAP.ZBI_G_Open_Fiat_Dag1_MSG",
          |"ZAP.ZBI_Zak_Klantgeg_Wijz_MSG",
          |"ZAP.ZBI_Fallback_MSG",
          |"ZAP.ZBI_NRC_Condities_MSG",
          |"ZAP.ZBI_Interne_Rekeningen_MSG",
          |"ZAP.ZBI_G_Beheer_Verw_Dag3_MSG",
          |"ZAP.ZBI_G_Ophef_Fiat_Dag3_MSG",
          |"ZAP.ZBI_RCK_MSG",
          |"ZAP.ZBI_G_Ophef_Verw_Dag3_MSG",
          |"ZAP.ZBI_Zak_Mobapp_Ontdub_MSG",
          |"ZAP.ZBI_Ophef_Dag4_Verw_MSG",
          |"ZAP.ZBI_Ophef_URS_Fiat_MSG",
          |"ZAP.ZBI_Acquiring_Veri_MSG",
          |"ZAP.ZBI_Ophef_Dag1_Fiat_MSG",
          |"ZAP.ZBI_Waterspin_Bankverk_MSG",
          |"ZAP.ZBI_Ophef_Vraagbaak_MSG",
          |"ZAP.ZBI_VV_Open_Verw_Dag1_MSG",
          |"ZAP.ZBI_Waterspin_Ophef_MSG",
          |"ZAP.ZBI_Ophef_Dag4_Fiat_MSG",
          |"ZAP.ZBI_OAC_Aanv_MSG",
          |"ZAP.ZBI_Waterspin_Z_Team1_MSG",
          |"ZAP.ZBI_Retour_klant_Team1_MSG",
          |"ZAP.ZBI_Vertegenwoordigers_MSG",
          |"ZAP.ZBI_Ophef_Dag4_Verw_OP_MSG",
          |"ZAP.ZBI_Waterspin_Ophef_OP_MSG",
          |"ZAP.ZBI_Zak_Mobapp_Contr_MSG",
          |"ZAP.ZBI_RPA_Aanv_MSG",
          |"ZAP.ZBI_G_Beheer_Verw_Dag2_MSG",
          |"ZAP.ZBI_VV_Ophef_Fiat_Dag1_MSG",
          |"ZAP.ZBI_VV_Ophef_Fiat_Dag3_MSG",
          |"ZAP.ZBI_Ophef_Dag1_Fiat_OP_MSG",
          |"ZAP.ZBI_G_Ophef_Verw_Dag1_MSG",
          |"ZAP.ZBI_PPC_of_OAB_Oph_MSG",
          |"ZAP.ZBI_Z_Naar_P_MSG",
          |"ZAP.ZBI_Waterspin_PPC_OABC_MSG",
          |"ZAP.ZBI_Bankverk_Refbrief_MSG",
          |"ZAP.ZBI_G_Open_Verw_Dag2_MSG",
          |"ZAP.ZBI_PPC_of_OAB_Aanv_MSG",
          |"ZAP.ZBI_IBP_Monitoren_MSG",
          |"ZAP.ZBI_Adressen_Wijz_MSG",
          |"ZAP.ZBI_Waterspin_Ophf_MKB_MSG",
          |"ZAP.ZBI_Ophef_Dg6_Verw_MKB_MSG",
          |"ZAP.ZBI_Betaalpas_Aanvraag_MSG",
          |"ZAP.ZBI_Ophef_Dg1_Verw_MKB_MSG",
          |"ZAP.ZBI_Acc_Giro_Contract_MSG",
          |"ZAP.ZBI_G_Ophef_Fiat_Dag1_MSG",
          |"ZAP.ZBI_Zak_Ondersteuning_MSG",
          |"ZAP.ZBI_VV_Beheer_MSG",
          |"ZAP.ZBI_Gemachtigden_MSG",
          |"ZAP.ZBI_PIN_Overig_Complex_MSG",
          |"ZAP.ZBI_Ophef_Dg1_Fiat_MKB_MSG",
          |"ZAP.ZBI_Waterspin_Zakrel_MSG",
          |"ZAP.ZBI_Ophef_Dag1_Verw_MSG",
          |"ZAP.ZBI_Print_kantoor_MSG",
          |"ZAP.ZBI_VV_Ophef_Verw_Dag3_MSG",
          |"ZAP.ZBI_Klachten_KING_VVR_MSG",
          |"ZAP.ZBI_Bevoegdheden_Wijz_MSG",
          |"ZAP.ZBI_G_Ophef_Verw_Dag5_MSG",
          |"ZAP.ZBI_Combiverzoeken_MSG",
          |"ZAP.ZBI_Ophef_Dag6_Verw_MSG",
          |"ZAP.ZBI_PPC_of_OAB_Wijz_MSG",
          |"ZAP.ZBI_Handelsnaam_Wijz_MSG",
          |"ZAP.ZBI_Ophef_Dg4_Fiat_MKB_MSG",
          |"ZAP.ZBI_Ophef_Dg4_Verw_MKB_MSG",
          |"ZAP.ZBI_G_Open_Fiat_Dag2_MSG",
          |"ZAP.ZBI_IBP_Klantvragen_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Billing",
          |"twilioSkills": [
          |"ZAP.Zakelijk_Billing.0",
          |"ZAP.Zakelijk_Billing.1"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Cards",
          |"twilioSkills": [
          |"ZAP.KVC_AP_Kantoor_Spin_MSG",
          |"ZAP.KVC_BP_FREEZE_back_MSG",
          |"ZAP.KVC_Coll_Verrekenen_MSG",
          |"ZAP.KVC_BP_Beeindigen_GB_MSG",
          |"ZAP.KVC_Coll_Stornolijst_MSG",
          |"ZAP.KVC_BC_Diversen_MSG",
          |"ZAP.KVC_BC_Beheer_Spoed_MSG",
          |"ZAP.KVC_AP_Cre_Ass_Vragen_MSG",
          |"ZAP.KVC_BC_Spin_MSG",
          |"ZAP.KVC_FZ_Dag_EURaflos_MSG",
          |"ZAP.KVC_BP_Kopie_Afschr_MSG",
          |"ZAP.KVC_AP_Allianz_Vooraan_MSG",
          |"ZAP.KVC_AP_Kantoor_Schrift_MSG",
          |"Zap.KVC_BC_Mail_Div_MSG",
          |"ZAP.KVC_AP_Kantoor_Spoed_MSG",
          |"ZAP.KVC_BC_Klachten_MSG",
          |"ZAP.KVC_BP_Aanvr_Herpin_MSG",
          |"ZAP.KVC_FZ_Maand_CHFafroom_MSG",
          |"ZAP.KVC_BC_Mail_MSG",
          |"ZAP.KVC_CZ_Archvrn_Captvrn_MSG",
          |"ZAP.KVC_AP_Cred_Ass_Spin_MSG",
          |"ZAP.KVC_BP_Kop_Afs_Priba_MSG",
          |"ZAP.KVC_Coll_Priobestand_MSG",
          |"ZAP.KVC_CZ_Tibco_MSG",
          |"ZAP.KVC_CZ_Contr_Company_MSG",
          |"ZAP.KVC_Coll_Spin_MSG",
          |"ZAP.KVC_BP_Naamswijz_CC_MSG",
          |"ZAP.KVC_BP_Beeindigen_CC_MSG",
          |"ZAP.KVC_FZ_Dag_Converteren_MSG",
          |"ZAP.KVC_FZ_Dag_BTLaflos_MSG",
          |"ZAP.KVC_CZ_MLRO_MSG",
          |"ZAP.KVC_AP_PEGA_Revolving_MSG",
          |"ZAP.KVC_BP_Priba_Spoed_MSG",
          |"ZAP.KVC_Coll_Mail_ZA_MSG",
          |"ZAP.KVC_FZ_Perio_Smartdata_MSG",
          |"ZAP.KVC_Fallback_MSG",
          |"ZAP.KVC_BP_Verzoek_Spoed_MSG",
          |"ZAP.KVC_FZ_Dag_DDSrapport_MSG",
          |"ZAP.KVC_FZ_Issues_Spoed_MSG",
          |"ZAP.KVC_Coll_PortfolioMM_MSG",
          |"ZAP.KVC_BP_Wijz_Reknummer_MSG",
          |"ZAP.KVC_Coll_Retourpost_MSG",
          |"ZAP.KVC_BC_Overstapservice_MSG",
          |"ZAP.KVC_AP_Controle_Aanvr_MSG",
          |"ZAP.KVC_FZ_Verz_Restitutie_MSG",
          |"Zap.KVC_AP_Kantoor_Inkomen_MSG",
          |"ZAP.KVC_FZ_Week_LijstenCFO_MSG",
          |"ZAP.KVC_Coll_Mail_Overig_MSG",
          |"ZAP.KVC_AP_Cre_Klacht_Spin_MSG",
          |"ZAP.KVC_BP_Omzetting_CC_MSG",
          |"ZAP.KVC_AP_Klacht_Vragen_MSG",
          |"ZAP.KVC_AP_Kantoor_Vragen_MSG",
          |"ZAP.KVC_Coll_Mail_KYC_MSG",
          |"ZAP.KVC_Coll_Graydon_MSG",
          |"ZAP.KVC_AP_PEGA_Gespr_Bet_MSG",
          |"ZAP.KVC_AP_Klacht_Verzoek_MSG",
          |"ZAP.KVC_BC_Aanvr_Spoed_MSG",
          |"ZAP.KVC_AP_Overrules_MSG",
          |"ZAP.KVC_FZ_Perio_DB_TSYS_MSG",
          |"ZAP.KVC_Coll_MAIL_CORP_MSG",
          |"ZAP.KVC_BP_Aanvr_Preaccn_MSG",
          |"ZAP.KVC_BP_Beheer_Spin_MSG",
          |"ZAP.KVC_AP_Speg_Limiet_MSG",
          |"ZAP.KVC_FZ_Dag_Nakijkwerk_MSG",
          |"ZAP.KVC_FZ_Maand_TabelTS2_MSG",
          |"ZAP.KVC_BP_Limiet_Wijz_MSG",
          |"ZAP.KVC_Coll_Overdracht_IB_MSG",
          |"ZAP.KVC_AP_Speg_Spoed_MSG",
          |"ZAP.KVC_Coll_Over_queues_MSG",
          |"ZAP.KVC_FZ_Vra_Keycontrols_MSG",
          |"ZAP.KVC_CZ_Beheer_Spoed_MSG",
          |"ZAP.KVC_BP_Vervangen_Card_MSG",
          |"ZAP.KVC_CZ_Beheer_MSG",
          |"ZAP.KVC_Coll_Rev_bestanden_MSG",
          |"ZAP.KVC_BP_BKR_uitval_MSG",
          |"ZAP.KVC_AP_Klacht_MSG",
          |"ZAP.KVC_AP_Klacht_Spoed_MSG",
          |"ZAP.KVC_CZ_Comp_Spoed_MSG",
          |"ZAP.KVC_FZ_Week_Weeklypay_MSG",
          |"ZAP.KVC_CZ_Comp_Aanvraag_MSG",
          |"ZAP.KVC_FZ_Dag_Trade_MSG",
          |"ZAP.KVC_BC_1e_screening_MSG",
          |"ZAP.KVC_FZ_Verz_Latefee_MSG",
          |"ZAP.KVC_BP_Aanv_MTLB_tool_MSG",
          |"ZAP.KVC_AP_Beheer_MSG",
          |"ZAP.KVC_CZ_TS2_Aanvr_TMS_MSG",
          |"ZAP.KVC_BP_Herver_Card_MSG",
          |"ZAP.KVC_CZ_Archiveren_Card_MSG",
          |"ZAP.KVC_CZ_Dagelijks_Contr_MSG",
          |"ZAP.KVC_Coll_Mail_TMS_MSG",
          |"ZAP.KVC_FZ_Vra_Algemeen_MSG",
          |"ZAP.KVC_AP_Speg_Vragen_MSG",
          |"ZAP.KVC_Coll_Diversen_MSG",
          |"ZAP.KVC_AP_Speg_Spin_MSG",
          |"ZAP.KVC_BP_Aflosnota_Hyp_MSG",
          |"ZAP.KVC_AP_PEGA_Spoed_MSG",
          |"ZAP.KVC_BC_Beheer_MSG",
          |"ZAP.KVC_FZ_Perio_Rebate_MSG",
          |"ZAP.KVC_FZ_Verz_Overig_MSG",
          |"ZAP.KVC_FZ_Perio_DB_MSG",
          |"ZAP.KVC_Coll_OS_Saldo_MSG",
          |"ZAP.KVC_Coll_Klachten_UW_MSG",
          |"ZAP.KVC_FZ_Dag_Zwitserl_MSG",
          |"ZAP.KVC_AP_Controle_Beheer_MSG",
          |"ZAP.KVC_AP_PEGA_Limiet_MSG",
          |"ZAP.KVC_Coll_Fiditon_MSG",
          |"ZAP.KVC_BP_Pre_Blokkade_MSG",
          |"ZAP.KVC_BP_Kort_verz_Card_MSG",
          |"ZAP.KVC_BP_Aanvraag_Spin_MSG",
          |"ZAP.KVC_FZ_Dag_GBPstorno_MSG",
          |"ZAP.KVC_BP_Adreswijziging_MSG",
          |"ZAP.KVC_BP_Diversen_MSG",
          |"ZAP.KVC_AP_Cre_Uitz_Spin_MSG",
          |"ZAP.KVC_FZ_Dag_Keycontrols_MSG",
          |"ZAP.KVC_AP_Speg_Charge_MSG",
          |"ZAP.KVC_FZ_Jaar_GSD_MSG",
          |"ZAP.KVC_AP_Pega_Controle_MSG",
          |"ZAP.KVC_CZ_Mail__MSG",
          |"ZAP.KVC_BC_Aanvr_Post_MSG",
          |"ZAP.KVC_CZ_Cardaanvr_MSG",
          |"ZAP.KVC_AP_PEGA_Vragen_MSG",
          |"ZAP.KVC_BP_Arr_Wijziging_MSG",
          |"ZAP.KVC_FZ_Verz_Cre_saldo_MSG",
          |"ZAP.KVC_COLL_Mail_Faill_MSG",
          |"ZAP.KVC_AP_Kantoor_Charge_MSG",
          |"ZAP.KVC_BC_Aanvr_MINGZ_MSG",
          |"ZAP.KVC_CZ_Spin_MSG",
          |"ZAP.KVC_BC_Beheer_Omhang_MSG",
          |"ZAP.KVC_CZ_Cardaanvr_Spoed_MSG",
          |"ZAP.KVC_FZ_Spin_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Experience",
          |"twilioSkills": [
          |"ZAP.Zakelijk_iDeal.0",
          |"ZAP.Zakelijk_MING2elijn.1",
          |"ZAP.Zakl_Hlpdsk_Scan_Active.1",
          |"ZAP.Zakelijk_Basis.1",
          |"ZAP.Zakelijk_iDeal.1",
          |"ZAP.Zakl_Helpdsk_ING_Scanner.0",
          |"ZAP.Zakelijk_Basis.0",
          |"ZAP.Zakl_Hlpdsk_Scan_Active.0",
          |"ZAP.Zakl_Helpdsk_ING_Scanner.1",
          |"ZAP.Zakelijk_MING2elijn.0"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Experience 1",
          |"twilioSkills": []
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients IBP",
          |"twilioSkills": [
          |"ZAP.ZBI_IBP_Wijzigen_MSG",
          |"ZAP.Zakelijk_IBP_Helpdesk.1",
          |"ZAP.ZBI_IBP_Monitoren_MSG",
          |"ZAP.Zakelijk_IBP_Helpdesk.0",
          |"ZAP.ZBI_Gemachtigden_MSG",
          |"ZAP.ZBI_IBP_Klantvragen_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Incasso",
          |"twilioSkills": [
          |"ZAP.Zakelijk_DVB_Incasso.0",
          |"ZAP.ZIO_Zak_Bet_Derisk_MSG",
          |"ZAP.ZIO_Zak_Inc_Tech_Ond_MSG",
          |"ZAP.ZIO_Zak_Bet_Zak_Arran_MSG",
          |"ZAP.ZIO_Zak_Bet_Squad_Afw_MSG",
          |"ZAP.ZIO_Zak_Bet_Start_risi_MSG",
          |"ZAP.ZIO_Zak_Inc_IDIN_MSG",
          |"ZAP.Zakelijk_DVB_Incasso.1",
          |"ZAP.ZIO_Zak_Bet_Captiva_MSG",
          |"ZAP.ZIO_Zak_Bet_Interv_Afw_MSG",
          |"ZAP.ZIO_Waterspin_Inc_Mach_MSG",
          |"ZAP.ZIO_Zak_Bet_Aanvr_Fiat_MSG",
          |"ZAP.ZIO_Waterspin_Zak_Bet_MSG",
          |"ZAP.ZIO_Zak_Inc_Ret_Contr_MSG",
          |"ZAP.ZIO_Zak_Bet_Aanvr_Beo_MSG",
          |"ZAP.ZIO_Zak_Bet_CF_Afw_MSG",
          |"ZAP.ZIO_Zak_Inc_Mach_Aanvr_MSG",
          |"ZAP.ZIO_Zak_Bet_Contr_Fiat_MSG",
          |"ZAP.ZIO_Zak_Inc_B2B_MSG",
          |"ZAP.ZIO_Zak_Inc_Vraagbaak_MSG",
          |"ZAP.ZIO_Zak_Bet_Vraagbaak_MSG",
          |"ZAP.ZIO_Zak_Bet_Retour_Con_MSG",
          |"ZAP.ZIO_Zak_Bet_Vantage_MSG",
          |"ZAP.ZIO_Waterspin_Zak_Inc_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients Incasso en Openen",
          |"twilioSkills": [
          |"ZAP.ZIO_Koppelen_Stan_Ret_MSG",
          |"ZAP.ZIO_MINGZ_MSG",
          |"ZAP.ZIO_Spoed_Opvoeren_VW_MSG",
          |"ZAP.ZIO_CF_PU_Andere_Bank_MSG",
          |"ZAP.ZIO_Zak_Bet_Derisk_MSG",
          |"ZAP.ZIO_Zak_Inc_Tech_Ond_MSG",
          |"ZAP.ZIO_Zak_Bet_Zak_Arran_MSG",
          |"ZAP.ZIO_Openen_Enhanced_MSG",
          |"ZAP.ZIO_Waterspin_DOZ_MSG",
          |"ZAP.ZIO_CF_IBP_Fiat_MSG",
          |"ZAP.ZIO_Zak_Bet_Squad_Afw_MSG",
          |"ZAP.ZIO_CF_Fin_Stornos_MSG",
          |"ZAP.ZIO_Openen_Honeymoon_MSG",
          |"ZAP.ZIO_Koppelen_Honeymoon_MSG",
          |"ZAP.ZIO_CF_Pos_Saldo_Fiat_MSG",
          |"ZAP.ZIO_Open_Extra_ZR_Rek_MSG",
          |"ZAP.ZIO_CF_Ext_Saldo_Fiat_MSG",
          |"ZAP.ZIO_DOZ_Deblokkade_MSG",
          |"ZAP.ZIO_Koppelen_DRG_MSG",
          |"ZAP.ZIO_Zak_Bet_Start_risi_MSG",
          |"ZAP.ZIO_Zak_Inc_IDIN_MSG",
          |"ZAP.ZIO_DOZ_Spoed_MSG",
          |"ZAP.ZIO_Zak_Bet_Captiva_MSG",
          |"ZAP.ZIO_Zak_Bet_Interv_Afw_MSG",
          |"ZAP.ZIO_CF_Balance_Transf_MSG",
          |"ZAP.ZIO_Waterspin_Open_Fys_MSG",
          |"ZAP.ZIO_CF_Aflossen_Lenen_MSG",
          |"ZAP.ZIO_Waterspin_Inc_Mach_MSG",
          |"ZAP.ZIO_Openen_Fiatteren_MSG",
          |"ZAP.ZIO_CF_IBP_Verwerken_MSG",
          |"ZAP.ZIO_Zak_Bet_Aanvr_Fiat_MSG",
          |"ZAP.ZIO_Waterspin_Zak_Bet_MSG",
          |"ZAP.ZIO_Zak_Inc_Ret_Contr_MSG",
          |"ZAP.ZIO_DOZ_Algemeen_MSG",
          |"ZAP.ZIO_CF_Restituties_MSG",
          |"ZAP.ZIO_CF_Pos_Saldo_MSG",
          |"ZAP.ZIO_Kop_Extra_ZR_Rek_MSG",
          |"ZAP.ZIO_Zak_Bet_Aanvr_Beo_MSG",
          |"ZAP.ZIO_Zak_Bet_CF_Afw_MSG",
          |"ZAP.ZIO_Zak_Inc_Mach_Aanvr_MSG",
          |"ZAP.ZIO_DOZ_Akk_Uit_MSG",
          |"ZAP.ZIO_Zak_Bet_Contr_Fiat_MSG",
          |"ZAP.ZIO_DOZ_Akkoord_MSG",
          |"ZAP.ZIO_Zak_Inc_B2B_MSG",
          |"ZAP.ZIO_Zak_Inc_Vraagbaak_MSG",
          |"ZAP.ZIO_Zak_Bet_Vraagbaak_MSG",
          |"ZAP.ZIO_Openen_DRG_MSG",
          |"ZAP.ZIO_CF_MOD_Verzoeken_MSG",
          |"ZAP.ZIO_Zak_Bet_Retour_Con_MSG",
          |"ZAP.ZIO_Waterspin_Card_Fin_MSG",
          |"ZAP.ZIO_CF_Intr_Autoris_MSG",
          |"ZAP.ZIO_DOZ_Cor_Wijzigen_MSG",
          |"ZAP.ZIO_Openen_Afwijzen_MSG",
          |"ZAP.ZIO_IBP_Specials_MSG",
          |"ZAP.ZIO_Openen_Stan_Ret_MSG",
          |"ZAP.ZIO_DOZ_Uitval_Wijz_MSG",
          |"ZAP.ZIO_CF_Extra_Saldo_MSG",
          |"ZAP.ZIO_Zak_Bet_Vantage_MSG",
          |"ZAP.ZIO_Waterspin_Zak_Inc_MSG",
          |"ZAP.ZIO_Koppelen_Enhanced_MSG",
          |"ZAP.ZIO_DOZ_Alg_Tot_MSG",
          |"ZAP.ZIO_Fallback_MSG",
          |"ZAP.ZIO_Waterspin_Open_Ext_MSG",
          |"ZAP.ZIO_CF_Ben_Nalaten_MSG",
          |"ZAP.ZIO_MINGZ_Ontvang_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients MINGZ 2e Lijn",
          |"twilioSkills": [
          |"ZAP.Zakelijk_MING2elijn.1",
          |"ZAP.Zakelijk_MING2elijn.0"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Business Clients PPC",
          |"twilioSkills": [
          |"ZAP.Zakelijk_PPC.0",
          |"ZAP.ZBI_PPC_of_OAB_Oph_MSG",
          |"ZAP.ZBI_Waterspin_PPC_OABC_MSG",
          |"ZAP.ZBI_PPC_of_OAB_Aanv_MSG",
          |"ZAP.Zakelijk_PPC.1",
          |"ZAP.ZBI_PPC_of_OAB_Wijz_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Cards",
          |"twilioSkills": [
          |"ZAP.Cards.TeleOpti"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Helpdesk",
          |"twilioSkills": [
          |"ZAP.Helpdesk_TAN.1",
          |"ZAP.Helpdesk_App.0",
          |"ZAP.Helpdesk.1",
          |"ZAP.Helpdesk-2de-lijn.0",
          |"ZAP.Helpdesk_App.1",
          |"ZAP.Helpdesk_TAN.0",
          |"ZAP.Helpdesk-2de-lijn.1",
          |"ZAP.Helpdesk.0"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Lenen",
          |"twilioSkills": [
          |"ZAP.Lenen_CV_Algemeen_MSG",
          |"ZAP.Lenen_CV_Algemeen_Fiat_MSG",
          |"ZAP.Lenen_CV_Zak_Mail_MSG",
          |"ZAP.Lenen_Beheer_Fiat_MSG",
          |"ZAP.Lenen_Beheer_Aflosnota_MSG",
          |"ZAP.Lenen_Moni_Fiat_Complx_MSG",
          |"ZAP.Lenen_Rood_Staan_MSG",
          |"ZAP.Lenen_KL_Uitzondering_MSG",
          |"ZAP.Lenen_CV_Zak_Complex_MSG",
          |"ZAP.Lenen_Kwartaallimieten_MSG",
          |"ZAP.Lenen_CV_Zak_EZ_VOF_MSG",
          |"ZAP.Lenen_Beheer_Overlijd_MSG",
          |"ZAP.Lenen_CV_Alg_FraudFiat_MSG",
          |"ZAP.Kwartaallimiet.0",
          |"ZAP.Lenen_Moni_Klus_MSG",
          |"ZAP.Lenen_KL_Klachten_MSG",
          |"ZAP.Lenen.0",
          |"ZAP.Lenen_CV_Zak_HO_MSG",
          |"ZAP.Lenen_Beheer_Tegenrek_MSG",
          |"ZAP.Lenen_CV_Alg_Opl_Fiat_MSG",
          |"ZAP.Lenen_Moni_Complx_MSG",
          |"ZAP.Lenen_Beheer_Basis_MSG",
          |"ZAP.Lenen_CV_Alg_Fraude_MSG",
          |"ZAP.Lenen_Beheer_Fiat_Com_MSG",
          |"ZAP.Lenen_CV_Zak_Klus_MSG",
          |"ZAP.Continuelimiet.1",
          |"ZAP.Lenen_CV_Zak_Algemeen_MSG",
          |"ZAP.Lenen_Beheer_Expert_MSG",
          |"ZAP.Lenen_CV_Zak_Fiat_Opl_MSG",
          |"ZAP.Kwartaallimiet.1",
          |"ZAP.Lenen_CV_Zak_Fiat_Gev_MSG",
          |"ZAP.Lenen_Spin_Zak_MSG",
          |"ZAP.Lenen_CV_Zak_Uitval_MSG",
          |"ZAP.Lenen.1",
          |"ZAP.Lenen_CV_Zak_Fiat_Comp_MSG",
          |"ZAP.Lenen_Beheer_Fiat_Exp_MSG",
          |"ZAP.Lenen_Moni_Spin_MSG",
          |"ZAP.ZIO_CF_Aflossen_Lenen_MSG",
          |"ZAP.Lenen_Beheer_Gevorderd_MSG",
          |"ZAP.Lenen_CV_Zorgeloos_MSG",
          |"ZAP.Lenen_Beheer_Reversal_MSG",
          |"ZAP.Lenen_Beheer_Spin_MSG",
          |"ZAP.Lenen_Moni_Algemeen_MSG",
          |"ZAP.Lenen_Moni_Klachten_MSG",
          |"ZAP.Lenen_Moni_Fiat_MSG",
          |"ZAP.Lenen_KL_Uitval_MSG",
          |"ZAP.Continuelimiet.0",
          |"ZAP.Lenen_CV_Zak_Fiat_Bas_MSG",
          |"ZAP.Lenen_Beheer_Fiat_Bas_MSG",
          |"ZAP.Lenen_Beheer_Fiat_Regu_MSG",
          |"ZAP.Lenen_Captiva_MSG",
          |"ZAP.Lenen_Beheer_Regulier_MSG",
          |"ZAP.Lenen_Beheer_BEcontr_MSG",
          |"ZAP.Lenen_Spin_RS_MSG",
          |"ZAP.Lenen_Spin_MSG",
          |"ZAP.Lenen_Fallback_MSG",
          |"ZAP.Lenen_CV_Zak_Fiat_MSG",
          |"ZAP.Lenen_CV_Alg_Mail_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Open Time",
          |"twilioSkills": [
          |"Digital20.teleopti",
          |"Social.teleopti",
          |"Personal-Banking.teleopti",
          |"Private-Banking.teleopti"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "SDN",
          |"twilioSkills": [
          |"ZAP.SDN_Maatwerk_BOD_MSG",
          |"ZAP.SDN_Maatwerk_OHO_MSG",
          |"ZAP.SDN_Coulance_Beheer_MSG",
          |"ZAP.SDN_Maatwerk_Zak_Wacht_MSG",
          |"ZAP.SDN_Coulance_TBO_MSG",
          |"ZAP.SDN_Coulance_Uitval_MSG",
          |"ZAP.SDN_Coulance_LST_MSG",
          |"ZAP.SDN_Coulance.0",
          |"ZAP.SDN_Maatwerk_Basis_MSG",
          |"ZAP.SDN_Algemeen.1",
          |"ZAP.SDN_Maatwerk.0",
          |"ZAP.SDN_Maatwerk_KING_MSG",
          |"ZAP.SDN_Coulance_BOD_MSG",
          |"ZAP.SDN_Coulance_WOL_MSG",
          |"ZAP.SDN_Coulance_VOO_MSG",
          |"ZAP.SDN_Maatwerk_TBO_MSG",
          |"ZAP.SDN_Maatwerk_Spe_Zak_MSG",
          |"ZAP.SDN_Maatwerk_Overig_MSG",
          |"ZAP.SDN_Maatwerk_Spe_Klach_MSG",
          |"ZAP.SDN_Maatwerk_Buit_land_MSG",
          |"ZAP.SDN_Maatwerk_Spe_Verw_MSG",
          |"ZAP.SDN_Maatwerk.1",
          |"ZAP.SDN_Maatwerk_VOO_MSG",
          |"ZAP.SDN_Coulance_OHO_MSG",
          |"ZAP.SDN_Coulance_Basis_MSG",
          |"ZAP.SDN_Algemeen.0",
          |"ZAP.SDN_Coulance.1",
          |"ZAP.SDN_Coulance_Overig_MSG",
          |"ZAP.SDN_Maatwerk_Spe_Spar_MSG",
          |"ZAP.SDN_Maatwerk_Spin_MSG",
          |"ZAP.SDN_Maatwerk_Spe_Schei_MSG",
          |"ZAP.SDN_Coulance_SAO_MSG",
          |"ZAP.SDN_Maatwerk_Wachtbak_MSG",
          |"ZAP.SDN_Maatwerk_Spe_Hypo_MSG",
          |"ZAP.SDN_Maatwerk_Spe_Bene_MSG",
          |"ZAP.SDN_Maatwerk_Spoed_MSG",
          |"ZAP.SDN_Fallback_MSG",
          |"ZAP.SDN_Coulance_KING_MSG",
          |"ZAP.SDN_Coulance_Spoed_MSG",
          |"ZAP.SDN_Coulance_Wachtbak_MSG",
          |"ZAP.SDN_Maatwerk_Int_Rek_MSG",
          |"ZAP.SDN_Maatwerk_Hyp_Light_MSG",
          |"ZAP.SDN_Coulance_1eMelding_MSG",
          |"ZAP.SDN_Coulance_Klachten_MSG",
          |"ZAP.SDN_Maatwerk_Rappel_MSG",
          |"ZAP.SDN_Maatwerk_Flower_MSG",
          |"ZAP.SDN_Coulance_AFS_MSG",
          |"ZAP.SDN_Coulance_Spin_MSG",
          |"ZAP.SDN_Coulance_Team_K_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "SDN Messaging",
          |"twilioSkills": []
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Service Desk Specials",
          |"twilioSkills": [
          |"ZAP.SDS_Zak_Nieuw_MSG",
          |"ZAP.SDS_Priba_MSG",
          |"ZAP.SDS_Part_Opheffen_MSG",
          |"ZAP.SDS_Part_Nieuw_MSG",
          |"ZAP.SDS_Zak_UBO_MSG",
          |"ZAP.SDS_Jeugdzorg_Beheer_MSG",
          |"ZAP.SDS_Spin_MSG",
          |"ZAP.SDS_Zak_Opheffen_MSG",
          |"ZAP.SDS_GMU_Spoed_MSG",
          |"ZAP.SDS_Jeugdzorg_Spoed_MSG",
          |"ZAP.SDS_CC_Algemeen_MSG",
          |"ZAP.SDS_Orange_Carpet_MSG",
          |"ZAP.SDS_Zak_Beheer_MSG",
          |"ZAP.SDS_Part_Spoed_MSG",
          |"ZAP.SDS_Part_Klus_MSG",
          |"ZAP.SDS_Jeugdzorg_Klus_MSG",
          |"ZAP.Zakelijk_Events.1",
          |"ZAP.SDS_Zak_Klus_MSG",
          |"ZAP.SDS_Fallback_MSG",
          |"ZAP.SDS_GMU_Algemeen_MSG",
          |"ZAP.SDS_Zak_Spoed_MSG",
          |"ZAP.SDS_Jeugdzorg_Nieuw_MSG",
          |"ZAP.SDS_Part_Beheer_MSG",
          |"ZAP.SDS_Jeugdzorg_wijzigen_MSG",
          |"ZAP.SDS_Jeugdzorg_voogdij_MSG",
          |"ZAP.Zakelijk_Events.0",
          |"ZAP.SDS_Priba_Spoed_MSG"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "SkillNotInTeleOpti",
          |"twilioSkills": [
          |"SkillNotInTeleOpti"
          |]
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "Test validation",
          |"twilioSkills": []
          |},
          |{
          |"accountName": "NL-prd",
          |"teleoptiSkill": "klachten",
          |"twilioSkills": []
          |}
          |]}
        """.stripMargin

      val ts1 =
        """
          |{ "data":
          |[{
          |"name": "PBW.ZW-team_Debet.1",
          |"id": 129321
          |},
          |{
          |"name": "twitel",
          |"id": 58300
          |},
          |{
          |"name": "PBW.PWAM-team09.0",
          |"id": 129274
          |},
          |{
          |"name": "ZAP.KVC_Coll_Rev_bestanden_MSG",
          |"id": 176463
          |},
          |{
          |"name": "ZAP.KV-Cards_Finance.1",
          |"id": 149262
          |},
          |{
          |"name": "ZAP.Alarmlijn_Spoed.1",
          |"id": 140252
          |},
          |{
          |"name": "ZAP.Lenen_Moni_Fiat_MSG",
          |"id": 157309
          |},
          |{
          |"name": "ZAP.Bewind_Cur_Nieuw_MSG",
          |"id": 98351
          |},
          |{
          |"name": "LEN.Risicobeheer.0",
          |"id": 366
          |},
          |{
          |"name": "ZAP.ZBI_Betaalpas_Aanvraag_MSG",
          |"id": 173362
          |},
          |{
          |"name": "ZAP.Bewind_Cur_Bee_MSG",
          |"id": 160250
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Inc_Vraagbaak_MSG",
          |"id": 178259
          |},
          |{
          |"name": "ZAP.ASOM_Print_kantoor_MSG",
          |"id": 176401
          |},
          |{
          |"name": "ZAP.ZIO_Waterspin_Card_Fin_MSG",
          |"id": 178264
          |},
          |{
          |"name": "ZAP.KVC_CZ_Cardaanvr_Spoed_MSG",
          |"id": 176476
          |},
          |{
          |"name": "BELL.Campagne.0",
          |"id": 30401
          |},
          |{
          |"name": "PBW.NO-team2_Zwolle.1",
          |"id": 129264
          |},
          |{
          |"name": "HYP.aanvragen_CLT02.2",
          |"id": 31106
          |},
          |{
          |"name": "ZAP.ZIO_CF_Intr_Autoris_MSG",
          |"id": 178266
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_CF_Afw_MSG",
          |"id": 178255
          |},
          |{
          |"name": "HYP.scheiden_notaris.1",
          |"id": 31127
          |},
          |{
          |"name": "FRD.CREDIT_Reactie_mailbox_MSG",
          |"id": 171267
          |},
          |{
          |"name": "ZAP.Helpdesk_TAN.1",
          |"id": 46254
          |},
          |{
          |"name": "Col.sec_Afscheid.1",
          |"id": 26100
          |},
          |{
          |"name": "FRD.PAYSUP_Algemeen_MSG",
          |"id": 172253
          |},
          |{
          |"name": "PBW.ZW-team2_WMBZ.1",
          |"id": 129327
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_BOD_MSG",
          |"id": 178346
          |},
          |{
          |"name": "ZAP.SDS_Jeugdzorg_Beheer_MSG",
          |"id": 176451
          |},
          |{
          |"name": "HYP.aanvragen_CLT09.1",
          |"id": 31112
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Start_risi_MSG",
          |"id": 178258
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Oud_Spin_MSG",
          |"id": 169403
          |},
          |{
          |"name": "ZAP.ZIO_Waterspin_Inc_Mach_MSG",
          |"id": 177260
          |},
          |{
          |"name": "PBW.PWAM-KM.0",
          |"id": 188250
          |},
          |{
          |"name": "ZAP.Lenen.1",
          |"id": 34250
          |},
          |{
          |"name": "ZAP.IBP_BEW_Fiat_Alg_MSG",
          |"id": 196254
          |},
          |{
          |"name": "ZAP.Lenen_Moni_Complx_MSG",
          |"id": 177250
          |},
          |{
          |"name": "ZAP.KVC_BP_Beeindigen_GB_MSG",
          |"id": 176428
          |},
          |{
          |"name": "BELL.Opties.0",
          |"id": 30304
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_Fiat_Opl_MSG",
          |"id": 176444
          |},
          |{
          |"name": "FRD.HYP_SFH_Melding_MSG",
          |"id": 171261
          |},
          |{
          |"name": "ZAP.SDN_Coulance_Klachten_MSG",
          |"id": 150306
          |},
          |{
          |"name": "LEN.Wijzigen.1",
          |"id": 388
          |},
          |{
          |"name": "FRD.PAYSUP_Fiditon_MSG",
          |"id": 171251
          |},
          |{
          |"name": "PBW.PWAM-team01.1",
          |"id": 129312
          |},
          |{
          |"name": "HYP.Jaaroverzicht.2",
          |"id": 79259
          |},
          |{
          |"name": "ZAP.KVC_FZ_Verz_Restitutie_MSG",
          |"id": 176413
          |},
          |{
          |"name": "ZAP.ZBI_G_Open_Verw_Dag2_MSG",
          |"id": 173253
          |},
          |{
          |"name": "FRD.PAYMENT_Fallback_MSG",
          |"id": 170266
          |},
          |{
          |"name": "PBW.NO-team1_Zwolle.0",
          |"id": 129262
          |},
          |{
          |"name": "KYC.EHMT-Team2.0",
          |"id": 52351
          |},
          |{
          |"name": "ZAP.KVC_BP_Aanvraag_Spin_MSG",
          |"id": 176433
          |},
          |{
          |"name": "ZAP.ZBI_Combiverzoeken_MSG",
          |"id": 173321
          |},
          |{
          |"name": "WUB.Preventief_Beheer_CAL.1",
          |"id": 119304
          |},
          |{
          |"name": "ZAP.KIA_Koerier_Ontvangst_MSG",
          |"id": 166252
          |},
          |{
          |"name": "KYC.RSPE-PTM_MassEnhancement.1",
          |"id": 76350
          |},
          |{
          |"name": "ZAP.KVC_CZ_Beheer_Spoed_MSG",
          |"id": 176528
          |},
          |{
          |"name": "PBW.ZO-team_Limburg.0",
          |"id": 128267
          |},
          |{
          |"name": "LEN.Hypotheken.0",
          |"id": 384
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Nw_PStap1_MSG",
          |"id": 169262
          |},
          |{
          |"name": "PBW.NW-team_Amsterdam.1",
          |"id": 129359
          |},
          |{
          |"name": "ZAP.ZIO_CF_Ext_Saldo_Fiat_MSG",
          |"id": 178314
          |},
          |{
          |"name": "LEN.Archief.1",
          |"id": 29101
          |},
          |{
          |"name": "ZAP.KVC_CZ_Archvrn_Captvrn_MSG",
          |"id": 192305
          |},
          |{
          |"name": "PBW.ZO-team_ZO-Debet.0",
          |"id": 128268
          |},
          |{
          |"name": "FRD.Wholesale_Support.1",
          |"id": 47457
          |},
          |{
          |"name": "ZAP.Lenen_Spin_Zak_MSG",
          |"id": 176497
          |},
          |{
          |"name": "LEN.Opschorten_Aflossen.1",
          |"id": 40250
          |},
          |{
          |"name": "ZAP.SDS_Priba_Spoed_MSG",
          |"id": 176403
          |},
          |{
          |"name": "ZAP.SLK-Opheffen.0",
          |"id": 35402
          |},
          |{
          |"name": "ZAP.ASOM_Rechtsvorm_Spoed_MSG",
          |"id": 165355
          |},
          |{
          |"name": "ZAP.Zakelijk_MING2elijn.0",
          |"id": 41303
          |},
          |{
          |"name": "ZAP.KIA_Incident_MING_P_MSG",
          |"id": 167252
          |},
          |{
          |"name": "HYP.aanvragen_CLT10.1",
          |"id": 32117
          |},
          |{
          |"name": "ZAP.SDN_Coulance_LST_MSG",
          |"id": 151253
          |},
          |{
          |"name": "BELL.Opheffen.0",
          |"id": 30353
          |},
          |{
          |"name": "WUB.Risk_CAL.0",
          |"id": 119355
          |},
          |{
          |"name": "HYP.pilotnummer6.0",
          |"id": 39752
          |},
          |{
          |"name": "KYC.ZKL-Review.0",
          |"id": 52264
          |},
          |{
          |"name": "HYP.pilotnummer5.2",
          |"id": 39851
          |},
          |{
          |"name": "Col.sec_Specialties.1",
          |"id": 26061
          |},
          |{
          |"name": "LEN.TA-desk.0",
          |"id": 33200
          |},
          |{
          |"name": "ZAP.ZIO_Openen_Honeymoon_MSG",
          |"id": 178353
          |},
          |{
          |"name": "Telephony_Confidence",
          |"id": 35463
          |},
          |{
          |"name": "ZAP.Betalen.1",
          |"id": 35350
          |},
          |{
          |"name": "ZAP.Lenen_Moni_Fiat_Complx_MSG",
          |"id": 176388
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk.1",
          |"id": 35201
          |},
          |{
          |"name": "HYP.FGI.0",
          |"id": 32121
          |},
          |{
          |"name": "HYP.herstructureren.0",
          |"id": 32207
          |},
          |{
          |"name": "PBW.ZW-team1_Rotterdam.0",
          |"id": 129374
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Vantage_MSG",
          |"id": 178257
          |},
          |{
          |"name": "HYP.tra_intermediair.1",
          |"id": 31140
          |},
          |{
          |"name": "ZAP.ZBI_VV_Beheer_MSG",
          |"id": 173302
          |},
          |{
          |"name": "KYC.GZ-Building_Institutions.0",
          |"id": 87350
          |},
          |{
          |"name": "InteractingNL_Test_skill",
          |"id": 103305
          |},
          |{
          |"name": "ZAP.SDS_Fallback_MSG",
          |"id": 165361
          |},
          |{
          |"name": "HYP.scheiden.0",
          |"id": 31124
          |},
          |{
          |"name": "ZAP.SDS_Jeugdzorg_Nieuw_MSG",
          |"id": 176402
          |},
          |{
          |"name": "KYC.PBW-Review.0",
          |"id": 52355
          |},
          |{
          |"name": "ZAP.Betalen_Rest.0",
          |"id": 47602
          |},
          |{
          |"name": "ZAP.BenF_Deblokkades_MSG",
          |"id": 167303
          |},
          |{
          |"name": "ZAP.ZBI_Bankverk_Status_MSG",
          |"id": 194313
          |},
          |{
          |"name": "ZAP.BenF_Meerdere_afdracht_MSG",
          |"id": 167307
          |},
          |{
          |"name": "HYP.gekoppelde_prod.1",
          |"id": 32205
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Nw_ZStap2_MSG",
          |"id": 169360
          |},
          |{
          |"name": "FRD.DECT_Klantverzoek_MSG",
          |"id": 172264
          |},
          |{
          |"name": "HYP.hsp_aanvragen.0",
          |"id": 32147
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spe_Bene_MSG",
          |"id": 150261
          |},
          |{
          |"name": "HYP.aanvragen_CLT02.1",
          |"id": 31105
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_Converteren_MSG",
          |"id": 176519
          |},
          |{
          |"name": "PBW.NO-team_Noord-Nederland.1",
          |"id": 129354
          |},
          |{
          |"name": "OTW.Intake.1",
          |"id": 45300
          |},
          |{
          |"name": "ZAP.ZBI_RPA_Aanv_MSG",
          |"id": 173272
          |},
          |{
          |"name": "Private-Banking",
          |"id": 47456
          |},
          |{
          |"name": "ZAP.KVC_AP_Kantoor_Spin_MSG",
          |"id": 176372
          |},
          |{
          |"name": "PBW.PWAM-team05.0",
          |"id": 128264
          |},
          |{
          |"name": "HYP.connect_acquisitie.1",
          |"id": 32155
          |},
          |{
          |"name": "ZAP.SDN_Coulance_VOO_MSG",
          |"id": 165256
          |},
          |{
          |"name": "HYP.Verhoger-Particulier.1",
          |"id": 47303
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Nw_Nood_Voorl_MSG",
          |"id": 169361
          |},
          |{
          |"name": "KYC.RSPE-Regulier.0",
          |"id": 52262
          |},
          |{
          |"name": "LEN.Risicobeheer.1",
          |"id": 367
          |},
          |{
          |"name": "ZAP.Zakelijk_ART.0",
          |"id": 35304
          |},
          |{
          |"name": "ZAP.Lenen_Captiva_MSG",
          |"id": 157301
          |},
          |{
          |"name": "ZAP.BSLK_Openen_Algemeen_MSG",
          |"id": 169254
          |},
          |{
          |"name": "ZAP.BSLK_Convenant_Beheer_MSG",
          |"id": 182301
          |},
          |{
          |"name": "FRD.PAYSUP_Vrijwaring_MSG",
          |"id": 172254
          |},
          |{
          |"name": "KYC.PBW-Review.1",
          |"id": 52356
          |},
          |{
          |"name": "ZAP.Vraagbaak_Taskforce",
          |"id": 104300
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Contr_Fiat_MSG",
          |"id": 177258
          |},
          |{
          |"name": "ZAP.KV-Cards_CorporateCards.0",
          |"id": 150267
          |},
          |{
          |"name": "ZAP.KVC_BC_Beheer_Omhang_MSG",
          |"id": 176473
          |},
          |{
          |"name": "ZAP.KVC_Coll_Mail_KYC_MSG",
          |"id": 176512
          |},
          |{
          |"name": "HYP.cmis.1",
          |"id": 39900
          |},
          |{
          |"name": "HYP.Verhoger-Particulier.2",
          |"id": 47304
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spoed_MSG",
          |"id": 150307
          |},
          |{
          |"name": "KYC.ProjectCO-Team2.1",
          |"id": 167312
          |},
          |{
          |"name": "KAP.Aanvragen_Welkom_MSG",
          |"id": 91251
          |},
          |{
          |"name": "HYP.Contactme_Acquisitie_CMN.0",
          |"id": 116450
          |},
          |{
          |"name": "ZAP.ZBI_G_Ophef_Fiat_Dag1_MSG",
          |"id": 173306
          |},
          |{
          |"name": "HYP.Aflosvrij.0",
          |"id": 56250
          |},
          |{
          |"name": "ZAP.KVC_CZ_Comp_Aanvraag_MSG",
          |"id": 176422
          |},
          |{
          |"name": "HYP.hsp.pilot.1",
          |"id": 31131
          |},
          |{
          |"name": "ZAP.Zakelijk_Events.0",
          |"id": 35404
          |},
          |{
          |"name": "ZAP.Lenen_Moni_Spin_MSG",
          |"id": 157307
          |},
          |{
          |"name": "HYP.elt.0",
          |"id": 32140
          |},
          |{
          |"name": "KYC.EHMT-Team5.0",
          |"id": 52255
          |},
          |{
          |"name": "ZAP.BSLK_Studenten_MSG",
          |"id": 169354
          |},
          |{
          |"name": "ADV.Concreet-Particulier.0",
          |"id": 47351
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_Fiat_Gev_MSG",
          |"id": 176443
          |},
          |{
          |"name": "LEN.Audits-Systems.1",
          |"id": 400
          |},
          |{
          |"name": "ZAP.ASOM_WV_En_Mach_MSG",
          |"id": 165409
          |},
          |{
          |"name": "ZAP.Zakelijk_PPC.1",
          |"id": 41302
          |},
          |{
          |"name": "ZAP.BSLK_Open_Kop_Spin_MSG",
          |"id": 169400
          |},
          |{
          |"name": "HYP.connect_beheer.2",
          |"id": 32154
          |},
          |{
          |"name": "PBW.ZW-team_Debet.0",
          |"id": 129320
          |},
          |{
          |"name": "PBW.NO-team1_Twente.1",
          |"id": 129355
          |},
          |{
          |"name": "ZAP.Zakelijk_DVB_Incasso.1",
          |"id": 35307
          |},
          |{
          |"name": "ZAP.BenF_Totaal_afdracht_MSG",
          |"id": 167305
          |},
          |{
          |"name": "ZAP.KVC_BP_Kopie_Afschr_MSG",
          |"id": 176369
          |},
          |{
          |"name": "PBW-ACM-PWAM-Default.0",
          |"id": 129283
          |},
          |{
          |"name": "FRD.CREDIT_Navraag_banken_MSG",
          |"id": 171309
          |},
          |{
          |"name": "ZAP.KVC_AP_Speg_Spin_MSG",
          |"id": 176374
          |},
          |{
          |"name": "ZAP.Bewind_Spin_MSG",
          |"id": 98251
          |},
          |{
          |"name": "FRD.PAY_Waterspin_MSG",
          |"id": 171304
          |},
          |{
          |"name": "ZAP.Lenen_Rood_Staan_MSG",
          |"id": 176494
          |},
          |{
          |"name": "ZAP.WholesaleCompliance.0",
          |"id": 119359
          |},
          |{
          |"name": "KYC.GRZ-ReviewTrnsprt-Logist.1",
          |"id": 52304
          |},
          |{
          |"name": "PBW.ZO-team_Arnhem-Nijmegen.0",
          |"id": 129367
          |},
          |{
          |"name": "ZAP.IBP_BEW_Beh_IBP_Spaar_MSG",
          |"id": 197301
          |},
          |{
          |"name": "ZAP.KV-Cards_BusinessCards.1",
          |"id": 151256
          |},
          |{
          |"name": "LEN.Risicobeheer_2.1",
          |"id": 373
          |},
          |{
          |"name": "PBW.NW-team_NW-Debet.0",
          |"id": 129267
          |},
          |{
          |"name": "FRD.JUR_126NE_MSG",
          |"id": 172255
          |},
          |{
          |"name": "WUB.Actuariaat_CAL.2",
          |"id": 120250
          |},
          |{
          |"name": "HYP.elt.1",
          |"id": 31133
          |},
          |{
          |"name": "ZAP.BSLK_Recht_van_verzet_MSG",
          |"id": 169401
          |},
          |{
          |"name": "HYP.oip_PPW.0",
          |"id": 32143
          |},
          |{
          |"name": "ZAP.Bewind_Testamentair_MSG",
          |"id": 98401
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Spin_MSG",
          |"id": 157356
          |},
          |{
          |"name": "ZAP.Helpdesk_App.1",
          |"id": 61314
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Nw_Gew_Voorl_MSG",
          |"id": 169307
          |},
          |{
          |"name": "HYP.gekoppelde_prod.2",
          |"id": 32206
          |},
          |{
          |"name": "ZAP.Studenten.0",
          |"id": 35356
          |},
          |{
          |"name": "CORP.Grootzakelijk_CLT5.1",
          |"id": 45551
          |},
          |{
          |"name": "PBW.NO-team_Apeldrn-Achterh.1",
          |"id": 129308
          |},
          |{
          |"name": "HYP.cmis.0",
          |"id": 39801
          |},
          |{
          |"name": "BELL.Overstapservice.1",
          |"id": 30451
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_Complex_MSG",
          |"id": 158252
          |},
          |{
          |"name": "ZAP.Lenen_Monitoring.1",
          |"id": 129302
          |},
          |{
          |"name": "ZAP.BSLK_KYC_Outreach_MSG",
          |"id": 169357
          |},
          |{
          |"name": "ZAP.SDN_CMN.0",
          |"id": 110350
          |},
          |{
          |"name": "ZAP.Kwartaallimiet.0",
          |"id": 47501
          |},
          |{
          |"name": "LEN.Archief.2",
          |"id": 29102
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Nw_PStap2_MSG",
          |"id": 169359
          |},
          |{
          |"name": "Z_Kred-Lopend_Krediet",
          |"id": 22
          |},
          |{
          |"name": "FRD.Fraud_Investigations.0",
          |"id": 141254
          |},
          |{
          |"name": "HYP.aanvragen_CLT10.0",
          |"id": 32116
          |},
          |{
          |"name": "PBW.NW-team_Kennemerland.0",
          |"id": 129360
          |},
          |{
          |"name": "FRD.Juridische_Uitlevering.0",
          |"id": 26205
          |},
          |{
          |"name": "HYP.cct3.1",
          |"id": 192314
          |},
          |{
          |"name": "HYP.geldverkeer.1",
          |"id": 31143
          |},
          |{
          |"name": "ZAP.KVC_CZ_Mail__MSG",
          |"id": 176425
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dg1_Fiat_MKB_MSG",
          |"id": 173265
          |},
          |{
          |"name": "ZAP.Lenen_Fallback_MSG",
          |"id": 158258
          |},
          |{
          |"name": "ZAP.ZIO_CF_Pos_Saldo_Fiat_MSG",
          |"id": 178357
          |},
          |{
          |"name": "ZAP.Helpdesk_ING_Scanner.1",
          |"id": 79355
          |},
          |{
          |"name": "LEN.Taskforce_JO-INA.0",
          |"id": 461
          |},
          |{
          |"name": "ZAP.BSLK_Restsaldo_Ver_MSG",
          |"id": 169300
          |},
          |{
          |"name": "PBW.ZW-team_ZW_Leiden.0",
          |"id": 129322
          |},
          |{
          |"name": "Betalen_Opheffen.1",
          |"id": 47453
          |},
          |{
          |"name": "ZAP.Helpdesk.1",
          |"id": 35355
          |},
          |{
          |"name": "KYC.ProjectCO-Team4.2",
          |"id": 167315
          |},
          |{
          |"name": "ZAP.Bankkluis.0",
          |"id": 144303
          |},
          |{
          |"name": "ZAP.ZBI_G_Beheer_Verw_Dag3_MSG",
          |"id": 173304
          |},
          |{
          |"name": "ZAP.KVC_BC_Aanvr_MINGZ_MSG",
          |"id": 176525
          |},
          |{
          |"name": "LEN.Kredietaanvragen.1",
          |"id": 422
          |},
          |{
          |"name": "ZAP.ZIO_Kop_Extra_ZR_Rek_MSG",
          |"id": 178309
          |},
          |{
          |"name": "HYP.Contactme_CMN",
          |"id": 98300
          |},
          |{
          |"name": "ZAP.Kansrijk_Beleggen.0",
          |"id": 167265
          |},
          |{
          |"name": "FRD.Fraud_Investigations.1",
          |"id": 140353
          |},
          |{
          |"name": "HYP.connect_beheer.0",
          |"id": 31147
          |},
          |{
          |"name": "ZAP.ZBI_G_Open_Fiat_Dag1_MSG",
          |"id": 173301
          |},
          |{
          |"name": "ZAP.KVC_CZ_Spin_MSG",
          |"id": 176421
          |},
          |{
          |"name": "ZAP.KVC_Coll_MAIL_CORP_MSG",
          |"id": 192253
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam3.0",
          |"id": 144353
          |},
          |{
          |"name": "ZAP.ZBI_IBP_Klantvragen_MSG",
          |"id": 173327
          |},
          |{
          |"name": "PBW.NO-team3_Zwolle.1",
          |"id": 129358
          |},
          |{
          |"name": "LEN.Krediet_Klantbeheer_2.1",
          |"id": 74362
          |},
          |{
          |"name": "ZAP.ZIO_DOZ_Akk_Uit_MSG",
          |"id": 192409
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Oud_ZStap2_MSG",
          |"id": 169308
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Retour_Con_MSG",
          |"id": 177257
          |},
          |{
          |"name": "FRD.Juridische_Uitlevering.1",
          |"id": 26158
          |},
          |{
          |"name": "LEN.Watchlist.1",
          |"id": 379
          |},
          |{
          |"name": "ZAP.Studenten.1",
          |"id": 35454
          |},
          |{
          |"name": "ZAP.ZBI_Bankverk_Refbrief_MSG",
          |"id": 173258
          |},
          |{
          |"name": "BELL.Opheffen.1",
          |"id": 30404
          |},
          |{
          |"name": "FRD.DECT_Beg_Versturen_VAK_MSG",
          |"id": 171308
          |},
          |{
          |"name": "ZAP.Zakelijk_Billing.0",
          |"id": 41250
          |},
          |{
          |"name": "ZAP.ZBI_Acc_Giro_Contract_MSG",
          |"id": 173259
          |},
          |{
          |"name": "FRD.JUR_Algemeen_spoed_MSG",
          |"id": 171258
          |},
          |{
          |"name": "BELL.Beleggen_Tarieven.0",
          |"id": 150252
          |},
          |{
          |"name": "ADV.Verhoger-Zakelijk.1",
          |"id": 47404
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam2.1",
          |"id": 144256
          |},
          |{
          |"name": "ZAP.BenF_Screenen_MSG",
          |"id": 167258
          |},
          |{
          |"name": "BELL.Beleggen.0",
          |"id": 30301
          |},
          |{
          |"name": "LEN.BCC_Starters.1",
          |"id": 74414
          |},
          |{
          |"name": "PBW.PWAM-team06.0",
          |"id": 129271
          |},
          |{
          |"name": "ZAP.BSLK_Openen_Koppelen_MSG",
          |"id": 169255
          |},
          |{
          |"name": "KYC.ZKL-Onboarding.1",
          |"id": 47600
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Inc_B2B_MSG",
          |"id": 176399
          |},
          |{
          |"name": "FRD.JUR_126ND_Complex_MSG",
          |"id": 171256
          |},
          |{
          |"name": "ZAP.Betalen_Opheffen.0",
          |"id": 47604
          |},
          |{
          |"name": "ZAP.KV-Cards_Collections.0",
          |"id": 150263
          |},
          |{
          |"name": "ZAP.Helpdesk_ING_Scanner.0",
          |"id": 79354
          |},
          |{
          |"name": "FRD.Fraud_Payment_Support.0",
          |"id": 140303
          |},
          |{
          |"name": "KYC.PBW-Onboarding.1",
          |"id": 52405
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dg6_Verw_MKB_MSG",
          |"id": 173368
          |},
          |{
          |"name": "ZAP.KVC_Coll_Mail_TMS_MSG",
          |"id": 176410
          |},
          |{
          |"name": "KYC.PBW-ZW.0",
          |"id": 144251
          |},
          |{
          |"name": "ZAP.IBP_BEW_Beh_IBP_Vragen_MSG",
          |"id": 195259
          |},
          |{
          |"name": "Private-Banking.teleopti",
          |"id": 176545
          |},
          |{
          |"name": "ZAP.Enticement_Verzekeren.1",
          |"id": 145311
          |},
          |{
          |"name": "ZAP.Betalen_Betalen.1",
          |"id": 47552
          |},
          |{
          |"name": "ZAP.Lenen_Moni_Klus_MSG",
          |"id": 157310
          |},
          |{
          |"name": "KYC.EHMT-TeamTrust.1",
          |"id": 52404
          |},
          |{
          |"name": "KYC.CAM-PTM_Mass.1",
          |"id": 52409
          |},
          |{
          |"name": "HYP.pilotnummer2.0",
          |"id": 32150
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Hyp_Light_MSG",
          |"id": 178296
          |},
          |{
          |"name": "BELL.Overstapservice.2",
          |"id": 30403
          |},
          |{
          |"name": "HYP.oip_PPW.2",
          |"id": 32144
          |},
          |{
          |"name": "ZAP.Bewind_Cur_IBP_MSG",
          |"id": 98352
          |},
          |{
          |"name": "ZAP.KVC_FZ_Verz_Latefee_MSG",
          |"id": 176465
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_HO_MSG",
          |"id": 176498
          |},
          |{
          |"name": "ZAP.SDN_Algemeen.1",
          |"id": 35152
          |},
          |{
          |"name": "ADV.Online-Zakelijk.1",
          |"id": 47407
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam4.1",
          |"id": 144302
          |},
          |{
          |"name": "HYP.Verhoger-Particulier.0",
          |"id": 47401
          |},
          |{
          |"name": "FRD.PAYSUP_4010_MSG",
          |"id": 170251
          |},
          |{
          |"name": "ZAP.Zakelijk_iDeal.0",
          |"id": 35358
          |},
          |{
          |"name": "PBW.PWAM-team08.1",
          |"id": 129273
          |},
          |{
          |"name": "Col.uns_Afscheid.0",
          |"id": 26104
          |},
          |{
          |"name": "HYP.zekerheden_notaris.0",
          |"id": 31120
          |},
          |{
          |"name": "HYP.aanvragen_CLT06.1",
          |"id": 32109
          |},
          |{
          |"name": "FRD.PAYSUP_Legal_MSG",
          |"id": 171252
          |},
          |{
          |"name": "Investing",
          |"id": 6
          |},
          |{
          |"name": "KAP.Beheer_FastJourney_MSG",
          |"id": 91250
          |},
          |{
          |"name": "KYC.EHMT-Team4.1",
          |"id": 52254
          |},
          |{
          |"name": "HYP.tra.1",
          |"id": 32131
          |},
          |{
          |"name": "ZAP.BenF_Deel_af_vrijgeven_MSG",
          |"id": 167351
          |},
          |{
          |"name": "KYC.EHMT-Team5.1",
          |"id": 52352
          |},
          |{
          |"name": "ZAP.KVC_AP_PEGA_Gespr_Bet_MSG",
          |"id": 176383
          |},
          |{
          |"name": "HYP.pilotnummer3.0",
          |"id": 36100
          |},
          |{
          |"name": "ZAP.SDS_Zak_Klus_MSG",
          |"id": 176501
          |},
          |{
          |"name": "FRD.PAY_Overig_inforverz_MSG",
          |"id": 172257
          |},
          |{
          |"name": "LEN.Opschorten_Aflossen.0",
          |"id": 39951
          |},
          |{
          |"name": "ZAP.BSLK_Koppelen_Fiat_MSG",
          |"id": 169259
          |},
          |{
          |"name": "HYP.aflossen_notaris.2",
          |"id": 31119
          |},
          |{
          |"name": "Col.sec_Real_Estate.1",
          |"id": 26059
          |},
          |{
          |"name": "ZAP.Helpdesk_Part_DVBSCAN.0",
          |"id": 119250
          |},
          |{
          |"name": "KYC.ProjectCO-Team5.2",
          |"id": 167316
          |},
          |{
          |"name": "KAP.aanvragen_1ste_lijn_CMN.0",
          |"id": 357
          |},
          |{
          |"name": "ZAP.KIA_Koerier_Buitenland_MSG",
          |"id": 178349
          |},
          |{
          |"name": "ZAP.KVC_AP_Controle_Aanvr_MSG",
          |"id": 176385
          |},
          |{
          |"name": "ZAP.KIA_Incident_Mobiel_Z_MSG",
          |"id": 167350
          |},
          |{
          |"name": "ZAP.BSLK_Deblokkeren_MING_MSG",
          |"id": 169304
          |},
          |{
          |"name": "ZAP.ZIO_Openen_Afwijzen_MSG",
          |"id": 177266
          |},
          |{
          |"name": "ZAP.SDS_Zak_Spoed_MSG",
          |"id": 176352
          |},
          |{
          |"name": "ZAP.Lenen_CV_Alg_Mail_MSG",
          |"id": 176548
          |},
          |{
          |"name": "Col.sec_Zakelijk.1",
          |"id": 26062
          |},
          |{
          |"name": "ZAP.KVC_Coll_Verrekenen_MSG",
          |"id": 176360
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_OHO_MSG",
          |"id": 178299
          |},
          |{
          |"name": "PBW.ZW-team2_Rotterdam.1",
          |"id": 129326
          |},
          |{
          |"name": "KYC.RSPE-Regulier.1",
          |"id": 52314
          |},
          |{
          |"name": "KYC.ProjectCO-Team5.0",
          |"id": 167357
          |},
          |{
          |"name": "KYC.RSPE-PTM_MassEnhancement.0",
          |"id": 76252
          |},
          |{
          |"name": "OTW.Online.1",
          |"id": 45350
          |},
          |{
          |"name": "FRD.Fraud_Payments.0",
          |"id": 140354
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Nw_Spin_MSG",
          |"id": 169261
          |},
          |{
          |"name": "ZAP.Vraagbaak_Starting",
          |"id": 104253
          |},
          |{
          |"name": "ZAP.KVC_CZ_TS2_Aanvr_TMS_MSG",
          |"id": 176530
          |},
          |{
          |"name": "WUB.Risk_CAL.2",
          |"id": 120300
          |},
          |{
          |"name": "PBW.NO-team_Debet.1",
          |"id": 128256
          |},
          |{
          |"name": "HYP.app.0",
          |"id": 192353
          |},
          |{
          |"name": "ZAP.KVC_CZ_MLRO_MSG",
          |"id": 176529
          |},
          |{
          |"name": "ZAP.SDN_Coulance_SAO_MSG",
          |"id": 165414
          |},
          |{
          |"name": "ZAP.KVC_AP_Klacht_MSG",
          |"id": 176489
          |},
          |{
          |"name": "ZAP.ZBI_Fallback_MSG",
          |"id": 173411
          |},
          |{
          |"name": "ZAP.Kansrijk_Doorverbinden.0",
          |"id": 65263
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Derisk_MSG",
          |"id": 177259
          |},
          |{
          |"name": "HYP.zekerheden.1",
          |"id": 31117
          |},
          |{
          |"name": "FRD.Fraud_Payments.1",
          |"id": 140304
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag4_Fiat_OP_MSG",
          |"id": 173319
          |},
          |{
          |"name": "LEN.Taskforce_HRCK.1",
          |"id": 406
          |},
          |{
          |"name": "ZAP.Enticement_Verzekeren.0",
          |"id": 145363
          |},
          |{
          |"name": "ZAP.SDS_Part_Beheer_MSG",
          |"id": 165309
          |},
          |{
          |"name": "HYP.pilotnummer3.1",
          |"id": 36101
          |},
          |{
          |"name": "ZAP.Lenen_KL_Klachten_MSG",
          |"id": 176447
          |},
          |{
          |"name": "HYP.aanvragen_CLT03.1",
          |"id": 32104
          |},
          |{
          |"name": "HYP.scheiden_notaris.0",
          |"id": 32134
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag1_Fiat_MSG",
          |"id": 173261
          |},
          |{
          |"name": "FRD.CREDIT_Fallback_MSG",
          |"id": 171314
          |},
          |{
          |"name": "BELL.Opheffen.2",
          |"id": 30453
          |},
          |{
          |"name": "HYP.aflossen.1",
          |"id": 31116
          |},
          |{
          |"name": "PBW.PWAM-team06.1",
          |"id": 129315
          |},
          |{
          |"name": "ZAP.Zakelijk_Events.1",
          |"id": 35405
          |},
          |{
          |"name": "ZAP.KVC_AP_Cre_Uitz_Spin_MSG",
          |"id": 176544
          |},
          |{
          |"name": "ZAP.ZBI_Print_kantoor_MSG",
          |"id": 192410
          |},
          |{
          |"name": "KYC.ZKL-Onboarding.0",
          |"id": 47452
          |},
          |{
          |"name": "FRD.PAYSUP_EVA_IVA_MSG",
          |"id": 170256
          |},
          |{
          |"name": "KAP.aanvragen_1ste_lijn_CMN.1",
          |"id": 358
          |},
          |{
          |"name": "ZAP.Bewind_Cur_Eenvoudig_MSG",
          |"id": 98252
          |},
          |{
          |"name": "HYP.geldverkeer.0",
          |"id": 32151
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Regulier_MSG",
          |"id": 158256
          |},
          |{
          |"name": "OTW.Intake.0",
          |"id": 45250
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Zak_Wacht_MSG",
          |"id": 179252
          |},
          |{
          |"name": "Digital20.teleopti",
          |"id": 176441
          |},
          |{
          |"name": "ZAP.Helpdesk_SCA.1",
          |"id": 122250
          |},
          |{
          |"name": "KYC.ProjectCO-Team6.1",
          |"id": 167317
          |},
          |{
          |"name": "ZAP.ZBI_PPC_of_OAB_Oph_MSG",
          |"id": 173271
          |},
          |{
          |"name": "HYP.pilotnummer6.1",
          |"id": 39852
          |},
          |{
          |"name": "KYC.ProjectCO-Team3.0",
          |"id": 167314
          |},
          |{
          |"name": "PBW.NW-team_Noord-Holland.1",
          |"id": 129266
          |},
          |{
          |"name": "KYC.LBK-Alerts.0",
          |"id": 52310
          |},
          |{
          |"name": "ZAP.ZIO_Openen_Enhanced_MSG",
          |"id": 177263
          |},
          |{
          |"name": "HYP.cct2.2",
          |"id": 192413
          |},
          |{
          |"name": "HYP.aanvraag.2",
          |"id": 31101
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Basis_MSG",
          |"id": 150259
          |},
          |{
          |"name": "FRD.Detection_CreditCard.1",
          |"id": 141250
          |},
          |{
          |"name": "ZAP.ASOM_FEBO_MSG",
          |"id": 176450
          |},
          |{
          |"name": "HYP.OmniHub.1",
          |"id": 53450
          |},
          |{
          |"name": "FRD.JUR_Algemeen_vragen_MSG",
          |"id": 171257
          |},
          |{
          |"name": "ZAP.SLK-Particulieren.0",
          |"id": 35352
          |},
          |{
          |"name": "Digital20",
          |"id": 29100
          |},
          |{
          |"name": "ADV.Inbound.lead.0",
          |"id": 49250
          |},
          |{
          |"name": "HYP.pilotnummer4.2",
          |"id": 39601
          |},
          |{
          |"name": "ZAP.Lenen_Moni_Algemeen_MSG",
          |"id": 157308
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam5.2",
          |"id": 166260
          |},
          |{
          |"name": "ZAP.KVC_Coll_Stornolijst_MSG",
          |"id": 176514
          |},
          |{
          |"name": "HYP.aflossen.0",
          |"id": 32124
          |},
          |{
          |"name": "OTW.Online.0",
          |"id": 45301
          |},
          |{
          |"name": "LEN.BCC_Starters.2",
          |"id": 159268
          |},
          |{
          |"name": "ZAP.SDN_Coulance_Beheer_MSG",
          |"id": 165411
          |},
          |{
          |"name": "KYC.ProjectCO-Team1.0",
          |"id": 166261
          |},
          |{
          |"name": "ZAP.Webhelp_Navraag_MING.0",
          |"id": 36154
          |},
          |{
          |"name": "LEN.Taskforce_JO-INA.1",
          |"id": 462
          |},
          |{
          |"name": "ZAP.Betalen_Vergoedingstaat.0",
          |"id": 79356
          |},
          |{
          |"name": "KYC.EHMT-Team1.1",
          |"id": 52402
          |},
          |{
          |"name": "ZAP.ASOM_Sparen_Pensioen_MSG",
          |"id": 165407
          |},
          |{
          |"name": "LEN.Adviseur_Zakelijk.2",
          |"id": 74363
          |},
          |{
          |"name": "ZAP.KVC_BC_Beheer_Spoed_MSG",
          |"id": 176474
          |},
          |{
          |"name": "ZAP.KVC_AP_Overrules_MSG",
          |"id": 176440
          |},
          |{
          |"name": "ZAP.ASOM_Incassovolmachten_MSG",
          |"id": 165353
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Wachtbak_MSG",
          |"id": 180302
          |},
          |{
          |"name": "ADV.Inbound.lead.1",
          |"id": 49251
          |},
          |{
          |"name": "ZAP.SDN_Coulance_WOL_MSG",
          |"id": 150305
          |},
          |{
          |"name": "LEN.TA-desk.2",
          |"id": 33102
          |},
          |{
          |"name": "ZAP.ZIO_Spoed_Opvoeren_VW_MSG",
          |"id": 177265
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Squad_Afw_MSG",
          |"id": 178256
          |},
          |{
          |"name": "ZAP.Betalen_Betalen_R.0",
          |"id": 157250
          |},
          |{
          |"name": "HYP.aanvraag.0",
          |"id": 32100
          |},
          |{
          |"name": "HYP.aanvragen_CLT06.2",
          |"id": 32110
          |},
          |{
          |"name": "PBW.ZW-team2_DenHaag.0",
          |"id": 129277
          |},
          |{
          |"name": "ZAP.ZBI_Bankverk_SBV_MSG",
          |"id": 173407
          |},
          |{
          |"name": "ZAP.ZIO_Koppelen_Honeymoon_MSG",
          |"id": 178308
          |},
          |{
          |"name": "PBW.PWAM-team04.1",
          |"id": 129365
          |},
          |{
          |"name": "ZAP.ZBI_G_Open_Verw_Dag1_MSG",
          |"id": 173355
          |},
          |{
          |"name": "ZAP.BSLK_Hypotheken_MSG",
          |"id": 169355
          |},
          |{
          |"name": "FRD.PAY_1e_km_fraude_MSG",
          |"id": 170259
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Oud_ZStap1_MSG",
          |"id": 169265
          |},
          |{
          |"name": "ZAP.KVC_BP_Omzetting_CC_MSG",
          |"id": 176532
          |},
          |{
          |"name": "ZAP.Cards.0",
          |"id": 35458
          |},
          |{
          |"name": "KAP.PBW_Beheer.0",
          |"id": 159259
          |},
          |{
          |"name": "ZAP.SDS_Zak_Opheffen_MSG",
          |"id": 165311
          |},
          |{
          |"name": "ZAP.ZBI_Waterspin_PPC_OABC_MSG",
          |"id": 173409
          |},
          |{
          |"name": "FRD.Wholesale_Support.0",
          |"id": 47553
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Basis_MSG",
          |"id": 157357
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam4.0",
          |"id": 143253
          |},
          |{
          |"name": "ZAP.BSLK_Betpas_Saldolijn_MSG",
          |"id": 182350
          |},
          |{
          |"name": "WUB.Actuariaat_CAL.0",
          |"id": 119352
          |},
          |{
          |"name": "ZAP.Betaalpassen.1",
          |"id": 35457
          |},
          |{
          |"name": "HYP.connect_acquisitie.2",
          |"id": 32200
          |},
          |{
          |"name": "PBW.ZO-team2_DenBosch.0",
          |"id": 128269
          |},
          |{
          |"name": "ZAP.KVC_COLL_Mail_Faill_MSG",
          |"id": 192403
          |},
          |{
          |"name": "ZAP.Helpdesk.0",
          |"id": 35450
          |},
          |{
          |"name": "ZAP.Events_OrangeCarpet.0",
          |"id": 95250
          |},
          |{
          |"name": "ZAP.KVC_BP_Adreswijziging_MSG",
          |"id": 176481
          |},
          |{
          |"name": "KYC.PBW-NO.0",
          |"id": 144350
          |},
          |{
          |"name": "KYC.EHMT-Team7.1",
          |"id": 73402
          |},
          |{
          |"name": "ZAP.Webhelp_Ervaren_Medewrkr.1",
          |"id": 36156
          |},
          |{
          |"name": "HYP.zekerheden_notaris.1",
          |"id": 31121
          |},
          |{
          |"name": "HYP.tra.2",
          |"id": 32132
          |},
          |{
          |"name": "KAP.Aanvragen_FastFinance_MSG",
          |"id": 89366
          |},
          |{
          |"name": "ZAP.Betalen_Opheffen.1",
          |"id": 47503
          |},
          |{
          |"name": "ZAP.Webhelp_Navraag_MING.1",
          |"id": 36103
          |},
          |{
          |"name": "KYC.EHMT-Team14.1",
          |"id": 73354
          |},
          |{
          |"name": "PBW.NO-team_Noord-Nederland.0",
          |"id": 129353
          |},
          |{
          |"name": "ZAP.Lenen_CMN.0",
          |"id": 110250
          |},
          |{
          |"name": "KAP.Beheer_Actualisatie_MSG",
          |"id": 90252
          |},
          |{
          |"name": "FRD.Fraud_CreditCards.1",
          |"id": 141252
          |},
          |{
          |"name": "ZAP.ZIO_Open_Extra_ZR_Rek_MSG",
          |"id": 178354
          |},
          |{
          |"name": "PBW-ACM-NO-Deafult.0",
          |"id": 129281
          |},
          |{
          |"name": "ZAP.SDS_Part_Opheffen_MSG",
          |"id": 165259
          |},
          |{
          |"name": "HYP.aanvraag_notaris.2",
          |"id": 32120
          |},
          |{
          |"name": "HYP.aanvragen_CLT05.2",
          |"id": 32107
          |},
          |{
          |"name": "FRD.PAYSUP_Afstandsverkl_MSG",
          |"id": 172251
          |},
          |{
          |"name": "PBW.ZW-team1_Rotterdam.1",
          |"id": 128271
          |},
          |{
          |"name": "FRD.HYP_Hitmeldingen_MSG",
          |"id": 170262
          |},
          |{
          |"name": "Col.uns_Behoud.1",
          |"id": 26108
          |},
          |{
          |"name": "PBW.ZO-team_ZO-Debet.1",
          |"id": 129275
          |},
          |{
          |"name": "ZAP.BenF_Spoed_meerdere_MSG",
          |"id": 166256
          |},
          |{
          |"name": "KYC.ProjectCO-Team2.0",
          |"id": 166263
          |},
          |{
          |"name": "HYP.pilotnummer2.1",
          |"id": 31141
          |},
          |{
          |"name": "ZAP.BetalenTBIC.1",
          |"id": 40354
          |},
          |{
          |"name": "KYC.GZ-Trade_Retail_Industry.0",
          |"id": 87252
          |},
          |{
          |"name": "WUB.Finance_CAL.1",
          |"id": 119354
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spe_Hypo_MSG",
          |"id": 150260
          |},
          |{
          |"name": "BELL.Beleggen_SelectFund.0",
          |"id": 149251
          |},
          |{
          |"name": "HYP.hsp.pilot.2",
          |"id": 31132
          |},
          |{
          |"name": "ZAP.Cards.1",
          |"id": 35357
          |},
          |{
          |"name": "ZAP.KVC_CZ_Contr_Company_MSG",
          |"id": 176426
          |},
          |{
          |"name": "ZAP.Lenen_CV_Algemeen_Fiat_MSG",
          |"id": 157353
          |},
          |{
          |"name": "ZAP.KVC_FZ_Perio_Smartdata_MSG",
          |"id": 176469
          |},
          |{
          |"name": "LEN.Wijzigen.2",
          |"id": 389
          |},
          |{
          |"name": "KYC.ZKL-Review.1",
          |"id": 52363
          |},
          |{
          |"name": "ZAP.ZBI_PPC_of_OAB_Wijz_MSG",
          |"id": 173324
          |},
          |{
          |"name": "KAP.PBW_Beheer.1",
          |"id": 159306
          |},
          |{
          |"name": "HYP.cct2.0",
          |"id": 192312
          |},
          |{
          |"name": "ZAP.KVC_AP_PEGA_Limiet_MSG",
          |"id": 176384
          |},
          |{
          |"name": "KYC.CAM-OverigeSignalen.1",
          |"id": 52410
          |},
          |{
          |"name": "HYP.aanvraag_notaris.0",
          |"id": 32119
          |},
          |{
          |"name": "ZAP.BSLK_Lijstopdrachten_MSG",
          |"id": 169306
          |},
          |{
          |"name": "LEN.Grootzakelijk_PPW.2",
          |"id": 365
          |},
          |{
          |"name": "ZAP.ASOM_Persoonsgeg_Wijz_MSG",
          |"id": 165303
          |},
          |{
          |"name": "HYP.pilotnummer4.0",
          |"id": 39600
          |},
          |{
          |"name": "ZAP.BSLK_Openen_Kop_Fiat_MSG",
          |"id": 169260
          |},
          |{
          |"name": "KYC.PBW-ZO.0",
          |"id": 144351
          |},
          |{
          |"name": "PBW-ACM-ZO-Default.0",
          |"id": 129285
          |},
          |{
          |"name": "ZAP.ASOM_Sparen_Oud_Prod_MSG",
          |"id": 165304
          |},
          |{
          |"name": "KYC.GZ-Trnsprt_Lgstcs_Srvcs.1",
          |"id": 89250
          |},
          |{
          |"name": "ZAP.BenF_Faill_Opheffingen_MSG",
          |"id": 167310
          |},
          |{
          |"name": "ZAP.BenF_Faill_Beheer_MSG",
          |"id": 167309
          |},
          |{
          |"name": "ZAP.SDN_Coulance_BOD_MSG",
          |"id": 165258
          |},
          |{
          |"name": "FRD.JUR_126NDA_Uitleveren_MSG",
          |"id": 172256
          |},
          |{
          |"name": "HYP.aanvragen_CLT08.2",
          |"id": 32113
          |},
          |{
          |"name": "HYP.Concreet-Zakelijk.0",
          |"id": 54251
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Fiat_Regu_MSG",
          |"id": 177252
          |},
          |{
          |"name": "PBW.PWAM-team03.0",
          |"id": 129269
          |},
          |{
          |"name": "ZAP.Helpdesk_Zak_SCA.1",
          |"id": 120307
          |},
          |{
          |"name": "ZAP.Betaalpassen.TeleOpti",
          |"id": 145362
          |},
          |{
          |"name": "LEN.Krediet_Klantbeheer_2.0",
          |"id": 74275
          |},
          |{
          |"name": "KAP.Aanvragen_Regulier_MSG",
          |"id": 91252
          |},
          |{
          |"name": "ZAP.ZBI_Klachten_KING_VVR_MSG",
          |"id": 173250
          |},
          |{
          |"name": "ZAP.SDN_Coulance_OHO_MSG",
          |"id": 165357
          |},
          |{
          |"name": "ZAP.IBP_BEW_Exit_Afr_MSG",
          |"id": 197256
          |},
          |{
          |"name": "Business",
          |"id": 5
          |},
          |{
          |"name": "FRD.Fraud_Bezwaren.1",
          |"id": 140352
          |},
          |{
          |"name": "BELL.Opties.1",
          |"id": 30351
          |},
          |{
          |"name": "FRD.HYP_Force_MSG",
          |"id": 172260
          |},
          |{
          |"name": "ZAP.ZBI_G_Ophef_Fiat_Dag3_MSG",
          |"id": 173307
          |},
          |{
          |"name": "ZAP.ZBI_Waterspin_Ophef_OP_MSG",
          |"id": 173317
          |},
          |{
          |"name": "LEN.Audits-Systems.2",
          |"id": 401
          |},
          |{
          |"name": "FRD.CREDIT_Mastercard_MSG",
          |"id": 172269
          |},
          |{
          |"name": "ZAP.KVC_FZ_Jaar_GSD_MSG",
          |"id": 176468
          |},
          |{
          |"name": "ZAP.KIA.1",
          |"id": 36151
          |},
          |{
          |"name": "ZAP.Lenen_CV_Alg_Fraude_MSG",
          |"id": 158251
          |},
          |{
          |"name": "HYP.FGI.2",
          |"id": 32122
          |},
          |{
          |"name": "ZAP.ZBI_OAC_Aanv_MSG",
          |"id": 173325
          |},
          |{
          |"name": "WUB.Actuariaat_CAL.1",
          |"id": 119353
          |},
          |{
          |"name": "ZAP.KVC_BP_Wijz_Reknummer_MSG",
          |"id": 176429
          |},
          |{
          |"name": "HYP.cmis.2",
          |"id": 39753
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Aanvr_Fiat_MSG",
          |"id": 178302
          |},
          |{
          |"name": "LEN.Krediet_Klantbeheer.0",
          |"id": 74415
          |},
          |{
          |"name": "KYC.EHMT-Team7.0",
          |"id": 73355
          |},
          |{
          |"name": "KYC.EHMT-Team3.1",
          |"id": 52403
          |},
          |{
          |"name": "HYP.FGI.1",
          |"id": 31114
          |},
          |{
          |"name": "ZAP.Thuiswerk_Helpdesk.1",
          |"id": 159258
          |},
          |{
          |"name": "ZAP.ZIO_Waterspin_Open_Ext_MSG",
          |"id": 177267
          |},
          |{
          |"name": "BELL.Overstapservice.0",
          |"id": 30305
          |},
          |{
          |"name": "HYP.zekerheden.2",
          |"id": 32127
          |},
          |{
          |"name": "ZAP.ZBI_IBP_Monitoren_MSG",
          |"id": 173410
          |},
          |{
          |"name": "ZAP.ASOM_Sparen_Complex_MSG",
          |"id": 165356
          |},
          |{
          |"name": "HYP.pilotnummer3.2",
          |"id": 36102
          |},
          |{
          |"name": "ZAP.RR-Bewinden.0",
          |"id": 35203
          |},
          |{
          |"name": "HYP.herstructureren.2",
          |"id": 32157
          |},
          |{
          |"name": "PBW.ZO-team_Limburg.1",
          |"id": 129370
          |},
          |{
          |"name": "ZAP.BetalenSparenIVR.1",
          |"id": 40306
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag4_Verw_OP_MSG",
          |"id": 173318
          |},
          |{
          |"name": "Col.sec_Behoud_2de_lijn.0",
          |"id": 26101
          |},
          |{
          |"name": "KYC.RSPE-MassEnhancement.0",
          |"id": 52359
          |},
          |{
          |"name": "ZAP.IBP_BEW_Spin_MSG",
          |"id": 197253
          |},
          |{
          |"name": "KYC.ProjectCO-Team1.1",
          |"id": 166262
          |},
          |{
          |"name": "BELL.Beleggen.1",
          |"id": 30350
          |},
          |{
          |"name": "ZAP.RR-Bewinden.1",
          |"id": 35250
          |},
          |{
          |"name": "ZAP.ZBI_Vertegenwoordigers_MSG",
          |"id": 173268
          |},
          |{
          |"name": "PBW.PWAM-team10.0",
          |"id": 129317
          |},
          |{
          |"name": "LEN.Audits-Systems.0",
          |"id": 399
          |},
          |{
          |"name": "HYP.herstructureren.1",
          |"id": 32156
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Fiat_Exp_MSG",
          |"id": 176496
          |},
          |{
          |"name": "FRD.PAY_BLOK_Waterspin_MSG",
          |"id": 170264
          |},
          |{
          |"name": "KYC.ProjectCO-Team3.1",
          |"id": 167269
          |},
          |{
          |"name": "LEN.Wijzigen.0",
          |"id": 387
          |},
          |{
          |"name": "ZAP.Vraagbaak_Events",
          |"id": 103302
          |},
          |{
          |"name": "ZAP.Volmacht_Spin_MSG",
          |"id": 98254
          |},
          |{
          |"name": "FRD.DECT_Creditcards_MSG",
          |"id": 172262
          |},
          |{
          |"name": "HYP.aanvragen_CLT09.2",
          |"id": 32115
          |},
          |{
          |"name": "HYP.hulpdienst.2",
          |"id": 32136
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_KING_MSG",
          |"id": 180250
          |},
          |{
          |"name": "PBW.PWAM-team07.1",
          |"id": 129272
          |},
          |{
          |"name": "ZAP.KVC_BC_Aanvr_Post_MSG",
          |"id": 176526
          |},
          |{
          |"name": "ZAP.BenF_Conservatoir_MSG",
          |"id": 192402
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Expert_MSG",
          |"id": 157359
          |},
          |{
          |"name": "ZAP.KIA_Incident_Spoed_MSG",
          |"id": 167253
          |},
          |{
          |"name": "PBW.ZW-team1_WMBZ.1",
          |"id": 128272
          |},
          |{
          |"name": "KYC.EHMT-TeamTrust.0",
          |"id": 52256
          |},
          |{
          |"name": "BELL.Events_Overig.2",
          |"id": 30452
          |},
          |{
          |"name": "ZAP.SDS_Priba_MSG",
          |"id": 165417
          |},
          |{
          |"name": "ZAP.ASOM_Spec_Bezorgd_MSG",
          |"id": 165305
          |},
          |{
          |"name": "Social",
          |"id": 61340
          |},
          |{
          |"name": "ZAP.Helpdesk_TAN.0",
          |"id": 46253
          |},
          |{
          |"name": "ZAP.Betalen_Rest.1",
          |"id": 47454
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_Zwitserl_MSG",
          |"id": 176518
          |},
          |{
          |"name": "KYC.EHMT-Team3.0",
          |"id": 52307
          |},
          |{
          |"name": "ZAP.Thuiswerk_Helpdesk.0",
          |"id": 159257
          |},
          |{
          |"name": "HYP.cct2.1",
          |"id": 192354
          |},
          |{
          |"name": "KYC.EHMT-Team2.1",
          |"id": 52253
          |},
          |{
          |"name": "PBW.PWAM-team10.1",
          |"id": 129318
          |},
          |{
          |"name": "KYC.PBW-NW.0",
          |"id": 144250
          |},
          |{
          |"name": "KYC.EHMT-Team1.0",
          |"id": 52252
          |},
          |{
          |"name": "LEN.TA-desk.1",
          |"id": 33201
          |},
          |{
          |"name": "Col.sec_Behoud_1ste_lijn.1",
          |"id": 26105
          |},
          |{
          |"name": "ZAP.KV-Cards_CorporateCards.1",
          |"id": 150312
          |},
          |{
          |"name": "ADV.Concreet-Zakelijk.1",
          |"id": 47402
          |},
          |{
          |"name": "HYP.Aflosvrij.1",
          |"id": 56251
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam1.0",
          |"id": 144352
          |},
          |{
          |"name": "ZAP.ASOM_Adressen_MSG",
          |"id": 165352
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spe_Spar_MSG",
          |"id": 149259
          |},
          |{
          |"name": "HYP.scheiden.2",
          |"id": 31126
          |},
          |{
          |"name": "FRD.Fraud_Payment_Support.1",
          |"id": 141255
          |},
          |{
          |"name": "ZAP.Betalen_Betaalpas.0",
          |"id": 193258
          |},
          |{
          |"name": "ZAP.KIA_Incident_Mobiel_P_MSG",
          |"id": 167302
          |},
          |{
          |"name": "PBW.NO-team2_Zwolle.0",
          |"id": 129357
          |},
          |{
          |"name": "PBW.PWAM-KM.1",
          |"id": 188300
          |},
          |{
          |"name": "ZAP.Helpdesk_App_Activeren.0",
          |"id": 108250
          |},
          |{
          |"name": "ZAP.ZBI_Zak_Ondersteuning_MSG",
          |"id": 173313
          |},
          |{
          |"name": "ZAP.Kansrijk_Doorverbinden.1",
          |"id": 64276
          |},
          |{
          |"name": "WUB.Special_Cases_CAL.1",
          |"id": 118255
          |},
          |{
          |"name": "FRD.DECT_Beg_MIP_of_Vrij_MSG",
          |"id": 171265
          |},
          |{
          |"name": "PBW.ZW-team_ZW_Leiden.1",
          |"id": 129373
          |},
          |{
          |"name": "ZAP.Lenen_Moni_Klachten_MSG",
          |"id": 158255
          |},
          |{
          |"name": "ZAP.SDS_Part_Nieuw_MSG",
          |"id": 165415
          |},
          |{
          |"name": "FRD.DECT_CTI_MSG",
          |"id": 170267
          |},
          |{
          |"name": "HYP.aanvraag.1",
          |"id": 32101
          |},
          |{
          |"name": "ZAP.KVC_Coll_Retourpost_MSG",
          |"id": 176359
          |},
          |{
          |"name": "HYP.Concreet-Particulier.2",
          |"id": 53407
          |},
          |{
          |"name": "ZAP.ASOM_Rechtsvorm_Vragen_MSG",
          |"id": 197257
          |},
          |{
          |"name": "ZAP.IBP_BEW_Aanm_Contract_MSG",
          |"id": 195258
          |},
          |{
          |"name": "ADV.Online-Zakelijk.0",
          |"id": 47306
          |},
          |{
          |"name": "HYP.zekerheden.0",
          |"id": 32126
          |},
          |{
          |"name": "ZAP.RR-Beslagen.0",
          |"id": 35202
          |},
          |{
          |"name": "LEN.Risicobeheer_1.2",
          |"id": 371
          |},
          |{
          |"name": "KYC.ProjectCO-Team6.0",
          |"id": 166264
          |},
          |{
          |"name": "VER.Vermogen.0",
          |"id": 163250
          |},
          |{
          |"name": "ZAP.ZAE_Payvision_MSG",
          |"id": 179259
          |},
          |{
          |"name": "ZAP.SDN_Coulance_TBO_MSG",
          |"id": 165255
          |},
          |{
          |"name": "ZAP.BSLK_Mach_Aanmeld_Fiat_MSG",
          |"id": 169358
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_DDSrapport_MSG",
          |"id": 176466
          |},
          |{
          |"name": "KYC.GZ-Taskforce_Remediation.0",
          |"id": 87301
          |},
          |{
          |"name": "BELL.Campagne.2",
          |"id": 30307
          |},
          |{
          |"name": "HYP.aanvragen_CLT03.2",
          |"id": 32105
          |},
          |{
          |"name": "HYP.omzetten.2",
          |"id": 31123
          |},
          |{
          |"name": "ZAP.Rentepunten.1",
          |"id": 35453
          |},
          |{
          |"name": "ZAP.ZIO_CF_Restituties_MSG",
          |"id": 178356
          |},
          |{
          |"name": "HYP.cct1.0",
          |"id": 159303
          |},
          |{
          |"name": "BELL.Beleggen_Eenvoudig.1",
          |"id": 149253
          |},
          |{
          |"name": "FRD.DECT_RSA_MSG",
          |"id": 172265
          |},
          |{
          |"name": "ZAP.KVC_AP_Kantoor_Charge_MSG",
          |"id": 176538
          |},
          |{
          |"name": "HYP.beleggershypotheek.0",
          |"id": 39800
          |},
          |{
          |"name": "KYC.RSPE-SpecialsRegulier.0",
          |"id": 52261
          |},
          |{
          |"name": "FRD.PAY_BLOK_1e_km_ING_MSG",
          |"id": 171307
          |},
          |{
          |"name": "KYC.LBK-Uitl-bevelen_Uitloop.1",
          |"id": 52260
          |},
          |{
          |"name": "HYP.hsp_beheer.1",
          |"id": 32145
          |},
          |{
          |"name": "ZAP.ASOM_Afschriften_MSG",
          |"id": 165402
          |},
          |{
          |"name": "KYC.ProjectCO-Team4.0",
          |"id": 167270
          |},
          |{
          |"name": "KAP.Fallback_MSG",
          |"id": 86353
          |},
          |{
          |"name": "ZAP.KIA_Koerier_Binnenland_MSG",
          |"id": 180304
          |},
          |{
          |"name": "KYC.INV-LIMA.1",
          |"id": 145404
          |},
          |{
          |"name": "Col.sec_Financiele_Afwikk.1",
          |"id": 26058
          |},
          |{
          |"name": "KYC.PBW-General.0",
          |"id": 52354
          |},
          |{
          |"name": "ZAP.Betaalpassen.0",
          |"id": 35456
          |},
          |{
          |"name": "ZAP.KVC_BP_BKR_uitval_MSG",
          |"id": 176482
          |},
          |{
          |"name": "PBW.NO-team_Apeldrn-Achterh.0",
          |"id": 129307
          |},
          |{
          |"name": "PBW.PWAM-team08.0",
          |"id": 128265
          |},
          |{
          |"name": "ZAP.KVC_BC_Beheer_MSG",
          |"id": 176472
          |},
          |{
          |"name": "ZAP.SLK-Particulieren.1",
          |"id": 35353
          |},
          |{
          |"name": "ZAP.SDN_CMN.1",
          |"id": 110301
          |},
          |{
          |"name": "ZAP.ZIO_Openen_Stan_Ret_MSG",
          |"id": 178352
          |},
          |{
          |"name": "ZAP.KVC_FZ_Spin_MSG",
          |"id": 176412
          |},
          |{
          |"name": "ZAP.Lenen_KL_Uitval_MSG",
          |"id": 176393
          |},
          |{
          |"name": "HYP.hsp_beheer.2",
          |"id": 32146
          |},
          |{
          |"name": "KYC.CAM-PTM_MKB.0",
          |"id": 52316
          |},
          |{
          |"name": "Col.sec_Afscheid.0",
          |"id": 26050
          |},
          |{
          |"name": "ZAP.BenF_Besl_Opheffing_MSG",
          |"id": 167255
          |},
          |{
          |"name": "FRD.PAYSUP_Navraag_bank_Al_MSG",
          |"id": 172252
          |},
          |{
          |"name": "ZAP.BenF_Fallback_MSG",
          |"id": 167261
          |},
          |{
          |"name": "WUB.Secretaresse_CAL.0",
          |"id": 119306
          |},
          |{
          |"name": "HYP.pilotnummer1.0",
          |"id": 31145
          |},
          |{
          |"name": "ZAP.Bewind_Spo_MSG",
          |"id": 159353
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Aanvr_Beo_MSG",
          |"id": 177256
          |},
          |{
          |"name": "ZAP.KVC_Coll_Over_queues_MSG",
          |"id": 176464
          |},
          |{
          |"name": "ZAP.SDN_Coulance_1eMelding_MSG",
          |"id": 165307
          |},
          |{
          |"name": "PBW.NW-team_NW-Debet.1",
          |"id": 128263
          |},
          |{
          |"name": "ZAP.SDN_Algemeen.0",
          |"id": 35151
          |},
          |{
          |"name": "LEN.Loyalty-Retentie.0",
          |"id": 390
          |},
          |{
          |"name": "KYC.GZ-Specials.0",
          |"id": 87351
          |},
          |{
          |"name": "ZAP.ZIO_CF_Fin_Stornos_MSG",
          |"id": 177269
          |},
          |{
          |"name": "LEN.Hypotheken.2",
          |"id": 386
          |},
          |{
          |"name": "ZAP.KVC_BP_Beheer_Spin_MSG",
          |"id": 176427
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Nw_ZStap1_MSG",
          |"id": 169402
          |},
          |{
          |"name": "LEN.Loyalty-Retentie.1",
          |"id": 391
          |},
          |{
          |"name": "HYP.cct1.2",
          |"id": 159305
          |},
          |{
          |"name": "ZAP.KVC_BP_Pre_Blokkade_MSG",
          |"id": 176432
          |},
          |{
          |"name": "ZAP.Continuelimiet.0",
          |"id": 62500
          |}]
          |}
        """.stripMargin


      val ts2 =
        """
          |{"data":[{
          |"name": "ZAP.ZBI_Ophef_Dag1_Verw_OP_MSG",
          |"id": 173267
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zorgeloos_MSG",
          |"id": 157306
          |},
          |{
          |"name": "KYC.GZ-Specials.1",
          |"id": 87254
          |},
          |{
          |"name": "ZAP.ZBI_Adressen_Wijz_MSG",
          |"id": 173314
          |},
          |{
          |"name": "ZAP.ZAE_CSDB_Payvision_MSG",
          |"id": 179258
          |},
          |{
          |"name": "ZAP.Sparen.1",
          |"id": 52416
          |},
          |{
          |"name": "ZAP.ZBI_Waterspin_VVR_MSG",
          |"id": 173401
          |},
          |{
          |"name": "HYP.connect_acquisitie.0",
          |"id": 31149
          |},
          |{
          |"name": "ZAP.KVC_AP_Cre_Klacht_Spin_MSG",
          |"id": 176382
          |},
          |{
          |"name": "HYP.pilotnummer4.1",
          |"id": 39650
          |},
          |{
          |"name": "ZAP.ASOM_Betaalrek_Openen_MSG",
          |"id": 165302
          |},
          |{
          |"name": "ZAP.Bewind_Kla_MSG",
          |"id": 159352
          |},
          |{
          |"name": "ZAP.KVC_FZ_Verz_Overig_MSG",
          |"id": 176517
          |},
          |{
          |"name": "PBW.NW-team_Midden_Nederland.1",
          |"id": 129361
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Buit_land_MSG",
          |"id": 178297
          |},
          |{
          |"name": "ZAP.ZIO_MINGZ_Ontvang_MSG",
          |"id": 192408
          |},
          |{
          |"name": "ZAP.Bewind_Cur_MSG",
          |"id": 98253
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam1.1",
          |"id": 144254
          |},
          |{
          |"name": "ZAP.Zakl_Helpdsk_ING_Scanner.1",
          |"id": 104251
          |},
          |{
          |"name": "FRD.JUR_126ND_MSG",
          |"id": 171255
          |},
          |{
          |"name": "ZAP.BetalenAfschriften.1",
          |"id": 40308
          |},
          |{
          |"name": "HYP.pilotnummer6.2",
          |"id": 39701
          |},
          |{
          |"name": "ZAP.KIA_Incident_Vragen_MSG",
          |"id": 166254
          |},
          |{
          |"name": "LEN.Actualisatie.2",
          |"id": 377
          |},
          |{
          |"name": "KYC.INV-Investigations.0",
          |"id": 52406
          |},
          |{
          |"name": "ZAP.Webhelp_Ervaren_Medewrkr.0",
          |"id": 36155
          |},
          |{
          |"name": "ZAP.ZBI_Acquiring_Veri_MSG",
          |"id": 173323
          |},
          |{
          |"name": "KAP.PBW_Service.0",
          |"id": 159354
          |},
          |{
          |"name": "ZAP.ZBI_OAC_Screening_MSG",
          |"id": 173322
          |},
          |{
          |"name": "ZAP.ZBI_G_Ophef_Verw_Dag3_MSG",
          |"id": 173404
          |},
          |{
          |"name": "ZAP.SLK-WijzigenEnBetaalpas.1",
          |"id": 35459
          |},
          |{
          |"name": "ZAP.KVC_BP_Diversen_MSG",
          |"id": 176480
          |},
          |{
          |"name": "LEN.Actualisatie.1",
          |"id": 376
          |},
          |{
          |"name": "Col.sec_Behoud_1ste_lijn.0",
          |"id": 26051
          |},
          |{
          |"name": "ZAP.BSLK_Fallback_MSG",
          |"id": 169362
          |},
          |{
          |"name": "Col.uns_Insolventie.1",
          |"id": 26063
          |},
          |{
          |"name": "KYC.PBW-ZO.1",
          |"id": 144301
          |},
          |{
          |"name": "KYC.ProjectCO-Team1.2",
          |"id": 167268
          |},
          |{
          |"name": "LEN.Krediet_Klantbeheer_1.0",
          |"id": 74416
          |},
          |{
          |"name": "ZAP.Helpdesk-2de-lijn.1",
          |"id": 35452
          |},
          |{
          |"name": "LEN.Taskforce_HRCK.0",
          |"id": 405
          |},
          |{
          |"name": "ADV.Concreet-Zakelijk.0",
          |"id": 47254
          |},
          |{
          |"name": "ZAP.BetalenSparenIVR.0",
          |"id": 40353
          |},
          |{
          |"name": "ZAP.Lenen_KL_Uitzondering_MSG",
          |"id": 176499
          |},
          |{
          |"name": "LEN.Risicobeheer_2.0",
          |"id": 372
          |},
          |{
          |"name": "KYC.CAM-PTM_MKB.1",
          |"id": 52263
          |},
          |{
          |"name": "Personal-Banking.teleopti",
          |"id": 176442
          |},
          |{
          |"name": "ZAP.Betalen_Betalen_R.1",
          |"id": 157300
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Overlijd_MSG",
          |"id": 176390
          |},
          |{
          |"name": "ZAP.ZBI_Handelsnaam_Wijz_MSG",
          |"id": 173312
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag1_Verw_MSG",
          |"id": 173363
          |},
          |{
          |"name": "LEN.Kredietaanvragen.0",
          |"id": 421
          |},
          |{
          |"name": "ZAP.Helpdesk_App_Activeren.1",
          |"id": 106252
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Captiva_MSG",
          |"id": 178305
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Zak_Arran_MSG",
          |"id": 178304
          |},
          |{
          |"name": "BELL.Events_Overig.0",
          |"id": 30450
          |},
          |{
          |"name": "HYP.Intermediair_CHT",
          |"id": 89365
          |},
          |{
          |"name": "LEN.Krediet_Klantbeheer_1.2",
          |"id": 74311
          |},
          |{
          |"name": "KYC.ProjectCO-Team3.2",
          |"id": 167356
          |},
          |{
          |"name": "ZAP.Alarmlijn.1",
          |"id": 35302
          |},
          |{
          |"name": "ZAP.ZBI_Interne_Rekeningen_MSG",
          |"id": 173300
          |},
          |{
          |"name": "welkom",
          |"id": 75720
          |},
          |{
          |"name": "LEN.Grootzakelijk_PPW.0",
          |"id": 363
          |},
          |{
          |"name": "FRD.Fraud_Detection_Betalen.1",
          |"id": 141253
          |},
          |{
          |"name": "PBW.ZW-team1_WMBZ.0",
          |"id": 129324
          |},
          |{
          |"name": "ZAP.Volmacht_MSG",
          |"id": 98402
          |},
          |{
          |"name": "ZAP.ZIO_Koppelen_Stan_Ret_MSG",
          |"id": 177264
          |},
          |{
          |"name": "HYP.tra_intermediair.0",
          |"id": 32148
          |},
          |{
          |"name": "HYP.pilotnummer1.2",
          |"id": 32153
          |},
          |{
          |"name": "ZAP.ZAE_Fallback_MSG",
          |"id": 181250
          |},
          |{
          |"name": "ZAP.ZIO_CF_MOD_Verzoeken_MSG",
          |"id": 177270
          |},
          |{
          |"name": "FRD.PAY_Screening_MSG",
          |"id": 171259
          |},
          |{
          |"name": "Social.teleopti",
          |"id": 176492
          |},
          |{
          |"name": "ZAP.ZBI_Zak_Mobapp_Ontdub_MSG",
          |"id": 173400
          |},
          |{
          |"name": "KAP.Beheer_Welkom_MSG",
          |"id": 90251
          |},
          |{
          |"name": "PBW.ZO-team_Arnhem-Nijmegen.1",
          |"id": 129368
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_BTLaflos_MSG",
          |"id": 176414
          |},
          |{
          |"name": "PBW.ZW-team2_DenHaag.1",
          |"id": 129325
          |},
          |{
          |"name": "ZAP.BSLK_Wereldbetalingen_MSG",
          |"id": 182252
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_Fiat_Bas_MSG",
          |"id": 177253
          |},
          |{
          |"name": "KYC.PBW-NO.1",
          |"id": 144253
          |},
          |{
          |"name": "ZAP.KVC_BP_Aflosnota_Hyp_MSG",
          |"id": 176534
          |},
          |{
          |"name": "ADV.Acquisitie-Zakelijk.0",
          |"id": 47305
          |},
          |{
          |"name": "ZAP.ZBI_G_Beheer_Verw_Dag2_MSG",
          |"id": 173356
          |},
          |{
          |"name": "ZAP.Betalen_Betalen_GR.1",
          |"id": 157351
          |},
          |{
          |"name": "ZAP.SLK-WijzigenEnBetaalpas.0",
          |"id": 35303
          |},
          |{
          |"name": "ZAP.Lenen_CV_Algemeen_MSG",
          |"id": 158250
          |},
          |{
          |"name": "ZAP.KIA_Koerier_Scanner_MSG",
          |"id": 179255
          |},
          |{
          |"name": "ZAP.ZBI_Gemachtigden_MSG",
          |"id": 173269
          |},
          |{
          |"name": "KYC.GZ-Building_Institutions.1",
          |"id": 87253
          |},
          |{
          |"name": "FRD.PAY_Oplichting_spoed_MSG",
          |"id": 171306
          |},
          |{
          |"name": "PBW.ZW-team1_DenHaag.0",
          |"id": 128270
          |},
          |{
          |"name": "ZAP.Helpdesk_Zak_DVBSCAN.0",
          |"id": 119300
          |},
          |{
          |"name": "ZAP.Alarmlijn.0",
          |"id": 35455
          |},
          |{
          |"name": "Col.uns_Taskforce.1",
          |"id": 26064
          |},
          |{
          |"name": "HYP.beleggershypotheek.2",
          |"id": 82442
          |},
          |{
          |"name": "HYP.app.2",
          |"id": 192310
          |},
          |{
          |"name": "ZAP.KVC_AP_Controle_Beheer_MSG",
          |"id": 176491
          |},
          |{
          |"name": "ZAP.BenF_Betekeningen_MSG",
          |"id": 176394
          |},
          |{
          |"name": "HYP.aanvragen_CLT04.0",
          |"id": 31107
          |},
          |{
          |"name": "HYP.Concreet-Particulier.0",
          |"id": 54250
          |},
          |{
          |"name": "HYP.OmniHub.0",
          |"id": 53400
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Oud_PStap2_MSG",
          |"id": 169404
          |},
          |{
          |"name": "KYC.RSPE-MassEnhancement.1",
          |"id": 52313
          |},
          |{
          |"name": "HYP.Algemeen_CHT",
          |"id": 99301
          |},
          |{
          |"name": "ZAP.Leven.1",
          |"id": 35308
          |},
          |{
          |"name": "ZAP.IBP_BEW_Aanm_EOM_MSG",
          |"id": 196256
          |},
          |{
          |"name": "ZAP.SDS_Part_Spoed_MSG",
          |"id": 176452
          |},
          |{
          |"name": "HYP.pilotnummer5.1",
          |"id": 39850
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag6_Verw_MSG",
          |"id": 173263
          |},
          |{
          |"name": "HYP.aanvragen_CLT03.0",
          |"id": 32103
          |},
          |{
          |"name": "ZAP.KVC_BP_Beeindigen_CC_MSG",
          |"id": 176368
          |},
          |{
          |"name": "LEN.Risicobeheer_2.2",
          |"id": 374
          |},
          |{
          |"name": "Betalen_Opheffen.0",
          |"id": 47551
          |},
          |{
          |"name": "PBW.NW-team_Midden_Nederland.0",
          |"id": 128262
          |},
          |{
          |"name": "HYP.aanvragen_CLT04.2",
          |"id": 31109
          |},
          |{
          |"name": "LEN.Risicobeheer_1.0",
          |"id": 369
          |},
          |{
          |"name": "BELL.Beleggen_Eenvoudig.0",
          |"id": 151251
          |},
          |{
          |"name": "ZAP.KVC_Coll_Fiditon_MSG",
          |"id": 176461
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_Algemeen_MSG",
          |"id": 157303
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Inc_Mach_Aanvr_MSG",
          |"id": 177261
          |},
          |{
          |"name": "KYC.Part-Onboarding.0",
          |"id": 104305
          |},
          |{
          |"name": "LEN.Quality_Assurance.1",
          |"id": 397
          |},
          |{
          |"name": "WUB.Finance_CAL.2",
          |"id": 120251
          |},
          |{
          |"name": "HYP.orienterend-zakelijk.2",
          |"id": 69353
          |},
          |{
          |"name": "KYC.CAM-Uitleveringsbevelen.0",
          |"id": 52358
          |},
          |{
          |"name": "ZAP.SDS_Zak_Nieuw_MSG",
          |"id": 165358
          |},
          |{
          |"name": "FRD.JUR_126NDA_camera_MSG",
          |"id": 170258
          |},
          |{
          |"name": "ZAP.Lenen_CV_Alg_Opl_Fiat_MSG",
          |"id": 176547
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag1_Fiat_OP_MSG",
          |"id": 173369
          |},
          |{
          |"name": "ZAP.ZIO_CF_Pos_Saldo_MSG",
          |"id": 178265
          |},
          |{
          |"name": "ZAP.BenF_Fail_Spin_MSG",
          |"id": 167260
          |},
          |{
          |"name": "FRD.PAYSUP_BKR_MSG",
          |"id": 171301
          |},
          |{
          |"name": "ZAP.BetalenAfschriften.0",
          |"id": 40307
          |},
          |{
          |"name": "ZAP.Helpdesk_Scan_Activeren.1",
          |"id": 107251
          |},
          |{
          |"name": "ZAP.RR-Beslagen.1",
          |"id": 35153
          |},
          |{
          |"name": "ZAP.KVC_AP_Kantoor_Schrift_MSG",
          |"id": 176435
          |},
          |{
          |"name": "BELL.Beleggen_SelectFund.1",
          |"id": 150301
          |},
          |{
          |"name": "Col.uns_Afscheid.1",
          |"id": 26107
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Oud_PStap1_MSG",
          |"id": 169264
          |},
          |{
          |"name": "ZAP.KVC_Coll_Mail_ZA_MSG",
          |"id": 176511
          |},
          |{
          |"name": "ZAP.ASOM_Sparen_Eenvoudig_MSG",
          |"id": 165405
          |},
          |{
          |"name": "HYP.gekoppelde_prod.0",
          |"id": 32204
          |},
          |{
          |"name": "ZAP.Lenen_Monitoring.0",
          |"id": 129301
          |},
          |{
          |"name": "ZAP.ZBI_IBP_Wijzigen_MSG",
          |"id": 173326
          |},
          |{
          |"name": "ZAP.Continuelimiet.1",
          |"id": 62501
          |},
          |{
          |"name": "WUB.Special_Cases_CAL.0",
          |"id": 119357
          |},
          |{
          |"name": "ZAP.Betalen_Betaalpas.1",
          |"id": 193259
          |},
          |{
          |"name": "LEN.Krediet_Klantbeheer.1",
          |"id": 74274
          |},
          |{
          |"name": "PBW.ZW-team3_Rotterdam.0",
          |"id": 134253
          |},
          |{
          |"name": "ZAP.KVC_Coll_Overdracht_IB_MSG",
          |"id": 176462
          |},
          |{
          |"name": "KYC.INV-LIMA.0",
          |"id": 145359
          |},
          |{
          |"name": "PBW.ZO-team_Eindhoven.1",
          |"id": 129369
          |},
          |{
          |"name": "HYP.aanvragen_CLT02.0",
          |"id": 31104
          |},
          |{
          |"name": "ZAP.BSLK_Herstel_ouderrol_MSG",
          |"id": 169253
          |},
          |{
          |"name": "FRD.CREDIT_Waterspin_MSG",
          |"id": 172267
          |},
          |{
          |"name": "FRD.Fraud_CreditCards.0",
          |"id": 141251
          |},
          |{
          |"name": "HYP.pilotnummer2.2",
          |"id": 31142
          |},
          |{
          |"name": "ZAP.ZBI_G_Open_Fiat_Dag2_MSG",
          |"id": 173254
          |},
          |{
          |"name": "ZAP.SDN_Fallback_MSG",
          |"id": 149261
          |},
          |{
          |"name": "Col.uns_Behoud.0",
          |"id": 26055
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dg4_Fiat_MKB_MSG",
          |"id": 173367
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spe_Schei_MSG",
          |"id": 150309
          |},
          |{
          |"name": "FRD.HYP_ABC_constructie_MSG",
          |"id": 172261
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_Nakijkwerk_MSG",
          |"id": 176520
          |},
          |{
          |"name": "FRD.PAY_BLOK_1e_km_extern_MSG",
          |"id": 171262
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Fiat_Com_MSG",
          |"id": 176391
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam3.1",
          |"id": 144257
          |},
          |{
          |"name": "PBW.NO-team2_Twente.1",
          |"id": 129263
          |},
          |{
          |"name": "ZAP.KIA_Incident_MING_Z_MSG",
          |"id": 166253
          |},
          |{
          |"name": "LEN.Krediet_Klantbeheer_2.2",
          |"id": 74312
          |},
          |{
          |"name": "ZAP.ZBI_VV_Ophef_Verw_Dag1_MSG",
          |"id": 173305
          |},
          |{
          |"name": "ZAP.KVC_AP_Cred_Ass_Spin_MSG",
          |"id": 176486
          |},
          |{
          |"name": "ZAP.Zakl_Hlpdsk_Scan_Active.1",
          |"id": 112274
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam2.0",
          |"id": 144255
          |},
          |{
          |"name": "ZAP.BenF_GE_MSG",
          |"id": 192401
          |},
          |{
          |"name": "PBW-ACM-NW-Default.0",
          |"id": 129329
          |},
          |{
          |"name": "ZAP.SDN_Coulance_Spin_MSG",
          |"id": 150257
          |},
          |{
          |"name": "HYP.zekerheden_notaris.2",
          |"id": 32129
          |},
          |{
          |"name": "ZAP.BSLK_Mach_Afmelden_MSG",
          |"id": 169353
          |},
          |{
          |"name": "KYC.LBK-Uitl-bevelen_Uitloop.0",
          |"id": 52312
          |},
          |{
          |"name": "ZAP.IBP_BEW_Exit_Com_MSG",
          |"id": 197254
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam5.1",
          |"id": 166259
          |},
          |{
          |"name": "Zap.KVC_AP_Kantoor_Inkomen_MSG",
          |"id": 192306
          |},
          |{
          |"name": "ZAP.ASOM_Fallback_MSG",
          |"id": 165410
          |},
          |{
          |"name": "HYP.cct1.1",
          |"id": 159304
          |},
          |{
          |"name": "ZAP.KVC_FZ_Perio_DB_TSYS_MSG",
          |"id": 192254
          |},
          |{
          |"name": "Col.sec_Behoud_2de_lijn.1",
          |"id": 26106
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_TBO_MSG",
          |"id": 178298
          |},
          |{
          |"name": "cc20",
          |"id": 63548
          |},
          |{
          |"name": "ZAP.ZIO_CF_Balance_Transf_MSG",
          |"id": 178312
          |},
          |{
          |"name": "HYP.aanvragen_CLT04.1",
          |"id": 31108
          |},
          |{
          |"name": "HYP.pilotnummer5.0",
          |"id": 39751
          |},
          |{
          |"name": "FRD.DECT_Fallback_MSG",
          |"id": 172266
          |},
          |{
          |"name": "KYC.EHMT-Team6.0",
          |"id": 73401
          |},
          |{
          |"name": "LEN.Hypotheken.1",
          |"id": 385
          |},
          |{
          |"name": "ZAP.KVC_FZ_Perio_Rebate_MSG",
          |"id": 176416
          |},
          |{
          |"name": "KYC.GZ-Trade_Retail_Industry.1",
          |"id": 87300
          |},
          |{
          |"name": "ZAP.ZIO_MINGZ_MSG",
          |"id": 178310
          |},
          |{
          |"name": "ADV.Verhoger-Zakelijk.0",
          |"id": 47403
          |},
          |{
          |"name": "ZAP.ASOM_Rechtsvorm_Regu_MSG",
          |"id": 165354
          |},
          |{
          |"name": "ZAP.SDN_Coulance_KING_MSG",
          |"id": 180300
          |},
          |{
          |"name": "LEN.Juridische_Omzettingen.0",
          |"id": 381
          |},
          |{
          |"name": "FRD.HYP_Bespreek_zaak_MSG",
          |"id": 170263
          |},
          |{
          |"name": "ZAP.Kansrijk.0",
          |"id": 35354
          |},
          |{
          |"name": "ZAP.KVC_BP_Priba_Spoed_MSG",
          |"id": 176434
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_EURaflos_MSG",
          |"id": 176362
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_URS_Fiat_MSG",
          |"id": 173364
          |},
          |{
          |"name": "ZAP.Zakelijk_Basis.1",
          |"id": 35462
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Inc_IDIN_MSG",
          |"id": 177262
          |},
          |{
          |"name": "ZAP.ZIO_Openen_Fiatteren_MSG",
          |"id": 178260
          |},
          |{
          |"name": "ZAP.BSLK_Machtigingen_Spin_MSG",
          |"id": 169352
          |},
          |{
          |"name": "ZAP.BenF_Afdracht_MSG",
          |"id": 167306
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag4_Fiat_MSG",
          |"id": 173262
          |},
          |{
          |"name": "ZAP.KIA_Zakelijk.1",
          |"id": 119301
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Flower_MSG",
          |"id": 179253
          |},
          |{
          |"name": "ZAP.Kansrijk_Beleggen.1",
          |"id": 166258
          |},
          |{
          |"name": "ZAP.Kansrijk.1",
          |"id": 35400
          |},
          |{
          |"name": "ZAP.BSLK_IBP_Migratie_MSG",
          |"id": 169303
          |},
          |{
          |"name": "HYP.hsp_aanvragen.1",
          |"id": 31138
          |},
          |{
          |"name": "HYP.cct3.2",
          |"id": 192256
          |},
          |{
          |"name": "ZAP.SDS_Spin_MSG",
          |"id": 165308
          |},
          |{
          |"name": "FRD.CREDIT_Reactie_2nd_MSG",
          |"id": 170269
          |},
          |{
          |"name": "KYC.EHMT-Team14.0",
          |"id": 73353
          |},
          |{
          |"name": "ZAP.ZBI_Zak_Mobapp_Contr_MSG",
          |"id": 173352
          |},
          |{
          |"name": "HYP.oip_PPW.1",
          |"id": 31136
          |},
          |{
          |"name": "ZAP.ZBI_G_Ophef_Verw_Dag5_MSG",
          |"id": 173405
          |},
          |{
          |"name": "ZAP.BSLK_OVboekjes_MSG",
          |"id": 169251
          |},
          |{
          |"name": "ZAP.BenF_Meerdere_opheffen_MSG",
          |"id": 167257
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Gevorderd_MSG",
          |"id": 157358
          |},
          |{
          |"name": "PBW.NO-team1_Twente.0",
          |"id": 128257
          |},
          |{
          |"name": "ZAP.KVC_BC_Spin_MSG",
          |"id": 176470
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_URS_Algemeen_MSG",
          |"id": 173408
          |},
          |{
          |"name": "KYC.PBW-General.1",
          |"id": 52257
          |},
          |{
          |"name": "LEN.Quality_Assurance.2",
          |"id": 398
          |},
          |{
          |"name": "PBW.NW-team_Amsterdam.0",
          |"id": 128260
          |},
          |{
          |"name": "HYP.Contactme_Beheer_CMN.0",
          |"id": 116500
          |},
          |{
          |"name": "HYP.aanvragen_CLT08.0",
          |"id": 32111
          |},
          |{
          |"name": "LEN.Risicobeheer_1.1",
          |"id": 370
          |},
          |{
          |"name": "ZAP.KIA_Zakelijk.0",
          |"id": 118251
          |},
          |{
          |"name": "KYC.GZ-Trnsprt_Lgstcs_Srvcs.0",
          |"id": 87352
          |},
          |{
          |"name": "ZAP.KVC_FZ_Issues_Spoed_MSG",
          |"id": 176417
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spe_Verw_MSG",
          |"id": 150308
          |},
          |{
          |"name": "HYP.retentie_connect.1",
          |"id": 32202
          |},
          |{
          |"name": "ZAP.SDS_Zak_UBO_MSG",
          |"id": 165416
          |},
          |{
          |"name": "ZAP.Zakelijk_ART.1",
          |"id": 35403
          |},
          |{
          |"name": "HYP.aanvragen_CLT06.0",
          |"id": 32108
          |},
          |{
          |"name": "KYC.PBW-NW.1",
          |"id": 144300
          |},
          |{
          |"name": "VER.VermogenCSDB.0",
          |"id": 195250
          |},
          |{
          |"name": "PBW.ZW-team3_Rotterdam.1",
          |"id": 133251
          |},
          |{
          |"name": "LEN.BCC_Starters.0",
          |"id": 74361
          |},
          |{
          |"name": "KAP.aanvragen_1ste_lijn_IM.1",
          |"id": 40400
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Aflosnota_MSG",
          |"id": 176389
          |},
          |{
          |"name": "ZAP.KVC_CZ_Beheer_MSG",
          |"id": 176367
          |},
          |{
          |"name": "LEN.Juridische_Omzettingen.2",
          |"id": 383
          |},
          |{
          |"name": "ZAP.Zakelijk_DVB_Incasso.0",
          |"id": 35306
          |},
          |{
          |"name": "KAP.aanvragen_1ste_lijn.1",
          |"id": 360
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Int_Rek_MSG",
          |"id": 180251
          |},
          |{
          |"name": "ZAP.SDN_Coulance.0",
          |"id": 35100
          |},
          |{
          |"name": "ZAP.SDN_Coulance_Overig_MSG",
          |"id": 179254
          |},
          |{
          |"name": "KYC.PBW-ZW.1",
          |"id": 144252
          |},
          |{
          |"name": "ZAP.ZIO_CF_PU_Andere_Bank_MSG",
          |"id": 177268
          |},
          |{
          |"name": "Col.uns_Insolventie.0",
          |"id": 26056
          |},
          |{
          |"name": "ZAP.BSLK_RGB_SPIN_MSG",
          |"id": 169258
          |},
          |{
          |"name": "ZAP.KVC_CZ_Cardaanvr_MSG",
          |"id": 176475
          |},
          |{
          |"name": "HYP.hulpdienst.0",
          |"id": 31129
          |},
          |{
          |"name": "ZAP.SDS_Zak_Beheer_MSG",
          |"id": 165310
          |},
          |{
          |"name": "HYP.scheiden_notaris.2",
          |"id": 31128
          |},
          |{
          |"name": "FRD.DECT_Waterspin_MSG",
          |"id": 171263
          |},
          |{
          |"name": "KAP.aanvragen_1ste_lijn.0",
          |"id": 359
          |},
          |{
          |"name": "ZAP.Betalen_Vergoedingstaat.1",
          |"id": 79261
          |},
          |{
          |"name": "ZAP.ZIO_Fallback_MSG",
          |"id": 178268
          |},
          |{
          |"name": "KYC.ProjectCO-Team2.2",
          |"id": 167313
          |},
          |{
          |"name": "LEN.Adviseur_Zakelijk.1",
          |"id": 74360
          |},
          |{
          |"name": "PBW.NO-team3_Twente.1",
          |"id": 129311
          |},
          |{
          |"name": "FRD.DECT_Navraag_banken_MSG",
          |"id": 172263
          |},
          |{
          |"name": "ZAP.SDN_Coulance_Spoed_MSG",
          |"id": 165412
          |},
          |{
          |"name": "PBW.ZW-team1_DenHaag.1",
          |"id": 129323
          |},
          |{
          |"name": "LEN.Loyalty-Retentie.2",
          |"id": 392
          |},
          |{
          |"name": "ZAP.BenF_Diversen_MSG",
          |"id": 167259
          |},
          |{
          |"name": "ZAP.KIA_Fallback_MSG",
          |"id": 167254
          |},
          |{
          |"name": "ZAP.Vraagbaak_PrivIndi",
          |"id": 103254
          |},
          |{
          |"name": "ZAP.ZBI_G_Beheer_Verw_Dag1_MSG",
          |"id": 173303
          |},
          |{
          |"name": "ZAP.ZIO_IBP_Specials_MSG",
          |"id": 192407
          |},
          |{
          |"name": "ZAP.BetalenTBIC.0",
          |"id": 40309
          |},
          |{
          |"name": "ZAP.KIA.0",
          |"id": 36150
          |},
          |{
          |"name": "KYC.CAM-PTM_Mass.0",
          |"id": 52315
          |},
          |{
          |"name": "BELL.Opties.2",
          |"id": 30352
          |},
          |{
          |"name": "ZAP.ZBI_NRC_Condities_MSG",
          |"id": 173350
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_GBPstorno_MSG",
          |"id": 176415
          |},
          |{
          |"name": "ZAP.Zakl_Hlpdsk_Scan_Active.0",
          |"id": 112305
          |},
          |{
          |"name": "KYC.LBK-Warrents.0",
          |"id": 52311
          |},
          |{
          |"name": "ZAP.ZIO_Waterspin_Zak_Bet_MSG",
          |"id": 178300
          |},
          |{
          |"name": "LEN.Opschorten_Aflossen.2",
          |"id": 40251
          |},
          |{
          |"name": "ZAP.Sparen.0",
          |"id": 52275
          |},
          |{
          |"name": "HYP.aflossen.2",
          |"id": 32125
          |},
          |{
          |"name": "ZAP.ZAE_Kassacompleet_MSG",
          |"id": 179257
          |},
          |{
          |"name": "KAP.2de_lijn.0",
          |"id": 361
          |},
          |{
          |"name": "Personal-Banking",
          |"id": 48250
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_Fiat_Comp_MSG",
          |"id": 176387
          |},
          |{
          |"name": "KAP.aanvragen_1ste_lijn_IM.0",
          |"id": 40338
          |},
          |{
          |"name": "LEN.Krediet_Klantbeheer_1.1",
          |"id": 74417
          |},
          |{
          |"name": "ZAP.ASOM_Betaalrek_Uit_CS_MSG",
          |"id": 165251
          |},
          |{
          |"name": "Col.sec_Specialties.0",
          |"id": 26103
          |},
          |{
          |"name": "FRD.CREDIT_TOB_MSG",
          |"id": 171266
          |},
          |{
          |"name": "ZAP.KVC_BC_1e_screening_MSG",
          |"id": 192404
          |},
          |{
          |"name": "HYP.hsp.pilot.0",
          |"id": 32139
          |},
          |{
          |"name": "LEN.Adviseur_Zakelijk.0",
          |"id": 74273
          |},
          |{
          |"name": "LEN.Business_Lending.0",
          |"id": 74310
          |},
          |{
          |"name": "Fraude",
          |"id": 46251
          |},
          |{
          |"name": "ZAP.Vraagbaak_Webhelp",
          |"id": 104301
          |},
          |{
          |"name": "ZAP.SDN_Coulance_Wachtbak_MSG",
          |"id": 178347
          |},
          |{
          |"name": "ZAP.ASOM_KING_MSG",
          |"id": 176351
          |},
          |{
          |"name": "ZAP.ZIO_CF_Extra_Saldo_MSG",
          |"id": 178355
          |},
          |{
          |"name": "ZAP.ZBI_Waterspin_Ophef_MSG",
          |"id": 173315
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_BEcontr_MSG",
          |"id": 177251
          |},
          |{
          |"name": "ADV.Concreet-Particulier.1",
          |"id": 47253
          |},
          |{
          |"name": "PBW.ZO-team_Eindhoven.0",
          |"id": 129319
          |},
          |{
          |"name": "Col.sec_Zakelijk.0",
          |"id": 26054
          |},
          |{
          |"name": "ZAP.KV-Cards_Finance.0",
          |"id": 150265
          |},
          |{
          |"name": "ZAP.Default.0",
          |"id": 35407
          |},
          |{
          |"name": "ZAP.Vraagbaak_Social",
          |"id": 103303
          |},
          |{
          |"name": "ZAP.ZIO_DOZ_Alg_Tot_MSG",
          |"id": 192308
          |},
          |{
          |"name": "ZAP.Zakl_Helpdsk_ING_Scanner.0",
          |"id": 103306
          |},
          |{
          |"name": "FRD.CREDIT_Bezwaren_credit_MSG",
          |"id": 171268
          |},
          |{
          |"name": "PBW-ACM-ZW-Default.0",
          |"id": 129377
          |},
          |{
          |"name": "ZAP.KVC_CZ_Tibco_MSG",
          |"id": 176477
          |},
          |{
          |"name": "ZAP.KVC_Coll_Priobestand_MSG",
          |"id": 176357
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_EZ_VOF_MSG",
          |"id": 157304
          |},
          |{
          |"name": "ZAP.ZBI_PIN_Overig_Complex_MSG",
          |"id": 173270
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Nw_Nood_Nieuw_MSG",
          |"id": 169263
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Tegenrek_MSG",
          |"id": 176445
          |},
          |{
          |"name": "ZAP.BSLK_Open_Rek_Uitval_MSG",
          |"id": 169351
          |},
          |{
          |"name": "KYC.RSPE-SpecialsRegulier.1",
          |"id": 52408
          |},
          |{
          |"name": "HYP.aanvraag_notaris.1",
          |"id": 31113
          |},
          |{
          |"name": "ZAP.KVC_CZ_Dagelijks_Contr_MSG",
          |"id": 176478
          |},
          |{
          |"name": "FRD.PAY_TOB_MSG",
          |"id": 171305
          |},
          |{
          |"name": "HYP.retentie_connect.2",
          |"id": 32203
          |},
          |{
          |"name": "KYC.GZ-Taskforce_Remediation.1",
          |"id": 87400
          |},
          |{
          |"name": "KYC.CAM-Uitleveringsbevelen.1",
          |"id": 52407
          |},
          |{
          |"name": "KYC.CAM-OverigeSignalen.0",
          |"id": 52360
          |},
          |{
          |"name": "ZAP.ZBI_RCK_MSG",
          |"id": 173360
          |},
          |{
          |"name": "ZAP.ZBI_Zakrel_Wijz_MSG",
          |"id": 192309
          |},
          |{
          |"name": "ZAP.SDN_Coulance_Team_K_MSG",
          |"id": 165306
          |},
          |{
          |"name": "ZAP.ZBI_VV_Ophef_Fiat_Dag1_MSG",
          |"id": 173403
          |},
          |{
          |"name": "ConfidenceCheck",
          |"id": 36
          |},
          |{
          |"name": "PBW.ZW-team2_WMBZ.0",
          |"id": 129279
          |},
          |{
          |"name": "ZAP.KVC_FZ_Week_LijstenCFO_MSG",
          |"id": 176467
          |},
          |{
          |"name": "ZAP.Alarmlijn_Spoed.0",
          |"id": 140251
          |},
          |{
          |"name": "BELL.Mifid.1",
          |"id": 98302
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag6_Verw_OP_MSG",
          |"id": 173320
          |},
          |{
          |"name": "ZAP.SLK-Opheffen.1",
          |"id": 35460
          |},
          |{
          |"name": "FRD.PAY_Bezwaar_benadeelde_MSG",
          |"id": 170261
          |},
          |{
          |"name": "Col.uns_Taskforce.0",
          |"id": 26057
          |},
          |{
          |"name": "ZAP.ZBI_G_Beheer_Fiat_Dag1_MSG",
          |"id": 173255
          |},
          |{
          |"name": "ZAP.SDS_Jeugdzorg_Spoed_MSG",
          |"id": 176404
          |},
          |{
          |"name": "ZAP.SDN_Coulance_AFS_MSG",
          |"id": 165413
          |},
          |{
          |"name": "ZAP.Kwartaallimiet.1",
          |"id": 47502
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Vraagbaak_MSG",
          |"id": 173365
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spin_MSG",
          |"id": 150258
          |},
          |{
          |"name": "ZAP.Lenen_Spin_RS_MSG",
          |"id": 176446
          |},
          |{
          |"name": "HYP.hulpdienst.1",
          |"id": 32135
          |},
          |{
          |"name": "KYC.PBW-Onboarding.0",
          |"id": 52258
          |},
          |{
          |"name": "KAP.PBW_Service.1",
          |"id": 159307
          |},
          |{
          |"name": "ZAP.ZAE_Zakelijkcontact_MSG",
          |"id": 180252
          |},
          |{
          |"name": "ZAP.SDN_Coulance.1",
          |"id": 35150
          |},
          |{
          |"name": "HYP.aflossen_notaris.1",
          |"id": 31118
          |},
          |{
          |"name": "ZAP.KIA_Koerier_Stap2_MSG",
          |"id": 180305
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Inc_Tech_Ond_MSG",
          |"id": 178307
          |},
          |{
          |"name": "BELL.Events_Overig.1",
          |"id": 30355
          |},
          |{
          |"name": "FRD.JUR_Privacy_office_MSG",
          |"id": 170257
          |},
          |{
          |"name": "HYP.aanvragen_CLT01.2",
          |"id": 31103
          |},
          |{
          |"name": "ZAP.ZBI_VV_Open_Fiat_Dag1_MSG",
          |"id": 173252
          |},
          |{
          |"name": "ZAP.ZIO_CF_Ben_Nalaten_MSG",
          |"id": 178313
          |},
          |{
          |"name": "FRD.PAYSUP_Saldoverzoek_MSG",
          |"id": 170254
          |},
          |{
          |"name": "HYP.aanvragen_CLT05.1",
          |"id": 31110
          |},
          |{
          |"name": "PBW.PWAM-team02.0",
          |"id": 129364
          |},
          |{
          |"name": "PBW.NW-team_Kennemerland.1",
          |"id": 128261
          |},
          |{
          |"name": "HYP.scheiden.1",
          |"id": 31125
          |},
          |{
          |"name": "ZAP.KVC_AP_Speg_Charge_MSG",
          |"id": 176375
          |},
          |{
          |"name": "PBW.ZO-team1_DenBosch.0",
          |"id": 129371
          |},
          |{
          |"name": "ZAP.ASOM_Sparen_Spin_MSG",
          |"id": 165253
          |},
          |{
          |"name": "ZAP.KVC_Coll_Graydon_MSG",
          |"id": 176513
          |},
          |{
          |"name": "FRD.CREDIT_Fraude_account_MSG",
          |"id": 171312
          |},
          |{
          |"name": "LEN.Juridische_Omzettingen.1",
          |"id": 382
          |},
          |{
          |"name": "ZAP.BenF_Strafrechtelijk_MSG",
          |"id": 192252
          |},
          |{
          |"name": "ZAP.KIA_Verw_Boekhoudpak_MSG",
          |"id": 167301
          |},
          |{
          |"name": "ZAP.SDS_CC_Algemeen_MSG",
          |"id": 165360
          |},
          |{
          |"name": "ZAP.BSLK_Koppelen_MSG",
          |"id": 169350
          |},
          |{
          |"name": "FRD.Fraud_Bezwaren.0",
          |"id": 140351
          |},
          |{
          |"name": "ZAP.Zakelijk_IBP_Helpdesk.0",
          |"id": 35359
          |},
          |{
          |"name": "ZAP.Events_OrangeCarpet.1",
          |"id": 95300
          |},
          |{
          |"name": "HYP.cct3.0",
          |"id": 192313
          |},
          |{
          |"name": "ZAP.Helpdesk_SCA.0",
          |"id": 120305
          |},
          |{
          |"name": "FRD.JUR_126NC_MSG",
          |"id": 171254
          |},
          |{
          |"name": "ZAP.BSLK_Controleren_MSG",
          |"id": 171300
          |},
          |{
          |"name": "ADV.Acquisitie-Zakelijk.1",
          |"id": 47405
          |},
          |{
          |"name": "HYP.aanvragen_CLT05.0",
          |"id": 32106
          |},
          |{
          |"name": "HYP.Concreet-Zakelijk.1",
          |"id": 53451
          |},
          |{
          |"name": "ZAP.BSLK_SEPA_MSG",
          |"id": 169252
          |},
          |{
          |"name": "FRD.PAYSUP_Waterspin_MSG",
          |"id": 172250
          |},
          |{
          |"name": "FRD.CREDIT_Stand_in_file_MSG",
          |"id": 170272
          |},
          |{
          |"name": "HYP.aanvragen_CLT01.1",
          |"id": 32102
          |},
          |{
          |"name": "HYP.Aflosvrij.2",
          |"id": 56300
          |},
          |{
          |"name": "LEN.Watchlist.2",
          |"id": 380
          |},
          |{
          |"name": "ZAP.KIA_Incident_Terugkop_MSG",
          |"id": 176400
          |},
          |{
          |"name": "HYP.hsp_aanvragen.2",
          |"id": 31139
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_Mail_MSG",
          |"id": 176549
          |},
          |{
          |"name": "ZAP.KVC_FZ_Verz_Cre_saldo_MSG",
          |"id": 176516
          |},
          |{
          |"name": "PBW.NW-team_Noord-Holland.0",
          |"id": 129362
          |},
          |{
          |"name": "FRD.PAYSUP_MOT_MSG",
          |"id": 170253
          |},
          |{
          |"name": "Col.sec_Real_Estate.0",
          |"id": 26053
          |},
          |{
          |"name": "ZAP.Bewind_Fallback_MSG",
          |"id": 98403
          |},
          |{
          |"name": "ZAP.IBP_BEW_Exit_Start_MSG",
          |"id": 197255
          |},
          |{
          |"name": "HYP.Jaaroverzicht.0",
          |"id": 79257
          |},
          |{
          |"name": "ZAP.SDS_Part_Klus_MSG",
          |"id": 176453
          |},
          |{
          |"name": "ZAP.ASOM_Sparen_Levensloop_MSG",
          |"id": 165406
          |},
          |{
          |"name": "KYC.LBK-Alerts.1",
          |"id": 52357
          |},
          |{
          |"name": "PBW.NO-team3_Twente.0",
          |"id": 129265
          |},
          |{
          |"name": "ZAP.BenF_Klachten_MSG",
          |"id": 167308
          |},
          |{
          |"name": "PBW.NO-team2_Twente.0",
          |"id": 128258
          |},
          |{
          |"name": "ZAP.BetalenBasis.1",
          |"id": 35351
          |},
          |{
          |"name": "FRD.CREDIT_Werkbakken_MSG",
          |"id": 171311
          |},
          |{
          |"name": "WUB.Risk_CAL.1",
          |"id": 119305
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_Trade_MSG",
          |"id": 176361
          |},
          |{
          |"name": "ZAP.KV-Cards_Collections.1",
          |"id": 150264
          |},
          |{
          |"name": "KYC.Part-Onboarding.1",
          |"id": 104306
          |},
          |{
          |"name": "ZAP.Zakelijk_MING2elijn.1",
          |"id": 41304
          |},
          |{
          |"name": "HYP.tra.0",
          |"id": 32130
          |},
          |{
          |"name": "FRD.PAYSUP_GEA_of_BEA_MSG",
          |"id": 170252
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dg4_Verw_MKB_MSG",
          |"id": 173266
          |},
          |{
          |"name": "KYC.ProjectCO-Team5.1",
          |"id": 167358
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk.0",
          |"id": 35200
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spe_Klach_MSG",
          |"id": 149260
          |},
          |{
          |"name": "LEN.Quality_Assurance.0",
          |"id": 396
          |},
          |{
          |"name": "WUB.Secretaresse_CAL.1",
          |"id": 119356
          |},
          |{
          |"name": "ZAP.Zakelijk_Billing.1",
          |"id": 41300
          |},
          |{
          |"name": "BELL.Beleggen.2",
          |"id": 30400
          |},
          |{
          |"name": "HYP.aanvragen_CLT08.1",
          |"id": 32112
          |},
          |{
          |"name": "ZAP.ZBI_Bevoegdheden_Wijz_MSG",
          |"id": 173308
          |},
          |{
          |"name": "ZAP.ZIO_Openen_DRG_MSG",
          |"id": 178261
          |},
          |{
          |"name": "ZAP.Betalen_Betalen.0",
          |"id": 47603
          |},
          |{
          |"name": "HYP.pilotnummer1.1",
          |"id": 31146
          |},
          |{
          |"name": "FRD.DECT_Algemeen_MSG",
          |"id": 170268
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dag4_Verw_MSG",
          |"id": 173316
          |},
          |{
          |"name": "ZAP.BetalenBasis.0",
          |"id": 35301
          |},
          |{
          |"name": "ZAP.ZBI_Waterspin_Bankverk_MSG",
          |"id": 173406
          |},
          |{
          |"name": "ZAP.Lenen.0",
          |"id": 34201
          |},
          |{
          |"name": "Zap.KVC_BC_Mail_Div_MSG",
          |"id": 192405
          |},
          |{
          |"name": "KYC.GZ-Klant_worden.1",
          |"id": 87251
          |},
          |{
          |"name": "FRD.PAYSUP_Werkbakken_MSG",
          |"id": 171303
          |},
          |{
          |"name": "HYP.geldverkeer.2",
          |"id": 31144
          |},
          |{
          |"name": "ZAP.KVC_Coll_Spin_MSG",
          |"id": 176356
          |},
          |{
          |"name": "PBW.PWAM-team03.1",
          |"id": 129313
          |},
          |{
          |"name": "ZAP.ZIO_Waterspin_Zak_Inc_MSG",
          |"id": 176398
          |},
          |{
          |"name": "PBW.NO-team_Debet.0",
          |"id": 129309
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Fiat_Bas_MSG",
          |"id": 177300
          |},
          |{
          |"name": "FRD.PAY_Bezw_begunstigde_MSG",
          |"id": 172258
          |},
          |{
          |"name": "PBW.PWAM-team02.1",
          |"id": 129268
          |},
          |{
          |"name": "ZAP.Helpdesk_Scan_Activeren.0",
          |"id": 106251
          |},
          |{
          |"name": "ZAP.ZIO_Koppelen_DRG_MSG",
          |"id": 178262
          |},
          |{
          |"name": "PBW.PWAM-team05.1",
          |"id": 129314
          |},
          |{
          |"name": "ZAP.SDS_Orange_Carpet_MSG",
          |"id": 165262
          |},
          |{
          |"name": "ZAP.SDS_GMU_Spoed_MSG",
          |"id": 176405
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Oud_IAV_ZAK_MSG",
          |"id": 169405
          |},
          |{
          |"name": "ZAP.BenF_Faill_Spoed_MSG",
          |"id": 167352
          |},
          |{
          |"name": "ZAP.KIA_Opzeggen_MING_MSG",
          |"id": 167300
          |},
          |{
          |"name": "BELL.Beleggen_Tarieven.1",
          |"id": 149252
          |},
          |{
          |"name": "PBW.PWAM-team07.0",
          |"id": 129366
          |},
          |{
          |"name": "Col.sec_Rente_Pauze.0",
          |"id": 26102
          |},
          |{
          |"name": "ADV.Online-Zakelijk_CMN.0",
          |"id": 142250
          |},
          |{
          |"name": "ZAP.KVC_CZ_Comp_Spoed_MSG",
          |"id": 176423
          |},
          |{
          |"name": "ZAP.BenF_NA_MSG",
          |"id": 192251
          |},
          |{
          |"name": "Col.sec_Financiele_Afwikk.0",
          |"id": 26052
          |},
          |{
          |"name": "ZAP.BSLK_Opheffen_Part_MSG",
          |"id": 169257
          |},
          |{
          |"name": "ZAP.SDS_GMU_Algemeen_MSG",
          |"id": 165261
          |},
          |{
          |"name": "ZAP.ZIO_Koppelen_Enhanced_MSG",
          |"id": 178351
          |},
          |{
          |"name": "HYP.omzetten.0",
          |"id": 32133
          |},
          |{
          |"name": "LEN.Actualisatie.0",
          |"id": 375
          |},
          |{
          |"name": "ZAP.Leven.0",
          |"id": 35360
          |},
          |{
          |"name": "ZAP.BSLK_Tarifering_MSG",
          |"id": 195257
          |},
          |{
          |"name": "ZAP.Rentepunten.0",
          |"id": 35401
          |},
          |{
          |"name": "LEN.Kredietaanvragen.2",
          |"id": 423
          |},
          |{
          |"name": "FRD.JUR_Waterspin_MSG",
          |"id": 171253
          |},
          |{
          |"name": "FRD.HYP_Waterspin_MSG",
          |"id": 171260
          |},
          |{
          |"name": "KYC.LBK-Warrents.1",
          |"id": 52259
          |},
          |{
          |"name": "ZAP.Cards.TeleOpti",
          |"id": 145260
          |},
          |{
          |"name": "ZAP.KVC_BP_Arr_Wijziging_MSG",
          |"id": 176371
          |},
          |{
          |"name": "HYP.beleggershypotheek.1",
          |"id": 82332
          |},
          |{
          |"name": "BELL.Mifid.2",
          |"id": 100275
          |},
          |{
          |"name": "BELL.Campagne.1",
          |"id": 30354
          |},
          |{
          |"name": "KAP.beheer_1ste_lijn.1",
          |"id": 356
          |},
          |{
          |"name": "ZAP.Helpdesk_Zak_SCA.0",
          |"id": 120306
          |},
          |{
          |"name": "KYC.GZ-Klant_worden.0",
          |"id": 87250
          |},
          |{
          |"name": "LEN.Watchlist.0",
          |"id": 378
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Overig_MSG",
          |"id": 180303
          |},
          |{
          |"name": "ZAP.Alarmlijn.Teleopti",
          |"id": 145405
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Spe_Zak_MSG",
          |"id": 149258
          |},
          |{
          |"name": "ZAP.IBP_BEW_Afbouw_MSG",
          |"id": 196255
          |},
          |{
          |"name": "HYP.orienterend-zakelijk.1",
          |"id": 69352
          |},
          |{
          |"name": "KYC.ProjectCO-Team4.1",
          |"id": 167271
          |},
          |{
          |"name": "FRD.CREDIT_Dispute_MSG",
          |"id": 171310
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_Rappel_MSG",
          |"id": 180301
          |},
          |{
          |"name": "CORP.Grootzakelijk_CLT5.0",
          |"id": 46250
          |},
          |{
          |"name": "WUB.Preventief_Beheer_CAL.0",
          |"id": 118254
          |},
          |{
          |"name": "KAP.beheer_1ste_lijn.0",
          |"id": 355
          |},
          |{
          |"name": "KYC.EHMT-Team6.1",
          |"id": 73310
          |},
          |{
          |"name": "KYC.GRZ-ReviewTrnsprt-Logist.0",
          |"id": 52400
          |},
          |{
          |"name": "FRD.DECT_Wholesale_MSG",
          |"id": 171264
          |},
          |{
          |"name": "HYP.connect_beheer.1",
          |"id": 31148
          |},
          |{
          |"name": "PBW.PWAM-team04.0",
          |"id": 129270
          |},
          |{
          |"name": "HYP.orienterend-zakelijk.0",
          |"id": 69302
          |},
          |{
          |"name": "HYP.Jaaroverzicht.1",
          |"id": 79258
          |},
          |{
          |"name": "PBW.ZW-team2_Rotterdam.0",
          |"id": 129278
          |},
          |{
          |"name": "ZAP.KV-Cards_BusinessCards.0",
          |"id": 150266
          |},
          |{
          |"name": "PBW.PWAM-team01.0",
          |"id": 129363
          |},
          |{
          |"name": "WUB.Finance_CAL.0",
          |"id": 119303
          |},
          |{
          |"name": "ZAP.BSLK_Convenanten_MSG",
          |"id": 169302
          |},
          |{
          |"name": "FRD.PAYSUP_VT_melding_MSG",
          |"id": 170255
          |},
          |{
          |"name": "ZAP.Lenen_CV_Zak_Uitval_MSG",
          |"id": 176392
          |},
          |{
          |"name": "ZAP.BSLK_OVS_Oud_POV_MSG",
          |"id": 169266
          |},
          |{
          |"name": "ZAP.Zakelijk_Basis.0",
          |"id": 35461
          |},
          |{
          |"name": "WUB.Secretaresse_CAL.2",
          |"id": 120301
          |},
          |{
          |"name": "ZAP.ZBI_VV_Open_Verw_Dag1_MSG",
          |"id": 173402
          |},
          |{
          |"name": "ZAP.KVC_FZ_Week_Weeklypay_MSG",
          |"id": 176364
          |},
          |{
          |"name": "ZAP.Vraagbaak_BusinessClients",
          |"id": 104250
          |},
          |{
          |"name": "ZAP.ZBI_Ophef_Dg1_Verw_MKB_MSG",
          |"id": 173366
          |},
          |{
          |"name": "ZAP.KVC_FZ_Vra_Algemeen_MSG",
          |"id": 176523
          |},
          |{
          |"name": "HYP.tra_intermediair.2",
          |"id": 32149
          |},
          |{
          |"name": "ZAP.KVC_BP_Naamswijz_CC_MSG",
          |"id": 176370
          |},
          |{
          |"name": "KYC.ZKL-ReviewTeam5.0",
          |"id": 167266
          |},
          |{
          |"name": "HYP.app.1",
          |"id": 192255
          |},
          |{
          |"name": "HYP.Concreet-Particulier.1",
          |"id": 53502
          |},
          |{
          |"name": "KAP.2de_lijn.1",
          |"id": 362
          |},
          |{
          |"name": "ZAP.Zakelijk_iDeal.1",
          |"id": 35305
          |},
          |{
          |"name": "ZAP.SDS_Jeugdzorg_Klus_MSG",
          |"id": 176406
          |},
          |{
          |"name": "ZAP.BSLK_Mach_Aanmelden_MSG",
          |"id": 169256
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Interv_Afw_MSG",
          |"id": 178301
          |},
          |{
          |"name": "HYP.aanvragen_CLT09.0",
          |"id": 32114
          |},
          |{
          |"name": "ZAP.Helpdesk-2de-lijn.0",
          |"id": 35451
          |},
          |{
          |"name": "PBW.NO-team3_Zwolle.0",
          |"id": 128259
          |},
          |{
          |"name": "ZAP.ZBI_VV_Ophef_Verw_Dag3_MSG",
          |"id": 173358
          |},
          |{
          |"name": "ZAP.KVC_AP_PEGA_Revolving_MSG",
          |"id": 176439
          |},
          |{
          |"name": "ZAP.KIA_Algemeen_Spin_MSG",
          |"id": 167250
          |},
          |{
          |"name": "ZAP.ASOM_Sparen_Rechtspos_MSG",
          |"id": 165408
          |},
          |{
          |"name": "ZAP.Zakelijk_IBP_Helpdesk.1",
          |"id": 35406
          |},
          |{
          |"name": "HYP.aanvragen_CLT01.0",
          |"id": 31102
          |},
          |{
          |"name": "HYP.retentie_connect.0",
          |"id": 32201
          |},
          |{
          |"name": "LEN.Archief.0",
          |"id": 29150
          |},
          |{
          |"name": "ZAP.Lenen_CMN.1",
          |"id": 110300
          |},
          |{
          |"name": "ZAP.SDN_Maatwerk_VOO_MSG",
          |"id": 179251
          |},
          |{
          |"name": "LEN.Risicobeheer.2",
          |"id": 368
          |},
          |{
          |"name": "ZAP.Bankkluis.1",
          |"id": 143254
          |},
          |{
          |"name": "FRD.CREDIT_Reserveringen_MSG",
          |"id": 170270
          |},
          |{
          |"name": "ZAP.ZBI_PPC_of_OAB_Aanv_MSG",
          |"id": 173370
          |},
          |{
          |"name": "HYP.elt.2",
          |"id": 32141
          |},
          |{
          |"name": "ZAP.ASOM_Caseturning18_MSG",
          |"id": 165252
          |},
          |{
          |"name": "PBW.ZO-team2_DenBosch.1",
          |"id": 129276
          |},
          |{
          |"name": "ZAP.Lenen_Spin_MSG",
          |"id": 157352
          |},
          |{
          |"name": "ZAP.KVC_FZ_Dag_Keycontrols_MSG",
          |"id": 176363
          |},
          |{
          |"name": "ZAP.BSLK_Ontdubbelen_MSG",
          |"id": 171250
          |},
          |{
          |"name": "ZAP.Lenen_Beheer_Reversal_MSG",
          |"id": 176495
          |},
          |{
          |"name": "ZAP.Lenen_CV_Alg_FraudFiat_MSG",
          |"id": 176546
          |},
          |{
          |"name": "HYP.Concreet-Zakelijk.2",
          |"id": 53504
          |},
          |{
          |"name": "FRD.CREDIT_Arbitration_MSG",
          |"id": 170271
          |},
          |{
          |"name": "HYP.hsp_beheer.0",
          |"id": 31137
          |},
          |{
          |"name": "KYC.ProjectCO-Team6.2",
          |"id": 167359
          |},
          |{
          |"name": "PBW.PWAM-team09.1",
          |"id": 129316
          |},
          |{
          |"name": "ZAP.BSLK_Convenanten_Spin_MSG",
          |"id": 182251
          |},
          |{
          |"name": "FRD.Fraud_Detection_Betalen.0",
          |"id": 140302
          |},
          |{
          |"name": "BELL.Mifid.0",
          |"id": 98350
          |},
          |{
          |"name": "ZAP.KVC_BP_Kort_verz_Card_MSG",
          |"id": 192406
          |},
          |{
          |"name": "FRD.CREDIT_Stat_processen_MSG",
          |"id": 171313
          |},
          |{
          |"name": "FRD.PAY_DAD_MSG",
          |"id": 172259
          |},
          |{
          |"name": "ZAP.KVC_BP_Verzoek_Spoed_MSG",
          |"id": 176479
          |},
          |{
          |"name": "Col.sec_Rente_Pauze.1",
          |"id": 26060
          |},
          |{
          |"name": "FRD.PAYSUP_Navraag_afs_Alg_MSG",
          |"id": 171302
          |},
          |{
          |"name": "ZAP.ZIO_Waterspin_Open_Fys_MSG",
          |"id": 178350
          |},
          |{
          |"name": "ZAP.ZBI_G_Beheer_Fiat_Dag2_MSG",
          |"id": 173357
          |},
          |{
          |"name": "KYC.EHMT-Team4.0",
          |"id": 52308
          |},
          |{
          |"name": "ZAP.Zakelijk_PPC.0",
          |"id": 41301
          |},
          |{
          |"name": "PBW.NO-team1_Zwolle.1",
          |"id": 129356
          |},
          |{
          |"name": "ZAP.Helpdesk_App.0",
          |"id": 61313
          |},
          |{
          |"name": "ZAP.KVC_Coll_OS_Saldo_MSG",
          |"id": 176358
          |},
          |{
          |"name": "PBW.ZO-team1_DenBosch.1",
          |"id": 129372
          |},
          |{
          |"name": "ZAP.ZAE_Ideal_MSG",
          |"id": 180306
          |},
          |{
          |"name": "ZAP.Betalen.0",
          |"id": 35300
          |},
          |{
          |"name": "Z_Kred-Nieuw_Verhoging",
          |"id": 21
          |},
          |{
          |"name": "ZAP.BSLK_Incasso_MSG",
          |"id": 169250
          |},
          |{
          |"name": "ZAP.KVC_BC_Aanvr_Spoed_MSG",
          |"id": 176471
          |},
          |{
          |"name": "ZAP.ASOM_Rechtsvorm_Spin_MSG",
          |"id": 165404
          |},
          |{
          |"name": "ZAP.Betalen_Betalen_GR.0",
          |"id": 157350
          |},
          |{
          |"name": "HYP.aanvragen_CLT10.2",
          |"id": 32118
          |},
          |{
          |"name": "HYP.omzetten.1",
          |"id": 31122
          |},
          |{
          |"name": "ZAP.KVC_BC_Overstapservice_MSG",
          |"id": 176420
          |},
          |{
          |"name": "LEN.Grootzakelijk_PPW.1",
          |"id": 364
          |},
          |{
          |"name": "KYC.INV-Investigations.1",
          |"id": 52309
          |},
          |{
          |"name": "ZAP.BenF_Beslagen_Spin_MSG",
          |"id": 166255
          |},
          |{
          |"name": "ZAP.ZAE_EBSD_2e_Lijn_MSG",
          |"id": 179256
          |},
          |{
          |"name": "ZAP.KVC_Fallback_MSG",
          |"id": 176386
          |},
          |{
          |"name": "ZAP.ZBI_G_Ophef_Verw_Dag1_MSG",
          |"id": 173359
          |},
          |{
          |"name": "Z-Kred.Financieren_CHT",
          |"id": 102352
          |},
          |{
          |"name": "KAP.Beheer_Regulier_MSG",
          |"id": 89422
          |},
          |{
          |"name": "FRD.Detection_CreditCard.0",
          |"id": 140301
          |},
          |{
          |"name": "ZAP.BenF_Deel_af_boeking_MSG",
          |"id": 167304
          |},
          |{
          |"name": "HYP.aflossen_notaris.0",
          |"id": 32128
          |},
          |{
          |"name": "ZAP.ZIO_Zak_Bet_Vraagbaak_MSG",
          |"id": 176397
          |}]}
        """.stripMargin

      implicit val residentReads0 = Json.reads[SkillMapping]
      implicit val residentReads2 = Json.reads[TwilioSkills]
      val z = (Json.parse(sms) \"data").as[List[SkillMapping]]
      val z1 = (Json.parse(ts1) \"data").as[List[TwilioSkills]]
      val z2 = (Json.parse(ts2) \"data").as[List[TwilioSkills]]
      val z3 = z1 ++ z2
      val uniqueTwilioSkillsToSet = z.map(_.twilioSkills).toSet.flatten
      val actualTwilioSkillNames = z3.map(_.name).toSet
      println((uniqueTwilioSkillsToSet diff actualTwilioSkillNames).size)
      val z8 = uniqueTwilioSkillsToSet diff actualTwilioSkillNames
      z8.map(zz => {
        val f: Seq[SkillMapping] = z.filter(zzz => zzz.twilioSkills.contains(zz))
        f.map(ff => println(ff.teleoptiSkill + "-->" + zz))
      })
    }
  }
}
case class SkillMapping(accountName: String = "", teleoptiSkill: String, twilioSkills: Set[String] = Set.empty) {
  require(teleoptiSkill.nonEmpty, "Teleopti skill cannot be empty")
}

case class TwilioSkills(name: String, id: Int)

package models

import org.scalatest.{FunSpec, Matchers}
import org.scalatestplus.mockito.MockitoSugar
import rules.StandardGame

class GameTest extends FunSpec with MockitoSugar with Matchers {
  describe("GameTest") {
    val opponent = Player("op full name", "opp-id", SpaceshipProtocol("host", 1000))
    val game = Game(opponent = opponent, rules = StandardGame())

    it("should return correct shots status and update self grid for accepting shots") {
      val firstPresenceOfSpaceship = game.selfGrid.array.zipWithIndex.find(elAndIndex => elAndIndex._1.contains('*')).get
      val row = firstPresenceOfSpaceship._2
      val salvo = List.range(0, 10).map(i => s"${row}x$i") ++ Seq(s"${row}xA", s"${row}xB", s"${row}xC", s"${row}xD", s"${row}xE", s"${row}xF")
      game.acceptShots(Shots(salvo)).right.get should contain("hit")
    }

    it("should check shots validity before accepting") {
      game.acceptShots(Shots(List("0x0","0x1","0x2","0x3","0xM"))) should be(Left("Error parsing shots"))
    }

    it("should update game finished status when finished for accepting shots") {
      game.acceptShots(Shots(List("0x0","0x1","0x2","0x3","0x4","0x5","0x6","0x7","0x8","0x9","0xA","0xB","0xC","0xD","0xE","0xF","1x0","1x1","1x2","1x3","1x4","1x5","1x6","1x7","1x8","1x9","1xA","1xB","1xC","1xD","1xE","1xF","2x0","2x1","2x2","2x3","2x4","2x5","2x6","2x7","2x8","2x9","2xA","2xB","2xC","2xD","2xE","2xF","3x0","3x1","3x2","3x3","3x4","3x5","3x6","3x7","3x8","3x9","3xA","3xB","3xC","3xD","3xE","3xF","4x0","4x1","4x2","4x3","4x4","4x5","4x6","4x7","4x8","4x9","4xA","4xB","4xC","4xD","4xE","4xF","5x0","5x1","5x2","5x3","5x4","5x5","5x6","5x7","5x8","5x9","5xA","5xB","5xC","5xD","5xE","5xF","6x0","6x1","6x2","6x3","6x4","6x5","6x6","6x7","6x8","6x9","6xA","6xB","6xC","6xD","6xE","6xF","7x0","7x1","7x2","7x3","7x4","7x5","7x6","7x7","7x8","7x9","7xA","7xB","7xC","7xD","7xE","7xF","8x0","8x1","8x2","8x3","8x4","8x5","8x6","8x7","8x8","8x9","8xA","8xB","8xC","8xD","8xE","8xF","9x0","9x1","9x2","9x3","9x4","9x5","9x6","9x7","9x8","9x9","9xA","9xB","9xC","9xD","9xE","9xF","Ax0","Ax1","Ax2","Ax3","Ax4","Ax5","Ax6","Ax7","Ax8","Ax9","AxA","AxB","AxC","AxD","AxE","AxF","Bx0","Bx1","Bx2","Bx3","Bx4","Bx5","Bx6","Bx7","Bx8","Bx9","BxA","BxB","BxC","BxD","BxE","BxF","Cx0","Cx1","Cx2","Cx3","Cx4","Cx5","Cx6","Cx7","Cx8","Cx9","CxA","CxB","CxC","CxD","CxE","CxF","Dx0","Dx1","Dx2","Dx3","Dx4","Dx5","Dx6","Dx7","Dx8","Dx9","DxA","DxB","DxC","DxD","DxE","DxF","Ex0","Ex1","Ex2","Ex3","Ex4","Ex5","Ex6","Ex7","Ex8","Ex9","ExA","ExB","ExC","ExD","ExE","ExF","Fx0","Fx1","Fx2","Fx3","Fx4","Fx5","Fx6","Fx7","Fx8","Fx9","FxA","FxB","FxC","FxD","FxE","FxF")))
      game.isGameFinished should be(true)
    }

    it("should update opponent shot results and game finished status") {
      val game = Game(opponent = opponent, rules = StandardGame())
      game.updateOpponentShots(Map("0x0" -> "hit", "0x1" -> "kill", "0x2" -> "miss"))
      game.opponentGrid.array.head.mkString("") should be("XX-.............")
      game.isGameFinished should be(false)
      game.updateOpponentShots(Map("0x0" -> "hit", "0x1" -> "kill", "0x2" -> "miss"), true)
      game.isGameFinished should be(true)
    }
  }
}

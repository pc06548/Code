sbt clean
sbt compile
sbt dist
unzip -o target/universal/spaceship-1.0.0.zip && chmod +x spaceship-1.0.0/bin/spaceship
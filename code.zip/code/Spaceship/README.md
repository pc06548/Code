# Spaceship

## Start

From terminal project home directory run following commands
1. To run the application default 8080:
    $ ./run.sh
    
    ./run.sh takes following parameters
    1) -p 9000 (port number, defaults 8080)
    2) -f prashant (fullName, defaults random)
    3) -u userid (userid, defaults random)

2. To run with custom params:
    $ ./script.sh -p 8081 -u userId-2 -f fullName-2

3. To compile and package and test
    Need to have sbt on machine
    to test $ sbt test
    to prepare build $ ./build.sh

## Language/Frameworks used
Scala
Play
Akka - Actor
Scala Html Template + Javascript

Once the servers are up
1. Visit the browser at http://hostname:port/
2. Once games are created you can follow links from home page or visit http://hostname:port/xl-spaceship/:gameId
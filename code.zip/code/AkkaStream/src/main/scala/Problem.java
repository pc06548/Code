import java.util.*;

public class Problem {
    public static void main(String[] args) {
        System.out.println(maximumOccurringCharacter("helloworld"));
        System.out.println(maxTrailing(new ArrayList<Integer>(Arrays.asList(5,3,6,7,4))));
        System.out.println(maxTrailing(new ArrayList<Integer>(Arrays.asList(7,2,3, 10, 2, 4, 8, 1))));
        System.out.println(maxTrailing(new ArrayList<Integer>(Arrays.asList(6,7,9,5,6,3,2))));
    }

    public static int maxTrailing(List<Integer> levels) {
        // Write your code here
        int minIndex = 0;
        int maxIndex = 0;
        int nonEligibleMinIndex = 0;
        for(int i = 0; i < levels.size(); i++) {
            int intAtI = levels.get(i);
            if (intAtI > levels.get(maxIndex) || (intAtI - levels.get(nonEligibleMinIndex) > levels.get(maxIndex) -  levels.get(minIndex))) {
                maxIndex = i;
                minIndex = nonEligibleMinIndex;
            }
            if(intAtI < levels.get(nonEligibleMinIndex)) {
                nonEligibleMinIndex = i;
            }
        }
        if (maxIndex > minIndex) {
            return levels.get(maxIndex) - levels.get(minIndex);
        } else {
            return -1;
        }
    }

    public static char maximumOccurringCharacter(String text) {
        // Write your code here
        Map<Character, Integer> map = new HashMap();
        Set<Character> uniqueSeq = new LinkedHashSet();
        int countMax = 0;
        for (int i=0; i < text.length(); i++) {
            int countCurrent = 1;
            char c = text.charAt(i);
            if (map.containsKey(c)) {
                countCurrent += map.get(c);
            }
            map.put(c, countCurrent);
            if(countCurrent > countMax) {
                countMax = countCurrent;
            }
            if(!uniqueSeq.contains(c)) {
                uniqueSeq.add(c);
            }
        }
        for(Character uniqueCh: uniqueSeq) {
            if(map.get(uniqueCh) == countMax) {
                return uniqueCh;
            }
        }
        return '-';
    }
}

import CrawlerActor.{NewUrls, Crawl}
import CrawlerExecutor.actorSystem
import akka.actor.{Actor, ActorLogging, ActorRef, ActorSystem, Props}
import akka.http.scaladsl.Http
import akka.http.scaladsl.model.{HttpMethods, HttpRequest}
import akka.http.scaladsl.unmarshalling.Unmarshal
import akka.stream.ActorMaterializer
import net.ruippeixotog.scalascraper.browser.JsoupBrowser
import net.ruippeixotog.scalascraper.dsl.DSL.Extract._
import net.ruippeixotog.scalascraper.dsl.DSL._

import scala.concurrent.ExecutionContext.Implicits._


class CrawlerActor(baseUrl: String) extends Actor with ActorLogging {

  var exploredUrls = Set.empty[String]
  var urls = Set.empty[String]

  override def preStart() = {
    urls = urls + baseUrl
  }

  override def receive: Receive = {
    case Crawl =>
      val newUrls = urls
      exploredUrls = exploredUrls ++ urls
      log.info(s"exploredUrls size: ${exploredUrls.size}")
      urls = urls.empty
      newUrls.map(url => {
        val crawlerActor = context.actorOf(Props(new ExplorerActor(url)))
        crawlerActor ! Crawl
      })
    case NewUrls(newUrls) =>
      urls = newUrls -- exploredUrls
      if (urls.size > 0) {
        log.info(s"found new ${urls.size}")
        urls.map(url => log.debug(url))
        self ! Crawl
      } else {
        log.error(s"Finished processing: ${exploredUrls.size}")
      }
  }

}

class ExplorerActor(url: String) extends Actor with ActorLogging {
  implicit val materilazer = ActorMaterializer()(context.system)
  override def receive: Receive = {
    case Crawl =>  {
      val request = HttpRequest(HttpMethods.GET, url)
      val browser = JsoupBrowser()
      log.debug(s"Exploring url ${request.uri}")
      Http()(context.system).singleRequest(request).map(response => {
        log.info(s"Resonse received for $url. Status code ${response.status}")
        Unmarshal(response).to[String].map(responseString => {
          val doc = browser.parseString(responseString)
          val wiproUrls: Set[String] = (doc >> elementList("a").map(_ >> attr("href"))).toSet.filter(_.startsWith("https://wiprodigital.com") )
          context.parent ! NewUrls(wiproUrls)
        })
      })
    }
  }
}


object CrawlerActor {
  case class AddUrl(url: String)
  case object Crawl
  case class NewUrls(urls: Set[String])
}


object CrawlerExecutor extends App {
  implicit val actorSystem = ActorSystem()
  val crawlerActor: ActorRef = actorSystem.actorOf(Props(new CrawlerActor("https://wiprodigital.com/")),"crawler-actor")
  crawlerActor ! Crawl

}
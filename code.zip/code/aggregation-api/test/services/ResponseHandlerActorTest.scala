package services

import akka.actor.{ActorSystem, Props}
import akka.testkit.{TestKit, TestProbe}
import clients.dtos._
import config.SystemModule
import models.{AggregationResult, PricingResult, ShipmentResult, TrackingResult}
import org.scalatest.FunSpecLike

import scala.collection.mutable.ListBuffer
import scala.concurrent.duration._

class ResponseHandlerActorTest  extends TestKit(ActorSystem("test-system")) with FunSpecLike {

  val testModule = new SystemModule {}

  val service = new AggregationThrottleService(testModule)
  val actor = testModule.actorSystem.actorOf(Props(new service.ResponseHandlerActor), "test-actor")


  describe("ResponseHandlerActorTest") {

    it("should add request and handle response and send out response") {
      val probe = TestProbe()(testModule.actorSystem)
      val shipmentQueries = ListBuffer("123", "456")
      val pricingQueries = ListBuffer("CN", "NL")
      val trackingQueries = ListBuffer("123", "456")

      val requestResponse = service.RequestResponse(probe.ref, AggregationResult(shipmentQueries, trackingQueries, pricingQueries))

      actor ! service.AddRequestCommand(requestResponse)

      val shipmentResponse = ShipmentResponseDto(Right(Map("123" -> Seq("box", "box", "pallet"), "456" -> Seq.empty)))
      actor ! shipmentResponse

      val pricingResponse = PricingResponseDto(Right(Map("CN" -> Some(BigDecimal(1.2)), "NL" -> None)))
      actor ! pricingResponse

      val trackingResponse = TrackingResponseDto(Right(Map("123" -> Some("NEW"), "456" -> None)))
      actor ! trackingResponse

      probe.expectMsg[AggregationResult](
        AggregationResult(
          ShipmentResult(Map("123" -> List("box", "box", "pallet"), "456" -> List())),
          TrackingResult(Map("123" -> Some("NEW"), "456" -> None)),
          PricingResult(Map("CN" -> Some(BigDecimal(1.2)), "NL" -> None))))
    }

    it("should add request and handle response and not send out response when all responses are not in") {
      val probe = TestProbe()(testModule.actorSystem)
      val shipmentQueries = ListBuffer("123", "456")
      val pricingQueries = ListBuffer("CN", "NL")
      val trackingQueries = ListBuffer("123", "456")

      val requestResponse = service.RequestResponse(probe.ref, AggregationResult(shipmentQueries, trackingQueries, pricingQueries))

      actor ! service.AddRequestCommand(requestResponse)

      val shipmentResponse = ShipmentResponseDto(Right(Map("123" -> Seq("box", "box", "pallet"), "456" -> Seq.empty)))
      actor ! shipmentResponse

      val pricingResponse = PricingResponseDto(Right(Map("CN" -> Some(BigDecimal(1.2)), "NL" -> None)))
      actor ! pricingResponse

      // send partial tracking response, no response for q=456
      val trackingResponse = TrackingResponseDto(Right(Map("123" -> Some("NEW"))))
      actor ! trackingResponse

      probe.expectNoMessage(3 seconds)
    }
  }

  it("should add multiple requests and handle response and send only completed responses") {
    val probe = TestProbe()(testModule.actorSystem)
    val probe1 = TestProbe()(testModule.actorSystem)
    val probe2 = TestProbe()(testModule.actorSystem)

    val shipmentQueries = ListBuffer("123", "456")
    val pricingQueries = ListBuffer("CN", "NL")
    val trackingQueries = ListBuffer("123", "456")

    val shipmentQueries1 = ListBuffer("123", "3")
    val pricingQueries1 = ListBuffer("CN", "IN")
    val trackingQueries1 = ListBuffer("123", "3")

    val shipmentQueries2 = ListBuffer("123", "4")
    val pricingQueries2 = ListBuffer("CN", "IN")
    val trackingQueries2 = ListBuffer("123", "4")

    val requestResponse = service.RequestResponse(probe.ref, AggregationResult(shipmentQueries, trackingQueries, pricingQueries))
    val requestResponse1 = service.RequestResponse(probe1.ref, AggregationResult(shipmentQueries1, trackingQueries1, pricingQueries1))
    val requestResponse2 = service.RequestResponse(probe2.ref, AggregationResult(shipmentQueries2, trackingQueries2, pricingQueries2))

    // send all 3 requests
    actor ! service.AddRequestCommand(requestResponse)
    actor ! service.AddRequestCommand(requestResponse1)
    actor ! service.AddRequestCommand(requestResponse2)

    val shipmentResponse = ShipmentResponseDto(Right(Map("123" -> Seq("box", "box", "pallet"), "456" -> Seq.empty)))
    actor ! shipmentResponse

    val pricingResponse = PricingResponseDto(Right(Map("CN" -> Some(BigDecimal(1.2)), "NL" -> None)))
    actor ! pricingResponse

    val trackingResponse = TrackingResponseDto(Right(Map("123" -> Some("NEW"), "456" -> None)))
    actor ! trackingResponse

    // send 2nd round of responses
    val shipmentResponse1 = ShipmentResponseDto(Right(Map("3" -> Seq.empty)))
    actor ! shipmentResponse1

    val pricingResponse1 = PricingResponseDto(Right(Map("IN" -> None)))
    actor ! pricingResponse1

    val trackingResponse1 = TrackingResponseDto(Right(Map("3" -> None)))
    actor ! trackingResponse1

    // expect two requests are handled
    probe.expectMsg[AggregationResult](
      AggregationResult(
        ShipmentResult(Map("123" -> List("box", "box", "pallet"), "456" -> List()), List()),
        TrackingResult(Map("123" -> Some("NEW"), "456" -> None), List()),
        PricingResult(Map("CN" -> Some(BigDecimal(1.2)), "NL" -> None), List())))

    probe1.expectMsg[AggregationResult](
      AggregationResult(
        ShipmentResult(Map("123" -> List("box", "box", "pallet"), "3" -> List()), List()),
        TrackingResult(Map("123" -> Some("NEW"), "3" -> None), List()),
        PricingResult(Map("CN" -> Some(BigDecimal(1.2)), "IN" -> None), List())))

    // expect last is not handled
    probe2.expectNoMessage(3 seconds)

  }

}

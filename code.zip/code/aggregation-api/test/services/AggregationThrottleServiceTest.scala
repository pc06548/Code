package services

import ch.qos.logback.classic.Level
import clients.dtos._
import clients.http.{PricingClient, ShipmentClient, TrackingClient}
import config.SystemModule
import helper.{LogMessageLevelTimes, MockLogging}
import models.AggregationResult
import org.mockito.Mockito
import org.mockito.Mockito.when
import org.scalatest.{AsyncFunSpec, BeforeAndAfterEach}
import models._

import scala.concurrent.Future
import scala.concurrent.duration._


class AggregationThrottleServiceTest extends AsyncFunSpec with MockLogging[AggregationThrottleService] with BeforeAndAfterEach {

  val trackingClientMock = mock[TrackingClient]
  val shipmentClientMock = mock[ShipmentClient]
  val pricingClientMock = mock[PricingClient]

  val testModule = new SystemModule {
    override val pricingClient: PricingClient = pricingClientMock
    override val shipmentClient: ShipmentClient = shipmentClientMock
    override val trackingClient: TrackingClient = trackingClientMock
    override val FORCE_SEND_REQ_TIME: FiniteDuration = 2 seconds
  }

  val service = new AggregationThrottleService(testModule)

  override protected def beforeEach(): Unit = {
    initMockLogging
  }

  describe("AggregationThrottleServiceTest") {

    /* This test is from story 2 and is no more valid. Needs to be removed
    it("should timeout the request when there are no sufficient requests") {

      val shipmentQueries = Seq("123", "456")
      val pricingQueries = Seq("CN", "NL")
      val trackingQueries = Seq("123", "456")

      service.execute(shipmentQueries, trackingQueries, pricingQueries) map {
        result => {
          verifyMultipleMessagesMultipleTimes(
            Seq(LogMessageLevelTimes("Unexpected error occurred while getting API responses, {}", Level.ERROR, 1))
          )
          assert(result == Left("Unexpected error while getting api responses"))
        }
      }
    }*/

    it("should complete the request when there are sufficient requests") {
      when(shipmentClientMock.getShipments(Seq("123", "456", "321", "543", "567"))(testModule.executionContext)).thenReturn(Future.successful(ShipmentResponseDto(Right(Map(
        "123" -> Seq("box", "box", "pallet"),
        "456" -> Seq.empty,
        "321" -> Seq.empty,
        "543" -> Seq.empty,
        "567" -> Seq.empty,
      )))))


      when(pricingClientMock.getPricing(Seq("CN", "NL", "IN", "US", "UK"))(testModule.executionContext)).thenReturn(Future.successful(PricingResponseDto(Right(Map(
        "CN" -> Some(BigDecimal(1.2)),
        "NL" -> None,
        "IN" -> None,
        "US" -> None,
        "UK" -> None
      )))))


      when(trackingClientMock.getTracking(Seq("123", "456", "321", "543", "567"))(testModule.executionContext)).thenReturn(Future.successful(TrackingResponseDto(Right(Map(
        "123" -> Some("NEW"),
        "456" -> None,
        "321" -> None,
        "543" -> None,
        "567" -> None
      )))))

      val shipmentQueries = Seq("123", "456", "321", "543", "567")
      val pricingQueries = Seq("CN", "NL", "IN", "US", "UK")
      val trackingQueries = Seq("123", "456", "321", "543", "567")

      val expectedResponse = AggregationResult(
        ShipmentResult(Map("321" -> List(), "567" -> List(), "123" -> List("box", "box", "pallet"), "456" -> List(), "543" -> List())),
        TrackingResult(Map("321" -> None, "567" -> None, "123" -> Some("NEW"), "456" -> None, "543" -> None)),
        PricingResult(Map("IN" -> None, "US" -> None, "UK" -> None, "NL" -> None, "CN" -> Some(BigDecimal(1.2)))))

      service.execute(shipmentQueries, trackingQueries, pricingQueries) map {
        result => {
          assert(result == Right(expectedResponse))
        }
      }
    }

    it("should complete the request after force time is reached when there are not sufficient requests") {
      when(shipmentClientMock.getShipments(Seq("123", "456"))(testModule.executionContext)).thenReturn(Future.successful(ShipmentResponseDto(Right(Map(
        "123" -> Seq("box", "box", "pallet"),
        "456" -> Seq.empty
      )))))


      when(pricingClientMock.getPricing(Seq("CN", "NL"))(testModule.executionContext)).thenReturn(Future.successful(PricingResponseDto(Right(Map(
        "CN" -> Some(BigDecimal(1.2)),
        "NL" -> None
      )))))


      when(trackingClientMock.getTracking(Seq("123", "456"))(testModule.executionContext)).thenReturn(Future.successful(TrackingResponseDto(Right(Map(
        "123" -> Some("NEW"),
        "456" -> None
      )))))

      val shipmentQueries = Seq("123", "456")
      val pricingQueries = Seq("CN", "NL")
      val trackingQueries = Seq("123", "456")

      val expectedResponse = AggregationResult(
        ShipmentResult(Map("123" -> List("box", "box", "pallet"), "456" -> List())),
        TrackingResult(Map("123" -> Some("NEW"), "456" -> None)),
        PricingResult(Map("NL" -> None, "CN" -> Some(BigDecimal(1.2)))))

      service.execute(shipmentQueries, trackingQueries, pricingQueries) map {
        result => {
          assert(result == Right(expectedResponse))
        }
      }
    }

  }

}

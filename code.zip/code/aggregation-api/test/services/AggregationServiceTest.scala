package services

import clients.dtos._
import clients.http.{PricingClient, ShipmentClient, TrackingClient}
import config.SystemModule
import helper.MockLogging
import models.{AggregationResult, PricingResult, ShipmentResult, TrackingResult}
import org.scalatest.AsyncFunSpec
import org.mockito.Mockito.when

import scala.concurrent.Future

class AggregationServiceTest extends AsyncFunSpec with MockLogging[AggregationService] {

  val trackingClientMock = mock[TrackingClient]
  val shipmentClientMock = mock[ShipmentClient]
  val pricingClientMock = mock[PricingClient]

  val testModule = new SystemModule {
    override val pricingClient: PricingClient = pricingClientMock
    override val shipmentClient: ShipmentClient = shipmentClientMock
    override val trackingClient: TrackingClient = trackingClientMock
  }

  val service = new AggregationService(testModule)

  describe("AggregationServiceTest") {

    it("should execute all the requests") {
      val shipmentQueries = Seq("123", "456")
      val pricingQueries = Seq("CN", "NL")
      val trackingQueries = Seq("123", "456")

      when(shipmentClientMock.getShipments(Seq("123", "456"))(testModule.executionContext)).thenReturn(Future.successful(ShipmentResponseDto(Right(Map(
        "123" -> Seq("box", "box", "pallet"),
        "456" -> Seq.empty
      )))))


      when(pricingClientMock.getPricing(Seq("CN", "NL"))(testModule.executionContext)).thenReturn(Future.successful(PricingResponseDto(Right(Map(
        "CN" -> Some(BigDecimal(1.2)),
        "NL" -> None
      )))))


      when(trackingClientMock.getTracking(Seq("123", "456"))(testModule.executionContext)).thenReturn(Future.successful(TrackingResponseDto(Right(Map(
        "123" -> Some("NEW"),
        "456" -> None
      )))))

      service.execute(shipmentQueries,trackingQueries, pricingQueries) map { result =>
        assert(result ==
          Right(AggregationResult(
            ShipmentResult(Map("123" -> List("box", "box", "pallet"), "456" -> List())),
            TrackingResult(Map("123" -> Some("NEW"), "456" -> None)),
            PricingResult(Map("CN" -> Some(BigDecimal(1.2)), "NL" -> None)))))
      }
    }

    it("should handle failure of any request") {
      val shipmentQueries = Seq("123", "456")
      val pricingQueries = Seq("CN", "NL")
      val trackingQueries = Seq("123", "456")

      when(shipmentClientMock.getShipments(Seq("123", "456"))(testModule.executionContext)).thenReturn(Future.failed(new Exception("some error")))


      when(pricingClientMock.getPricing(Seq("CN", "NL"))(testModule.executionContext)).thenReturn(Future.successful(PricingResponseDto(Right(Map(
        "CN" -> Some(BigDecimal(1.2)),
        "NL" -> None
      )))))


      when(trackingClientMock.getTracking(Seq("123", "456"))(testModule.executionContext)).thenReturn(Future.successful(TrackingResponseDto(Right(Map(
        "123" -> Some("NEW"),
        "456" -> None
      )))))

      service.execute(shipmentQueries,trackingQueries, pricingQueries) map { result =>
        assert(result == Left("Unexpected error while getting api responses"))
      }
    }
  }
}

package clients.http

import ch.qos.logback.classic.Level
import helper.{LogMessageLevelTimes, MockLogging}
import org.mockito.Mockito.when
import org.mockito.{ArgumentMatchers, Mockito}
import org.scalatest.{AsyncFunSpec, BeforeAndAfterEach}
import play.api.libs.json.Json
import play.api.libs.ws.{WSClient, WSRequest, WSResponse}

import scala.concurrent.Future


class ShipmentClientTest extends AsyncFunSpec with BeforeAndAfterEach with MockLogging[ShipmentClient]  {
  val wsClientMock = mock[WSClient]
  val requestMock = mock[WSRequest]

  val host = "localhost"

  val client = new ShipmentClient(host, wsClientMock)

  override protected def beforeEach(): Unit = {
    initMockLogging
    Mockito.reset(wsClientMock)
  }

  describe("ShipmentClientTest") {
    it("should getShipments for queries and ignore all other responses") {
      val responseMock = mock[WSResponse]

      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(responseMock.status).thenReturn(200)
      when(responseMock.json).thenReturn(Json.parse(s"""{
                                                  "123": ["box", "box", "pallet"],
                                                  "789": ["box", "box", "pallet"]}""".stripMargin))

      val responseF = client.getShipments(Seq("123", "456"))

      responseF.map(response => {
        assert(response.errorOrResult == Right(Map(("123", Seq("box", "box", "pallet")), ("456", Seq()))))
      })
    }

    it("should handle error for non 200 status code") {
      val responseMock = mock[WSResponse]

      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(requestMock.url).thenReturn("/shipment?q=123,456")
      when(responseMock.status).thenReturn(500)

      val responseF = client.getShipments(Seq("123", "456"))

      responseF.map(response => {
        verifyMultipleMessagesMultipleTimes(
          Seq(
            LogMessageLevelTimes("Unexpected response status for request: /shipment?q=123,456. Code: 500", Level.ERROR, 1),
          )
        )
        assert(response.errorOrResult == Right(Map(("123", Seq()), ("456", Seq()))))
      })
    }

    it("should handle non json responses") {
      val responseMock = mock[WSResponse]

      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(requestMock.url).thenReturn("/shipment?q=123,456")
      when(responseMock.status).thenReturn(200)
      when(responseMock.json).thenThrow(new RuntimeException)


      val responseF = client.getShipments(Seq("123", "456"))

      responseF.map(response => {
        verifyMultipleMessagesMultipleTimes(
          Seq(
            LogMessageLevelTimes("Non json response for request: /shipment?q=123,456. Error: null", Level.ERROR, 1),
          )
        )
        assert(response.errorOrResult == Right(Map(("123", Seq()), ("456", Seq()))))
      })
    }
  }
}

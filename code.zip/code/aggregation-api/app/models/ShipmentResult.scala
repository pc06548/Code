package models

case class ShipmentResult(value: Map[String, Seq[String]], pendingQueries: Seq[String]) extends ApiResult {

  def addResult(newResult: Map[String, Seq[String]]) = {
    val filteredMap = newResult.filter((keyValue) => pendingQueries.contains(keyValue._1))
    val newPendingQueries = pendingQueries.diff(newResult.keys.toSeq)
    val newMap = value ++ filteredMap
    ShipmentResult(newMap, newPendingQueries)
  }

  def isResultComplete = pendingQueries.isEmpty

}

object ShipmentResult {
  def empty = ShipmentResult(Seq.empty)

  def apply(queries: Seq[String]): ShipmentResult = new ShipmentResult(Map.empty, queries)

  def apply(map: Map[String, Seq[String]]): ShipmentResult = new ShipmentResult(map, Seq.empty)
}

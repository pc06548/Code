package models

trait ApiResult
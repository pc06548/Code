package config

import akka.actor.ActorSystem
import akka.stream.ActorMaterializer
import akka.util.Timeout
import clients.http.{PricingClient, ShipmentClient, TrackingClient}
import com.google.inject.AbstractModule
import play.api.libs.ws.WSClient
import play.api.libs.ws.ahc.{AhcWSClient, StandaloneAhcWSClient}
import services.{AggregationServiceT, AggregationThrottleService}

import scala.concurrent.ExecutionContext.Implicits
import scala.concurrent.duration._

trait SystemModule {
  implicit val actorSystem = ActorSystem("api-actor-system")
  implicit val mat = ActorMaterializer()
  implicit val timeout = Timeout(10 seconds)

  implicit val executionContext = Implicits.global

  private val httpClient: StandaloneAhcWSClient = StandaloneAhcWSClient()
  val wsClient: WSClient = new AhcWSClient(httpClient)

  val shipmentClient = new ShipmentClient("localhost:8080", wsClient)
  val trackingClient = new TrackingClient("localhost:8080", wsClient)
  val pricingClient = new PricingClient("localhost:8080", wsClient)

  val aggregationService: AggregationServiceT= new AggregationThrottleService(this)

  val REQUEST_CAP_COUNT = 5

  val FORCE_SEND_REQ_TIME = 5 seconds
}

class DefaultSystemModule extends SystemModule {
  override val aggregationService: AggregationServiceT = new AggregationThrottleService(this)
}

class BindModule extends AbstractModule {
  override def configure = {
    bind(classOf[SystemModule]).to(classOf[DefaultSystemModule])
  }
}
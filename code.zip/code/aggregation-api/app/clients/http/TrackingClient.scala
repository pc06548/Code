package clients.http

import clients.dtos.TrackingResponseDto
import com.typesafe.scalalogging.StrictLogging
import javax.inject.Inject
import play.api.libs.ws.{WSClient, WSResponse}

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class TrackingClient (host: String, @Inject() wsClient: WSClient) extends StrictLogging {
  val url = s"http://${host}/track"

  val request = wsClient.url(url)

  def getTracking(queries: Seq[String])(implicit executionContext: ExecutionContext): Future[TrackingResponseDto] = {
    if(queries.nonEmpty) {
      val responseF: Future[WSResponse] = request.withQueryStringParameters(("q" -> queries.mkString(","))).get()

      responseF map { response =>
        if (response.status == 200) {
          TrackingResponseDto(Right(parseResponse(response, queries)))
        } else {
          logger.error(s"Unexpected response status for request: ${request.url}. Code: ${response.status}")
          TrackingResponseDto(Right(emptyResponse(queries)))
        }
      } recover {
        case ex =>
          logger.error(s"Unexpected error occurred for request: ${request.url}. $ex")
          TrackingResponseDto(Left("Unexpected error occurred while getting tracking information"))
      }
    } else {
      logger.debug(s"Empty tracking response sent")
      Future.successful(TrackingResponseDto())
    }
  }

  private def parseResponse(response: WSResponse, queries: Seq[String]): Map[String, Option[String]] = {
    Try(response.json) match {
      case Success(json) =>
        queries.map(query => {
          (json \ query).asOpt[String] match {
            case Some(status) =>
              query -> Some(status)
            case None =>
              query -> None
          }
        }).toMap
      case Failure(error) =>
        logger.error(s"Non json response for request: ${request.url}. Error: ${error.getMessage}")
        emptyResponse(queries)
    }
  }

  private def emptyResponse(queries: Seq[String]) = queries.map(query => query -> None).toMap

}

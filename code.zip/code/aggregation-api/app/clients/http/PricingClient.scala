package clients.http

import clients.dtos.PricingResponseDto
import com.typesafe.scalalogging.StrictLogging
import javax.inject.Inject
import play.api.libs.ws.{WSClient, WSResponse}

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class PricingClient ( host: String, @Inject() wsClient: WSClient) extends StrictLogging {
  val url = s"http://${host}/pricing"

  val request = wsClient.url(url)

  def getPricing(queries: Seq[String])(implicit executionContext: ExecutionContext): Future[PricingResponseDto] = {
    if(queries.nonEmpty) {
      val responseF: Future[WSResponse] = request.withQueryStringParameters(("q" -> queries.mkString(","))).get()

      responseF map { response =>
        if (response.status == 200) {
          PricingResponseDto(Right(parseResponse(response, queries)))
        } else {
          logger.error(s"Unexpected response status for request: ${request.url}. Code: ${response.status}")
          PricingResponseDto(Right(emptyResponse(queries)))
        }
      } recover {
        case ex =>
          logger.error(s"Unexpected error occurred for request: ${request.url}. $ex")
          PricingResponseDto(Left("Unexpected error occurred while getting pricing information"))
      }
    } else {
      logger.debug(s"Empty pricing response sent")
      Future.successful(PricingResponseDto())
    }
  }

  private def parseResponse(response: WSResponse, queries: Seq[String]): Map[String, Option[BigDecimal]] = {
    Try(response.json) match {
      case Success(json) =>
        queries.map(query => {
          (json \ query).asOpt[BigDecimal] match {
            case Some(price) =>
              query -> Some(price)
            case None =>
              query -> None
          }
        }).toMap
      case Failure(error) =>
        logger.error(s"Non json response for request: ${request.url}. Error: ${error.getMessage}")
        emptyResponse(queries)
    }
  }

  private def emptyResponse(queries: Seq[String]) = queries.map(query => query -> None).toMap
}

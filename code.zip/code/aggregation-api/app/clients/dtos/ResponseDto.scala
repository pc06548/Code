package clients.dtos

trait ResponseDto
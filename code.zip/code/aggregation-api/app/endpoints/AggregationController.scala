package endpoints

import com.typesafe.scalalogging.StrictLogging
import config.SystemModule
import endpoints.helpers.ResponseHelpers
import javax.inject.Inject
import play.api.mvc.{AbstractController, ControllerComponents}

class AggregationController @Inject()(systemModule: SystemModule,
                                       controllerComponents: ControllerComponents)
  extends AbstractController(controllerComponents) with StrictLogging {

  import systemModule._
  import models.AggregationResultJsonWrites._

  def aggregate(shipments:String, track:String, pricing:String)= Action.async {

    val shipmentQueries = getSeqFromCommaSeperatedString(shipments)
    val trackQueries = getSeqFromCommaSeperatedString(track)
    val pricingQueries = getSeqFromCommaSeperatedString(pricing)

    logger.debug(s"Request received shipments=$shipmentQueries, track=$trackQueries, pricing=$pricingQueries")
    ResponseHelpers.eitherToResponse(systemModule.aggregationService.execute(shipmentQueries, trackQueries, pricingQueries))

  }

  private def getSeqFromCommaSeperatedString(value: String): Seq[String] = {
    value.split(",").map(_.trim).filterNot(_.isEmpty).distinct.toSeq
  }

}

# aggregation-api

### Technology and tools
* Scala
* SBT
* Play

### To RUN, Test
Test:
```
sbt test
```
Run:
* Start docker image
* Start play server
```
docker pull xyzassessment/backend-services
docker run -p 8080:8080 xyzassessment/backend-services
sbt run
```
Sbt server will start by default on 9000 port.

Application expects the underlying services to run on localhost:8080.
It is hardcoded in `SystemModule` at the moment.

Sample request
```
http://localhost:9000/aggregation?pricing=NL,CN&track=109347263,123456891&shipments=109347263,123456891
```

###Work pending
* Types for response of services
* Host and other configurable params needs to be added to conf file.
## Mailing API

Scala, kafka, akka stream based mail send api
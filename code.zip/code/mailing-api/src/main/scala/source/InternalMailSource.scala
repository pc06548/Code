package source

import akka.actor.ActorSystem
import akka.kafka.scaladsl.Consumer
import akka.kafka.{ConsumerMessage, ConsumerSettings, Subscriptions}
import akka.stream.{ClosedShape, Materializer}
import akka.stream.scaladsl.{GraphDSL, Merge, Source, Zip}
import org.apache.kafka.common.serialization.Deserializer

class KafkaSource[Key, Value](keyDeserializer: Deserializer[Key], valueDeserializer: Deserializer[Value]) {

  implicit val actorSystem = ActorSystem("mailing-system")

  implicit val materializer = Materializer(actorSystem)

  val consumerSetting = ConsumerSettings(actorSystem, keyDeserializer, valueDeserializer)

  val subscriptions = Subscriptions("mail-request")

  val source: Source[ConsumerMessage.CommittableMessage[String, String], Consumer.Control] = Consumer.committableSource(consumerSetting, subscriptions)

  def createSource(actorSystem: ActorSystem) = {
    val source: Source[ConsumerMessage.CommittableMessage[String, String], Consumer.Control] = Consumer.committableSource(consumerSetting, subscriptions)
  }

  val source1 = Source(List(1,2,3))
  val source2 = Source(List("hello", "local", "data"))

  GraphDSL.create() {
    implicit builder => {
      import GraphDSL.Implicits._
      val merge = builder.add(Merge[Int](2))

      val zip = builder.add(Zip[Int, String]())

      source1 ~> zip.in0
      source2 ~> zip.in1
      ClosedShape
    }
  }
}

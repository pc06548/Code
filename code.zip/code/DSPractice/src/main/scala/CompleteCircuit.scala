class CompleteCircuit {
  def canCompleteCircuit(A: Array[Int], B: Array[Int]):Int = {
    val aLength = A.length
    val bLength = B.length
    if (aLength != bLength) {
      -1
    } else {
      val res = A.zip(B).zipWithIndex.foldLeft(-1, 0, 0)((result, tuple) => {
        val index = result._1
        val fuel = result._2
        val fromPositive = result._3
        val a = tuple._1._1
        val b = tuple._1._2
        val currIndex = tuple._2
        val fuelRem = a - b
        println(currIndex+"======="+a+"====="+b+"====="+fuel+"======"+fuelRem+"======"+index+"===="+fromPositive)
        if (index == -1) {
          if (fuelRem >= 0) {
            (currIndex, fuel + fuelRem, fuelRem)
          } else {
            (-1, fuel + fuelRem, 0)
          }
        } else {
          if (fromPositive + fuelRem >= 0) {
            (index, fuel + fuelRem, fromPositive + fuelRem)
          } else {
            (-1, fuel + fuelRem, 0)
          }
        }
      })
      if (res._2 >= 0) {
        res._1
      } else -1
    }
  }
}
package consts

object ErrorMessages {
  val INCORRECT_USERNAME_PASSWORD_JSON = """{"message":"Incorrect username or password!"}"""
  val BAD_REQUEST_PARAMS_JSON = """{"message":"Bad request parameters"}"""
  val RESOURCE_NOT_FOUND_JSON = """{"message":"Resource not found"}"""
}

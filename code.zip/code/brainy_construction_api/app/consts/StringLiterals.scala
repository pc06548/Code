package consts

object StringLiterals {
  val BAT = "bat"
}

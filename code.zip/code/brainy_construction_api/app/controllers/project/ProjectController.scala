package controllers.project

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.project.validators.ProjectValidator
import javax.inject._
import model.Project
import play.api.libs.json.Json
import play.api.mvc._
import services.ProjectService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._
@Singleton
class ProjectController @Inject()(projectService:ProjectService,
                                  authService : AuthService,
                                  authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with ProjectValidator{

  def getProject(companyId : Int,id : Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async{
    request => {
      projectService.getProject(id,companyId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
  def searchProjects(companyId : Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      val name = request.getQueryString("name").toOptionString
      val status = request.getQueryString("status").toOptionString
      val projects = projectService.searchProjects(companyId,name,status)
      projects.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getAllNames(companyId : Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      val projects = projectService.getAllNames(companyId)
      projects.map(c => c match {
        case Right(names) => Ok(Json.toJson(names.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveProject(companyId : Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = projectService.saveProject(input.copy(companyId = Some(companyId)),request)
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateProject(companyId : Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          projectService.updateProject(input.copy(companyId = Some(companyId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteProject(companyId : Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => projectService.delete(id,companyId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

}

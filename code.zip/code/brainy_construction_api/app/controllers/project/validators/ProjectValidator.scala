package controllers.project.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.Project
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait ProjectValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Project] =  {
    body match {
      case Some(json) => {
        Try(Project.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Project](NoJsonBodyFound())
    }
  }

  private def validate(entity: Project):Either[BadRequest,Project] = {
    for{
      _ <- dateFormatCheck(entity.projectStartDate)
      _ <- dateFormatCheck(entity.projectEndDate)
      _ <- dateFormatCheck(entity.last_modified)
      _ <- panNumberCheck(entity.panNumber)
      _ <- phoneNumberCheck(entity.contactPerPhonenNbr)
      _ <- phoneNumberCheck(entity.siteContactPerPhoneNbr)
      _ <- emptyCheck(entity.name,"Project name")
    }yield entity
  }
}

package controllers

import auth.action.Authorization
import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import javax.inject.{Inject, _}
import model.Feature
import play.api.libs.json.{JsObject, JsValue, Json}
import play.api.mvc._

@Singleton
class BaseController @Inject()(authServiceP: AuthService,
                               authInfoExtractor: AuthInfoExtractorDb,
                               controllerComponent: ControllerComponents) extends AbstractController(controllerComponent) with Authorization {

  override def authService: AuthService = authServiceP
  override def authInfoExtractorDb: AuthInfoExtractorDb = authInfoExtractor
  override def cc: ControllerComponents = controllerComponent

  def bat(bat: String): JsValue ={
    Json.parse(s""" {"bat" : "${bat}" } """)
  }

  implicit class RichResult (result: Result) {
    def withBat(bat: String) =  result.withHeaders(
      "Access-Control-Allow-Origin" -> "*"
      ,"Access-Control-Allow-Methods" -> "*"
      , "bat" -> s"${bat}"
      , "access-control-expose-headers" -> "Accept, bat, Content-Type, Origin, X-Json, X-Prototype-Version, X-Requested-With"
    )
  }
}


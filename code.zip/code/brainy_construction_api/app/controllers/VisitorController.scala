package controllers

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import consts.{Roles, StringLiterals}
import controllers.validators.VisitorValidator
import javax.inject._
import play.api.libs.json.{JsValue, Json}
import play.api.mvc._
import services.VisitorService
import config.ScalaHelpers._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class VisitorController @Inject()(visitorService: VisitorService,
                                  authService : AuthService,
                                  authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with VisitorValidator {

  def getVisitorDetails(companyId : Int,id : Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async{
    request => {
      visitorService.searchById(companyId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchVisitorDetails(companyId:Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      val name = request.getQueryString("name").getOrElse("")
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")

      val projectInterestedIn = request.getQueryString("projectInterestedIn")
      val typeOfProperty = request.getQueryString("typeOfProperty")
      val occupation = request.getQueryString("occupation")
      val purpose = request.getQueryString("purpose")
      val budget = request.getQueryString("budget")
      val possessionExpected = request.getQueryString("possessionExpected")
      val loanStatus = request.getQueryString("loanStatus")
      val interestedInpromotion = request.getQueryString("interestedInpromotion")




      val visitors = visitorService.search(companyId,name,dates._1,dates._2,projectInterestedIn,
        typeOfProperty,occupation,purpose,budget,possessionExpected,loanStatus,interestedInpromotion)
      visitors.map(c => c match {
        case Right(searched) => {
          reportFormat match {
            case "excel" => {
              val filePath = visitorService.generateExcelReport(searched,startDate,endDate)
              Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
            }
            case _ => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
          }
        }
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }


  def saveVisitorDetails(companyId:Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = visitorService.saveVisitor(input.copy(companyId = Some(companyId)))
          res.map(locationId => locationId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateVisitorDetails(companyId : Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          visitorService.updateVisitor(input.copy(companyId = Some(companyId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteVisitorDetails(companyId:Int,id: Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => visitorService.delete(companyId,id).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }

  def getVisitorDetailOptions(companyId:Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      visitorService.getVisitorsFormOptions(companyId).map(c => c match {
        case Right(entity) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
}

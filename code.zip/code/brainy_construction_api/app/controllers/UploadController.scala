package controllers

import java.io.File
import java.nio.file.Paths

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.AppConstants
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc.{Action, AnyContent, ControllerComponents}
import services.UploadService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._
import consts.Roles

@Singleton
class UploadController @Inject()(uploadService: UploadService,
                                 authService : AuthService,
                                 authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) {


  def upload(companyId:Int) = AuthenticateFileRequestWithCompany(companyId).async { request =>
    request.request.body
      .file("file")
      .map { file =>
        val filename = Paths.get(file.filename).getFileName
        val path = Paths.get(s"${AppConstants.s3FolderPath}$filename")
        file.ref.copyTo(path, replace = true)
        uploadService.upload(request.orgId,companyId,new File(s"${AppConstants.s3FolderPath}$filename"),filename.toString) match {
          case Left(e) => {
            java.nio.file.Files.delete(path)
            Future(InternalServerError(e.getMessage).withBat(request.bat))
          }
          case Right(uniqueFileName) => {
            java.nio.file.Files.delete(path)
            val res =  Json.parse(s""" {"fileName" : "${uniqueFileName}" } """)
            Future(Ok(res).withBat(request.bat))
          }
        }
      }
      .getOrElse {
        Future(BadRequest("File not found"))
      }
  }

  def downloadFile(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      val fileName = request.getQueryString("fileName").toOptionString
      fileName match {
        case Some(name) => {
          val filePath = uploadService.getFile(request.orgId,companyId,name)
          filePath match {
            case Right(p) => Future(Ok.sendPath(p, onClose = () => p.toFile.delete()).withBat(request.bat))
            case Left(e)    => Future(InternalServerError(e.errorMessage).withBat(request.bat))
          }
        }
        case None => Future(BadRequest("File  name query param is mandatory").withBat(request.bat))
      }

    }
  }

}

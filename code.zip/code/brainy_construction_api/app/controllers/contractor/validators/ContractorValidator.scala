package controllers.contractor.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.contractor.Contractor
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait ContractorValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Contractor] =  {
    body match {
      case Some(json) => {
        Try(Contractor.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Contractor](NoJsonBodyFound())
    }
  }

  private def validate(entity: Contractor):Either[BadRequest,Contractor] = {
    for{
      _ <- emptyCheck(entity.name,"name")
      _ <- emailCheck(entity.basicDetails.email)
      _ <- phoneNumberCheck(entity.basicDetails.phoneNumber1)
      _ <- phoneNumberCheck(entity.basicDetails.phoneNumber2)
    }yield entity
  }
}

package controllers.contractor.validators

import config.ScalaHelpers._
import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.contractor.{WSRDetails, WeeklyStatusReport}
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}
trait WsrValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,WeeklyStatusReport] =  {
    body match {
      case Some(json) => {
        Try(WeeklyStatusReport.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,WeeklyStatusReport](NoJsonBodyFound())
    }
  }

  private def validate(entity: WeeklyStatusReport):Either[BadRequest,WeeklyStatusReport] = {
    for{
      _ <- dateFormatCheck(entity.startDate)
      _ <- dateFormatCheck(entity.endDate)
    }yield entity
  }

  def validatedDetail(body: Option[JsValue]): Either[BadRequest,WSRDetails] =  {
    body match {
      case Some(json) => {
        Try(WSRDetails.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,WSRDetails](NoJsonBodyFound())
    }
  }

  private def validate(entity: WSRDetails):Either[BadRequest,WSRDetails] = {
    sequence(entity.resources.map(r => dateFormatCheck(r.date)))
        .map(_ => entity)
  }
}

package controllers.contractor.validators

import config.DateUtil
import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.contractor.PaymentSchedule
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait PaymentScheduleValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,PaymentSchedule] =  {
    body match {
      case Some(json) => {
        Try(PaymentSchedule.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,PaymentSchedule](NoJsonBodyFound())
    }
  }

  private def validate(entity: PaymentSchedule):Either[BadRequest,PaymentSchedule] = {
    for{
      _ <- dateFormatCheck(entity.created_on)
      _ <- dateFormatCheck(entity.lastModified)
      _ <- nonZeroValueCheck(entity.totalAmount,"Total amount")
    }yield entity.copy(lastModified = Some(DateUtil.today))
  }
}

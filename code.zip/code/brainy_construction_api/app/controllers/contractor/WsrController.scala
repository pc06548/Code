package controllers.contractor

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.Roles
import controllers.BaseController
import controllers.contractor.validators.WsrValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.WsrService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._
@Singleton
class WsrController @Inject()(wsrService: WsrService,
                              authService : AuthService,
                              authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent)
  with WsrValidator{

  def searchWsr(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async{
    request => {
      val mayBeDate = request.getQueryString("date")
      val mayBeContractorId = request.getQueryString("contractorId").toOptionInt
      mayBeDate match {
        case Some(date) => {
          wsrService.getWsr(projectId,date,mayBeContractorId).map(c => c match {
            case Right(Some(entity)) => Ok(entity.toJson).withBat(request.bat)
            case Right(None) => NotFound.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case None   => Future(BadRequest("Query Param date is Mandatory"))
      }

    }
  }

  def saveWeeklyStatusReport(companyId:Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>{
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = wsrService.saveWeeklyStatusReport(input.copy(projectId = projectId))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }
  def updateWeeklyStatusReport(companyId:Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>{
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = wsrService.updateWsr(input.copy(projectId = projectId))

          res.map(entityId => entityId match {
            case Right(_) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def deleteWsr(companyId:Int,projectId:Int,id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request =>
      {
        wsrService.deleteWsr(id,projectId).map(updateRes => updateRes match {
          case Right(_) =>NoContent.withBat(request.bat)
          case Left(e) => InternalServerError(e.errorMessage)
        })
      }
  }

  def getWsrDetails(companyId:Int,projectId:Int,wsrId:Int,detailId: Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request => {
      wsrService.getWsrDetail(wsrId,detailId).map(c => c match {
        case Right(Some(wsrDetail)) => Ok(wsrDetail.toJson).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
  def saveWsrDetails(companyId:Int,projectId:Int,wsrId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>{
      validatedDetail(request.body.asJson) match {
        case Right(input) => {
          val res = wsrService.saveWeeklyStatusReportDetail(input.copy(wsrId = wsrId))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }
  def updateWsrDetails(companyId:Int,projectId:Int,wsrId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>{
      validatedDetail(request.body.asJson) match {
        case Right(input) => {
          val res = wsrService.updateWsrDetail(input.copy(wsrId = wsrId))

          res.map(entityId => entityId match {
            case Right(_) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }
  def deleteWsrDetails(companyId:Int,projectId:Int,wsrId:Int,detailId: Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>
      wsrService.deleteWsrDetails(detailId,wsrId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

}

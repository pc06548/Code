package controllers.contractor

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import controllers.BaseController
import controllers.contractor.validators.PaymentScheduleValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.PaymentScheduleService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._
import consts.Roles

@Singleton
class PaymentScheduleController @Inject()(paymentScheduleService: PaymentScheduleService,
                                          authService : AuthService,
                                          authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent)
                              with PaymentScheduleValidator{

  def searchPaymentSchedule(companyId:Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val contractorName = request.getQueryString("contractorName")
      val workOrderNumber = request.getQueryString("woNumber")
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val ps = paymentScheduleService.searchPaymentSchedule(contractorName, workOrderNumber,projectId,startDate,endDate)
      ps.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def searchPaymentScheduleById(companyId:Int,projectId:Int, id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>{
      paymentScheduleService.getPaymentSchedule(projectId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def savePaymentSchedule(companyId:Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>{
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = paymentScheduleService.savePaymentSchedule(input.copy(projectId = projectId))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }
  def updatePaymentSchedule(companyId:Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>{
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = paymentScheduleService.updatePs(input.copy(projectId = projectId))

          res.map(entityId => entityId match {
            case Right(_) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def deletePS(companyId:Int,projectId:Int,id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request =>
      paymentScheduleService.deletePS(id,projectId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

  def deletePsDetails(companyId:Int,projectId:Int,psId:Int,detailId: Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      paymentScheduleService.deletePsDetails(detailId,psId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })

  }
}

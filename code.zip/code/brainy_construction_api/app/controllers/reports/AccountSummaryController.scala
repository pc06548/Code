package controllers.reports

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import controllers.BaseController
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.reports.{AccountSummaryService, CollectiveSummaryService}
import config.ScalaHelpers._

import scala.concurrent.ExecutionContext.Implicits.global

@Singleton
class AccountSummaryController @Inject()(accountSummaryService: AccountSummaryService,
                                         collectiveSummaryService: CollectiveSummaryService,
                                          authService : AuthService,
                                         authInfoExtractorDb: AuthInfoExtractorDb,
                                         controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) {

  def getAccountSummary(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").toOptionString
      val category = request.getQueryString("category").toOptionString
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val onlyOfficeData = request.getQueryString("onlyOfficeData").toOptionBoolean.getOrElse(false)
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      accountSummaryService.getReport(companyId,projectId,name,dates._1,dates._2, category,onlyOfficeData)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = accountSummaryService.generateExcelReport(entity.details)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }
          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

  def getCollectiveSummary(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val onlyOfficeData = request.getQueryString("onlyOfficeData").toOptionBoolean.getOrElse(false)
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      collectiveSummaryService.getReport(companyId,projectId,dates._1,dates._2,onlyOfficeData)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = collectiveSummaryService.generateExcelReport(entity)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }
          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

}

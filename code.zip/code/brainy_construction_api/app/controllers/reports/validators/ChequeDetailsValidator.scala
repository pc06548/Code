package controllers.reports.validators

import auth.action.UserRequest
import controllers.validators.BasicValidator
import exceptions.{BadRequest}
import model.ChequeDetails
import play.api.mvc.AnyContent
import config.ScalaHelpers._

trait ChequeDetailsValidator extends BasicValidator{

  def validatedChequePrintInput(request: UserRequest[AnyContent]): Either[BadRequest,ChequeDetails] =  {
    val templateFileName = request.getQueryString("templateFileName").getOrElse("")
    val name = request.getQueryString("name").getOrElse("")
    val accNbr = request.getQueryString("accNbr").getOrElse("")
    val amountInWords = request.getQueryString("amountInWords").getOrElse("")
    val amount = request.getQueryString("amount").toOptionString.getOrElse("")
    val chequeDate = request.getQueryString("chequeDate").getOrElse("")

    for{
      t <- emptyCheck(templateFileName,"Template File Name")
      n <- emptyCheck(name,"Mame")
      aiw <- emptyCheck(amountInWords,"Amount in words")
      c <- dateFormatCheck(chequeDate)
      a <- emptyCheck(amount,"Amount")
    }yield ChequeDetails(t,n,accNbr,aiw,a.toString,c)

  }
  def validatedSMSInput(request: UserRequest[AnyContent]) =  {
    val message = request.getQueryString("message").getOrElse("")
    val numbers = request.getQueryString("numbers").getOrElse("")

    for{
      m <- emptyCheck(message,"Message")
      n <- emptyCheck(numbers,"Numbers cannot be empty")

    }yield (m,n)

  }

}

package controllers.reports

import java.io.File
import java.nio.file.Paths

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import controllers.{BaseController, routes}
import controllers.reports.validators.ChequeDetailsValidator
import exceptions.RuntimeException
import javax.inject.{Inject, Singleton}
import play.api.mvc._
import services.reports.excel.CheckPrintExcelService
import services.{MailerService, SmsService}
import services.reports.{DirectorReportService, WordDocumentService}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try
@Singleton
class ExcelReportsController @Inject()(excelReportService: CheckPrintExcelService,
                                       wordDocumentService: WordDocumentService,
                                       mailerService: MailerService,
                                       smsService: SmsService,
                                       authService : AuthService,
                                       authInfoExtractorDb: AuthInfoExtractorDb,
                                       controllerComponent: ControllerComponents,
                                       directorReportService: DirectorReportService)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with ChequeDetailsValidator {

  def printCheque(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request => {
      validatedChequePrintInput(request) match {
        case Right(input) => {
          val filePath = excelReportService.printCheque(input)
          filePath match {
            case Right(p) => Future(Ok.sendPath(p, onClose = () => p.toFile.delete()))
            case Left(e)    => Future(InternalServerError(e.errorMessage))
          }
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def directorReport(companyId:Int): Action[AnyContent] = Authenticate().async {
    _ => {

      val result = directorReportService.getDirectorReport(Some(companyId)).map(Right(_)).recover{
        case e: Throwable => Left(RuntimeException(e))
      }
      result.map(res => {
        res match {
          case Right(p) => Ok("Director report request accepted.")
          case Left(e)    => InternalServerError(e.errorMessage)
        }
      })
    }
  }

  def sendEmail(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    _ => {
     // mailerService.sendEmail()
      Future(Ok("Email sent successfully"))
    }
  }

  def getWordDocument(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    _ => {
      val filePath = wordDocumentService.dummyWordDoc()
       Future(Ok.sendPath(filePath, onClose = () => filePath.toFile.delete()))
    }
  }

  def sendSMS(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request => {

      validatedSMSInput(request) match {
        case Right(input) => {
          val msg = smsService.send(input._1,input._2)
          msg match {
            case Right(p) => Future(Ok("Message Sent"))
            case Left(e)    => Future(InternalServerError(e.errorMessage))
          }
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }
}

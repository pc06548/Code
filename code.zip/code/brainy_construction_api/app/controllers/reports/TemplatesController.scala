package controllers.reports

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import controllers.BaseController
import javax.inject._
import play.api.libs.json._
import play.api.mvc.ControllerComponents
import services.reports.TemplateNameService
import config.ScalaHelpers._
import scala.concurrent.ExecutionContext.Implicits.global

@Singleton
class TemplatesController @Inject()(templateNameService:TemplateNameService,
                                     authService : AuthService,
                                    authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent)  {

  
  def getTemplateNames(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val projectId = request.getQueryString("projectId").toOptionInt
      templateNameService.getTemplateNames(request.orgId,companyId,projectId).map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.toJson)).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

}

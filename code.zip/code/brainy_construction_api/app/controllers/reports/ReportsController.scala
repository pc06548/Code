package controllers.reports

import java.io

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import config.ScalaHelpers._
import controllers.BaseController
import javax.inject.{Inject, Singleton}
import play.api.libs.json.Json
import play.api.mvc.{Action, AnyContent, Controller, ControllerComponents}
import services.reports._

import scala.concurrent.ExecutionContext.Implicits.global

@Singleton
class ReportsController @Inject()(purchaseReportService: PurchaseReportService,
                                  salesReportService: SalesReportService,
                                  recoveryReportService: RecoveryReportService,
                                  customerCollectionReportService: CustomerCollectionReportService,
                                  voucherListReportService: VoucherListReportService,
                                  tdsReportService: TdsReportService,
                                  dueReportService:DueReportService,
                                  authService : AuthService,
                                  authInfoExtractorDb: AuthInfoExtractorDb,
                                  controllerComponent: ControllerComponents,
                                  customerAccountSummaryService:CustomerAccountSummaryService,
                                  paymentDelayReportService:PaymentDelayReportService)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) {

  def getCustomerCollectionReport(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").toOptionString
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val isTemporary = request.getQueryString("isTemporary").toOptionBoolean
      val extraInvoices = request.getQueryString("isExtraInvoices").toOptionBoolean
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      customerCollectionReportService.getReport(companyId,projectId,name,dates._1,dates._2,isTemporary,extraInvoices)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
               val filePath = customerCollectionReportService.generateExcelReport(entity)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }

          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

  def getNoDueReport(companyId:Int,projectId:Int,customerId:Int) = AuthenticateWithCompany(companyId).async {
    request =>
      customerCollectionReportService.getNoDueReport(companyId,projectId,customerId)
        .map(c => c match {
          case Right(entity) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

  def getAccountSummary(companyId:Int,projectId:Int,customerId:Int) = AuthenticateWithCompany(companyId).async {
    request =>
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      customerAccountSummaryService.getReport(companyId,projectId,customerId)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = customerAccountSummaryService.generateExcelReport(entity)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }
          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

  def getSalesReport(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request =>
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      salesReportService.getReport(companyId,projectId,dates._1,dates._2)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = salesReportService.generateExcelReport(entity)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ =>  Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }

          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

  def getRecoveryReport(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").toOptionString
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = Some(request.getQueryString("endDate").toOptionDateString.getOrElse(DateUtil.today))
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      recoveryReportService.getReport(companyId,projectId,name,dates._1,dates._2)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = recoveryReportService.generateExcelReport(entity)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }

          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

  def getPurchaseReport(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").getOrElse("")
      val category = request.getQueryString("category").toOptionString
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val onlyOfficeData = request.getQueryString("onlyOfficeData").toOptionBoolean.getOrElse(false)
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      purchaseReportService.getReport(companyId,projectId,name,dates._1,dates._2, category,onlyOfficeData)
        .map(c => c match {
        case Right(entity) => {
          reportFormat match {
            case "excel" => {
              val filePath = purchaseReportService.generateExcelReport(entity)
              Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
            }
            case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
          }
        }
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def getVoucherListReport(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").toOptionString
      val category = request.getQueryString("category").toOptionString
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val onlyOfficeData = request.getQueryString("onlyOfficeData").toOptionBoolean.getOrElse(false)
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val modeOfPayment = request.getQueryString("modeOfPayment").toOptionString
      val sortBy = request.getQueryString("sortBy").toOptionString
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      voucherListReportService.getReport(companyId,projectId,name,dates._1,dates._2, category,modeOfPayment,sortBy,onlyOfficeData)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = voucherListReportService.generateExcelReport(entity.vouchers)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }
          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }
  def getTdsReport(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").toOptionString
      val category = request.getQueryString("category").toOptionString
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val onlyOfficeData = request.getQueryString("onlyOfficeData").toOptionBoolean.getOrElse(false)
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      tdsReportService.getReport(companyId,projectId,name,dates._1,dates._2, category,onlyOfficeData)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = tdsReportService.generateExcelReport(entity)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }
          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

  def getDueReport(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").toOptionString.getOrElse("")
      val category = request.getQueryString("category").toOptionString
      val projectId = request.getQueryString("projectId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val onlyOfficeData = request.getQueryString("onlyOfficeData").toOptionBoolean.getOrElse(false)
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val isTemporary = request.getQueryString("isTemporary").toOptionBoolean
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      dueReportService.getReport(name,companyId,projectId,category,dates._1,dates._2, isTemporary,onlyOfficeData)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = dueReportService.generateExcelReport(entity)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }

          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }

  def getPaymentDelayReport(companyId:Int,projectId:Int,customerId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val reportFormat = request.getQueryString("reportFormat").getOrElse("json")
      paymentDelayReportService.getReport(companyId,projectId,customerId)
        .map(c => c match {
          case Right(entity) => {
            reportFormat match {
              case "excel" => {
                val filePath = paymentDelayReportService.generateExcelReport(entity)
                Ok.sendPath(filePath, onClose = () => filePath.toFile.delete())
              }
              case _ => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
            }
          }
          case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
        })
  }
}

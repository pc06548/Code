package controllers.company

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.company.validators.{CompanyConfigValidator}
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc.ControllerComponents
import services.CompanyConfigService
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class CompanyConfigController @Inject()(companyConfigService: CompanyConfigService,
                                        authService : AuthService,
                                        authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with CompanyConfigValidator {

  def getCompanyConfig(companyId : Int) = Authenticate(Roles.allRoles).async{
    request => {
      companyConfigService.getCompanyConfig(companyId).map(c => c match {
        case Right(Some(company)) => Ok(Json.toJson(company.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }


  def saveCompanyConfig(companyId : Int) = Authenticate().async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {

          val res = companyConfigService.saveCompanyConfig(input.copy(companyId = Some(companyId)))
          res.map(companyId => companyId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
            })
          }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateCompanyConfig(companyId : Int) = Authenticate().async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          companyConfigService.updateCompanyConfig(input.copy(companyId = Some(companyId)))
          .map(updateRes => updateRes match {
            case Right(_) =>NoContent.withBat(request.bat)
            case Left(e) => InternalServerError(e.errorMessage)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

}
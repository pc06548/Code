package controllers.company
import config.ScalaHelpers._
import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.company.validators.CompanyValidator
import javax.inject._
import services.CompanyService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import play.api.libs.json.{Json}

@Singleton
class CompanyController @Inject()(companyService: CompanyService,
                                     authService : AuthService,
                                     authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with CompanyValidator {

  def getCompany(id : Int) = AuthenticateWithCompany(id,Roles.allRoles).async{
    request => {
      companyService.getCompany(id).map(c => c match {
        case Right(Some(company)) => Ok(Json.toJson(company.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchCompanies() = Authenticate(Roles.allRoles).async {
    request => {
      val companyName = request.getQueryString("name").toOptionString
      val companies = companyService.searchCompanies(request.loginId,request.orgId,companyName)

      companies.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getAllNames() = Authenticate(Roles.allRoles).async {
    request => {
      val companies = companyService.getAllNames(request.orgId)
      companies.map(c => c match {
        case Right(names) => Ok(Json.toJson(names.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveCompany = Authenticate(List(Roles.ADMIN)).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {

          val res = companyService.saveCompany(input.copy(orgId = Some(request.orgId)),request)
          res.map(companyId => companyId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
            })
          }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateCompany() = Authenticate(List(Roles.ADMIN)).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          companyService.updateCompany(input.copy(orgId = Some(request.orgId)))
          .map(updateRes => updateRes match {
            case Right(_) =>NoContent.withBat(request.bat)
            case Left(e) => InternalServerError(e.errorMessage)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteCompany(id: Int) =  AuthenticateWithCompany(id,List(Roles.ADMIN)).async {
    request => {
      companyService.delete(id).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
    }
  }
}
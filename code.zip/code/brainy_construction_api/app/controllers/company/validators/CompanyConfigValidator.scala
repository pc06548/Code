package controllers.company.validators

import config.DateUtil
import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.CompanyConfig
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait CompanyConfigValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,CompanyConfig] =  {
    body match {
      case Some(json) => {
        Try(CompanyConfig.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,CompanyConfig](NoJsonBodyFound())
    }
  }

  private def validate(entity: CompanyConfig):Either[BadRequest,CompanyConfig] = {
    Right(entity)
  }
}
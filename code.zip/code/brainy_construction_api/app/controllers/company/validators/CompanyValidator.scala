package controllers.company.validators

import config.DateUtil
import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.company.Company
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait CompanyValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Company] =  {
    body match {
      case Some(json) => {
        Try(Company.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Company](NoJsonBodyFound())
    }
  }

  private def validate(entity: Company):Either[BadRequest,Company] = {
    for{
      _ <- emptyCheck(entity.name,"name")
      _ <- emailCheck(entity.email)
      _ <- dateFormatCheck(entity.startDate)
      _ <- phoneNumberCheck(entity.phoneNumber1)
      _ <- phoneNumberCheck(entity.phoneNumber2)
    }yield entity.copy(lastModified = Some(DateUtil.today))
  }
}
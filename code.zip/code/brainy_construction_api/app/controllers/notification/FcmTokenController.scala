package controllers.notification

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.notification.validators.FcmTokenValidator
import javax.inject._
import play.api.mvc.ControllerComponents
import services.FcmTokenService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class FcmTokenController @Inject()(fcmTokenService: FcmTokenService,
                                   authService : AuthService,
                                   authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with FcmTokenValidator {

  def saveFcmToken = Authenticate(Roles.allRoles).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = fcmTokenService.saveFcmToken(input.copy(userId = Some(request.userId)))
          res.map(companyId => companyId match {
            case Right(_) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
            })
          }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateFcmToken = Authenticate(Roles.allRoles).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          fcmTokenService.updateFcmToken(input.copy(userId = Some(request.userId)))
          .map(updateRes => updateRes match {
            case Right(_) =>NoContent.withBat(request.bat)
            case Left(e) => InternalServerError(e.errorMessage)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

}
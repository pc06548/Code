package controllers.notification.validators

import config.DateUtil
import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.notifications.FcmToken
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait FcmTokenValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,FcmToken] =  {
    body match {
      case Some(json) => {
        Try(FcmToken.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,FcmToken](NoJsonBodyFound())
    }
  }

  private def validate(entity: FcmToken):Either[BadRequest,FcmToken] = {
    Right(entity.copy(lastModified = Some(DateUtil.today)))
  }
}

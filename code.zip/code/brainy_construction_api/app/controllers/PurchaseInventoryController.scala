package controllers

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import consts.{Roles, StringLiterals}
import controllers.validators.PurchaseInventoryValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc.ControllerComponents
import services.PurchaseInventoryService
import config.ScalaHelpers._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class PurchaseInventoryController @Inject()(purchaseInventoryService:PurchaseInventoryService,
                                            authService : AuthService,
                                            authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with PurchaseInventoryValidator{

  def getPurchaseInventory(companyId : Int,projectId : Int,id : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async{
    request => {
      purchaseInventoryService.getPurchaseInventory(projectId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchPurchaseInventories(companyId : Int,projectId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request => {
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val supplierName = request.getQueryString("supplierName").toOptionString
      val transporterName = request.getQueryString("transporterName").toOptionString
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val purchaseInventorys = purchaseInventoryService.searchPurchaseInventories(companyId,projectId,dates._1,dates._2,supplierName,transporterName)
      purchaseInventorys.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })

    }
  }


  def savePurchaseInventory(companyId : Int,projectId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = purchaseInventoryService.savePurchaseInventory(input.copy(companyId = Some(companyId),projectId =  Some(projectId)))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updatePurchaseInventory(companyId : Int,projectId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          purchaseInventoryService.update(input.copy(companyId = Some(companyId),projectId =  Some(projectId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deletePurchaseInventory(companyId : Int,projectId : Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => purchaseInventoryService.delete(id,projectId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

}

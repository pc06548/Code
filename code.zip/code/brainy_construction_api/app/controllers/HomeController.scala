package controllers

import java.io.File
import java.nio.file.Paths

import javax.inject._
import play.api.mvc._
import services.MailerService
@Singleton
class HomeController @Inject()(controllerComponent: ControllerComponents,
                               mailerService: MailerService) extends AbstractController(controllerComponent) {

  def index = Action {
    Ok(views.html.home())
  }

  def keepAlive = Action {
    Ok("OK")
  }

  def headers = List(
    "Access-Control-Allow-Origin" -> "*",
    "Access-Control-Allow-Methods" -> "GET, POST, OPTIONS, DELETE, PUT",
    "Access-Control-Max-Age" -> "3600",
    "Access-Control-Allow-Headers" -> "Origin, Content-Type, Accept, Authorization",
    "Access-Control-Allow-Credentials" -> "true"
  )

  def rootOptions = options("/")

  def options(url: String) = Action { request =>
    NoContent.withHeaders(headers : _*)
  }

  def upload = Action(parse.multipartFormData) { request =>
    request.body
      .file("file")
      .map { file =>
        val filename    = Paths.get(file.filename).getFileName
        file.ref.copyTo(Paths.get(s"public/excel/$filename"), replace = true)
        mailerService.sendEmailWithAttachment(new File(s"public/excel/$filename"),filename.toString)
        java.nio.file.Files.delete(Paths.get(s"public/excel/$filename"))
        Ok("File uploaded")
      }
      .getOrElse {
        Redirect(routes.HomeController.index).flashing("error" -> "Missing file")
      }
  }
}

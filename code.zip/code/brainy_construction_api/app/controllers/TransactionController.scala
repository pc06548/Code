package controllers
import config.ScalaHelpers._
import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import config.DateUtil
import consts.{Roles, StringLiterals}
import controllers.validators.TransactionValidator
import javax.inject._
import play.api.libs.json.Json
import services.TransactionService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
@Singleton
class TransactionController @Inject()(transactionService: TransactionService,
                                      authService : AuthService,
                                      authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with TransactionValidator{

  def getTransaction(companyId : Int,projectId:Option[Int],id : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.EMPLOYEE,Roles.ACCOUNTANT)).async{
    request => {
      transactionService.getTransaction(id,companyId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveTransaction(companyId : Int,projectId:Option[Int]) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.EMPLOYEE,Roles.ACCOUNTANT)).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = transactionService.saveTransaction(input.copy(companyId = Some(companyId),projectId = projectId))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateTransaction(companyId : Int,projectId:Option[Int]) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.EMPLOYEE,Roles.ACCOUNTANT)).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          transactionService.updateTransaction(input.copy(companyId = Some(companyId),projectId = projectId))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def getExpenseSheet(companyId : Int,projectId:Option[Int]) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.EMPLOYEE,Roles.ACCOUNTANT)).async {
    request => {
      val employeeId = request.getQueryString("employeeId").toOptionInt
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val date = DateUtil.getFirstDayFromMonth(month.getOrElse(DateUtil.currentMonth))
      transactionService.getExpenseSheets(companyId,projectId,employeeId,date,dates._1,dates._2).map(c => c match {
        case Right(entity) => Ok(Json.toJson(entity.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }

  }

  def deleteTransaction(companyId : Int,projectId:Option[Int],id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.EMPLOYEE)).async {
    request => transactionService.delete(id,companyId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }


  def getProjectTransaction(companyId : Int,projectId:Int,id : Int) = {
    getTransaction(companyId,Some(projectId),id)
  }

  def saveProjectTransaction(companyId : Int,projectId:Int) = {
    saveTransaction(companyId,Some(projectId))
  }

  def updateProjectTransaction(companyId : Int,projectId:Int) = {
    updateTransaction(companyId,Some(projectId))
  }

  def deleteProjectTransaction(companyId : Int,projectId:Int,id: Int) = {
    deleteTransaction(companyId,Some(projectId),id)
  }

  def getOfficeTransaction(companyId : Int,id : Int) = {
    getTransaction(companyId,None,id)
  }

  def saveOfficeTransaction(companyId : Int) = {
    saveTransaction(companyId,None)
  }

  def updateOfficeTransaction(companyId : Int) = {
    updateTransaction(companyId,None)
  }

  def deleteOfficeTransaction(companyId : Int,id: Int) = {
    deleteTransaction(companyId,None,id)
  }

  def getOfficeExpenseSheet(companyId : Int) = {
    getExpenseSheet(companyId,None)
  }
  def getProjectExpenseSheet(companyId : Int,projectId:Int) = {
    getExpenseSheet(companyId,Some(projectId))
  }
}

package controllers.supplier

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.Roles
import controllers.BaseController
import controllers.supplier.validators.PurchaseOrderValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.PurchaseOrderService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._

@Singleton
class PurchaseOrderController @Inject()(purchaseOrderService: PurchaseOrderService,
                                          authService : AuthService,
                                          authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent)
  with PurchaseOrderValidator{

  def searchPurchaseOrder(companyId:Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>
      val supplierName = request.getQueryString("supplierName")
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val poId = request.getQueryString("poId").toOptionInt
      val po = purchaseOrderService.searchPurchaseOrder(supplierName,projectId,startDate,endDate,poId)
      po.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def searchPurchaseOrderById(companyId:Int,projectId:Int, id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>{
      purchaseOrderService.getPurchaseOrder(projectId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def savePurchaseOrder(companyId:Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>{
      validatedInput(request.body.asJson,request.roles) match {
        case Right(input) => {
          val res = purchaseOrderService.savePurchaseOrder(input.copy(projectId = projectId),request.userId,companyId)
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }
  def updatePurchaseOrder(companyId:Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request =>{
      validatedInput(request.body.asJson,request.roles) match {
        case Right(input) => {
          val res = purchaseOrderService.updatePs(input.copy(projectId = projectId),request.userId,companyId)

          res.map(entityId => entityId match {
            case Right(_) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def deletePO(companyId:Int,projectId:Int,id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request =>
      purchaseOrderService.deletePS(id,projectId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

  def deletePoDetails(companyId:Int,projectId:Int,poId:Int,detailId: Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request =>
      purchaseOrderService.deletePsDetails(detailId,poId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }
}
package controllers.supplier

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.supplier.validators.SupplierValidator
import javax.inject._
import play.api.libs.json.Json
import services.SupplierService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class SupplierController @Inject()(supplierService: SupplierService,
                                     authService : AuthService,
                                     authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with SupplierValidator{

  def getSupplier(companyId : Int,id : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async{
    request => {
      supplierService.getSupplier(id,companyId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
  def searchSuppliers(companyId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request => {
      val name = request.getQueryString("name")
      val supplierType = request.getQueryString("supplierType")
      val suppliers = supplierService.searchSuppliers(companyId,name,supplierType)
      suppliers.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getAllNames(companyId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request => {
      val suppliers = supplierService.getAllNames(companyId)
      suppliers.map(c => c match {
        case Right(names) => Ok(Json.toJson(names.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveSupplier(companyId : Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = supplierService.saveSupplier(input.copy(companyId = Some(companyId)))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateSupplier(companyId : Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          supplierService.updateSupplier(input.copy(companyId = Some(companyId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteSupplier(companyId : Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => supplierService.delete(id,companyId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }


}

package controllers.supplier.validators

import config.DateUtil
import consts.Roles
import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.ApprovalStatus
import model.supplier.PurchaseOrder
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait PurchaseOrderValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue],roles:List[String]): Either[BadRequest,PurchaseOrder] =  {
    body match {
      case Some(json) => {
        Try(PurchaseOrder.createFromJson(json)) match {
          case Success(entity) => validate(entity,roles)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,PurchaseOrder](NoJsonBodyFound())
    }
  }

  private def validate(entity: PurchaseOrder,roles:List[String]):Either[BadRequest,PurchaseOrder] = {
     for{
      _ <- dateFormatCheck(entity.deliveryDate)
      _ <- dateFormatCheck(entity.createdDate)
      _ <- nonZeroValueCheck(entity.totalAmount,"Total amount")
    }yield {
       val validPO = entity.copy(lastModified = Some(DateUtil.today))
       if(roles.contains(Roles.ADMIN)){
         validPO.copy(status = Some(ApprovalStatus.APPROVED))
       }else{
         validPO.copy(status = Some(ApprovalStatus.APPROVAL_PENDING))
       }
     }
  }
}

package controllers.supplier.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.supplier.Supplier
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait SupplierValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Supplier] =  {
    body match {
      case Some(json) => {
        Try(Supplier.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Supplier](NoJsonBodyFound())
    }
  }

  private def validate(entity: Supplier):Either[BadRequest,Supplier] = {
    for{
      _ <- emptyCheck(entity.name,"name")
      _ <- emailCheck(entity.basicDetails.email)
      _ <- phoneNumberCheck(entity.basicDetails.phoneNumber1)
      _ <- phoneNumberCheck(entity.basicDetails.phoneNumber2)
      _ <- phoneNumberCheck(entity.ownerPhoneNumber)
    }yield entity
  }
}

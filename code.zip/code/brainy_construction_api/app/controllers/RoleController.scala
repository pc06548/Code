
package controllers

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.Roles
import javax.inject._
import model._
import play.api.libs.json.{JsValue, Json}
import services.RoleService

import scala.concurrent.Future
import scala.util.Try
// TODO handle unhappy flows
@Singleton
class RoleController @Inject()(roleService: RoleService, authService : AuthService,
                               authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) {

  /**
    * Gets roles in the system
    * */
  def getRoles() = Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      val roles = roleService.getRoles()
      Future.successful(Ok(Json.toJson(roles.map(_.toJson))).withBat(authRequest.bat))
    }
  }

  /**
    * Only valid for admin
    * @return role mapping for specified login id
    */
  def getRoleMappingsByLoginId(loginId: Int) = Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      val roleMappings = roleService.getRoleMappingByLoginId(loginId)
      Future.successful(Ok(Json.toJson(roleMappings.map(_.toJson))).withBat(authRequest.bat))
    }
  }

  /**
    * Gets role mappings for specific company id for requesting user.
    * Requesting user is determined from bat token
    * */
  def getRoleMappingsByCompanyIdAndLoginId(companyId: Int) = AuthenticateWithCompany(companyId, Roles.allRoles).async {
    authRequest => {
      val roleMappings = roleService.getRoleMappingByLoginIdCompanyId(authRequest.loginId, companyId)
      Future.successful(Ok(Json.toJson(roleMappings.map(_.toJson))).withBat(authRequest.bat))
    }
  }

  /**
    * Gets role mappings for specific company id for requesting user.
    * Requesting user is determined from bat token
    * */
  def getRoleMappingsByCompanyId(companyId: Int) = AuthenticateWithCompany(companyId, List(Roles.ADMIN)).async {
    authRequest => {
      val roleMappings = roleService.getRoleMappingByCompanyId(companyId)
      Future.successful(Ok(Json.toJson(roleMappings.map(_.toJson))).withBat(authRequest.bat))
    }
  }

  /**
    * Gets role mappings for all companies for requesting user.
    * Requesting user is determined from bat token
    */
  def getRoleMappings() = Authenticate(Roles.allRoles).async {
    authRequest => {
      val roleMappings = roleService.getRoleMappingByLoginId(authRequest.loginId)
      Future.successful(Ok(Json.toJson(roleMappings.map(_.toJson))).withBat(authRequest.bat))
    }
  }

  /**
    * Gets role mappings for all companies for requesting user.
    * Requesting user is determined from bat token
    */
  def getRoleMappingsByOrgId() = Authenticate(Roles.allRoles).async {
    authRequest => {
      val roleMappings = roleService.getRoleMappingByOrgId(authRequest.orgId)
      Future.successful(Ok(Json.toJson(roleMappings.map(_.toJson))).withBat(authRequest.bat))
    }
  }

  def addRoleMappings()= Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      for {
        json <- authRequest.request.body.asJson
        createRoleMappingRequest <- RoleMappingsRequest.createFromJson(json)
      } yield {
        createRoleMappingRequest.roleMappings.map(roleMapping => {
          roleService.addRoleMapping(roleMapping)
        })
      }
      // TODO define failure case
      Future.successful(Ok(s"""{"message":"Created"}""").withBat(authRequest.bat))
    }
  }

  def removeRoleMappings()= Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      for {
        json <- authRequest.request.body.asJson
        removeRoleMappingRequest <- RoleMappingsRequest.createFromJson(json)
      } yield {
        val filteredRoleMappings = removeRoleMappingRequest.roleMappings.filter(_.loginId != authRequest.loginId)
        filteredRoleMappings.map(roleMapping => {
          roleService.removeRoleMapping(roleMapping)
        })
      }
      // TODO define failure case
      Future.successful(NoContent.withBat(authRequest.bat))
    }
  }

  def updateRoleMappings() = Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      for {
        json <- authRequest.request.body.asJson
        updateRoleMappingRequest <- UpdateRoleMappingsRequest.createFromJson(json)
      } yield {
        roleService.updateRoleMapping(updateRoleMappingRequest.addRoleMappings, updateRoleMappingRequest.removeRoleMappings)
      }
      // TODO define failure case
      Future.successful(NoContent.withBat(authRequest.bat))
    }
  }
}

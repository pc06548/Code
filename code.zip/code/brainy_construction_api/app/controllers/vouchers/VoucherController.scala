package controllers.vouchers

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import config.DateUtil
import controllers.BaseController
import controllers.vouchers.validators.VoucherValidator
import javax.inject._
import play.api.libs.json.{JsValue, Json}
import play.api.mvc._
import services.VoucherService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._
import consts.Roles

@Singleton
class VoucherController @Inject()(voucherService: VoucherService,
                                  authService : AuthService,
                                  authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with VoucherValidator  {

  def getVoucherById(companyId : Int,projectId:Int, id: Int,invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      voucherService.getVoucher(companyId,id,invoiceType).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def searchVouchers(companyId : Int,projectId:Int,invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name")
      val category = request.getQueryString("category").toOptionString
      val startDate = request.getQueryString("startDate").toOptionString
      val endDate = request.getQueryString("endDate").toOptionString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val voucherNumber = request.getQueryString("voucherNumber").toOptionString
      val isTemporary = request.getQueryString("isTemporary").toOptionBoolean

      val mayBeprojectId = if(projectId == 0) None else Some(projectId)
      val vouchers = voucherService.searchVoucher(companyId,name,mayBeprojectId,category,invoiceType,dates._1,dates._2,voucherNumber,isTemporary)
      vouchers.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def createVoucher(companyId: Int,projectId:Int,invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val id = voucherService.saveVoucher(companyId,input.copy(companyId = Some(companyId)),invoiceType)
          id.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(errorMessage) => Future(BadRequest(errorMessage.errorMessage))
      }
  }


  def deleteVoucher(companyId : Int,projectId:Int, id:Int,invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request =>
      voucherService.deleteVoucher(companyId,id,invoiceType).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

  def getVoucherNumber(companyId : Int,projectId:Int,invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>

      val vouchers = voucherService.getVoucherNumber(companyId,invoiceType)
      vouchers.map(c => c match {
        case Right(number) => Ok(VoucherNumberResponse(number).toJson).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def deleteAllTemporaryInvoicesAndVouchersForProject(companyId : Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request =>{
      voucherService.deleteAllTemporaryInvoicesAndVouchers(companyId,Some(projectId)).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
    }
  }
  def deleteAllTemporaryInvoicesAndVouchersForCompany(companyId : Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request =>{
      voucherService.deleteAllTemporaryInvoicesAndVouchers(companyId,None).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
    }
  }
}

case class VoucherNumberResponse(voucherNumber:String){
  implicit val implicitCompanyWrites = Json.writes[VoucherNumberResponse]
  def toJson: JsValue = Json.toJson(this)
}
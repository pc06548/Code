package controllers.validators

import config.DateUtil
import exceptions._

trait BasicValidator {

  def emptyCheck(field : String,fieldName:String): Either[BadRequest,String] = {
    if (field.trim.length == 0 )
      Left[BadRequest,String](FieldCannotBeEmpty(fieldName))
    else Right(field)
  }

  def emailCheck(mayBeEmail: Option[String]): Either[BadRequest,Option[String]] = {
    mayBeEmail match {
      case Some(e) if !e.contains("@") => Left[BadRequest,Option[String]](InvalidEmailAddress())
      case _ => Right(mayBeEmail)
    }
  }

  def emailCheck(email: String,field:String = ""): Either[BadRequest,String] = {
    if (!email.contains("@"))
      Left[BadRequest,String](InvalidEmailAddress())
    else Right(email)

  }

  def phoneNumberCheck(mayBePhone: Option[String],field:String = ""): Either[BadRequest,Option[String]] = {
    mayBePhone match {
      case Some(e) if (e.length < 5 || e.length > 15 ) => Left[BadRequest,Option[String]](InvalidContactNumber())
      case _ => Right(mayBePhone)
    }
  }

  def phoneNumberCheck(phone: String): Either[BadRequest,String] = {
      if (phone.length < 5 || phone.length > 15 )
        Left[BadRequest,String](InvalidContactNumber())
      else Right(phone)
  }

  def nonZeroValueCheck[A : Numeric](mayBeValue: Option[A],fieldName:String): Either[BadRequest,Option[A]] = {
    mayBeValue match {
      case Some(e) if e == 0  => Left[BadRequest,Option[A]](FieldCannotBeZero(fieldName))
      case _ => Right(mayBeValue)
    }
  }
  def nonZeroValueCheck[A : Numeric](value: A,fieldName:String): Either[BadRequest,A] = {
    if(value == 0 ){
      Left[BadRequest,A](FieldCannotBeZero(fieldName))
    }else{
      Right(value)
    }
  }

  def dateFormatCheck(mayBeDate: Option[String],field:String = ""): Either[BadRequest,Option[String]] = {
    mayBeDate match {
      case Some(e) => {
        DateUtil.validate(e,field) match {
          case Left(e) => Left[BadRequest,Option[String]](e)
          case Right(v) => Right[BadRequest,Option[String]](Some(v))
        }
      }
      case _ => Right(mayBeDate)
    }
  }
  def dateFormatCheck(date: String): Either[BadRequest,String] = {
    DateUtil.validate(date,"") match {
      case Left(e) => Left[BadRequest,String](e)
      case Right(v) => Right[BadRequest,String](v)
    }
  }
  def monthFormatCheck(date: Option[String]): Either[BadRequest,Option[String]] = {
    date match {
      case Some(d) => monthFormatCheck(d).map(o => Option(o))
      case None => Right(None)
    }
  }
  def monthFormatCheck(date: String): Either[BadRequest,String] = {
    DateUtil.validateMonthFormat(date,"Month") match {
      case Left(e) => Left[BadRequest,String](e)
      case Right(v) => Right[BadRequest,String](v)
    }
  }

  def panNumberCheck(mayBePan: Option[String]): Either[BadRequest,Option[String]] = {
    mayBePan match {
      case Some(e) if (e.trim.length != 10) => Left[BadRequest,Option[String]](InvalidPanNumber())
      case _ => Right(mayBePan)
    }
  }
  def aadharNumberCheck(mayBeAadhar: Option[String]): Either[BadRequest,Option[String]] = {
    val aadharRegx = """(\d\d\d\d)-(\d\d\d\d)-(\d\d\d\d)-(\d\d\d\d)""".r
    mayBeAadhar match {
      case Some(e) if aadharRegx.pattern.matcher(e).matches => Left[BadRequest,Option[String]](InvalidAadharNumber())
      case _ => Right(mayBeAadhar)
    }
  }
}

package controllers.validators

import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.Category
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait CategoryValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Category] =  {
    body match {
      case Some(json) => {
        Try(Category.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Category](NoJsonBodyFound())
    }
  }

  private def validate(entity: Category):Either[BadRequest,Category] = {
    for{
      _ <- emptyCheck(entity.categoryType,"Category type")
      _ <- emptyCheck(entity.name,"Category name")
    }yield entity
  }
}

package controllers.validators

import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.Location
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait LocationValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Location] =  {
    body match {
      case Some(json) => {
        Try(Location.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Location](NoJsonBodyFound())
    }
  }

  private def validate(entity: Location):Either[BadRequest,Location] = {
    for{
      _ <- nonZeroValueCheck(entity.longitude,"Location longitude")
      _ <- nonZeroValueCheck(entity.latitude,"Location latitude")
      _ <- emptyCheck(entity.name,"Location name")
    }yield entity
  }
}

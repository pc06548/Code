package controllers.validators

import config.DateUtil
import exceptions.{BadDateFormat, BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.Transaction
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait TransactionValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Transaction] =  {
    body match {
      case Some(json) => {
        Try(Transaction.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Transaction](NoJsonBodyFound())
    }
  }

  private def validate(entity: Transaction):Either[BadRequest,Transaction] = {
    for{
      _ <- dateFormatCheck(entity.transactionDate)
    }yield entity
  }

  def monthOrDateValidate(date: String) = {
    dateFormatCheck(date) match {
      case Right(d) => Right(d)
      case Left(_) => monthFormatCheck(date).map(DateUtil.getFirstDayFromMonth)
    }
  }

  def validateReportDate(date : Option[String],employeeId:Option[String]): Either[BadRequest,(String,Option[Int])] =  {
    val tupleRes = (date,employeeId) match {
      case (Some(date),Some(em)) => Right(date,Try(em.toInt).toOption)
      case (Some(date),None) => Right(date,None)
      case _       => Left[BadRequest,(String,Option[Int])](BadDateFormat("Report date"))
    }

    for{
      tuple <- tupleRes
      firstDay <- monthOrDateValidate(tuple._1)
    }yield (firstDay,tuple._2)
  }
}

package controllers.validators

import config.DateUtil
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.PurchaseInventory
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait PurchaseInventoryValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,PurchaseInventory] =  {
    body match {
      case Some(json) => {
        Try(PurchaseInventory.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,PurchaseInventory](NoJsonBodyFound())
    }
  }

  private def validate(entity: PurchaseInventory):Either[BadRequest,PurchaseInventory] = {
    for{
      _ <- dateFormatCheck(entity.date)
      _ <- emptyCheck(entity.material,"Purchase Inventory material")
    }yield entity
  }
}

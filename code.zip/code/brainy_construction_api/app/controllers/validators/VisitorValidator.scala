package controllers.validators

import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.VisitorDetails
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait VisitorValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,VisitorDetails] =  {
    body match {
      case Some(json) => {
        Try(VisitorDetails.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,VisitorDetails](NoJsonBodyFound())
    }
  }

  private def validate(entity: VisitorDetails):Either[BadRequest,VisitorDetails] = {
    for{
      _ <- phoneNumberCheck(entity.phoneNumber)
      _ <- emailCheck(entity.email)
      _ <- dateFormatCheck(entity.visitingDate)
      _ <- emptyCheck(entity.name,"Visitor name")
    }yield entity
  }
}

package controllers.customer

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import config.ScalaHelpers._
import controllers.BaseController
import controllers.customer.validators.ExtraWorkInvoiceValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc.{ControllerComponents, _}
import services.customer.ExtraWorkInvoiceService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class ExtraWorkInvoiceController @Inject()(extraWorkInvoiceService: ExtraWorkInvoiceService,
                                           authService : AuthService,
                                           authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents) 
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with ExtraWorkInvoiceValidator  {

  def getExtraWorkInvoiceById(companyId : Int,projectId:Int, id: Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      extraWorkInvoiceService.getInvoice(companyId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def searchExtraWorkInvoices(companyId : Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").getOrElse("")
      val status = request.getQueryString("status").getOrElse("")
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val invoiceNumber = request.getQueryString("invoiceNumber").toOptionString
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val isTemporary = request.getQueryString("isTemporary").toOptionBoolean

      val extraWorkInvoices = extraWorkInvoiceService.searchInvoice(name,projectId,status,dates._1,dates._2,isTemporary,invoiceNumber)
      extraWorkInvoices.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def createExtraWorkInvoice(companyId: Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val id = extraWorkInvoiceService.saveInvoice(input.copy(companyId = companyId))
          id.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(errorMessage) => Future(BadRequest(errorMessage.errorMessage))
      }
  }

  def updateExtraWorkInvoice(companyId: Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val id = extraWorkInvoiceService.updateInvoice(input)
          id.map(entityId => entityId match {
            case Right(_) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(errorMessage) => Future(BadRequest(errorMessage.errorMessage))
      }
  }

  def deleteExtraWorkInvoice(companyId : Int,projectId:Int, id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      extraWorkInvoiceService.deleteInvoice(companyId,id).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

  def deleteDetail(companyId : Int,projectId:Int,invoiceId : Int, id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request => extraWorkInvoiceService.deleteDetail(invoiceId,id).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

}

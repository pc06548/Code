package controllers.customer

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.customer.validators.DefaultDemandLetterValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc.ControllerComponents
import services.DefaultDemandLetterService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class DefaultDemandLetterController @Inject()(defaultDemandService: DefaultDemandLetterService,
                                              authService : AuthService,
                                              authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with DefaultDemandLetterValidator{

  def getDefaultDemand(companyId : Int,projectId:Int,id : Int) = AuthenticateWithCompany(companyId).async{
    request => {
      defaultDemandService.getDefaultDemand(id,projectId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveDefaultDemand(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = defaultDemandService.saveDefaultDemand(input.copy(companyId = companyId,projectId = projectId))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateDefaultDemand(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          defaultDemandService.updateDefaultDemand(input.copy(companyId = companyId,projectId = projectId))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteDefaultDemand(companyId : Int,projectId:Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => defaultDemandService.delete(id,projectId).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }

  def getDefaultDemandLetter(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      defaultDemandService.getDefaultDemandLetter(companyId,projectId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
}

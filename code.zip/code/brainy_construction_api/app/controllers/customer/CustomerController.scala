package controllers.customer

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.customer.validators.CustomerValidator
import javax.inject.{Inject, Singleton}
import play.api.libs.json.Json
import play.api.mvc.{Action, AnyContent}
import services.CustomerService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._

@Singleton
class CustomerController @Inject()(customerService: CustomerService,
                                   authService : AuthService,
                                   authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with CustomerValidator{

  def getCustomer(companyId : Int,projectId:Int,id : Int) = AuthenticateWithCompany(companyId).async{
    request => {
      customerService.getCustomer(projectId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchCustomers(companyId : Int,projectId: Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val name = request.getQueryString("name")
      val agreementStartDate = request.getQueryString("agreementStartDate").toOptionDateString
      val agreementEndDate = request.getQueryString("agreementEndDate").toOptionDateString

      val saledeedStartDate = request.getQueryString("saledeedStartDate").toOptionDateString
      val saledeedEndDate = request.getQueryString("saledeedEndDate").toOptionDateString

      val possessionStartDate = request.getQueryString("possessionStartDate").toOptionDateString
      val possessionEndDate = request.getQueryString("possessionEndDate").toOptionDateString

      val customers = customerService.searchCustomers(projectId,name,agreementStartDate,agreementEndDate,
        saledeedStartDate,saledeedEndDate,possessionStartDate,possessionEndDate)
      customers.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getAllNames(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val customers = customerService.getAllNames(projectId)
      customers.map(c => c match {
        case Right(names) => Ok(Json.toJson(names.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveCustomer(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = customerService.saveCustomer(input)
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateCustomer(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          customerService.updateCustomer(input)
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteCustomer(companyId : Int,projectId:Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => customerService.deleteCustomer(id,projectId).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }

  def deleteCoOwner(companyId : Int,projectId:Int,customerId : Int, coOwnerId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => customerService.deleteCoOwnerDetails(customerId,coOwnerId).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }
}

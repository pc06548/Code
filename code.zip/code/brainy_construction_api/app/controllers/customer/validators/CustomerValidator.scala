package controllers.customer.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.customer.Customer
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait CustomerValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Customer] =  {
    body match {
      case Some(json) => {
        Try(Customer.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Customer](NoJsonBodyFound())
    }
  }

  private def validate(entity: Customer):Either[BadRequest,Customer] = {
    for{
      _ <- emptyCheck(entity.ownerDetails.name,"name")
      _ <- emailCheck(entity.ownerDetails.email)
      _ <- emailCheck(entity.customerReferredBy.flatMap(_.referredByEmail))
      _ <- dateFormatCheck(entity.ownerDetails.dateOfBirth)
      _ <- dateFormatCheck(entity.agreementDetails.agreementDate)
      _ <- panNumberCheck(entity.ownerDetails.pan)
      _ <- aadharNumberCheck(entity.ownerDetails.aadharNbr)
      _ <- phoneNumberCheck(entity.ownerDetails.phoneNumber1)
      _ <- phoneNumberCheck(entity.ownerDetails.phoneNumber2)
      _ <- dateFormatCheck(entity.agreementDetails.agreementDate)
      _ <- nonZeroValueCheck(entity.agreementDetails.agreementCost,"agreement cost")
    }yield entity
  }
}
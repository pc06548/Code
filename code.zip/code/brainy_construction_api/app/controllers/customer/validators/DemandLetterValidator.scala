package controllers.customer.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.customer.CustomerDemand
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait DemandLetterValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,CustomerDemand] =  {
    body match {
      case Some(json) => {
        Try(CustomerDemand.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,CustomerDemand](NoJsonBodyFound())
    }
  }

  private def validate(entity: CustomerDemand):Either[BadRequest,CustomerDemand] = {
    for{
      _ <- dateFormatCheck(entity.dueDate)
      _ <- emptyCheck(entity.detail,"detail")
    }yield entity
  }
}
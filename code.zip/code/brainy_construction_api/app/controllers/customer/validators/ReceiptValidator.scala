package controllers.customer.validators

import controllers.validators.BasicValidator
import exceptions.{BadReceiptNumberFormat, BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.customer.{Receipt, ReceiptNumber}
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait ReceiptValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Receipt] =  {
    body match {
      case Some(json) => {
        Try(Receipt.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Receipt](NoJsonBodyFound())
    }
  }

  private def validate(entity: Receipt):Either[BadRequest,Receipt] = {
    for{
      _ <- dateFormatCheck(entity.dateCreated)
      _ <- dateFormatCheck(entity.paymentDate)
      _ <- emptyCheck(entity.receiptNumber,"Receipt Number")
      _ <- validateReceiptNumber(entity.receiptNumber)
      _ <- emptyCheck(entity.mode,"Mode of Payment")
    }yield entity
  }

  private def validateReceiptNumber(number : String):Either[BadRequest,String] = {
    ReceiptNumber.checkIfVocherNumberValid(number) match {
      case true => Right(number)
      case false => Left(BadReceiptNumberFormat())
    }
  }
}
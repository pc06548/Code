package controllers.customer.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.customer.DefaultDemand
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait DefaultDemandLetterValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,DefaultDemand] =  {
    body match {
      case Some(json) => {
        Try(DefaultDemand.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,DefaultDemand](NoJsonBodyFound())
    }
  }

  private def validate(entity: DefaultDemand):Either[BadRequest,DefaultDemand] = {

    for{
      _ <- emptyCheck(entity.detail,"detail")
    }yield entity
  }
}
package controllers.customer.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.customer.SaveExtraWorkInvoice
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait ExtraWorkInvoiceValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,SaveExtraWorkInvoice] =  {
    body match {
      case Some(json) => {
        Try(SaveExtraWorkInvoice.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,SaveExtraWorkInvoice](NoJsonBodyFound())
    }
  }

  private def validate(entity: SaveExtraWorkInvoice):Either[BadRequest,SaveExtraWorkInvoice] = {
    for{
      _ <- dateFormatCheck(entity.invoiceDate)
      _ <- dateFormatCheck(entity.createdDate)
      _ <- dateFormatCheck(entity.lastUpdated)
      _ <- emptyCheck(entity.invoiceNumber,"ExtraWorkInvoice Number")
    }yield entity
  }
}

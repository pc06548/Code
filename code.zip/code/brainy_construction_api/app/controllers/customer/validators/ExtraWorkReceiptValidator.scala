package controllers.customer.validators

import controllers.validators.BasicValidator
import exceptions._
import model.customer.{ExtraWorkReceipt, ReceiptNumber}
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait ExtraWorkReceiptValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,ExtraWorkReceipt] =  {
    body match {
      case Some(json) => {
        Try(ExtraWorkReceipt.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,ExtraWorkReceipt](NoJsonBodyFound())
    }
  }

  private def validate(entity: ExtraWorkReceipt):Either[BadRequest,ExtraWorkReceipt] = {
    for{
      _ <- dateFormatCheck(entity.dateCreated)
      _ <- dateFormatCheck(entity.paymentDate)
      _ <- emptyCheck(entity.receiptNumber,"Receipt Number")
      _ <- validateExtraWorkReceiptNumber(entity.receiptNumber)
      _ <- emptyCheck(entity.mode,"Mode of Payment")
    }yield entity
  }

  private def validateExtraWorkReceiptNumber(number : String):Either[BadRequest,String] = {
    ReceiptNumber.checkIfVocherNumberValid(number) match {
      case true => Right(number)
      case false => Left(BadReceiptNumberFormat())
    }
  }
}
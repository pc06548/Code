package controllers.customer

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.customer.validators.DemandLetterValidator
import javax.inject._
import play.api.libs.json.Json
import services.DemandLetterService
import utils.JsonImplicites._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class DemandLetterController @Inject()(customerDemandService: DemandLetterService,
                                       authService : AuthService,
                                       authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with DemandLetterValidator{

  def getDemand(companyId : Int,projectId:Int,customerId:Int,id : Int) = AuthenticateWithCompany(companyId).async{
    request => {
      customerDemandService.getDemand(id,projectId,customerId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveDemand(companyId : Int,projectId:Int,customerId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = customerDemandService.saveDemand(input.copy(companyId = companyId,projectId = projectId,customerId=customerId))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateDemand(companyId : Int,projectId:Int,customerId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          customerDemandService.updateDemand(input.copy(companyId = companyId,projectId = projectId,customerId=customerId))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteDemand(companyId : Int,projectId:Int,customerId:Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => customerDemandService.delete(id,projectId,customerId).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }

  def getDemandLetter(companyId : Int,projectId:Int,customerId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      customerDemandService.getDemandLetter(companyId,projectId,customerId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def search(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val name = request.getQueryString("name")
      val dl = customerDemandService.searchDemandLetters(companyId,projectId,name)
      dl.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
}

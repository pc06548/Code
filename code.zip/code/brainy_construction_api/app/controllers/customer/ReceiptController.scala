package controllers.customer

import auth.db.AuthInfoExtractorDb
import play.api.mvc.{Action, AnyContent, ControllerComponents}
import auth.services.AuthService
import config.DateUtil
import controllers.BaseController
import controllers.customer.validators.ReceiptValidator
import javax.inject.{Inject, Singleton}
import play.api.libs.json.{JsValue, Json}
import services.ReceiptService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._
import consts.Roles

@Singleton
class ReceiptController @Inject()(receiptService: ReceiptService,
                                  authService : AuthService,
                                  authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with ReceiptValidator{

  def getReceipt(companyId : Int,projectId:Int,id : Int) = AuthenticateWithCompany(companyId).async{
    request => {
      receiptService.getReceipt(id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchReceipts(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val name = request.getQueryString("name")
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val receiptNumber = request.getQueryString("receiptNumber").toOptionString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val isTemporary = request.getQueryString("isTemporary").toOptionBoolean
      val customers = receiptService.searchReceipts(companyId,projectId,name,dates._1,dates._2,isTemporary,receiptNumber)
      customers.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
  
  def saveReceipt(companyId : Int,projectId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = receiptService.saveReceipt(companyId,input)
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }


  def deleteReceipt(companyId : Int,projectId:Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => receiptService.deleteReceipt(id).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }
  def getReceiptNumber(companyId : Int,projectId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>

      val receipts = receiptService.getReceiptNumber(companyId)
      receipts.map(c => c match {
        case Right(number) => Ok(ReceiptNumberResponse(number).toJson).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }
}

case class ReceiptNumberResponse(receiptNumber:String){
  implicit val implicitCompanyWrites = Json.writes[ReceiptNumberResponse]
  def toJson: JsValue = Json.toJson(this)
}
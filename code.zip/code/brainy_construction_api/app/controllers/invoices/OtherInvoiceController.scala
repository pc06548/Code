package controllers.invoices

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import config.DateUtil
import controllers.BaseController
import controllers.invoices.validators.OtherInvoiceValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.OtherInvoiceService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._

@Singleton
class OtherInvoiceController @Inject()(invoiceService: OtherInvoiceService,
                                       authService : AuthService,
                                       authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with OtherInvoiceValidator  {

  def getInvoiceById(companyId : Int,projectId:Option[Int], id: Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      invoiceService.getInvoice(companyId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def searchInvoices(companyId : Int,projectId:Option[Int]): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").getOrElse("")
      val status = request.getQueryString("status").getOrElse("")
      val categoryName = request.getQueryString("categoryName").getOrElse("")
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val invoiceNumber = request.getQueryString("invoiceNumber").toOptionString
      val dates: (Option[String], Option[String]) = month match {
        case Some(m) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case None => (startDate,endDate)
      }
      val isTemporary = request.getQueryString("isTemporary").toOptionBoolean
      val invoices = invoiceService.searchInvoice(name,companyId,projectId,status,categoryName,dates._1,dates._2,isTemporary,invoiceNumber)
      invoices.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def createInvoice(companyId: Int,projectId:Option[Int]): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val id = invoiceService.saveInvoice(input.copy(companyId = companyId,projectId = projectId))
          id.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(errorMessage) => Future(BadRequest(errorMessage.errorMessage))
      }
  }

  def updateInvoice(companyId: Int,projectId:Option[Int]): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val id = invoiceService.updateInvoice(input)
          id.map(entityId => entityId match {
            case Right(_) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(errorMessage) => Future(BadRequest(errorMessage.errorMessage))
      }
  }

  def deleteInvoice(companyId : Int,projectId:Option[Int], id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request => invoiceService.deleteInvoice(companyId,id).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

  def deleteDetail(companyId : Int,projectId:Option[Int],invoiceId : Int, id:Int): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request => invoiceService.deleteDetail(invoiceId,id).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

  def getOtherInvoiceById(companyId : Int,projectId:Int, id: Int): Action[AnyContent] = getInvoiceById(companyId,Some(projectId),id)

  def searchOtherInvoices(companyId : Int,projectId:Int): Action[AnyContent] =  searchInvoices(companyId,Some(projectId))

  def createOtherInvoice(companyId: Int,projectId:Int): Action[AnyContent] = createInvoice(companyId,Some(projectId))

  def updateOtherInvoice(companyId: Int,projectId:Int): Action[AnyContent] = updateInvoice(companyId,Some(projectId))

  def deleteOtherInvoice(companyId : Int,projectId:Int, id:Int): Action[AnyContent] = deleteInvoice(companyId,Some(projectId),id)

  def deleteOtherInvoiceDetail(companyId : Int,projectId:Int,invoiceId : Int, id:Int): Action[AnyContent] =
    deleteDetail(companyId,Some(projectId),invoiceId,id)

  def getOfficeInvoiceById(companyId : Int,id: Int): Action[AnyContent] = getInvoiceById(companyId,None,id)

  def searchOfficeInvoices(companyId : Int): Action[AnyContent] = searchInvoices(companyId,None)

  def createOfficeInvoice(companyId: Int): Action[AnyContent] =  createInvoice(companyId,None)

  def updateOfficeInvoice(companyId: Int): Action[AnyContent] = updateInvoice(companyId,None)

  def deleteOfficeInvoice(companyId : Int,id:Int): Action[AnyContent] = deleteInvoice(companyId,None,id)

  def deleteOfficeInvoiceDetail(companyId : Int,invoiceId : Int, id:Int): Action[AnyContent] =
    deleteDetail(companyId,None,invoiceId,id)

}

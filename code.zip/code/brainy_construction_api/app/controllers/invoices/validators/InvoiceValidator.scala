package controllers.invoices.validators

import config.DateUtil
import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.invoices.SaveInvoice
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait InvoiceValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,SaveInvoice] =  {
    body match {
      case Some(json) => {
        Try(SaveInvoice.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,SaveInvoice](NoJsonBodyFound())
    }
  }

  private def validate(entity: SaveInvoice):Either[BadRequest,SaveInvoice] = {
    for{
      _ <- dateFormatCheck(entity.invoiceDate)
      _ <- nonZeroValueCheck(entity.totalAmount,"Total amount")
      _ <- dateFormatCheck(entity.createdDate)
      _ <- emptyCheck(entity.invoiceNumber,"Invoice Number")
    }yield entity.copy(lastUpdated = Some(DateUtil.today))
  }
}

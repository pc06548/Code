package controllers.invoices.validators

import config.DateUtil
import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.invoices.SaveOtherInvoice
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait OtherInvoiceValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,SaveOtherInvoice] =  {
    body match {
      case Some(json) => {
        Try(SaveOtherInvoice.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,SaveOtherInvoice](NoJsonBodyFound())
    }
  }

  private def validate(entity: SaveOtherInvoice):Either[BadRequest,SaveOtherInvoice] = {
    for{
      _ <- dateFormatCheck(entity.invoiceDate)
      _ <- dateFormatCheck(entity.createdDate)
      _ <- nonZeroValueCheck(entity.totalAmount,"Total amount")
      _ <- emptyCheck(entity.invoiceNumber,"Invoice Number")
    }yield entity.copy(lastUpdated = Some(DateUtil.today))
  }
}
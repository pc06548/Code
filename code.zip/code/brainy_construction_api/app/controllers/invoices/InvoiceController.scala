package controllers.invoices

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import config.DateUtil
import config.ScalaHelpers._
import controllers.BaseController
import controllers.invoices.validators.InvoiceValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.InvoiceService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class InvoiceController @Inject()(invoiceService: InvoiceService,
                                  authService : AuthService,
                                  authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with InvoiceValidator  {

  def getInvoiceById(companyId : Int,projectId:Option[Int], id: Int, invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      invoiceService.getInvoice(companyId,id, invoiceType).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def searchInvoices(companyId : Int,projectId:Option[Int], invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      val name = request.getQueryString("name").getOrElse("")
      val status = request.getQueryString("status").getOrElse("")
      val startDate = request.getQueryString("startDate").toOptionDateString
      val endDate = request.getQueryString("endDate").toOptionDateString
      val month = request.getQueryString("month").toOptionMonth
      val invoiceNumber = request.getQueryString("invoiceNumber").toOptionString
      val dates: (Option[String], Option[String]) = month match {
        case Some(m) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case None => (startDate,endDate)
      }
      val isTemporary = request.getQueryString("isTemporary").toOptionBoolean

      val invoices = invoiceService.searchInvoice(name,companyId,projectId,status, invoiceType,dates._1,dates._2,isTemporary,invoiceNumber)
      invoices.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
  }

  def createInvoice(companyId: Int,projectId:Option[Int], invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val id = invoiceService.saveInvoice(input.copy(companyId = companyId,projectId = projectId), invoiceType)
          id.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(errorMessage) => Future(BadRequest(errorMessage.errorMessage))
      }
  }

  def updateInvoice(companyId: Int,projectId:Option[Int], invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val id = invoiceService.updateInvoice(input.copy(companyId = companyId,projectId = projectId), invoiceType)
          id.map(entityId => entityId match {
            case Right(_) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(errorMessage) => Future(BadRequest(errorMessage.errorMessage))
      }
  }

  def deleteInvoice(companyId : Int,projectId:Option[Int], id:Int, invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request =>
      invoiceService.deleteInvoice(companyId,id, invoiceType).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

  def deleteDetail(companyId : Int,projectId:Option[Int],invoiceId : Int, id:Int, invoiceType: String): Action[AnyContent] = AuthenticateWithCompany(companyId).async {
    request => invoiceService.deleteDetail(invoiceId,id, invoiceType).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

  def getProjectInvoiceById(companyId : Int,projectId:Int, id: Int, invoiceType: String): Action[AnyContent] = getInvoiceById(companyId,Some(projectId),id,invoiceType)

  def getOfficeInvoiceById(companyId : Int,id: Int, invoiceType: String): Action[AnyContent] = getInvoiceById(companyId,None,id,invoiceType)

  def searchProjectInvoices(companyId : Int,projectId:Int, invoiceType: String): Action[AnyContent] = searchInvoices(companyId,Some(projectId),invoiceType)

  def searchOfficeInvoices(companyId : Int, invoiceType: String): Action[AnyContent] = searchInvoices(companyId,None,invoiceType)

  def createProjectInvoice(companyId: Int,projectId:Int, invoiceType: String): Action[AnyContent] = createInvoice(companyId,Some(projectId),invoiceType)

  def createOfficeInvoice(companyId: Int,invoiceType: String): Action[AnyContent] = createInvoice(companyId,None,invoiceType)

  def updateProjectInvoice(companyId: Int,projectId:Int, invoiceType: String): Action[AnyContent] = updateInvoice(companyId,Some(projectId),invoiceType)

  def updateOfficeInvoice(companyId: Int, invoiceType: String): Action[AnyContent] = updateInvoice(companyId,None,invoiceType)

  def deleteProjectInvoice(companyId : Int,projectId:Int, id:Int, invoiceType: String): Action[AnyContent] = deleteInvoice(companyId,Some(projectId),id,invoiceType)

  def deleteOfficeInvoice(companyId : Int,id:Int, invoiceType: String): Action[AnyContent] = deleteInvoice(companyId,None,id,invoiceType)

  def deleteProjectDetail(companyId : Int,projectId:Int,invoiceId : Int, id:Int, invoiceType: String): Action[AnyContent] = deleteDetail(companyId,Some(projectId),invoiceId,id,invoiceType)

  def deleteOfficeDetail(companyId : Int,invoiceId : Int, id:Int, invoiceType: String): Action[AnyContent]  = deleteDetail(companyId,None,invoiceId,id,invoiceType)

}


package controllers.user

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import consts.Roles
import controllers.BaseController
import exceptions.{PlanLimitReached, RuntimeException}
import javax.inject._
import model.EntityId
import play.api.libs.json.{JsValue, Json}
import play.api.mvc.ControllerComponents
import services.UserService

import scala.concurrent.Future
import scala.util.{Failure, Success, Try}

@Singleton
class UserController @Inject()(userService: UserService, authService : AuthService,
                               authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) {

  def create() = Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      val result: Either[Throwable, Option[EntityId]] = Try(
        for {
          json <- authRequest.request.body.asJson
          createUserRequest <- CreateUserRequest.createFromJson(json)
        } yield {
          val userId = userService.createUser(createUserRequest, authRequest)
          EntityId(userId._1)
        }
      ).toEither
      result match {
       case Right(Some(id)) => Future.successful(Ok(id.toJson).withBat(authRequest.bat))
       case Right(None) => Future.successful(InternalServerError("Something went wrong").withBat(authRequest.bat))
       case Left(PlanLimitReached()) => Future.successful(InternalServerError(PlanLimitReached().errorMessage).withBat(authRequest.bat))
       case Left(exception) => Future.successful(InternalServerError(RuntimeException(exception).errorMessage).withBat(authRequest.bat))
      }
    }
  }

  def update() = Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      val result = Try(
        for{
          json <- authRequest.request.body.asJson
          updateUserRequest <- UpdateUserRequest.createFromJson(json)
        }yield {
          userService.updateUser(updateUserRequest)
        }
      )
      result match {
        case Success(_) => Future.successful(NoContent.withBat(authRequest.bat))
        case Failure(exception) => Future.successful(InternalServerError(RuntimeException(exception).errorMessage).withBat(authRequest.bat))
      }
    }
  }

  def getUsersByOrgId() = Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      val name = authRequest.getQueryString("name").getOrElse("")
      val users = Try(userService.getUsersByOrgId(authRequest.orgId,name))
      users match {
        case Success(users) => {
          Future.successful(Ok(Json.toJson(users.filter(u => u.id != authRequest.userId).map(_.toJson))).withBat(authRequest.bat))
        }
        case Failure(exception) => Future.successful(InternalServerError(RuntimeException(exception).errorMessage).withBat(authRequest.bat))
      }
    }
  }

  def getUserByLoginId() = Authenticate(Roles.allRoles).async {
    authRequest => {
      userService.getUsersByLoginId(authRequest.loginId) match {
        case Right(userO) => userO match {
          case Some(user) =>
            Future.successful(Ok(user.toJson).withBat(authRequest.bat))
          case None =>
            Future.successful(NotFound.withBat(authRequest.bat))
        }
        case Left(ex) =>
          Future.successful(InternalServerError(ex.getMessage).withBat(authRequest.bat))
      }
    }
  }

  def getUserByUserId(userId: Int) = Authenticate(List(Roles.ADMIN)).async {
    authRequest => {
      userService.getUsersByUserId(userId) match {
        case Right(userO) => userO match {
          case Some(user) =>
            Future.successful(Ok(user.toJson).withBat(authRequest.bat))
          case None =>
            Future.successful(NotFound.withBat(authRequest.bat))
        }
        case Left(ex) =>
          Future.successful(InternalServerError(ex.getMessage).withBat(authRequest.bat))
      }
    }
  }

  def getOrgOfCurrentUser() = Authenticate(Roles.allRoles).async {
    authRequest => {
      val result = Try(userService.getOrgById(authRequest.orgId))
      result match {
        case Success(o) => o match {
          case Some(org) =>
            Future.successful(Ok(org.toJson).withBat(authRequest.bat))
          case None =>
            Future.successful(NotFound.withBat(authRequest.bat))
        }
        case Failure(exception) => Future.successful(InternalServerError(RuntimeException(exception).errorMessage).withBat(authRequest.bat))
      }
    }
  }
}

case class CreateUserRequest(name: String, mobileNumber: String, emailId: Option[String], userName: String)
object CreateUserRequest {
  private implicit val implicitCreateUserRequestReads = Json.reads[CreateUserRequest]
  def createFromJson(json: JsValue): Option[CreateUserRequest] = Try(Some(json.as[CreateUserRequest])).getOrElse(None)
}

case class UpdateUserRequest(id: Int, name: Option[String], mobileNumber: Option[String], emailId: Option[String])
object UpdateUserRequest {
  private implicit val implicitCreateUserRequestReads = Json.reads[UpdateUserRequest]
  def createFromJson(json: JsValue): Option[UpdateUserRequest] = Try(Some(json.as[UpdateUserRequest])).getOrElse(None)
}
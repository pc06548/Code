package controllers.employee

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.ScalaHelpers._
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.employee.validators.LoanPrepaymentValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.employees.LoanPrepaymentService

import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future

@Singleton
class LoanPrepaymentController @Inject()(loanService: LoanPrepaymentService,
                                         authService : AuthService,
                                         authInfoExtractorDb: AuthInfoExtractorDb,
                                         controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with LoanPrepaymentValidator {

  def getLoanPrepayment(companyId : Int,loanId:Int,id : Int) = AuthenticateWithCompany(companyId).async{
    request => {
      loanService.getLoanPrepayment(loanId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchLoanPrepayments(companyId:Int,loanId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val loans = loanService.searchLoanPrepayments(loanId)
      loans.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveLoanPrepayment(companyId:Int,loanId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = loanService.saveLoanPrepayment(companyId,input.copy(loanId = Some(loanId)))
          res.map(locationId => locationId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def deleteLoanPrepayment(companyId : Int,loanId:Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => loanService.delete(id,loanId).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }
}

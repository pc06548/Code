package controllers.employee

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import consts.{Roles, StringLiterals}
import controllers.BaseController
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.employees.AttendanceService
import config.ScalaHelpers._
import controllers.employee.validators.AttendanceValidator

import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future

@Singleton
class AttendanceController @Inject()(attendanceService: AttendanceService,
                                     authService : AuthService,
                                     authInfoExtractorDb: AuthInfoExtractorDb,
                                     controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with AttendanceValidator {

  def getAttendance(companyId : Int,id : Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async{
    request => {
      attendanceService.getAttendance(id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getAttendanceForToday(companyId : Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async{
    request => {
      val employeeId = request.getQueryString("employeeId").toOptionInt
      attendanceService.getAttendanceForEmployee(companyId,employeeId,DateUtil.today).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchAttendance(companyId:Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      val employeeId = request.getQueryString("employeeId").toOptionInt
      val startDate = request.getQueryString("startDate").getOrElse(DateUtil.getFirstDayOfMonth(DateUtil.today))
      val endDate = request.getQueryString("endDate").getOrElse(DateUtil.today)
      val locations = attendanceService.searchAttendances(companyId,employeeId,Some(startDate),Some(endDate))
      locations.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }


  def saveAttendance(companyId:Int) = AuthenticateWithCompany(companyId, Roles.allRoles).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = attendanceService.saveAttendance(companyId,input.copy(companyId = Some(companyId)))
          res.map(locationId => locationId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateAttendance(companyId : Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          attendanceService.updateAttendance(input.copy(companyId = Some(companyId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def getAttendanceReport(companyId:Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {
    request => {
      val employeeId = request.getQueryString("employeeId").toOptionInt
      val startDate = request.getQueryString("startDate").getOrElse(DateUtil.getFirstDayOfMonth(DateUtil.today))
      val endDate = request.getQueryString("endDate").getOrElse(DateUtil.today)
      val locations = attendanceService.attendanceReport(companyId,employeeId,Some(startDate),Some(endDate))
      locations.map(c => c match {
        case Right(report) => Ok(Json.toJson(report.toJson)).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
}

package controllers.employee

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import consts.Roles
import controllers.BaseController
import controllers.employee.validators.PayslipVoucherValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.employees.PayslipVoucherService
import config.ScalaHelpers._
import services.reports.GroupSalaryPaymentReportService

import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future

@Singleton
class PayslipVoucherController @Inject()(payslipVoucherService: PayslipVoucherService,
                                         authService : AuthService,
                                         authInfoExtractorDb: AuthInfoExtractorDb,
                                         controllerComponent: ControllerComponents,
                                         groupSalaryPaymentReportService:GroupSalaryPaymentReportService)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with PayslipVoucherValidator {

  def getPayslipVoucher(companyId : Int,id : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async{
    request => {
      payslipVoucherService.getPayslipVoucher(companyId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchPayslipVouchers(companyId:Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async {
    request => {
      val employeeId = request.getQueryString("employeeId").toOptionInt

      val startDate = request.getQueryString("startDate").toOptionString
      val endDate = request.getQueryString("endDate").toOptionString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val voucherNumber = request.getQueryString("voucherNumber").toOptionString

      val payslipVouchers = payslipVoucherService.searchPayslipVouchers(companyId,employeeId,dates._1,dates._2,voucherNumber)
      payslipVouchers.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def savePayslipVoucher(companyId:Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = payslipVoucherService.savePayslipVoucher(companyId,input)
          res.map(locationId => locationId match {
            case Right(id) => NoContent.withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def deletePayslipVoucher(companyId : Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => payslipVoucherService.delete(id,companyId).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }

  def getGroupSalaryReport(companyId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async{
    request => {
      val paymentReference = request.getQueryString("paymentReference").toOptionString
      val paymentDate = request.getQueryString("paymentDate").toOptionDateString
      groupSalaryPaymentReportService.getReport(companyId,paymentReference,paymentDate).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
}

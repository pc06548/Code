package controllers.employee

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.employee.validators.LoanValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.employees.LoanService
import config.ScalaHelpers._
import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future

@Singleton
class LoanController @Inject()(loanService: LoanService,
                               authService : AuthService,
                               authInfoExtractorDb: AuthInfoExtractorDb,
                               controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with LoanValidator {

  def getLoan(companyId : Int,employeeId:Int,id : Int) = AuthenticateWithCompany(companyId).async{
    request => {
      loanService.getLoan(employeeId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchLoansForEmployee(companyId:Int,employeeId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val isActive = request.getQueryString("isActive").toOptionBoolean
      val loans = loanService.searchLoans(companyId,None,Some(employeeId),isActive,None)
      loans.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchLoans(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val isActive = request.getQueryString("isActive").toOptionBoolean
      val employeeId = request.getQueryString("employeeId").toOptionInt
      val employeeName = request.getQueryString("employeeName").toOptionString
      val status = request.getQueryString("status").toOptionString

      val loans = loanService.searchLoans(companyId,employeeName,employeeId,isActive,status)
      loans.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveLoan(companyId:Int,employeeId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = loanService.saveLoan(companyId,input.copy(companyId = Some(companyId)))
          res.map(locationId => locationId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateLoan(companyId : Int,employeeId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          loanService.updateLoan(input.copy(companyId = Some(companyId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteLoan(companyId : Int,employeeId:Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => loanService.delete(id,employeeId).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }

  def getLoanStatement(companyId : Int,employeeId:Int) = AuthenticateWithCompany(companyId).async{
    request => {
      val loanId = request.getQueryString("loanId").toOptionInt
      loanService.getLoanStatement(companyId,employeeId,loanId).map(c => c match {
        case Right(entity) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

}

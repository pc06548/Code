package controllers.employee

import config.{DateHelperDeprecated, DateUtil}
import controllers.user.CreateUserRequest
import model.employee.{Employee, EmployeeWithUser}
import model.BankDetails
import play.api.libs.json.{JsValue, Json}

case class CreateEmployeeRequest(userId: Option[Int],
                                 name: String,
                                 mobileNumber: String,
                                 emailId: Option[String],
                                 userName: Option[String],
                                 companyId: Int,
                                 address: Option[String] = None,
                                 designation: Option[String] = None,
                                 department: Option[String] = None,
                                 pfNumber: Option[String] = None,
                                 panNumber: Option[String] = None,
                                 aadharNumber: Option[String] = None,
                                 joiningDate: Option[String] = None,
                                 workingHours: Option[Double] = None,
                                 bankDetails: Option[BankDetails] = None,
                                 activeUntil: Option[String],
                                 createTimestamp: Option[String],
                                 updateTimestamp: Option[String]) {
  def getEmployee:Employee = {
    Employee(
      None,
      userId = this.userId.getOrElse(-1), companyId = this.companyId,
      name = this.name,
      mobileNumber = this.mobileNumber,
      email = this.emailId,
      address = this.address, designation = this.designation, department = this.department, pfNumber = this.pfNumber,
      panNumber = this.panNumber, aadharNumber = this.aadharNumber, joiningDate = this.joiningDate,
      workingHours = this.workingHours, bankDetails = this.bankDetails,
      activeUntil = Some(this.activeUntil.getOrElse(DateUtil.endOfTimeDate)),None,None
    )
  }

  def getEmployeeWithUser = {
    EmployeeWithUser(getEmployee, Some(CreateUserRequest(this.name, this.mobileNumber, this.emailId, this.userName.getOrElse(""))))
  }
}
object CreateEmployeeRequest {
  private implicit val implicitBankDetails = Json.reads[BankDetails]
  private implicit val implicitUpdateRoleMappingRequestReads = Json.reads[CreateEmployeeRequest]
  def createFromJson(json: JsValue): CreateEmployeeRequest = json.as[CreateEmployeeRequest]
}

package controllers.employee.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.employee.Performance
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait PerformanceValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Performance] =  {
    body match {
      case Some(json) => {
        Try(Performance.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Performance](NoJsonBodyFound())
    }
  }

  private def validate(entity: Performance):Either[BadRequest,Performance] = {
    for{
      _ <- dateFormatCheck(entity.date)
    }yield entity
  }
}

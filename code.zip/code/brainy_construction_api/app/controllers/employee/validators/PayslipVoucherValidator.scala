package controllers.employee.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, BadVoucherNumberFormat, JsonParsingFailed, NoJsonBodyFound}
import model.VoucherNumber
import model.vouchers.{SavePayslipVoucher}
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait PayslipVoucherValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Seq[SavePayslipVoucher]] =  {
    body match {
      case Some(json) => {
        Try(SavePayslipVoucher.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Seq[SavePayslipVoucher]](NoJsonBodyFound())
    }
  }

  private def validate(entities: Seq[SavePayslipVoucher]):Either[BadRequest,Seq[SavePayslipVoucher]] = {
    val res: Seq[Either[BadRequest, SavePayslipVoucher]] = entities.map(entity => {
      for{
        _ <- dateFormatCheck(entity.paymentDate)
        _ <- emptyCheck(entity.voucherNumber,"Voucher number")
        _ <- validateVoucherNumber(entity.voucherNumber)
        _ <- dateFormatCheck(entity.voucherDate)
        _ <- emptyCheck(entity.reason,"Voucher reason")
        _ <- nonZeroValueCheck(entity.totalAmount,"Total amount")
      }yield entity
    })
    //TODO Need to fix this.
    Right(entities)
  }

  private def validateVoucherNumber(number : String):Either[BadRequest,String] = {
    VoucherNumber.checkIfVocherNumberValid(number) match {
      case true => Right(number)
      case false => Left(BadVoucherNumberFormat())
    }
  }
}

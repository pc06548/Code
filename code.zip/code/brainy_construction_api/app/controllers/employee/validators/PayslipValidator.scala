package controllers.employee.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, EmployeeIdMonthMissing}

trait PayslipValidator extends BasicValidator{

  def validatedInput(employeeId:Option[Int],month:Option[String]): Either[BadRequest,(Int,String)] =  {

    (employeeId,month) match {
      case (Some(id),Some(m))=> validate(id,m)
      case _ => Left[BadRequest,(Int,String)](EmployeeIdMonthMissing())
    }
  }

  private def validate(employeeId:Int,month:String):Either[BadRequest,(Int,String)] = {
    for{
      _ <- monthFormatCheck(month)
    }yield (employeeId,month)
  }
}

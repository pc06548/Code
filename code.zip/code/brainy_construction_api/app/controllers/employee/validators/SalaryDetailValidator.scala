package controllers.employee.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.employee.SalaryDetail
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait SalaryDetailValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,SalaryDetail] =  {
    body match {
      case Some(json) => {
        Try(SalaryDetail.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,SalaryDetail](NoJsonBodyFound())
    }
  }

  private def validate(entity: SalaryDetail):Either[BadRequest,SalaryDetail] = {
    for{
      _ <- nonZeroValueCheck(entity.amount,"Amount")
      _ <- emptyCheck(entity.description,"Description")
      _ <- emptyCheck(entity.detailType,"Type of detail")
      _ <- dateFormatCheck(entity.validFrom,"Valid From")
      _ <- dateFormatCheck(entity.validTill,"Valid Till")
    }yield entity
  }
}

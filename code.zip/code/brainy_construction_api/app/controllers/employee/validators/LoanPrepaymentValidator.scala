package controllers.employee.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.employee.LoanPrepayment
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait LoanPrepaymentValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,LoanPrepayment] =  {
    body match {
      case Some(json) => {
        Try(LoanPrepayment.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,LoanPrepayment](NoJsonBodyFound())
    }
  }

  private def validate(entity: LoanPrepayment):Either[BadRequest,LoanPrepayment] = {
    for{
      _ <- nonZeroValueCheck(entity.amountPaid,"Amount Paid")
      _ <- dateFormatCheck(entity.datePaid)
    }yield entity
  }
}

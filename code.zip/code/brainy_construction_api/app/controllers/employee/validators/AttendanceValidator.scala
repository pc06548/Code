package controllers.employee.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.employee.Attendance
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait AttendanceValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Attendance] =  {
    body match {
      case Some(json) => {
        Try(Attendance.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Attendance](NoJsonBodyFound())
    }
  }

  private def validate(entity: Attendance):Either[BadRequest,Attendance] = {
    for{
      _ <- dateFormatCheck(entity.date)
    }yield entity
  }
}

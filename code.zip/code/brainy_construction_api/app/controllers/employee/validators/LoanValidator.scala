package controllers.employee.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.employee.Loan
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait LoanValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Loan] =  {
    body match {
      case Some(json) => {
        Try(Loan.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Loan](NoJsonBodyFound())
    }
  }

  private def validate(entity: Loan):Either[BadRequest,Loan] = {
    for{
      _ <- nonZeroValueCheck(entity.monthlyEmi,"Monthly EMI")
      _ <- nonZeroValueCheck(entity.loanAmount,"Total Loan Amount")
      _ <- emptyCheck(entity.description,"Description")
      _ <- dateFormatCheck(entity.validFrom,"Valid From")
      _ <- dateFormatCheck(entity.validTill,"Valid Till")
    }yield entity
  }
}

package controllers.employee.validators

import controllers.employee.CreateEmployeeRequest
import controllers.validators.BasicValidator
import exceptions.{BadRequest, FieldCannotBeEmpty, JsonParsingFailed, NoJsonBodyFound}
import model.BankDetails
import model.employee.Employee
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait EmployeeValidator extends BasicValidator{

  def validateCreateEmployeeRequest(body: Option[JsValue]): Either[BadRequest, CreateEmployeeRequest] =  {
    body match {
      case Some(json) =>
        Try(CreateEmployeeRequest.createFromJson(json)) match {
          case Success(entity) => validateCreateEmployee(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      case None => Left[BadRequest, CreateEmployeeRequest](NoJsonBodyFound())
    }
  }

  private def validateCreateEmployee(entity: CreateEmployeeRequest):Either[BadRequest, CreateEmployeeRequest] = {
    for{
      _ <- eitherUserIdOrUserName(entity.userId,entity.userName)
      _ <- phoneNumberCheck(entity.mobileNumber)
      _ <- emailCheck(entity.emailId)
      _ <- dateFormatCheck(entity.joiningDate)
      _ <- dateFormatCheck(entity.activeUntil)
      _ <- bankDetailsIfPresentShouldBeCompleteCheck(entity.bankDetails)
    }yield entity
  }

  private def eitherUserIdOrUserName(userId: Option[Int], userName: Option[String]): Either[BadRequest, Any] = {
    (userId, userName) match {
      case (Some(_), _) => Right(userId)
      case (None, Some(userName)) if userName.trim.nonEmpty => Right(userName)
      case _ => Left[BadRequest,String](FieldCannotBeEmpty("Either provide userId or Username for creating new user"))
    }
  }

  private def bankDetailsIfPresentShouldBeCompleteCheck(bankDetailsO: Option[BankDetails]): Either[BadRequest, Any] = {
    bankDetailsO match {
      case Some(_) => Right(())
      case None => Right(())
      case _ => Left[BadRequest,String](FieldCannotBeEmpty("Either provide all bank details or none"))
    }
  }

  def validateEmployeeRequest(body: Option[JsValue]): Either[BadRequest, Employee] =  {
    body match {
      case Some(json) =>
        Try(Employee.createFromJson(json)) match {
          case Success(entity) => validateEmployee(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      case None => Left[BadRequest, Employee](NoJsonBodyFound())
    }
  }


  private def validateEmployee(entity: Employee):Either[BadRequest, Employee] = {
    for{
      _ <- dateFormatCheck(entity.joiningDate)
      _ <- dateFormatCheck(entity.activeUntil)
      _ <- bankDetailsIfPresentShouldBeCompleteCheck(entity.bankDetails)
    } yield entity
  }
}

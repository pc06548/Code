package controllers.employee

import auth.action.UserRequest
import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.employee.validators.EmployeeValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.employees.EmployeeService

import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future

@Singleton
class EmployeeController @Inject()(employeeService: EmployeeService,
                                   authService : AuthService,
                                   authInfoExtractorDb: AuthInfoExtractorDb,
                                   controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with EmployeeValidator {

  def createEmployee(companyId:Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async {

    request => {
      validateCreateEmployeeRequest(request.body.asJson) match {
        case Right(input) => {
          val res = createEmployeeWithOrWithoutUser(input, request)
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  private def createEmployeeWithOrWithoutUser(createEmployeeRequest: CreateEmployeeRequest,  userRequest: UserRequest[AnyContent]) = {
    createEmployeeRequest.userId match {
      case None => employeeService.createEmployeeWithUser(createEmployeeRequest.getEmployeeWithUser,userRequest)
      case Some(_) => employeeService.createEmployeeWithExistingUser(createEmployeeRequest.getEmployee)
    }
  }

  def updateEmployee(companyId:Int): Action[AnyContent] = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async {

    request => {
      validateEmployeeRequest(request.body.asJson) match {
        case Right(input) => {
          employeeService.updateEmployee(input)
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def getEmployee(companyId: Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async {
    request => {
      employeeService.getEmployeeByIdAndCompanyId(companyId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getSelfEmployee(companyId: Int) = AuthenticateWithCompany(companyId,Roles.allRoles).async {

    request => {
      employeeService.getEmployeeByUserIdAndCompanyId(request.userId, companyId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def search(companyId: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async {
    request => {
      val name = request.getQueryString("name").getOrElse("")
      employeeService.search(companyId,name).map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getAllNames(companyId : Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val emps = employeeService.getAllNames(companyId)
      emps.map(c => c match {
        case Right(names) => Ok(Json.toJson(names.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

}

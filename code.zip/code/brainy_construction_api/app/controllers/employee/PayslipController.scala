package controllers.employee

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import config.ScalaHelpers._
import consts.Roles
import controllers.BaseController
import controllers.employee.validators.PayslipValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.employees.PayslipService

import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future

@Singleton
class PayslipController @Inject()(payslipService: PayslipService,
                                  authService : AuthService,
                                  authInfoExtractorDb: AuthInfoExtractorDb,
                                  controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with PayslipValidator {

  def getPayslip(companyId : Int,id : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async{
    request => {
      payslipService.getPayslip(id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchPayslip(companyId:Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async {
    request => {
      val employeeId = request.getQueryString("employeeId").toOptionInt
      val status = request.getQueryString("status")
      val startDate = request.getQueryString("startDate").toOptionString
      val endDate = request.getQueryString("endDate").toOptionString
      val month = request.getQueryString("month").toOptionMonth
      val f_year = request.getQueryString("f_year").toOptionFYear
      val payslipId = request.getQueryString("payslipNumber").toOptionInt

      val dates: (Option[String], Option[String]) = (month,f_year) match {
        case (_,Some(y)) => (Some(DateUtil.getFirstDateOfFyear(y)),Some(DateUtil.getLastDateOfFyear(y)))
        case (Some(m),_) => (Some(DateUtil.getFirstDayFromMonth(m)),Some(DateUtil.getLastDayOfMonth(m)))
        case (None,None) => (startDate,endDate)
      }
      val locations = payslipService.searchPayslips(companyId,employeeId,month,status,dates._1,dates._2,payslipId)
      locations.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def deletePayslip(companyId : Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async {
    request => payslipService.deletePayslip(id).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }

  def generatePayslip(companyId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.CHIEF_ACCOUNTANT)).async{
    request => {
      val employeeId = request.getQueryString("employeeId").toOptionInt
      val month = request.getQueryString("month").toOptionString
      validatedInput(employeeId,month) match {
        case Right(input) => {

          val res = payslipService.createPayslip(companyId,input._1,input._2)
          res.map(locationId => locationId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

}

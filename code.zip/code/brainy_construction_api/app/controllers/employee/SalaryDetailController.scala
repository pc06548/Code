package controllers.employee

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import config.DateUtil
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.employee.validators.SalaryDetailValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.employees.SalaryDetailService

import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future
import config.ScalaHelpers._
@Singleton
class SalaryDetailController @Inject()(salaryDetailService: SalaryDetailService,
                                       authService : AuthService,
                                       authInfoExtractorDb: AuthInfoExtractorDb,
                                       controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with SalaryDetailValidator {

  def getSalaryDetail(companyId : Int,employeeId:Int,id : Int) = AuthenticateWithCompany(companyId).async{
    request => {
      salaryDetailService.getSalaryDetail(employeeId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getSalaryStructure(companyId:Int,employeeId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val date = request.getQueryString("date").getOrElse(DateUtil.today)
      val locations = salaryDetailService.getSalaryStructure(companyId,employeeId,date)
      locations.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.toJson)).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
  def searchSalaryStructures(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val name = request.getQueryString("name").toOptionString
      val salaries = salaryDetailService.searchSalaryStructures(companyId,name)
      salaries.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveSalaryDetail(companyId:Int,employeeId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = salaryDetailService.saveSalaryDetail(companyId,input.copy(companyId = Some(companyId),employeeId = Some(employeeId)))
          res.map(locationId => locationId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateSalaryDetail(companyId : Int,employeeId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          salaryDetailService.updateSalaryDetail(input.copy(companyId = Some(companyId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteSalaryDetail(companyId : Int,employeeId:Int,id: Int) = AuthenticateWithCompany(companyId).async {
    request => salaryDetailService.delete(id,employeeId).map(updateRes => updateRes match {
      case Right(_) =>NoContent.withBat(request.bat)
      case Left(e) => InternalServerError(e.errorMessage)
    })
  }
}

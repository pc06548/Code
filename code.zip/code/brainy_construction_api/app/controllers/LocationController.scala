package controllers

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.validators.LocationValidator
import javax.inject._
import play.api.libs.json._
import play.api.mvc.ControllerComponents
import services.LocationService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class LocationController @Inject()(locationService: LocationService,
                                   authService : AuthService,
                                   authInfoExtractorDb: AuthInfoExtractorDb, controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with LocationValidator {


  def getLocation(companyId : Int,id : Int) = AuthenticateWithCompany(companyId).async{
    request => {
      locationService.getLocation(companyId,id).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def searchLocations(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request => {

      val locations = locationService.getAll(companyId)
      locations.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }


  def saveLocation(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = locationService.saveLocation(input.copy(companyId = Some(companyId)))
          res.map(locationId => locationId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
            })
          }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateLocation(companyId : Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          locationService.updateLocation(input.copy(companyId = Some(companyId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteLocation(companyId:Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => locationService.delete(companyId,id).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

}

package controllers.consultant.validators

import controllers.validators.BasicValidator
import exceptions.{BadRequest, JsonParsingFailed, NoJsonBodyFound}
import model.consultant.Consultant
import play.api.libs.json.JsValue

import scala.util.{Failure, Success, Try}

trait ConsultantValidator extends BasicValidator{

  def validatedInput(body: Option[JsValue]): Either[BadRequest,Consultant] =  {
    body match {
      case Some(json) => {
        Try(Consultant.createFromJson(json)) match {
          case Success(entity) => validate(entity)
          case Failure(ex) => Left(JsonParsingFailed(ex.getMessage))
        }
      }
      case None => Left[BadRequest,Consultant](NoJsonBodyFound())
    }
  }

  private def validate(entity: Consultant):Either[BadRequest,Consultant] = {
    for{
      _ <- emptyCheck(entity.name,"name")
      _ <- emailCheck(entity.basicDetails.email)
      _ <- phoneNumberCheck(entity.basicDetails.phoneNumber1)
      _ <- phoneNumberCheck(entity.basicDetails.phoneNumber2)
      _ <- phoneNumberCheck(entity.ownerPhoneNumber)
    }yield entity
  }
}

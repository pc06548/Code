package controllers.consultant

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import consts.{Roles, StringLiterals}
import controllers.BaseController
import controllers.consultant.validators.ConsultantValidator
import javax.inject._
import play.api.libs.json.Json
import play.api.mvc._
import services.ConsultantService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

@Singleton
class ConsultantController @Inject()(consultantService: ConsultantService,
                                     authService : AuthService,
                                     authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) with ConsultantValidator{

  def getConsultant(companyId : Int,id : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async{
    request => {
      consultantService.getConsultant(id,companyId).map(c => c match {
        case Right(Some(entity)) => Ok(Json.toJson(entity.toJson)).withBat(request.bat)
        case Right(None) => NotFound.withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }
  def searchConsultants(companyId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request => {
      val name = request.getQueryString("name")
      val department = request.getQueryString("department")
      val consultants = consultantService.searchConsultants(companyId,name,department)
      consultants.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def getAllNames(companyId : Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.SITE_MANAGER)).async {
    request => {
      val consultants = consultantService.getAllNames(companyId)
      consultants.map(c => c match {
        case Right(names) => Ok(Json.toJson(names.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }

  def saveConsultant(companyId : Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = consultantService.saveConsultant(input.copy(companyId = Some(companyId)))
          res.map(entityId => entityId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
          })
        }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def updateConsultant(companyId : Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          consultantService.updateConsultant(input.copy(companyId = Some(companyId)))
            .map(updateRes => updateRes match {
              case Right(_) => NoContent.withBat(request.bat)
              case Left(e) => InternalServerError(e.errorMessage)
            })
        }
        case Left(error) => Future(BadRequest(error.errorMessage).withHeaders((StringLiterals.BAT, request.bat)))
      }
    }
  }

  def deleteConsultant(companyId : Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => consultantService.delete(id,companyId).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }

}

package controllers

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import config.ScalaHelpers._
import consts.Roles
import controllers.validators.CategoryValidator
import javax.inject._
import services.CategoryService
import play.api.libs.json._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
@Singleton
class CategoryController @Inject()(categoryService: CategoryService,
                                     authService : AuthService,
                                     authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents)
  extends BaseController(authService, authInfoExtractorDb,controllerComponent) with CategoryValidator {

  
  def searchCategories(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      val categoryName = request.getQueryString("name").toOptionString
      val categoryType = request.getQueryString("categoryType").toOptionString
      val adminCategories = request.getQueryString("adminCategories").toOptionBoolean
      val categories = categoryService.searchCategories(companyId,categoryType,categoryName,adminCategories.getOrElse(true))

      categories.map(c => c match {
        case Right(searched) => Ok(Json.toJson(searched.map(_.toJson))).withBat(request.bat)
        case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
      })
    }
  }


  def saveCategory(companyId:Int) = AuthenticateWithCompany(companyId).async {
    request => {
      validatedInput(request.body.asJson) match {
        case Right(input) => {
          val res = categoryService.saveCategory(input.copy(companyId = Some(companyId)))
          res.map(categoryId => categoryId match {
            case Right(id) => Ok(Json.toJson(id.toJson)).withBat(request.bat)
            case Left(e)    => InternalServerError(e.errorMessage).withBat(request.bat)
            })
          }
        case Left(error) => Future(BadRequest(error.errorMessage))
      }
    }
  }

  def deleteCategory(companyId:Int,id: Int) = AuthenticateWithCompany(companyId,List(Roles.ADMIN)).async {
    request => categoryService.delete(companyId,id).map(updateRes => updateRes match {
        case Right(_) =>NoContent.withBat(request.bat)
        case Left(e) => InternalServerError(e.errorMessage)
      })
  }
}

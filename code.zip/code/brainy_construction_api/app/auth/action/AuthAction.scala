package auth.action

import auth.db.{AuthInfoExtractorDb, RoleNameOrgIdFeatureNameCompaniesId}
import auth.services.AuthService
import consts.Roles
import play.api.http.HeaderNames
import play.api.libs.Files.TemporaryFile
import play.api.mvc._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{ExecutionContext, Future}

// A custom request type to hold our JWT claims, we can pass these to handling action
case class UserRequest[A](request: Request[A], bat: String = "", orgId: Int, loginId: Int, userId: Int,roles:List[String],feature:String) extends WrappedRequest[A](request)

trait Authorization {
  def authService : AuthService
  def authInfoExtractorDb: AuthInfoExtractorDb
  val defaultRoles = List(Roles.ADMIN,Roles.ACCOUNTANT,Roles.CHIEF_ACCOUNTANT)
  def cc: ControllerComponents

  def AuthenticateWithCompany(companyId:Int, roles: List[String] = defaultRoles) = new ActionBuilder[UserRequest,AnyContent] {
    override protected def executionContext: ExecutionContext = cc.executionContext
    override def parser: BodyParser[AnyContent] = cc.parsers.defaultBodyParser
    // Called when a request is invoked. Validate bearer token for request to proceed
    override def invokeBlock[A](request: Request[A], block: UserRequest[A] => Future[Result]): Future[Result] =
      extractBearerToken(request) map { token =>
        authService.auth(token) match {
          case Some(batWithLoginToken) => { // token was valid - proceed!
            val authInfoO = getAuthInfo(batWithLoginToken.loginToken.loginId)
            authInfoO match {
              case Some(authInfo) if roles.intersect(authInfo.roleNames).nonEmpty &&
                authInfo.companiesId.contains(companyId)  => block(UserRequest(request, batWithLoginToken.bat, authInfo.orgId,
                                                                  batWithLoginToken.loginToken.loginId, authInfo.userId,authInfo.roleNames,authInfo.featureName))
              case _                                   => Future.successful(Results.Forbidden("You do not have enough access to perform this operation"))
            }
          }
          case None                                       => Future.successful(Results.Unauthorized)  // token was invalid - return 401
        }
      } getOrElse Future.successful(Results.NotFound)   // no token was sent - return 404
  }

  def AuthenticateFileRequestWithCompany(companyId:Int, roles: List[String] = defaultRoles) = new ActionBuilder[UserRequest,MultipartFormData[TemporaryFile]] {
    override protected def executionContext: ExecutionContext = cc.executionContext
    override def parser: BodyParser[MultipartFormData[TemporaryFile]] = cc.parsers.multipartFormData
    // Called when a request is invoked. Validate bearer token for request to proceed
    override def invokeBlock[A](request: Request[A], block: UserRequest[A] => Future[Result]): Future[Result] =
      extractBearerToken(request) map { token =>
        authService.auth(token) match {
          case Some(batWithLoginToken) => { // token was valid - proceed!
            val authInfoO = getAuthInfo(batWithLoginToken.loginToken.loginId)
            authInfoO match {
              case Some(authInfo) if roles.intersect(authInfo.roleNames).nonEmpty &&
                authInfo.companiesId.contains(companyId)  => block(UserRequest(request, batWithLoginToken.bat, authInfo.orgId,
                batWithLoginToken.loginToken.loginId, authInfo.userId,authInfo.roleNames,authInfo.featureName))
              case _                                   => Future.successful(Results.Forbidden("You do not have enough access to perform this operation"))
            }
          }
          case None                                       => Future.successful(Results.Unauthorized)  // token was invalid - return 401
        }
      } getOrElse Future.successful(Results.NotFound)   // no token was sent - return 404
  }

  def Authenticate(roles: List[String] = defaultRoles) = new ActionBuilder[UserRequest,AnyContent] {
    override protected def executionContext: ExecutionContext = cc.executionContext
    override def parser: BodyParser[AnyContent] = cc.parsers.defaultBodyParser
    // Called when a request is invoked. Validate bearer token for request to proceed
    override def invokeBlock[A](request: Request[A], block: UserRequest[A] => Future[Result]): Future[Result] =
      extractBearerToken(request) map { token =>
        authService.auth(token) match {
          case Some(batWithLoginToken) => { // token was valid - proceed!
            val authInfoO = getAuthInfo(batWithLoginToken.loginToken.loginId)
            authInfoO match {
              case Some(authInfo) if roles.intersect(authInfo.roleNames).nonEmpty
                                => block(UserRequest(request,batWithLoginToken.bat, authInfo.orgId, batWithLoginToken.loginToken.loginId,
                authInfo.userId,authInfo.roleNames,authInfo.featureName))
              case _         => Future.successful(Results.Forbidden("You do not have enough access to perform this operation"))  // token was invalid - return 401
            }
          }
          case None                                       => Future.successful(Results.Unauthorized)  // token was invalid - return 401
        }
      } getOrElse Future.successful(Results.NotFound)   // no token was sent - return 404
  }

  private def getAuthInfo(loginId: Int): Option[RoleNameOrgIdFeatureNameCompaniesId] =
      authInfoExtractorDb.getRoleNameOrgIdByLoginId(loginId)

  private def extractBearerToken[A](request: Request[A]): Option[String] =
    request.headers.get(HeaderNames.AUTHORIZATION)
}

package auth.services

import java.util.Date
import java.util.UUID.randomUUID

import auth.db._
import auth.util.{LoginFailure, LoginSuccess, TokenExpired}
import javax.inject._
import config.{AppConstants, DateHelperDeprecated}
import consts.Roles
import model._
import model.company.Company
import model.request.AdminSignUpRequest
import org.slf4j.LoggerFactory
import play.api.Configuration
import services.db.CompanyDbUpdator

import scala.concurrent.Await
import scala.util.Try

case class BatWithLoginToken(bat: String, loginToken: LoginToken)
class AuthService @Inject()(cnf: Configuration, jwtService: JWTService, userDb: UserDb, loginDb: LoginDb, orgDb: OrgDb, loginTokenDb: LoginTokenDb, roleDb: RoleDb, companyDbUpdater: CompanyDbUpdator) {

  private val logger = LoggerFactory.getLogger(this.getClass)

  def getUUID = {
    randomUUID().toString
  }

  def login(userName: String, password: String) : Option[String] = {
    (for {
      loginId <- loginDb.validateAndGetLoginId(userName, password)
    } yield {
      val currentDate = new Date()
      val token = getUUID
      val loginToken = LoginToken(loginId, token, currentDate)
      loginTokenDb.create(loginToken)
      jwtService.createTokenForLogin(loginToken)
    }).flatten
  }

  def auth(bat: String): Option[BatWithLoginToken] = {
    jwtService.verify(bat) match {
      case LoginSuccess =>
        jwtService.decode(bat).map(BatWithLoginToken(bat, _))
      case TokenExpired =>
        jwtService.decode(bat).flatMap(loginToken => {
          val tokenUpdationTime = loginToken.updateTimestamp
          val expiryDuration = cnf.getLong(AppConstants.UserLoginExpirationTimeInSecs).get * 1000
          if ((tokenUpdationTime.getTime + expiryDuration) > System.currentTimeMillis() && loginTokenDb.exists(loginToken.loginId, loginToken.token)){
            // token not expired yet so update the update date
            val date = new Date()
            loginTokenDb.updateTimestamp(loginToken.loginId, loginToken.token, date)
            val newLoginToken = LoginToken(loginToken.loginId, loginToken.token, date)
            val newBat = jwtService.createTokenForLogin(newLoginToken)
            newBat.map(BatWithLoginToken(_, newLoginToken))
          } else {
            // token is expired. delete old token. new login is required
            loginTokenDb.deleteTokenByTokenAndLoginId(loginToken.loginId, loginToken.token)
            None
          }
        })
      case LoginFailure => {
        // needs login again
        None
      }
    }
  }

  def adminSingUp(adminSignUpRequest: AdminSignUpRequest) = {

    Try(
        (
          for {
            roleId <- roleDb.getRoleIdByName(Roles.ADMIN)
            orgId <- orgDb.getOrgIdByName(adminSignUpRequest.org)
          } yield {
            val userId = userDb.create(adminSignUpRequest.name, adminSignUpRequest.mobileNumber, adminSignUpRequest.emailId.getOrElse(""))
            //@TODO decide if date should be inside sql for all dates
            val currentDate = DateHelperDeprecated.nowSqlTimeStamp
            val login = Login(1, userId, orgId, adminSignUpRequest.userName, "", currentDate, currentDate, DateHelperDeprecated.endOfTimeSqlTimeStamp)
            val loginId = loginDb.createAndGetLoginId(login)
            val companyId = orgDb.createFirstCompany(adminSignUpRequest,orgId)
            roleDb.createRoleLoginCompanyMapping(roleId, loginId, companyId)
          }
        )
    ).toEither
  }

  def setPassword(userName: String, password: String): Option[String] = {
    if (loginDb.setPassword(userName, password)) {
      login(userName, password)
    } else {
      None
    }
  }

  def resetPassword(orgId:Int,userId:Int) = loginDb.resetPassword(orgId,userId)

  def deActivateUser(orgId:Int,userId: Option[Int]) = loginDb.deActivateUser(orgId,userId)

  def activateUser(orgId:Int,userId: Option[Int],activeTill : Option[String] = None) =
    loginDb.activateUser(orgId,userId,activeTill)
}

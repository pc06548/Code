package auth.services

import java.util.Date

import auth.util.{LoginFailure, LoginSuccess, TokenExpired}
import com.auth0.jwt.JWT
import com.auth0.jwt.algorithms.Algorithm
import com.auth0.jwt.exceptions.TokenExpiredException
import javax.inject._
import config.AppConstants
import model.LoginToken
import org.slf4j.LoggerFactory
import play.api.Configuration

import scala.util._


class JWTService @Inject()(cnf: Configuration) {

  private val logger = LoggerFactory.getLogger(this.getClass)
  def createTokenForLogin(login: LoginToken): Option[String] = {
    Try {
      val expiryDuration = cnf.getLong(AppConstants.LoginTokenExpirationTimeInSecs).get * 1000
      JWT.create().withIssuer("auth0")
        .withClaim("loginId", login.loginId.toString)
        .withClaim("token", login.token)
        .withClaim("updateTimestamp", login.updateTimestamp)
        .withExpiresAt(new Date(System.currentTimeMillis() + expiryDuration))
        .sign(Algorithm.HMAC256(AppConstants.JwtSecretKey))
    } match {
      case Success(value) => Some(value)
      case Failure(ex) =>
        logger.error(s"Error creating jwt token with exception: ${ex.getMessage}")
        None
    }
  }

  def verify(token: String) = {
     Try {
       val algorithm = Algorithm.HMAC256(AppConstants.JwtSecretKey)
       val verifier = JWT.require(algorithm).withIssuer("auth0").build()
       verifier.verify(token)
     } match {
       case Success(_) => LoginSuccess
       case Failure(_: TokenExpiredException) =>
         logger.info(s"Token expired: $token")
         TokenExpired
       case Failure(_) => LoginFailure
     }
  }

  def decode(token: String): Option[LoginToken] = {
    Try {
      val decodedJwt = JWT.decode(token)
      LoginToken(decodedJwt.getClaim("loginId").asString().toInt, decodedJwt.getClaim("token").asString(), decodedJwt.getClaim("updateTimestamp").asDate())
    } match {
      case Success(value)=> Some(value)
      case Failure(ex) =>
        //println(s"Error decoding jwt token. Exception: ${ex.getMessage}")
        logger.error(s"Error decoding jwt token. Exception: ${ex.getMessage}")
        None
    }
  }
}

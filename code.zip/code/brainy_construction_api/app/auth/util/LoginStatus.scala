package auth.util

sealed trait LoginStatus
case object LoginSuccess extends LoginStatus
case object TokenExpired extends LoginStatus
case object LoginFailure extends LoginStatus

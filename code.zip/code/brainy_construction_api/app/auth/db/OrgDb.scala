package auth.db

import javax.inject._
import config.{DateUtil, ResultSetIterator}
import model.Org
import model.request.AdminSignUpRequest
import services.db.DatabaseUpdatorService

class OrgDb @Inject()(databaseUpdatorService: DatabaseUpdatorService) {
  def createAndGetOrgId(org: Org) = {
      val query =
        s""" INSERT INTO ORG (NAME,LOGO, CREATE_TIMESTAMP, UPDATE_TIMESTAMP)
             |values ('${org.name}','${org.logo.getOrElse(null)}', '${org.createTimestamp}', '${org.updateTimestamp}')
        """.stripMargin
      databaseUpdatorService.runInsertAndReturnId(query)
  }

  def createFirstCompany(adminSignUpRequest: AdminSignUpRequest,orgId:Int): Int = {
    val query =
      s""" INSERT INTO COMPANY (name,address, phone_number1, last_modified,org_id,start_date,email,pan_number,gst_nbr)
         |values ('${adminSignUpRequest.companyName}','${adminSignUpRequest.companyAddress}',
         |'${adminSignUpRequest.companyNumber}', '${DateUtil.today}',$orgId, '${adminSignUpRequest.companyStartDate}',
         |'${adminSignUpRequest.companyEmail}','${adminSignUpRequest.companyPan}','${adminSignUpRequest.companyGstn}')
        """.stripMargin
    databaseUpdatorService.runInsertAndReturnId(query)
  }

  def getOrgIdByName(orgName: String): Option[Int] = {
    val query =
      s"""SELECT ID FROM ORG WHERE NAME = '${orgName}'""".stripMargin
    val rs = databaseUpdatorService.runSelectQuery(query)
    val rsi = new ResultSetIterator(rs)
    if (rsi.hasNext) {
      Some(rsi.next.getInt("ID"))
    } else {
      None
    }
  }

  def getOrgById(id: Int) = {
    val query =
      s"""SELECT * FROM ORG WHERE ID = ${id}""".stripMargin
    val rs = databaseUpdatorService.runSelectQuery(query)
    (new ResultSetIterator(rs)).map(r => {
      Org(
        Some(r.getInt("id")),
        r.getString("name"),
        Option(r.getString("logo")))
    }).toList.headOption
  }
}

package auth.db

import java.util.Date

import javax.inject._
import config.ResultSetIterator
import model.LoginToken
import services.db.DatabaseUpdatorService

class LoginTokenDb @Inject()(databaseUpdatorService: DatabaseUpdatorService) {
  def create(loginToken: LoginToken): Unit = {
      val query =
        s""" INSERT INTO LOGIN_TOKEN (LOGIN_ID, TOKEN, UPDATE_TIMESTAMP)
             |values (${loginToken.loginId}, '${loginToken.token}', '${loginToken.updateTimestamp.toString}')
        """.stripMargin
      //println(query)
      databaseUpdatorService.runInsertOrUpdate(query)
  }

  def insertOrUpdateToken(loginId: Int, newToken: String, oldToken: String) = {
    if (exists(loginId, oldToken)) {
      val query =
        s""" UPDATE LOGIN_TOKEN SET TOKEN = '${newToken}', UPDATE_TIMESTAMP = '${new Date().toString}'
           |WHERE TOKEN = '${oldToken}' and LOGIN_ID = ${loginId}
        """.stripMargin
      //println(query)
      databaseUpdatorService.runInsertOrUpdate(query)
    } else {
      val date = new Date()
      create(LoginToken(loginId, newToken, date))
    }
  }

  def updateTimestamp(loginId: Int, token: String, updateTimestamp: Date) = {
    //@TODO evaluate need of this
    val query =
      s""" UPDATE LOGIN_TOKEN SET UPDATE_TIMESTAMP = '${updateTimestamp.toString}'
         | WHERE TOKEN = '${token}' and LOGIN_ID = ${loginId}
       """.stripMargin
    //println(query)
    databaseUpdatorService.runInsertOrUpdate(query)
  }

  def exists(loginId: Int, token: String) = {
    val query =
      s""" SELECT * FROM LOGIN_TOKEN WHERE TOKEN = '${token}' and LOGIN_ID = ${loginId}
        """.stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    val rsi = new ResultSetIterator(rs)
    if (rsi.hasNext) {
      true
    } else {
      false
    }
  }

  def deleteTokenByTokenAndLoginId(loginId: Int, token: String) = {
    val query =
      s""" DELETE FROM LOGIN_TOKEN WHERE TOKEN = '${token}' and LOGIN_ID = ${loginId}
        """.stripMargin
    //println(query)
    databaseUpdatorService.runInsertOrUpdate(query)
  }
}

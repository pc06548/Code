package auth.db

import javax.inject._
import config.ResultSetIterator
import model.{GetRoleMapping, GetRoleMappingDetail, Role}
import org.slf4j.LoggerFactory
import services.db.DatabaseUpdatorService

class RoleDb @Inject()(databaseUpdatorService: DatabaseUpdatorService) {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def createAndGetRoleId(role: Role) = {
    val query =
      s""" INSERT INTO ROLE (NAME)
         |values ('${role.name}')
        """.stripMargin
    //println(query)
    databaseUpdatorService.runInsertAndReturnId(query)
  }

  def getRoles() = {
    val query =
      s""" SELECT * FROM ROLE
        """.stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    new ResultSetIterator(rs).map(r => {
      Role(r.getInt("ID"), r.getString("NAME"))
    }).toList
  }

  def getRoleIdByName(roleName: String): Option[Int] = {
    val query =
      s"""SELECT ID FROM ROLE WHERE NAME = '${roleName}'""".stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    val rsi = new ResultSetIterator(rs)
    if (rsi.hasNext) {
      Some(rsi.next.getInt("ID"))
    } else {
      None
    }
  }

  def createRoleLoginCompanyMapping(roleId: Int, loginId: Int, companyId: Int): Int = {
    val query =
      s"""INSERT INTO LOGIN_ROLE_MAPPING (ROLE_ID, LOGIN_ID, COMPANY_ID) VALUES ($roleId, $loginId, $companyId)""".stripMargin
    //println(query)
    databaseUpdatorService.runInsertAndReturnId(query)
  }

  def removeRoleLoginCompanyMapping(roleId: Int, loginId: Int, companyId: Int): Int = {
    val query =
      s"""DELETE FROM LOGIN_ROLE_MAPPING WHERE ROLE_ID=$roleId AND LOGIN_ID=$loginId AND COMPANY_ID=$companyId""".stripMargin
    //println(query)
    databaseUpdatorService.runInsertOrUpdate(query)
  }

  def getRemoveRoleLoginCompanyMappingQuery(companyId: Int): String = {

      s"""DELETE FROM LOGIN_ROLE_MAPPING WHERE COMPANY_ID=$companyId""".stripMargin
  }

  /**
    *
    * @param loginId : Required
    * @param companyIdO : If none it will give all companies role mapping
    * @return Roles and companies mappings
    */
  def getRoleMappings(loginId: Int, companyIdO: Option[Int]): List[GetRoleMapping] = {
    val companyWhereClause = companyIdO.map(companyId => s" AND rm.COMPANY_ID = $companyId ").getOrElse("")
    val query =
      s"""SELECT rm.ROLE_ID as ROLE_ID, r.NAME as ROLE_NAME, rm.COMPANY_ID as COMPANY_ID, c.NAME as COMPANY_NAME FROM LOGIN_ROLE_MAPPING as rm
         |INNER JOIN COMPANY AS c ON rm.COMPANY_ID = c.ID
         |INNER JOIN ROLE as r ON rm.ROLE_ID = r.ID
         |WHERE rm.LOGIN_ID = $loginId $companyWhereClause""".stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    new ResultSetIterator(rs).map(r => {
      GetRoleMapping(
        r.getInt("ROLE_ID"),
        r.getString("ROLE_NAME"),
        r.getInt("COMPANY_ID"),
        r.getString("COMPANY_NAME"))
    })toList
  }


  /**
    * @param companyId : If none it will give all companies role mapping
    * @return Roles and companies mappings
    */
  def getRoleMappingsByCompanyId(companyId: Int): List[GetRoleMappingDetail] = {
    val companyWhereClause = s" rm.COMPANY_ID = $companyId "
    val query =
      s"""SELECT rm.ROLE_ID as ROLE_ID, r.NAME as ROLE_NAME, rm.COMPANY_ID as COMPANY_ID, c.NAME as COMPANY_NAME, l.USER_NAME as USER_NAME, l.USER_ID as USER_ID, l.ID as LOGIN_ID FROM LOGIN_ROLE_MAPPING as rm
         |INNER JOIN COMPANY AS c ON rm.COMPANY_ID = c.ID
         |INNER JOIN ROLE as r ON rm.ROLE_ID = r.ID
         |INNER JOIN LOGIN as l ON rm.login_id = l.id
         |WHERE $companyWhereClause""".stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    new ResultSetIterator(rs).map(r => {
      GetRoleMappingDetail(
        r.getInt("ROLE_ID"),
        r.getString("ROLE_NAME"),
        r.getInt("COMPANY_ID"),
        r.getString("COMPANY_NAME"),
        r.getString("USER_NAME"),
        r.getInt("USER_ID"),
        r.getInt("LOGIN_ID"))
    })toList
  }

  /**
    * @param orgId : If none it will give all companies role mapping
    * @return Roles and companies mappings
    */
  def getRoleMappingsByOrgId(orgId: Int): List[GetRoleMappingDetail] = {
    val orgIdClause = s" c.ORG_ID = $orgId "
    val query =
      s"""SELECT rm.ROLE_ID as ROLE_ID, r.NAME as ROLE_NAME, rm.COMPANY_ID as COMPANY_ID, c.NAME as COMPANY_NAME, l.USER_NAME as USER_NAME, l.USER_ID as USER_ID, l.ID as LOGIN_ID FROM LOGIN_ROLE_MAPPING as rm
         |INNER JOIN COMPANY AS c ON rm.COMPANY_ID = c.ID
         |INNER JOIN ROLE as r ON rm.ROLE_ID = r.ID
         |INNER JOIN LOGIN as l ON rm.login_id = l.id
         |WHERE $orgIdClause""".stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    new ResultSetIterator(rs).map(r => {
      GetRoleMappingDetail(
        r.getInt("ROLE_ID"),
        r.getString("ROLE_NAME"),
        r.getInt("COMPANY_ID"),
        r.getString("COMPANY_NAME"),
        r.getString("USER_NAME"),
        r.getInt("USER_ID"),
        r.getInt("LOGIN_ID"))
    })toList
  }

}

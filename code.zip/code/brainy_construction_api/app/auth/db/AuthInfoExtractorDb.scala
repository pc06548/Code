package auth.db

import javax.inject._
import config.ResultSetIterator
import org.slf4j.LoggerFactory
import services.db.DatabaseUpdatorService

case class RoleNameOrgIdFeatureNameCompaniesId(orgId: Int, roleNames: List[String], featureName: String, companiesId: List[Int], userId: Int)

case class AuthRole(orgId: Int, roleName: String, featureName: String, companyId: Int, userId: Int)

class AuthInfoExtractorDb @Inject()(databaseUpdatorService: DatabaseUpdatorService) {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def getRoleNameOrgIdByLoginId(loginId: Int) = {

    val query =
      s"""
         |SELECT l.ORG_ID as ORG_ID, r.NAME as ROLE_NAME, f.NAME as FEATURE_NAME, rm.company_id as COMPANY_ID,
         |l.USER_ID as USER_ID FROM LOGIN_ROLE_MAPPING AS rm
         |INNER JOIN ROLE AS r ON rm.ROLE_ID = r.ID
         |INNER JOIN LOGIN as l ON l.ID = rm.LOGIN_ID
         |INNER JOIN ORG_FEATURE_MAPPING as fm ON fm.ORG_ID = l.ORG_ID
         |INNER JOIN FEATURE as f ON f.ID = fm.FEATURE_ID
         |WHERE rm.LOGIN_ID = ${loginId} and l.active_until >= current_timestamp""".stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    val rsi = new ResultSetIterator(rs)
    val authRoles =  rsi.map(i => {
      AuthRole(i.getInt("ORG_ID"),
      i.getString("ROLE_NAME"),
      i.getString("FEATURE_NAME"),
      i.getInt("COMPANY_ID"),
      i.getInt("USER_ID"))
    }).toList
    authRoles match {
      case _ if authRoles.isEmpty => None
      case roles => Some(
        RoleNameOrgIdFeatureNameCompaniesId(
          roles.head.orgId,
          ("USER" +: (roles.map(_.roleName))).distinct,
          roles.head.featureName,
          roles.map(_.companyId).distinct,
          roles.head.userId
        )
      )
    }
  }

}

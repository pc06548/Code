package auth.db

import javax.inject._
import config.ResultSetIterator
import model.Login
import org.slf4j.LoggerFactory
import services.db.DatabaseUpdatorService

class LoginDb @Inject()(databaseUpdatorService: DatabaseUpdatorService) {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def createAndGetLoginId(login: Login) = {
      val query =
        s""" INSERT INTO LOGIN (USER_ID, ORG_ID, USER_NAME, CREATE_TIMESTAMP, UPDATE_TIMESTAMP, ACTIVE_UNTIL)
             |values (${login.userId}, ${login.orgId}, '${login.userName}',
             |'${login.createTimestamp}', '${login.updateTimestamp}', '${login.activeUntil}')
        """.stripMargin
      //println(query)
      databaseUpdatorService.runInsertAndReturnId(query)
  }

  /*
  TODO need to consider time logic for set password in some time
  * */
  def setPassword(userName: String, password: String) = {
    val query = s""" UPDATE LOGIN SET PASSWORD='$password' WHERE USER_NAME = '$userName' AND PASSWORD IS NULL""".stripMargin
    //println(query)
    val updateCount = databaseUpdatorService.runInsertOrUpdate(query)
    updateCount == 1
  }

  def resetPassword(orgId:Int,userId: Int) = {
    val query = s""" UPDATE LOGIN SET PASSWORD = NULL WHERE USER_ID = $userId AND ORG_ID = ${orgId} """.stripMargin
    //println(query)
    val updateCount = databaseUpdatorService.runInsertOrUpdate(query)
    updateCount == 1
  }

  def deActivateUser(orgId:Int,userId: Option[Int]) = {
    val userIdFilter = userId.map(u => s"AND USER_ID = $u").getOrElse("")
    val query =
      s""" UPDATE LOGIN SET active_until = current_timestamp
         |WHERE ORG_ID = ${orgId} ${userIdFilter}""".stripMargin
    //println(query)
    databaseUpdatorService.runInsertOrUpdate(query)
  }

  def activateUser(orgId:Int,userId: Option[Int],activeTill : Option[String] = None) = {
    val userIdFilter = userId.map(u => s"AND USER_ID = $u").getOrElse("")
    val query =
      s""" UPDATE LOGIN SET active_until =  ${activeTill.getOrElse("'9999-01-01 00:00:00.000'")}
         |WHERE ORG_ID = ${orgId} ${userIdFilter}""".stripMargin
    //println(query)
    databaseUpdatorService.runInsertOrUpdate(query)
  }

  def validateAndGetLoginId(userName: String, password: String):Option[Int] = {
    val query =
      s""" SELECT ID FROM LOGIN WHERE USER_NAME = '$userName' AND PASSWORD = '$password' """
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    val rsi = new ResultSetIterator(rs)
    if (rsi.hasNext) {
      val n = rsi.next()
      Some(n.getInt("ID"))
    }
    else {
      None
    }
  }
}

package auth.db

import java.util.Date

import config.{DateHelperDeprecated, ResultSetIterator}
import javax.inject._
import model.User
import services.db.DatabaseUpdatorService

class UserDb @Inject()(databaseUpdatorService: DatabaseUpdatorService) {
  def create(name: String, mobileNumber: String, emailId: String = "")= {
    val date = DateHelperDeprecated.nowSqlDate
      val query =
        s""" INSERT INTO USERS (NAME, MOBILE_NUMBER, EMAIL_ID, CREATE_TIMESTAMP, UPDATE_TIMESTAMP)
             |VALUES ('${name}', '${mobileNumber}', '${emailId}', '${date}',
             |'${date}')
        """.stripMargin
      //println(query)
      databaseUpdatorService.runInsertAndReturnId(query)
  }

  def getUserIdByNameAndMobNumber(name: String, mobileNumber: String): Int = {
    val query =
      s"""SELECT ID FROM USERS WHERE NAME = '${name}' AND MOBILE_NUMBER = '${mobileNumber}'""".stripMargin
    //println(query)
    val resultSet = databaseUpdatorService.runSelectQuery(query)
    resultSet.getInt("ID")
  }

  def update(userId: Int, nameO: Option[String], mobileNumberO: Option[String], emailIdO: Option[String]) = {
    val emailIdClause = emailIdO.map(email => s"EMAIL_ID = '$email'").getOrElse("")
    val nameClause = nameO.map(name => s"NAME = '$name'").getOrElse("")
    val mobileNumberClause = mobileNumberO.map(mobileNumber => s"MOBILE_NUMBER = '$mobileNumber'").getOrElse("")
    val updateClause = List(emailIdClause, nameClause, mobileNumberClause).filter(_.nonEmpty).mkString(", ")
    if (updateClause.nonEmpty) {
      val query =
        s"""UPDATE USERS SET $updateClause , UPDATE_TIMESTAMP = '${(new Date()).toString}' WHERE ID = $userId""".stripMargin
      //println(query)
      databaseUpdatorService.runInsertOrUpdate(query)
    }
  }

  def getUsersByOrgId(orgId: Int,name:String): List[User] = {
    val query =
      s"""select u.id, u.name, u.mobile_number, u.email_id, u.create_timestamp, u.update_timestamp,
         |l.id as login_id, l.user_name,
         |CASE
         |    WHEN l.active_until >= current_timestamp THEN 'true'
         |    ELSE 'false'
         |END AS is_active
         |from users as u inner join login l on u.id = l.user_id inner join org o on l.org_id = o.id
         |where o.id = ${orgId} and u.name like '%${name}%' """.stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    new ResultSetIterator(rs).map(r => {
      User(
        r.getInt("id"),
        r.getString("name"),
        r.getString("mobile_number"),
        r.getString("email_id"),
        r.getDate("create_timestamp"),
        r.getDate("update_timestamp"),
        r.getInt("login_id"),
        Option(r.getString("user_name")),
        Option(r.getString("is_active"))
      )
    }) toList
  }

  def getUserByLoginId(loginId: Int): Either[Exception, Option[User]] = {
    val query =
      s"""select u.id, u.name, u.mobile_number, u.email_id, u.create_timestamp,
         |u.update_timestamp, l.user_name
         |from users as u inner join login l on u.id = l.user_id where l.id = ${loginId}""".stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    val result: Seq[User] = (new ResultSetIterator(rs)).map(r => {
      User(
        r.getInt("id"),
        r.getString("name"),
        r.getString("mobile_number"),
        r.getString("email_id"),
        r.getDate("create_timestamp"),
        r.getDate("update_timestamp"), loginId,
        Option(r.getString("user_name")))
    }).toList
    if(result.length > 1) {
      //println(s"Error: This should not happen. Multiple users for login id:$loginId")
      Left(new Exception("Multiple users for login id"))
    } else {
      Right(result.headOption)
    }
  }

  def getUserByUserId(userId: Int): Either[Exception, Option[User]] = {
    val query =
      s"""select u.id, u.name, u.mobile_number, u.email_id, u.create_timestamp, u.update_timestamp,
         |l.id as login_id,l.user_name,
         |CASE
         |    WHEN l.active_until >= current_timestamp THEN 'true'
         |    ELSE 'false'
         |END AS is_active
         |from users as u inner join login l on u.id = l.user_id where l.user_id = ${userId}""".stripMargin
    //println(query)
    val rs = databaseUpdatorService.runSelectQuery(query)
    val result: Seq[User] = (new ResultSetIterator(rs)).map(r => {
      User(
        r.getInt("id"),
        r.getString("name"),
        r.getString("mobile_number"),
        r.getString("email_id"),
        r.getDate("create_timestamp"),
        r.getDate("update_timestamp"),
        r.getInt("login_id"),
        Option(r.getString("user_name")),
        Option(r.getString("is_active"))
      )
    }).toList
    if(result.length > 1) {
      //println(s"Error: This should not happen. Multiple users for user id:$userId")
      Left(new Exception("Multiple users for login id"))
    } else {
      Right(result.headOption)
    }
  }
}

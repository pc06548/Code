package auth.controllers

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.AuthService
import config.AppConstants
import consts.{ErrorMessages, Roles}
import javax.inject.{Inject, Singleton}
import model.request.AdminSignUpRequest
import model.request.LoginRequest.LoginRequest
import play.api.mvc._
import controllers.BaseController
import play.api.libs.json.{JsLookupResult, JsValue}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try

@Singleton
class AuthController @Inject()(authService : AuthService,
                               authInfoExtractorDb: AuthInfoExtractorDb,controllerComponent: ControllerComponents) extends BaseController(authService, authInfoExtractorDb,controllerComponent) {


  def login = Action(parse.anyContent) {
    request:Request[AnyContent] => {
      (for {
        json <- request.body.asJson
        loginRequest <- LoginRequest.createFromJson(json)
      } yield {
        authService.login(loginRequest.userName, loginRequest.password) match {
          case Some(bat) => NoContent.withBat(bat)
          case None =>  Unauthorized(ErrorMessages.INCORRECT_USERNAME_PASSWORD_JSON)
        }
      }).getOrElse(BadRequest(ErrorMessages.BAD_REQUEST_PARAMS_JSON))
    }
  }

  def signUp = Action(parse.anyContent) {
    request:Request[AnyContent] => {
      (for {
        json <- request.body.asJson
        loginRequest <- LoginRequest.createFromJson(json)
      } yield {
        authService.setPassword(loginRequest.userName, loginRequest.password) match {
          case Some(bat) => NoContent.withBat(bat)
          case None =>
            NotFound(ErrorMessages.RESOURCE_NOT_FOUND_JSON)
        }
      }).getOrElse(BadRequest(ErrorMessages.BAD_REQUEST_PARAMS_JSON))
    }
  }

  def adminSignUp = Action(parse.anyContent) {
    request:Request[AnyContent] => {
      (for {
        json <- request.body.asJson
        adminSignUpRequest <- AdminSignUpRequest.createFromJson(json)
      } yield {
        if(adminSignUpRequest.secret == AppConstants.superAdminSecret){
          authService.adminSingUp(adminSignUpRequest) match {
            case Right(_) => Ok(s"""{"message":"Admin for UserName:${adminSignUpRequest.userName} is created"}""")
            case Left(e) => InternalServerError(e.getMessage)
          }
        }else
          NotFound
      }).getOrElse(BadRequest(ErrorMessages.BAD_REQUEST_PARAMS_JSON))
    }
  }

  def resetPassword(userId:Int) = Authenticate(List(Roles.ADMIN)).async{
    authRequest => {
      if(userId != authRequest.userId){
        Future(authService.resetPassword(authRequest.orgId,userId)).map(_ => NoContent.withBat(authRequest.bat))
      }else{
        Future(BadRequest("Cannot reset password for self").withBat(authRequest.bat))
      }

    }
  }

  def deActivateUser(userId:Int) = Authenticate(List(Roles.ADMIN)).async{

    authRequest => {
      if(userId != authRequest.userId){
        Future(authService.deActivateUser(authRequest.orgId,Some(userId))).map(_ => NoContent.withBat(authRequest.bat))
      }else{
        Future(BadRequest("Cannot Activate user for self").withBat(authRequest.bat))
      }
    }
  }

  def deActivateUsers(orgId:Int) = Action(parse.anyContent) {
    request => {
      val secretKey:String = Try(request.body.asJson.map(b => (b \ "secret").as[String])).toOption.flatten.getOrElse("")
      if(!(secretKey == AppConstants.superAdminSecret)){
        NotFound(ErrorMessages.RESOURCE_NOT_FOUND_JSON)
      }else {
        Ok(s"Deactivated users : ${authService.deActivateUser(orgId, None)}")
      }
    }
  }

  def activateUser(userId:Int) = Authenticate(List(Roles.ADMIN)).async{
    authRequest => {
      if(userId != authRequest.userId){
        Future(authService.activateUser(authRequest.orgId,Some(userId))).map(_ => NoContent.withBat(authRequest.bat))
      }else{
        Future(BadRequest("Cannot activate user for self").withBat(authRequest.bat))
      }
    }
  }

  def activateUsers(orgId:Int) = Action(parse.anyContent) {
    request => {
      val secretKey:String = Try(request.body.asJson.map(b => (b \ "secret").as[String])).toOption.flatten.getOrElse("")
      if(!(secretKey == AppConstants.superAdminSecret)){
        NotFound(ErrorMessages.RESOURCE_NOT_FOUND_JSON)
      }else {
        Ok(s"Activated users : ${authService.activateUser(orgId, None)}")
      }
    }
  }

}

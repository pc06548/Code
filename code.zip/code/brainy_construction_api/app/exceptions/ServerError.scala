package exceptions

import org.slf4j.LoggerFactory
import play.api.libs.json.JsValue
import config.ScalaHelpers._


sealed trait ServerError extends Throwable{
  def errorMessage(): JsValue = ErrorMessage("Something went wrong","").toJson
}

case class IDGenerationFailed() extends ServerError {
  override def errorMessage(): JsValue = ErrorMessage("Automatic ID generation failed","").toJson
}

case class LocationDidNotMatch() extends ServerError {
  override def errorMessage(): JsValue = ErrorMessage("Attendance cannot be marked as you are not at one of the office locations","").toJson
}

case class PlanLimitReached() extends ServerError {
  override def errorMessage(): JsValue = ErrorMessage("You have reached limit of your plan. Please upgrade", "").toJson
}

case class NoDueCertificateCannotBeCreated(agreementCost:Double,amountPaid:Double) extends ServerError {
  override def errorMessage(): JsValue = {
    if(agreementCost == 0 && amountPaid == 0){
      ErrorMessage(s"No due certificate cannot be created,No receipts found", "").toJson
    }else{
      ErrorMessage(s"No due certificate cannot be created, " +
        s"Agreement cost is ${agreementCost.round} but total amount Paid is ${amountPaid.round} ", "").toJson
    }

  }
}

case class RuntimeException(e: Throwable) extends ServerError {
  override def errorMessage(): JsValue =
    {
      (e.getMessage match {
        case m if m.contains("duplicate key value violates unique constraint") => {
          ErrorMessage("Record already exists",e.getMessage)
        }
        case m if m.contains("0 rows updated") => {
          ErrorMessage("Update was unsuccessful, Please try again",e.getMessage)
        }
        case m if m.contains("""delete on table "payslips" violates foreign key constraint""") => {
          ErrorMessage("Payslip cannot be not deleted. Please delete corresponding voucher first",e.getMessage)
        }
        case m if m.contains("""delete on table "company" violates foreign key constraint""") => {
          ErrorMessage("Company cannot be deleted because its linked to invoice",e.getMessage)
        }
        case m if m.contains("""delete on table "customer" violates foreign key constraint""") => {
          ErrorMessage("Customer cannot be deleted because its linked to receipt",e.getMessage)
        }
        case m if m.contains("No such file or directory") => {
          ErrorMessage("Template File not found on server. Please contact support",e.getMessage)
        }
        case _ => ErrorMessage("Something went wrong",s"${e.getMessage}")
      }).toJson
    }
}
package exceptions

import config.DateUtil

sealed trait BadRequest{
  def errorMessage : String = "Bad Request"
}

case class NoJsonBodyFound() extends BadRequest {
  override def errorMessage: String = s"No JSON body found"
}
case class JsonParsingFailed(reason : String) extends BadRequest {
  override def errorMessage: String = s"Json parsing failed: $reason"
}
case class InvalidEmailAddress() extends BadRequest{
  override def errorMessage: String = "Email Address Invalid"
}

case class InvalidContactNumber() extends BadRequest{
  override def errorMessage: String = "Contact number is invalid"
}
case class InvalidPanNumber() extends BadRequest{
  override def errorMessage: String = "PAN is invalid"
}
case class InvalidAadharNumber() extends BadRequest{
  override def errorMessage: String = "Aadhar is invalid"
}
case class FieldCannotBeEmpty(fieldName:String) extends BadRequest{
  override def errorMessage: String = s"${fieldName} cannot be empty"
}
case class FieldCannotBeZero(fieldName:String) extends BadRequest{
  override def errorMessage: String = s"${fieldName} cannot be 0"
}

case class BadDateFormat(field:String) extends BadRequest{
  override def errorMessage: String = s"Invalid date format ${field}. Correct format is ${DateUtil.dateFormatString}"
}
case class BadMonthFormat(field:String) extends BadRequest{
  override def errorMessage: String = s"Invalid month format ${field}. Correct format is ${DateUtil.monthFormatString}"
}
case class BadFYearFormat(field:String) extends BadRequest{
  override def errorMessage: String = s"Invalid financial year format ${field}. Correct format is ${DateUtil.fYearFormatString} with one year difference"
}
case class BadVoucherNumberFormat() extends BadRequest{
  override def errorMessage: String = s"Invalid voucher number format. Correct format is Company_abbreviation-voucher_number/financial year in YYYY-YY"
}
case class BadReceiptNumberFormat() extends BadRequest{
  override def errorMessage: String = s"Invalid receipt number format. Correct format is Company_abbreviation-receipt_number/financial year in YYYY-YY"
}

case class EmployeeIdMonthMissing() extends BadRequest{
  override def errorMessage: String = s"EmployeeId or month with correct format (MMMM-YYYY) is mandatory to generate payslip"
}
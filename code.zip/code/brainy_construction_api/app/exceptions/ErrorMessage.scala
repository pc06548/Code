package exceptions

import play.api.libs.json.{JsValue, Json}

case class ErrorMessage(displayMessage:String,exceptionMessage:String){
  implicit val implicitCompanyWrites = Json.writes[ErrorMessage]
  def toJson: JsValue = Json.toJson(this)
}

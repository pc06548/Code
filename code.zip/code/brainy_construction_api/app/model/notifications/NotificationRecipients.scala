package model.notifications

import slick.jdbc.GetResult

case class NotificationRecipients(userId:Int,
                                  roleName:String,
                                  token:String
                               ){
}

object NotificationRecipients {
  implicit val getInvoiceSearchResult = GetResult(r =>
    NotificationRecipients(r.nextInt(), r.nextString, r.nextString)
  )
}
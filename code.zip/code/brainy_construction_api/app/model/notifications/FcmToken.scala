package model.notifications

import play.api.libs.json.{JsValue, Json}

case class FcmToken(userId:Option[Int],
                    deviceId:String,
                    token:String,
                    lastModified:Option[String],
                    status:Option[String]){
  private implicit val implicitFcmTokenWrites = Json.writes[FcmToken]

  def toJson: JsValue = Json.toJson(this)
}

object FcmToken {
  private implicit val implicitFcmTokenReads = Json.reads[FcmToken]

  def createFromJson(fcmTokenJson: JsValue): FcmToken = fcmTokenJson.as[FcmToken]

  val ServerKey = "AAAAZlkjpGY:APA91bGebijdYVOz-sfJZJ60FR6UgAFdPNl2nJjyHoXawt3CmrqlgFxtvgXt7imqjJNtnDKRvKvoXNnbGRELcss1HrqxXQ-VwXP7_4aViKOV4qo0mhoompZ3dWd8w0W4RpKTvUlTzkNp"
}
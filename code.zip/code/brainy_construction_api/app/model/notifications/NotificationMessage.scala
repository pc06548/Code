package model.notifications

import play.api.libs.json.{JsValue, Json}

case class Notification(title:String,body:String)
case class NotificationMessage(
                         token:String,
                         notification:Notification,
                         data:Map[String,String]
                         )

case class FCMMessage(message:NotificationMessage){

  implicit val implicitNotificationWrites = Json.writes[Notification]
  implicit val implicitNotificationMessageWrites = Json.writes[NotificationMessage]
  implicit val implicitFCMMessageWrites = Json.writes[FCMMessage]
  def toJson: JsValue = Json.toJson(this)
}
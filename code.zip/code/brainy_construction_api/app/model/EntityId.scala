package model

import play.api.libs.json.{JsValue, Json}

case class EntityId(id: Int) {
  implicit val implicitEntityIdWrites = Json.writes[EntityId]
  def toJson: JsValue = Json.toJson(this)
}

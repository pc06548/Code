package model

import java.sql.Date

import play.api.libs.json.{JsValue, Json}

case class Org(id: Option[Int], name: String,logo:Option[String] = None,
               createTimestamp: Option[Date] = None, updateTimestamp: Option[Date] = None){
  implicit val implicitCompanyWrites = Json.writes[Org]
  def toJson: JsValue = Json.toJson(this)
}

package model.request

import play.api.libs.json.{JsValue, Json}

import scala.util.Try

case class AdminSignUpRequest(name: String, mobileNumber: String, emailId: Option[String], org: String,
                              userName: String, companyName: String,
                              companyAddress:String,companyNumber:String,companyStartDate:String,
                              companyEmail:String,companyPan:String,companyGstn:String,
                              secret:String)

object AdminSignUpRequest {
  private implicit val implicitLoginRequestReads = Json.reads[AdminSignUpRequest]

  def createFromJson(json: JsValue): Option[AdminSignUpRequest] = {
    Try(Some(json.as[AdminSignUpRequest])).getOrElse(None)
  }
}
package model.request.LoginRequest

import play.api.libs.json.{JsValue, Json}

import scala.util.Try

case class LoginRequest(userName: String, password: String)

object LoginRequest {
    private implicit val implicitLoginRequestReads = Json.reads[LoginRequest]

    def createFromJson(json: JsValue): Option[LoginRequest] = Try(Some(json.as[LoginRequest])).getOrElse(None)
}
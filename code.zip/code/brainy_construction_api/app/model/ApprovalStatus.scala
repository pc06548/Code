package model

object ApprovalStatus {

  val APPROVAL_PENDING = "APPROVAL_PENDING"
  val APPROVED = "APPROVED"
}

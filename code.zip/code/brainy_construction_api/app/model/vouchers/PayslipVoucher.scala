package model.vouchers

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class PayslipVoucher(id: Int,
                   voucherNumber: String,
                   reason: String,
                   totalAmount: Double,
                   voucherDate: String,
                   remark: Option[String],
                   paymentDetails: VoucherPaymentDetails,
                   payslipDetails: PayslipDetails){

  private implicit val implicitVoucherPaymentDetailsWrites = Json.writes[VoucherPaymentDetails]
  private implicit val implicitInvoiceDetailsWrites = Json.writes[PayslipDetails]
  private implicit val implicitVoucherWrites = Json.writes[PayslipVoucher]

  def toJson: JsValue = Json.toJson(this)
}

case class PayslipDetails(payslipId : Int, month: String, employeeName: String, amount:Double, employeeId: Int)

object PayslipVoucher {
  implicit val getVoucherResult = GetResult(r =>
    PayslipVoucher(r.nextInt(), r.nextString, r.nextString,
      r.nextDouble(),r.nextString(),Some(Option(r.nextString()).getOrElse("")),
      VoucherPaymentDetails(Option(r.nextString()).getOrElse(""),Option(r.nextString()).getOrElse(""), Option(r.nextString()).getOrElse(""),Option(r.nextString()).getOrElse("")),
      PayslipDetails(r.nextInt(), r.nextString, r.nextString,r.nextDouble(),r.nextInt()))
  )
}
package model.vouchers

import play.api.libs.json.{JsValue, Json}

case class SavePayslipVoucher(id: Option[Int],
                              voucherNumber: String,
                              reason: String,
                              payslipId:Int,
                              totalAmount: Double,
                              paymentRefNumber: Option[String],
                              accountNumber: Option[String],
                              paymentDate : Option[String],
                              mode: String,
                              voucherDate: String,
                              remark: Option[String]
                            ) {
  private implicit val implicitPayslipVoucherWrites = Json.writes[SavePayslipVoucher]

  def toJson: JsValue = Json.toJson(this)
}

object SavePayslipVoucher {
  private implicit val implicitPayslipVoucherReads = Json.reads[SavePayslipVoucher]

  def createFromJson(voucherJson: JsValue): Seq[SavePayslipVoucher] = voucherJson.as[Seq[SavePayslipVoucher]]
}
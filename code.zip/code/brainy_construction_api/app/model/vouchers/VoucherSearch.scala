package model.vouchers

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class VoucherSearch(id: Int, voucherNumber: String, name: String,
                         reason: String, invoiceNumber: String,
                         totalAmount: Double,
                         voucherDate: String,
                         category:String,
                         isTemporary:Boolean) {
  private implicit val implicitVoucherWrites = Json.writes[VoucherSearch]

  def toJson: JsValue = Json.toJson(this)
}

object VoucherSearch {
  implicit val getInvoiceSearchResult = GetResult(r =>
    VoucherSearch(r.nextInt(), r.nextString, r.nextString,r.nextString,r.nextString,
      r.nextDouble(),r.nextString(),r.nextString(),r.nextBoolean())
  )
}
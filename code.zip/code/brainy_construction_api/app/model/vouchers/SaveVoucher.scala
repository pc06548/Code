package model.vouchers

import play.api.libs.json.{JsValue, Json}

case class SaveVoucher(id: Option[Int],
                       companyId:Option[Int],
                       voucherNumber: String,
                       reason: String,
                       invoiceId:Int,
                       amountBeforTax: Double,
                       cgst : Double,
                       sgst : Double,
                       amountAfterTax: Double,
                       tds: Double,
                       totalAmount: Double,
                       paymentRefNumber: Option[String],
                       accountNumber: Option[String],
                       paymentDate : String,
                       mode: String,
                       voucherDate: String,
                       remark: Option[String],
                       lastModified:Option[String] = None
                            ) {
  private implicit val implicitContractorVoucherWrites = Json.writes[SaveVoucher]

  def toJson: JsValue = Json.toJson(this)
}

object SaveVoucher {
  private implicit val implicitContractorVoucherReads = Json.reads[SaveVoucher]

  def createFromJson(voucherJson: JsValue): SaveVoucher = voucherJson.as[SaveVoucher]
}
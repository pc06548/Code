package model.vouchers

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class Voucher(projectName:String,
                    id: Int,
                   voucherNumber: String,
                   reason: String,
                   amountBeforeTax: Double,
                   cgst : Double,
                   sgst : Double,
                   amountAfterTax: Double,
                   tds: Double,
                   tdsPercentage: Option[Int],
                   totalAmount: Double,
                   voucherDate: String,
                   remark: Option[String],
                   category: String,
                   paymentDetails: VoucherPaymentDetails,
                   invoiceDetails: InvoiceDetails){

  implicit val implicitVoucherPaymentDetailsWrites = Json.writes[VoucherPaymentDetails]
  implicit val implicitInvoiceDetailsWrites = Json.writes[InvoiceDetails]
  implicit val implicitVoucherWrites = Json.writes[Voucher]

  def toJson: JsValue = Json.toJson(this)
}


case class VoucherPaymentDetails(referenceNumber: String,accountNumber:String, paymentDate: String, mode: String)

case class InvoiceDetails(invoiceId : Int, invoiceNumber: String, name: String,isTemporary:Boolean)

object Voucher {
  implicit val implicitVoucherPaymentDetailsWrites = Json.writes[VoucherPaymentDetails]
  implicit val implicitInvoiceDetailsWrites = Json.writes[InvoiceDetails]
  implicit val implicitVoucherWrites = Json.writes[Voucher]

  implicit val getVoucherResult = GetResult(r => {
      val voucherFromDb = Voucher(r.nextStringOption().getOrElse("Office"),r.nextInt(), r.nextString, r.nextString,
        r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),None,r.nextDouble(),
        r.nextString(),Some(Option(r.nextString()).getOrElse("")),r.nextString(),
        VoucherPaymentDetails(Option(r.nextString()).getOrElse(""),Option(r.nextString()).getOrElse(""), Option(r.nextString()).getOrElse(""),Option(r.nextString()).getOrElse("")),
        InvoiceDetails(r.nextInt(), r.nextString, r.nextString,r.nextBoolean))
      voucherFromDb.copy(tdsPercentage = Some(calculateTdsPercentage(voucherFromDb.tds,voucherFromDb.amountAfterTax)))
    }
  )

  def calculateTdsPercentage(tds:Double,amountAfterTax:Double): Int = {
    ((100 * tds)/amountAfterTax).round.toInt
  }
}
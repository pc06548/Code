package model

import play.api.libs.json.{JsValue, Json}

case class CompanyConfig(companyId:Option[Int],
                          dueDateLimit:Int){
  private implicit val implicitCompanyConfigWrites = Json.writes[CompanyConfig]

  def toJson: JsValue = Json.toJson(this)
}

object CompanyConfig {
  val DEFAULT_DATE_LIMIT = 10
  private implicit val implicitCompanyConfigReads = Json.reads[CompanyConfig]

  def createFromJson(companyConfigJson: JsValue): CompanyConfig = companyConfigJson.as[CompanyConfig]

}
package model

import java.sql.ResultSet

import config.DateHelperDeprecated
import play.api.libs.json.{JsValue, Json, OWrites}
import slick.jdbc.GetResult

case class ExpenseSheet(id:Option[Int],
                        companyId: Int,
                        projectId: Option[Int],
                        employeeId: Option[Int],
                        startDate: String,
                        endDate: String,
                        openingBalance: Double,
                        closingBalance: Double,
                        lastModified:String,
                        transactions: List[Transaction] = List.empty[Transaction],
                        totalCreditedAmount: Option[Double] = None,
                        totalDebitedAmount: Option[Double] = None
                        ) {

  private implicit val implicitTransactionWrites: OWrites[Transaction] = Json.writes[Transaction]
  private implicit val implicitExpenseSheetWrites: OWrites[ExpenseSheet] = Json.writes[ExpenseSheet]

  def toJson: JsValue = Json.toJson(this)

  def calculateTotals():ExpenseSheet = {
    val totalCreditedAmount = this.transactions.filter(_.typeOfTransaction == "C").map(_.amount).sum
    val totalDebitedAmount = this.transactions.filter(_.typeOfTransaction == "D").map(_.amount).sum
    this.copy(totalCreditedAmount = Some(totalCreditedAmount),totalDebitedAmount = Some(totalDebitedAmount))
  }
}

object ExpenseSheet {
  implicit val getResult = GetResult(r =>
    ExpenseSheet(Some(r.nextInt()),r.nextInt(),r.nextIntOption() ,r.nextIntOption(),
      r.nextString,r.nextString,r.nextDouble(),r.nextDouble(),r.nextString())
  )

}

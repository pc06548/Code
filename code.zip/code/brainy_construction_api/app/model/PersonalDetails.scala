package model

case class PersonalDetails(email: String = "",address: String = "", primaryPhoneNumber: String = "",
                           secondaryPhoneNumber: String = "", pan: String = "", aadhar: String = "")
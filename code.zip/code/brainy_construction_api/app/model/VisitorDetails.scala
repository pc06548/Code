package model

import play.api.libs.json.{JsValue, Json, OWrites, Reads}
import slick.jdbc.GetResult

case class VisitorDetails(id: Option[Int],
                          companyId:Option[Int],
                          name: String,
                          email: Option[String],
                          address: Option[String],
                          phoneNumber: String,
                          visitingDate: String,
                          visitingTime: Option[String],
                          interestedInpromotion: Option[String],
                          typeOfProperty: Option[String],
                          budget: Option[String],
                          occupation: Option[String],
                          occupationDetails: Option[String],
                          salaryRange: Option[String],
                          loanStatus: Option[String],
                          projectInterestedIn: Option[String],
                          possessionExpected: Option[String],
                          purpose: Option[String],
                          ageRange: Option[String],
                          heardFrom: Option[String]) {

  private implicit val implicitWrites: OWrites[VisitorDetails] = Json.writes[VisitorDetails]

  def toJson: JsValue = Json.toJson(this)
}

object VisitorDetails {
  private implicit val implicitReads: Reads[VisitorDetails] = Json.reads[VisitorDetails]

  def createFromJson(json: JsValue): VisitorDetails = json.as[VisitorDetails]
  implicit val getResult = GetResult(r =>
    VisitorDetails(Some(r.nextInt()),Some(r.nextInt()),r.nextString(), Some(Option(r.nextString()).getOrElse("")),
      Some(Option(r.nextString()).getOrElse("")),r.nextString(),r.nextString(),
      Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),
      Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),
      Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),
      Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),
      Some(Option(r.nextString()).getOrElse(""))))
}

package model

import play.api.libs.json.{JsValue, Json}

case class Category(id: Option[Int],companyId: Option[Int], categoryType: String, name: String){
  implicit val implicitCategoryWrites = Json.writes[Category]
  def toJson: JsValue = Json.toJson(this)
}

object Category {
  implicit val implicitCategoryReads = Json.reads[Category]

  def createFromJson(companyJson: JsValue): Category = companyJson.as[Category]

  val contractor = "Contractor"
  val supplier = "Supplier"
  val consultant = "Consultant"
  val employee = "Employee"
  val all = "All"

  val constantCategories = Set(contractor,supplier,consultant)
}


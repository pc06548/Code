package model

import play.api.libs.json.{JsValue, Json}

case class SaveResponse(id : Int = 0, message : String = "Successfully Saved"){
  private implicit val implicitRDWrites = Json.writes[SaveResponse]
  def toJson: JsValue = Json.toJson(this)
}

object SaveResponse {
  private implicit val implicitRDReads = Json.reads[SaveResponse]

  def createFromJson(json: JsValue): SaveResponse = json.as[SaveResponse]

}
package model

import java.sql.ResultSet

import play.api.libs.json.{JsValue, Json}

case class Project(id: Option[Int],
                   companyId: Option[Int],
                   name: String ,
                   description: Option[String] ,
                   address: Option[String] ,
                   email: Option[String] ,
                   projectStartDate: Option[String] ,
                   projectEndDate: Option[String] ,
                   contactPerson: Option[String] ,
                   contactPerPhonenNbr: Option[String] ,
                   siteContactPerson: Option[String] ,
                   siteContactPerPhoneNbr: Option[String] ,
                   reraNbr : Option[String] ,
                   panNumber: Option[String] ,
                   gstNbr: Option[String] ,
                   last_modified : Option[String],
                   status: String = Project.PROJECT_STATUS_ACTIVE,
                   bankDetails: Option[BankDetails],
                   imageRef:Option[String] = None
                  ) {
  private implicit val implicitBankDetailsWrites = Json.writes[BankDetails]
  private implicit val implicitProjectWrites = Json.writes[Project]

  def toJson: JsValue = Json.toJson(this)
}

object Project {

  private implicit val implicitBankDetailsReads = Json.reads[BankDetails]
  private implicit val implicitProjectReads = Json.reads[Project]

  def createFromJson(contractorJson: JsValue): Project = contractorJson.as[Project]

  val PROJECT_STATUS_ACTIVE     = "ACTIVE"
  val PROJECT_STATUS_COMPLETED  = "COMPLETED"
  val PROJECT_STATUS_FUTURE     = "FUTURE"
  val PROJECT_STATUS_HOLD       = "HOLD"

  val allStatuses = List(PROJECT_STATUS_ACTIVE,
                         PROJECT_STATUS_COMPLETED ,
                       PROJECT_STATUS_FUTURE,PROJECT_STATUS_HOLD )
}

// . TODO cleanup of use
/*
package model

import play.api.libs.json.{JsValue, Json, OWrites, Reads}

case class User(id: Int,
                userName: String = "",
                password: String = "",
                name: String = "",
                accessType: String = "",
                defaultProjectID: Int,
                defaultProjectName: String,
                adminProjectId : Int) {

  private implicit val implicitUserWrites: OWrites[User] = Json.writes[User]

  def toJson: JsValue = Json.toJson(this)
}

object User {
  private implicit val implicitUserReads: Reads[User] = Json.reads[User]

  def createFromJson(dlJson: JsValue): User = dlJson.as[User]

  def convertToJsonMap(c: User): Map[String, JsValue] = {
    Map("id" -> Json.toJson(c.id),
      "name" -> Json.toJson(c.name),
      "projectId" -> Json.toJson(c.defaultProjectID),
      "adminProjectId" -> Json.toJson(c.adminProjectId),
      "projectName" -> Json.toJson(c.defaultProjectName),
      "access" -> Json.toJson("Authenticated"),
      "privilege" -> Json.toJson(c.accessType),
      "username" -> Json.toJson(c.userName)
    )
  }
}*/

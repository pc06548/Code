package model.reports

import java.sql.ResultSet

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import config.ScalaHelpers._
import ChartData._

case class CollectiveSummary(contractors : Seq[CollectiveSummaryData],
                             suppliers : Seq[CollectiveSummaryData],
                              consultants : Seq[CollectiveSummaryData],
                             categorySummary : Seq[CollectiveSummaryData],
                             chartData: Option[ChartData] = None) {

  private implicit val implicitWrites = Json.writes[CollectiveSummaryData]
  private implicit val implicitCollectiveSummaryWrites = Json.writes[CollectiveSummary]
  def toJson: JsValue = Json.toJson(this)
}
object CollectiveSummary {
  def createFromData(contractors : Seq[CollectiveSummaryData],
                     suppliers : Seq[CollectiveSummaryData],
                     consultants : Seq[CollectiveSummaryData],
                     categorySummary : Seq[CollectiveSummaryData]) = {

    CollectiveSummary(
      calculateIncurredPercentage(contractors),
      calculateIncurredPercentage(suppliers),
      calculateIncurredPercentage(consultants),
      calculateIncurredPercentage(categorySummary)
    )
  }

  private def calculateIncurredPercentage(list: Seq[CollectiveSummaryData]) = {
    val total: Double = list.map(_.amount).sum
    list.map(d => {
      val incurredCost = ((100 * d.amount)/total).roundTo2()
      d.copy(incurredPercentage = incurredCost)
    })
  }
}
case class CollectiveSummaryData(projectName:String,name : String, amount : Double , department : String,incurredPercentage: Double = 0.0)

object CollectiveSummaryData {
  implicit val getSRResult = GetResult(r =>
    CollectiveSummaryData(r.nextStringOption().getOrElse(""),r.nextString,r.nextDouble(),r.nextString())
  )

  def createSummaryFromList(list:Seq[CollectiveSummaryData],categoryName:String, projectId:Option[Int]) = {
    val projectName = projectId match {
      case Some(_) => list.headOption.map(_.projectName)
      case _ => None
    }
    CollectiveSummaryData(projectName.getOrElse(""),categoryName,list.map(_.amount).sum,"")
  }
}
package model.reports

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import config.ScalaHelpers._
import ChartData._
case class PurchaseReport(grossTotal : Double,
                          cgst : Double,
                          sgst : Double,
                          totalAmount : Double,
                          purchases : Seq[Purchase],
                          chartData: Option[ChartData] = None){
  implicit val implicitWrites = Json.writes[Purchase]
  implicit val implicitPRWrites = Json.writes[PurchaseReport]

  def toJson: JsValue = Json.toJson(this)
}

object PurchaseReport {

  def createPurchaseReport(purchases : Seq[Purchase]):PurchaseReport = {
    val totals: (Double, Double, Double, Double) = purchases.foldLeft((0.0,0.0,0.0,0.0)){
      (totals,purchase) => {
        (
          totals._1 + purchase.grossTotal,
          totals._2 + purchase.cgst,
          totals._3 + purchase.sgst,
          totals._4 + purchase.totalAmount

        )
      }
    }
    PurchaseReport(totals._1.roundTo2(),totals._2.roundTo2(),totals._3.roundTo2(),totals._4.roundTo2(),purchases)
  }
}

case class Purchase(projectName:String,
                    name : String,
                    description : String,
                    invoiceNumber : String,
                    invoiceDate : String,
                    grossTotal : Double,
                    cgst : Double,
                    sgst : Double,
                    totalAmount : Double,
                    category : String)

object Purchase {

  implicit val getPRResult = GetResult(r =>
    Purchase(r.nextStringOption().getOrElse("Office"),r.nextString,
      r.nextString.split(",").headOption.getOrElse(""),r.nextString,r.nextString,
      r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),
      r.nextString())
  )
}


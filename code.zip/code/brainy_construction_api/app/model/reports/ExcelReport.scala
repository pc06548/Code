package model.reports

case class ExcelReport(name:String, tables: List[Table],
                       columnWidths: Map[Int,Int] = ExcelReport.defaultColumnWidths,
                       columnsToIterate: List[Int] = List()){
  def getMaxColumnSize() :Int = {
    tables.map(_.headings.size).max - 1
  }

}

case class Table(caption:Option[String],headings:List[String],rows:List[Row]){
  def getMaxColumnSize() :Int = {
    headings.size - 1
  }
}

case class Row(values:List[Any],rowStyle: RowStyle = DefaultStyle)

object ExcelReport {
  val defaultColumnWidths: Map[Int, Int] = (0 to 15).map((_ -> 15)).toMap
}

sealed trait RowStyle

case object GreyBackground extends RowStyle

case object YellowBackground extends RowStyle

case object DefaultStyle extends RowStyle
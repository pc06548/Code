package model.reports
import config.ScalaHelpers._
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import ChartData._

case class CustomerCollectionSummary(amountTotal : Double,
                                     cgstTotal:Double,
                                     sgstTotal:Double,
                                     totalAmount : Double,
                                     collections: List[CustomerCollection],
                                     chartData: Option[ChartData] = None){

  private implicit val implicitWrites = Json.writes[CustomerCollection]
  private implicit val implicitWritesCCS = Json.writes[CustomerCollectionSummary]
  def toJson: JsValue = Json.toJson(this)
}

case class CustomerCollection(projectName:String,
                              customerName : String,
                              receiptNumber : String,
                              receiptDate : String,
                              installationAmount : Double,
                              cgst : Double,
                              sgst : Double,
                              totalAmount : Double,
                              paymentMode : String,
                              paymentRefNumber : String,
                              paymentDate : String,
                              bankName : String,
                              extraWork: Boolean) {

}

object CustomerCollection {
  implicit val getSRResult = GetResult(r =>
    CustomerCollection(r.nextString,r.nextString,r.nextString,r.nextString,
      r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),
      r.nextString(),r.nextString,r.nextString,r.nextString, r.nextBoolean())
  )

}

object CustomerCollectionSummary {
  def createFromCollection(collections: List[CustomerCollection]) = {
    val totals: (Double, Double, Double,Double) = collections.foldLeft((0.0,0.0,0.0,0.0)){
      (totals,c) => {
        (
          totals._1 + c.installationAmount,
          totals._2 + c.cgst,
          totals._3 + c.sgst,
          totals._4 + c.totalAmount

        )
      }
    }
    CustomerCollectionSummary(totals._1.roundTo2(),totals._2.roundTo2(),totals._3.roundTo2(),totals._4.roundTo2(),collections)
  }
}
package model.reports

import model.vouchers.{InvoiceDetails, Voucher, VoucherPaymentDetails}
import play.api.libs.json.{JsValue, Json}
import ChartData._
import Voucher._

case class VoucherListReport(vouchers: List[Voucher],
                             chartData: Option[ChartData] = None) {

  implicit val implicitVPRWrites = Json.writes[VoucherListReport]

  def toJson: JsValue = Json.toJson(this)
}

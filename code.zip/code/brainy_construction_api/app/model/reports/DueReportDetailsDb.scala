package model.reports

import config.DateUtil
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import config.ScalaHelpers._

import scala.collection.immutable
import ChartData._

case class DueReport(totalAmount: Double,amountPaid: Double,pendingAmount:Double ,
                     details:Seq[DueReportDetails],
                     chartData: Option[ChartData] = None){
  private implicit val implicitDueReportDetailsDbWrites = Json.writes[DueReportDetailsDb]
  private implicit val implicitDueReportDetailsWrites = Json.writes[DueReportDetails]
  private implicit val implicitDueReportWrites = Json.writes[DueReport]

  def toJson: JsValue = Json.toJson(this)
}

case class DueReportDetailsDb(projectName:String, id:Int, name : String, invoiceNumber : String, totalAmount: Double, category:String,
                              amountPaid: Double, invoiceDate: String, imgRef:List[String], isTemporary:Boolean,
                              pendingAmount:Option[Double] = None, paymentStatus:Option[String]= None, creditDays:Option[Int]= None){

}
case class DueReportDetails(name : String,totalAmount: Double,amountPaid: Double,pendingAmount:Double, details:Seq[DueReportDetailsDb])

object DueReportDetailsDb{

  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    DueReportDetailsDb(r.nextStringOption().getOrElse("Office"),r.nextInt(), r.nextString, r.nextString,
      r.nextDouble(),r.nextString(),r.nextDouble(),Option(r.nextString).getOrElse(""),
      Option(r.nextString).map(_.split(",").toList).getOrElse(List.empty[String]),r.nextBoolean())
  )
}
object DueReport {

  def createDueReport(details : Seq[DueReportDetailsDb]):DueReport = {

    val updatedDetils: immutable.Seq[DueReportDetails] = details.map(detail => {
      val pendingAmt = detail.totalAmount - detail.amountPaid
      val status = if(pendingAmt > 0) "Unpaid" else "Paid"
      val daysDiff = DateUtil.getDiffernceInDays(detail.invoiceDate,DateUtil.today)
      val credit = if(daysDiff > 0) daysDiff else 0
      detail.copy(pendingAmount = Some(pendingAmt),paymentStatus = Some(status),creditDays = Some(credit))
    }).groupBy(d => (d.name))
      .map{
        case (name,details) => {
          val totalAmount = details.map(_.totalAmount).sum
          val amountPaid = details.map(_.amountPaid).sum
          val pendingAmount = details.map(_.pendingAmount.getOrElse(0.0)).sum
          DueReportDetails(name,totalAmount,amountPaid,pendingAmount,details)
        }
        }.toList

    val totals: (Double, Double,Double) = updatedDetils.foldLeft((0.0,0.0,0.0)){
      (totals,detail) => {
        (
          totals._1 + detail.totalAmount,
          totals._2 + detail.amountPaid,
          totals._3 + detail.pendingAmount
        )
      }
    }

    DueReport(totals._1.roundTo2(),totals._2.roundTo2(),totals._3.roundTo2(),updatedDetils)
  }
}
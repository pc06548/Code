package model.reports

import slick.jdbc.GetResult

case class DirectorReport()

sealed trait DirectorReportData

case class ExpenseOverviewData(companyId:Int,projectName:String,category:String,name:String,
                               amount:Double,voucherNumber:String,paymentRef:String) extends DirectorReportData

case class DirectorReportCustomerCollectionData(companyId:Int,projectName:String,customerId:Int,name:String,
                                                flatDetails:String,flatNumber:String,
                                                amountDue:Double,receivedAmount:Double,totalAmountPaid:Double) extends DirectorReportData

case class DirectorReportPurchaseOverviewData(companyId:Int,projectName:String,category:String,name:String,
                                              totalAmount:Double,invoiceNumber:String,description:String) extends DirectorReportData

case class DirectorReportPurchaseOrderData(companyId:Int,projectName:String,poId:Int,name:String,
                                              totalAmount:Double,generatedBy:String,approvedBy:String) extends DirectorReportData

case class DirectorReportPurchaseInventoryData(companyId:Int,projectName:String,material:String,
                                               source:String,vehicleNumber:String,inTime:String,
                                               outTime:String,chalanNumber:String,purchaseOrderNumber:String) extends DirectorReportData

case class DirectorReportAttendanceData(companyId:Int,projectName:String,department:String,
                                        name:String,count:Double,shiftTime:String,createdBy:String) extends DirectorReportData

case class DirectorReportSiteExpensesData(companyId:Int,projectName:String,reason:String,
                                        name:String,typeOfTransaction:String,amount:Double,paymentMode:String) extends DirectorReportData

case class DirectorReportVisitorsData(companyId:Int,projectName:String,typeOfProperty:String,
                                      name:String,phoneNumber:String,email:String,purpose:String,
                                      visitingTime:String,occupation:String) extends DirectorReportData


object ExpenseOverviewData {
  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    ExpenseOverviewData(r.nextInt(),r.nextString(),r.nextString(),r.nextString(),r.nextDouble(),r.nextString(),r.nextStringOption().getOrElse("-"))
  )
}

object DirectorReportCustomerCollectionData {
  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    DirectorReportCustomerCollectionData(r.nextInt(),r.nextString(),r.nextInt(),r.nextString(),
      r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
      r.nextDouble(),r.nextDouble(),r.nextDouble())
  )
}
object DirectorReportPurchaseOverviewData {
  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    DirectorReportPurchaseOverviewData(r.nextInt(),r.nextString(),r.nextString(),r.nextString(),
      r.nextDouble(),r.nextString(),r.nextStringOption().getOrElse(""))
  )
}
object DirectorReportPurchaseOrderData {
  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    DirectorReportPurchaseOrderData(r.nextInt(),r.nextString(),r.nextInt(),r.nextString(),
      r.nextDouble(),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""))
  )
}
object DirectorReportPurchaseInventoryData {
  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    DirectorReportPurchaseInventoryData(r.nextInt(),r.nextString(),r.nextString(),
      r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
      r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
      r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse("")
    )
  )
}

object DirectorReportAttendanceData {
  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    DirectorReportAttendanceData(r.nextInt(),r.nextString(),
      r.nextStringOption().getOrElse(""),r.nextString(),
      r.nextDouble(),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""))
  )
}
object DirectorReportSiteExpensesData {
  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    DirectorReportSiteExpensesData(r.nextInt(),r.nextStringOption().getOrElse("Office"),
      r.nextStringOption().getOrElse(""),r.nextString(),r.nextString(),
      r.nextDouble(),r.nextStringOption().getOrElse(""))
  )
}

object DirectorReportVisitorsData {
  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    DirectorReportVisitorsData(r.nextInt(),r.nextStringOption().getOrElse("-"),
      r.nextStringOption().getOrElse("-"),r.nextString(),r.nextString(),
      r.nextStringOption().getOrElse("-"),r.nextStringOption().getOrElse("-"),
      r.nextStringOption().getOrElse("-"),r.nextStringOption().getOrElse("-"))
  )
}
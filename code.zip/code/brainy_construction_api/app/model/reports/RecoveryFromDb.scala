package model.reports

import config.DateUtil
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import config.ScalaHelpers._
import ChartData._
case class RecoveryReport(amount : Double,
                          cgst : Double,
                          sgst : Double,
                          netAmount : Double,
                          receivedAmount : Double,
                          pendingAmount : Double,
                          recoveries : List[CustomerRecovery],
                          chartData: Option[ChartData] = None){
  private implicit val implicitRecoveryWrites = Json.writes[Recovery]
  private implicit val implicitCustomerRecoveryWrites = Json.writes[CustomerRecovery]
  private implicit val implicitWritesRR = Json.writes[RecoveryReport]
  def toJson: JsValue = Json.toJson(this)
}

object RecoveryReport {
  def createFromRecoveries(recoveries : List[RecoveryFromDb]) = {

    val updated = recoveries.map(recovery => {
      val daysDiff = DateUtil.getDiffernceInDays(recovery.dueDate,DateUtil.today)
      val delay = if((daysDiff > 0) && (recovery.pendingAmount.getOrElse(0.0) > 0.0)) daysDiff else 0
      recovery.copy(delayInDays = Some(delay))
    })
    val groupByCustomer = updated.groupBy(g => (g.projectName,g.customerId,g.customerName,g.coOwners,g.phoneNumber,g.bankName,g.bankRepresentativeName,g.bankRepresentativePhoneNumber))
    val data = groupByCustomer.map{
      case ((projectName,customerId,customerName,coOwners,phoneNumber,bankName,bankRepresentativeName,bankRepresentativePhoneNumber),recoveries) => {
        CustomerRecovery(
          projectName,customerId,customerName,coOwners,phoneNumber,
          bankName,bankRepresentativeName,bankRepresentativePhoneNumber,
          recoveries.map(_.amount).sum,
          recoveries.map(_.cgst).sum,
          recoveries.map(_.sgst).sum,
          recoveries.map(_.netAmount).sum,
          recoveries.map(_.receivedAmount.getOrElse(0.0)).sum,
          recoveries.map(_.pendingAmount.getOrElse(0.0)).sum,
          recoveries.map(r => Recovery(r.dueDate,r.amount,r.cgst,r.sgst,r.netAmount,r.receivedAmount,r.pendingAmount,r.delayInDays))
        )
      }
    }.toList
    val totals: (Double, Double,Double,Double, Double,Double) = recoveries.foldLeft((0.0,0.0,0.0,0.0,0.0,0.0)){
      (totals,detail) => {
        (
          totals._1 + detail.amount,
          totals._2 + detail.cgst,
          totals._3 + detail.sgst,
          totals._4 + detail.netAmount,
          totals._5 + detail.receivedAmount.getOrElse(0.0),
          totals._6 + detail.pendingAmount.getOrElse(0.0)
        )
      }
    }
    RecoveryReport(totals._1.roundTo2(),totals._2.roundTo2(),totals._3.roundTo2(),
      totals._4.roundTo2(),totals._5.roundTo2(),totals._6.roundTo2(),data)
  }
}

case class CustomerRecovery(projectName:String,
                            customerId:Int,
                            customerName : String,
                            coOwners:String,
                            phoneNumber:String,
                            bankName : String,
                            bankRepresentativeName:String,
                            bankRepresentativePhoneNumber:String,
                            amount : Double,
                            cgst : Double,
                            sgst : Double,
                            netAmount : Double,
                            receivedAmount : Double,
                            pendingAmount : Double,
                            recoveries:List[Recovery]
                   )

case class Recovery(dueDate : String,
                    amount : Double,
                    cgst : Double,
                    sgst : Double,
                    netAmount : Double,
                    receivedAmount : Option[Double],
                    pendingAmount : Option[Double],
                    delayInDays : Option[Int]
                   )

case class RecoveryFromDb(projectName:String,
                          customerId:Int,
                          customerName : String,
                          coOwners:String,
                          phoneNumber:String,
                          dueDate : String,
                          amount : Double,
                          cgst : Double,
                          sgst : Double,
                          netAmount : Double,
                          receivedAmount : Option[Double],
                          pendingAmount : Option[Double],
                          bankName : String,
                          bankRepresentativeName:String,
                          bankRepresentativePhoneNumber:String,
                          delayInDays : Option[Int])

case class AmountReceived(customerId :Int,amountReceived:Double)

object AmountReceived {
  implicit val getARResult = GetResult(r =>
    AmountReceived(r.nextInt(), r.nextDouble())
  )
}

object RecoveryFromDb {
  implicit val getSRResult = GetResult(r =>
    RecoveryFromDb(r.nextString,r.nextInt(), r.nextString,
      r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
      r.nextString,
      r.nextDouble(),r.nextDouble(),r.nextDouble(),
      r.nextDouble(),None,None,Option(r.nextString()).getOrElse(""),
      r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),None)
  )
}

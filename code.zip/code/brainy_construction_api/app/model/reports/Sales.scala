package model.reports

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import config.ScalaHelpers._
import ChartData._

case class SalesReport(agreementAmount : Double,
                       amountReceived : Double,
                       balanceAmount : Double,
                       sales : Seq[Sales],
                       chartData: Option[ChartData] = None){

  private implicit val implicitWrites = Json.writes[Sales]
  private implicit val implicitSRWrites = Json.writes[SalesReport]
  def toJson: JsValue = Json.toJson(this)
}

case class Sales(projectName:String,
                  customerName : String,
                 flatNumber : String,
                 agreementDate : String,
                 saledeedDate : String,
                 possessionDate : String,
                 agreementAmount : Double,
                 amountReceived : Double,
                 balanceAmount : Double)

object Sales {
  implicit val getSRResult = GetResult(r =>
    Sales(r.nextString(),r.nextString, r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
      r.nextDouble(),r.nextDouble(),r.nextDouble())
  )
}

object SalesReport {
  def createSalesReport(sales : Seq[Sales]):SalesReport = {

    val totals: (Double, Double, Double) = sales.foldLeft((0.0,0.0,0.0)){
      (totals,sale) => {
        (
          totals._1 + sale.agreementAmount,
          totals._2 + sale.amountReceived,
          totals._3 + sale.balanceAmount

        )
      }
    }
    SalesReport(totals._1.roundTo2(),totals._2.roundTo2(),totals._3.roundTo2(),sales)
  }
}
package model.reports

import config.ScalaHelpers._
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class NoDueReport(amountTotal:Double,cgstTotal: Double,sgstTotal: Double,total:Double,
                       agreementCost:Double,
                       details:Seq[NoDueReportDetails]){
  private implicit val implicitDueReportDetailsWrites = Json.writes[NoDueReportDetails]
  private implicit val implicitDueReportWrites = Json.writes[NoDueReport]

  def toJson: JsValue = Json.toJson(this)
}

case class NoDueReportDetails(receiptNumber:String,content : String, dateCreated : String, mode: String,
                              paymentRefNumber:String,
                              amount:Double,
                              cgst: Double,
                              sgst: Double,
                              totalAmount: Double,
                              agreementCost:Double,
                              paymentDate:Option[String]
                             ){

}

object NoDueReportDetails{

  implicit val getOtherInvoiceSearchResult = GetResult(r =>
    NoDueReportDetails(r.nextString,r.nextString, r.nextString,r.nextString,r.nextString,
      r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextStringOption())
  )
}

object NoDueReport {

  def createDueReport(details : Seq[NoDueReportDetails]):NoDueReport = {
    val totals: (Double,Double, Double,Double) = details.foldLeft((0.0,0.0,0.0,0.0)){
      (totals,detail) => {
        (
          totals._1 + detail.amount,
          totals._2 + detail.cgst,
          totals._3 + detail.sgst,
          totals._4 + detail.totalAmount
        )
      }
    }
    NoDueReport(totals._1.roundTo2(),totals._2.roundTo2(),totals._3.roundTo2(),totals._4.roundTo2(),
      details.headOption.map(_.agreementCost).getOrElse(0.0),details)
  }
}
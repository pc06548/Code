package model.reports

import java.sql.ResultSet

import config.DateHelperDeprecated
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class GroupSalaryPaymentData(paymentRefNumber: String = "",
                                  paymentDate: String = "",
                                  mode: String = "",
                                  voucherDate: String = "",
                                  employeeName: String = "",
                                  bankName: String = "",
                                  bankAddress: String = "",
                                  bankAccountNumber: String = "",
                                  ifscCode: String = "",
                                  phoneNumber: String = "",
                                  panNumber: String = "",
                                  aadharNumber: String = "",
                                  totalAmount: Double = 0.0,
                                  content: String = "") {

}

object GroupSalaryPaymentData {

  implicit val getSRResult = GetResult(r =>
    GroupSalaryPaymentData(r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
      r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
      r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
      r.nextDouble(),r.nextStringOption().getOrElse("")
    )
  )

}

case class GroupSalaryPayment(paymentRefNumber: String = "",
                              paymentDate: String = "",
                              mode: String = "",
                              voucherDate: String = "",
                              employeeDetails: Seq[EmployeeDetails],
                              totalAmount: Double
                           ){
  private implicit val implicitEmployeeDetailsWrites = Json.writes[EmployeeDetails]
  private implicit val implicitGroupSalaryPaymentWrites = Json.writes[GroupSalaryPayment]
  def toJson: JsValue = Json.toJson(this)

}
case class EmployeeDetails(employeeName: String = "",
                           bankName: String = "",
                           bankAddress: String = "",
                           bankAccountNumber: String = "",
                           ifscCode: String = "",
                           phoneNumber: String = "",
                           panNumber: String = "",
                           aadharNumber: String = "",
                           totalAmount: Double = 0.0,
                           content: String = "")


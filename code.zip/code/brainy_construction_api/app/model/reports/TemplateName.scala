package model.reports

import play.api.libs.json.{JsValue, Json}

case class TemplateName(chequePrintTemplates:List[String] = List.empty) {
  private implicit val implicittdsWrites = Json.writes[TemplateName]
  def toJson: JsValue = Json.toJson(this)
}
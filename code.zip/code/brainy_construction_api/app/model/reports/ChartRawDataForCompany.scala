package model.reports

import java.util.Date

import config.DateUtil
import play.api.libs.json.{JsValue, Json}

case class ChartRawDataForCompany(projectName: String,
                                  date:Date,
                                  month:String,
                                  year:Int,
                                  amount:Double) {
}


object ChartRawDataForCompany {
  def createChartRawData(projectName: String,
                         date:String,
                         amount:Double): ChartRawDataForCompany ={
    ChartRawDataForCompany(
      projectName,
      DateUtil.getDateFromString(date),
      DateUtil.getMonthFormatFromDate(date),
      DateUtil.getYearFormatFromDate(date),
      amount
    )

  }
}
case class ChartRawDataForProject(fieldName: String,
                                  date:Date,
                                  month:String,
                                  year:Int,
                                  amount:Double) {
}


object ChartRawDataForProject {
  def createChartRawData(fieldName: String,
                         date:String,
                         amount:Double): ChartRawDataForProject ={
    ChartRawDataForProject(
      fieldName,
      DateUtil.getDateFromString(date),
      DateUtil.getMonthFormatFromDate(date),
      DateUtil.getYearFormatFromDate(date),
      amount
    )

  }
}

case class DoughnutChart(title:String,labels:List[String], datasets:List[DoughnutChartDataSet])

case class DoughnutChartDataSet(data:List[Double])

case class StackedBarChartDataSet(label:String,data:List[Double])

case class StackedBarChart(labels:List[String], datasets:List[StackedBarChartDataSet])

case class ChartData(stackedBarCharts: List[StackedBarChart],
                     doughnutCharts: List[DoughnutChart]){
   implicit val implicitStackedBarChartDataSetWrites = Json.writes[StackedBarChartDataSet]
   implicit val implicitStackedBarChartWrites = Json.writes[StackedBarChart]
  implicit val implicitDoughnutChartDataSetSetWrites = Json.writes[DoughnutChartDataSet]
  implicit val implicitDoughnutChartWrites = Json.writes[DoughnutChart]
  implicit val implicitChartDataWrites = Json.writes[ChartData]
  def toJson: JsValue = Json.toJson(this)
}

object ChartData {
  implicit val implicitStackedBarChartDataSetWrites = Json.writes[StackedBarChartDataSet]
  implicit val implicitStackedBarChartWrites = Json.writes[StackedBarChart]
  implicit val implicitDoughnutChartDataSetSetWrites = Json.writes[DoughnutChartDataSet]
  implicit val implicitDoughnutChartWrites = Json.writes[DoughnutChart]
  implicit val implicitChartDataWrites = Json.writes[ChartData]

  def empty = ChartData(List.empty[StackedBarChart],List.empty[DoughnutChart])
}
package model.reports

import java.sql.ResultSet

import config.DateHelperDeprecated
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult


import ChartData._

case class AccountSummaryData(name: String = "",
                    content: String = "",
                    projectName: String = "",
                    tds: Double = 0.0,
                    totalAmount: Double = 0.0,
                    chequeNumber: String = "",
                    chequeDate: String = "",
                    invoiceNumber: String = "",
                    category: String = "",
                    invoiceDate : String = "",
                    invoiceAmount: Double = 0.0,
                    basicAmount: Double = 0.0,
                    cgst: Double = 0.0,
                    sgst: Double = 0.0,
                    documentRefNumber : String = "",
                    voucherNumber:String,
                    isTemporary:Boolean) {

}

object AccountSummaryData {

  implicit val getSRResult = GetResult(r =>
    AccountSummaryData(r.nextString, r.nextString,r.nextStringOption().getOrElse("Office"),
      r.nextDouble(),r.nextDouble(),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse("")
      ,r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),r.nextBoolean()
    )
  )

}

case class AccountSummary(details: List[AccountSummaryDetails],
                          chartData: Option[ChartData] = None){
  implicit val implicitVoucherDetailsWrites = Json.writes[VoucherDetails]
  implicit val implicitAccountSummaryDWrites = Json.writes[AccountSummaryDetails]
  implicit val implicitAccountSummaryWrites = Json.writes[AccountSummary]
  def toJson: JsValue = Json.toJson(this)
}

case class AccountSummaryDetails(projectName: String = "",
                                 name: String = "",
                                 category: String = "",
                                 description:String = "",
                                 invoiceNumber: String = "",
                                 invoiceDate : String = "",
                                 invoiceAmount: Double = 0.0,
                                 basicAmount: Double = 0.0,
                                 cgst: Double = 0.0,
                                 sgst: Double = 0.0,
                                 documentRefNumber: String = "",
                                 isTemporary:Boolean,
                                 vouchers : Seq[VoucherDetails]
                           ){
  implicit val implicitVoucherDetailsWrites = Json.writes[VoucherDetails]
  implicit val implicitAccountSummaryWrites = Json.writes[AccountSummaryDetails]

}
case class VoucherDetails(content : String = "",
                          voucherNumber : String = "",
                          totalAmount: Double = 0.0,
                          tds: Double = 0.0,
                          chequeNumber: String = "",
                          chequeDate: String = "")


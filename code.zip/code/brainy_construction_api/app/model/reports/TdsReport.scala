package model.reports

import config.DateUtil
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import ChartData._

case class TdsReport(nameWiseTds: List[NameWiseTds],
                     monthWiseTds: List[MonthWiseTds],
                     chartData: Option[ChartData] = None){
  private implicit val implicitTdsDetailWrites = Json.writes[TdsDetail]
  private implicit val implicitWrites = Json.writes[NameWiseTds]
  private implicit val implicitMonthWiseWrites = Json.writes[MonthWiseTds]
  private implicit val implicittdsWrites = Json.writes[TdsReport]
  def toJson: JsValue = Json.toJson(this)
}

case class NameWiseTds(name : String,category : String,pan:String, details : List[TdsDetail]){
  private implicit val implicitTdsDetailWrites = Json.writes[TdsDetail]
}

case class TdsDetail(month : String,taxableValue : Double,tds : Double)

case class MonthWiseTds(month : String,totalTaxableValue : Double,totalTds : Double)

case class TdsData(name:String,date:String,taxableValue : Double,tds : Double,pan:Option[String],category:String)
object TdsData{
  implicit val getSRResult = GetResult(r =>
    TdsData(r.nextString,r.nextString,r.nextDouble(),r.nextDouble(),Option(r.nextString()),r.nextString())
  )
}

case class MonthWiseTdsPerCategory(companyId:Int, category:String,tds:Double, month: Option[String])

object MonthWiseTdsPerCategory{
  implicit val getMonthWiseTdsPerCategoryRResult = GetResult(r =>
    MonthWiseTdsPerCategory(r.nextInt(),r.nextString,r.nextDouble(),None)
  )
}

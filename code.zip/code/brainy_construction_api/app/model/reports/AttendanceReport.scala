package model.reports

import model.employee.Attendance
import play.api.libs.json.{JsValue, Json}

case class AttendanceReport(attendances : List[EmployeeAttendance]){
  private implicit val implicitAttendanceWrites = Json.writes[Attendance]
  private implicit val implicitEmpAttendanceWrites = Json.writes[EmployeeAttendance]
  private implicit val implicitAttendanceRWrites = Json.writes[AttendanceReport]
  def toJson: JsValue = Json.toJson(this)
}

case class EmployeeAttendance(name:Option[String],attendance: List[Attendance])

object AttendanceReport {
  def createFromAttendances(attendances:List[Attendance]): AttendanceReport = {
    val empAtt = attendances.groupBy(_.name).map(
      r =>  EmployeeAttendance(r._1,r._2)
    ).toList
    AttendanceReport(empAtt)
  }
}

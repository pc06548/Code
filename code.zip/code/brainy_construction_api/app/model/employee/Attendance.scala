package model.employee

import model.{BankDetails, Location}
import model.reports.Sales
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import utils.DistanceCalculator

case class Attendance(id:Option[Int],
                    companyId: Option[Int],
                    employeeId: Int,
                    name:Option[String],
                    date:String,
                    startTime:String,
                    endTime:Option[String],
                    workDetails:Option[String],
                      longitude:Option[Double] = None,
                      latitude:Option[Double] = None
                     ) {

  private implicit val implicitAttendanceWrites = Json.writes[Attendance]
  def toJson: JsValue = Json.toJson(this)

  def checkIfValid(locations: List[Location]):Boolean = {
    locations.map(l => {
      val d = DistanceCalculator.calculateDistanceInMeter(this.longitude.getOrElse(0), this.latitude.getOrElse(0), l)
      d < 300
    }).exists(_ == true)
  }
}

object Attendance {
  private implicit val implicitBankDetailsReads = Json.reads[BankDetails]
  private implicit val implicitAttendanceReads = Json.reads[Attendance]

  def createFromJson(json: JsValue): Attendance = json.as[Attendance]

  implicit val getSRResult = GetResult(r =>
    Attendance(Some(r.nextInt()),Some(r.nextInt()),r.nextInt(),Option(r.nextString()), r.nextString, r.nextString,
      Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")))
  )
}
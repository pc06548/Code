package model.employee

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class PayslipSearch(id:Option[Int],
                         month:String,
                         employeeId:Int,
                         employeeName:String,
                         totalAmount:Double,
                         amountPaid:Double,
                         status:Option[String] = None
                       ){
  private implicit val implicitPayslipSearchWrites = Json.writes[PayslipSearch]
  def toJson: JsValue = Json.toJson(this)

}

object PayslipSearch {
  val PAYSLIP_STATUS_UNPAID = "unpaid"
  val PAYSLIP_STATUS_PAID = "paid"

  private implicit val implicitPayslipSearchReads = Json.reads[PayslipSearch]

  def createFromJson(json: JsValue): PayslipSearch = json.as[PayslipSearch]

  implicit val getSRResult = GetResult(r =>
    PayslipSearch(Some(r.nextInt()),r.nextString,r.nextInt(),r.nextString,r.nextDouble,r.nextDouble())
  )
}
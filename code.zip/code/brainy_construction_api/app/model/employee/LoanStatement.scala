package model.employee

import model.BankDetails
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class LoanStatement(employee: Option[Employee],
                          loans:List[LoanStatementData]){
  private implicit val implicitBankDetailsWrites = Json.writes[BankDetails]
  private implicit val implicitEmployeeWrites = Json.writes[Employee]
  private implicit val implicitLoanInsWrites = Json.writes[LoanInstallment]
  private implicit val implicitLoanWrites = Json.writes[Loan]
  private implicit val implicitLoanStatementDataWrites = Json.writes[LoanStatementData]
  private implicit val implicitLoanStatementWrites = Json.writes[LoanStatement]
  def toJson: JsValue = Json.toJson(this)

}

case class LoanStatementData(
                      loanDetails:Loan,
                      totalAmountPaid:Double,
                      installments: List[LoanInstallment]
                      )

case class LoanInstallmentFromDB(loanId:Int,
                                 companyId:Option[Int],
                                 employeeId:Option[Int],
                                 loanDescription:String,
                                 monthlyEmi:Double,
                                 validFrom:Option[String],
                                 validTill:Option[String],
                                 loanAmount:Double,
                                 isActive:Boolean,
                                 dateCreated:Option[String],
                                 loanPaymentDate:Option[String],
                                 paymentMode:Option[String],
                                 paymentRefNumber:Option[String],
                                 interestPercentage:Option[Double],
                                 interestAmount:Option[Double],
                                 totalAmount:Option[Double],
                                 description:String,
                                 month:String,
                                 paymentDate:String,
                                 debitedAmount:Double,
                                 voucherNumber:String,
                                 balanceAmount:Option[Double] = None
                            ){

}
case class LoanInstallment(description:String,
                           month:String,
                           paymentDate:String,
                           debitedAmount:Double,
                           voucherNumber:String,
                           balanceAmount:Option[Double] = None){

}
object LoanInstallmentFromDB {

  implicit val getSRResult = GetResult(r =>
    LoanInstallmentFromDB(r.nextInt(),r.nextIntOption(),r.nextIntOption(),r.nextString,r.nextDouble,r.nextStringOption(),r.nextStringOption(),
      r.nextDouble,r.nextBoolean(),r.nextStringOption(),r.nextStringOption(),r.nextStringOption(),r.nextStringOption(),
      Some(r.nextDoubleOption().getOrElse(0.0)),Some(r.nextDoubleOption().getOrElse(0.0)),Some(r.nextDoubleOption().getOrElse(0.0)),
      r.nextString,r.nextString,r.nextString,r.nextDouble,r.nextString)
  )
}
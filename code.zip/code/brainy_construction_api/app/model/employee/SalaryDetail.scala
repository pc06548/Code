package model.employee

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class SalaryDetail(id:Option[Int],
                        companyId:Option[Int],
                        employeeId:Option[Int],
                        description:String,
                        detailType:String,
                        amount:Double,
                        validFrom:Option[String],
                        validTill:Option[String]
                       ){
  private implicit val implicitSalaryDetailWrites = Json.writes[SalaryDetail]
  def toJson: JsValue = Json.toJson(this)

}
object SalaryStructure {
  def createFromSalaryDetails(details:List[SalaryDetail]):SalaryStructure = {
    val earnings = details.filter(_.detailType == "C")
    val deductions = details.filter(_.detailType == "D")
    val total = earnings.map(_.amount).sum - deductions.map(_.amount).sum
    SalaryStructure(earnings,deductions,total)
  }
}
case class SalaryStructure(
                          earnings:List[SalaryDetail],
                          deductions:List[SalaryDetail],
                          total:Double
                          ){
  private implicit val implicitSalaryDetailWrites = Json.writes[SalaryDetail]
  private implicit val implicitSalaryStructureWrites = Json.writes[SalaryStructure]
  def toJson: JsValue = Json.toJson(this)

}

object SalaryDetail {
  private implicit val implicitSalaryDetailReads = Json.reads[SalaryDetail]

  def createFromJson(json: JsValue): SalaryDetail = json.as[SalaryDetail]

  implicit val getSRResult = GetResult(r =>
    SalaryDetail(Some(r.nextInt()),Some(r.nextInt()),Some(r.nextInt()),
      r.nextString, r.nextString,r.nextDouble(),
      Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")))
  )
}

case class SalaryStructureSearch(employeeId:Int, employeeName:String,earningsTotal: Double,
                                 deductionsTotal: Double, netSalary:Double){
  private implicit val implicitSalaryStructureSearchWrites = Json.writes[SalaryStructureSearch]
  def toJson: JsValue = Json.toJson(this)
}

object SalaryStructureSearch {
  implicit val getSRResult = GetResult(r =>
    SalaryStructureSearch(r.nextInt(),r.nextString,r.nextDouble(),r.nextDouble(),r.nextDouble())
  )
}
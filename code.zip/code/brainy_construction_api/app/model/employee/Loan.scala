package model.employee

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class Loan(id:Option[Int],
                        companyId:Option[Int],
                        employeeId:Option[Int],
                        description:String,
                        monthlyEmi:Double,
                        validFrom:Option[String],
                        validTill:Option[String],
                        loanAmount:Double,
                        interestPercentage:Option[Double],
                        interestAmount:Option[Double],
                        totalAmount:Option[Double],
                        isActive:Boolean,
                        dateCreated:Option[String],
                        paymentDate:Option[String],
                        paymentMode:Option[String],
                        paymentRefNumber:Option[String],
                        amountPaid:Option[Double],
                employeeName:Option[String] = None,
                numberOfMonths:Option[Int] = None
                       ){
  private implicit val implicitLoanWrites = Json.writes[Loan]
  def toJson: JsValue = Json.toJson(this)

}

case class LoansPerEmployee(employeeName: Option[String], loans: List[Loan]){
  private implicit val implicitLoanWrites = Json.writes[Loan]
  private implicit val implicitLoansPerEmployeeWrites = Json.writes[LoansPerEmployee]
  def toJson: JsValue = Json.toJson(this)
}

object Loan {
  private implicit val implicitLoanReads = Json.reads[Loan]

  def createFromJson(json: JsValue): Loan = json.as[Loan]

  implicit val getSRResult = GetResult(r =>
    Loan(Some(r.nextInt()),Some(r.nextInt()),Some(r.nextInt()),
      r.nextString,r.nextDouble, Some(r.nextString),Some(r.nextString),r.nextDouble,
      Some(r.nextDoubleOption().getOrElse(0.0)),
      Some(r.nextDoubleOption().getOrElse(0.0)),
      r.nextDoubleOption(),r.nextBoolean(),r.nextStringOption(),
      r.nextStringOption(),r.nextStringOption(),r.nextStringOption(),
      Option(r.nextDouble()),r.nextStringOption())
  )
}
package model.employee

import config.DateHelperDeprecated
import controllers.user.CreateUserRequest
import model.BankDetails
import play.api.libs.json.{JsValue, Json}

case class Employee(id:Option[Int],
                    userId: Int,
                    companyId: Int,
                    name: String,
                    mobileNumber: String,
                    email: Option[String],
                    address: Option[String] = None,
                    designation: Option[String] = None,
                    department: Option[String] = None,
                    pfNumber: Option[String] = None,
                    panNumber: Option[String] = None,
                    aadharNumber: Option[String] = None,
                    joiningDate: Option[String] = None,
                    workingHours:Option[Double] = None,
                    bankDetails: Option[BankDetails] = None,
                    activeUntil: Option[String] = Some(DateHelperDeprecated.endOfTimeString),
                    createTimestamp: Option[String],
                    updateTimestamp: Option[String]) {
  private implicit val implicitBankDetailsWrites = Json.writes[BankDetails]
  private implicit val implicitEmployeeWrites = Json.writes[Employee]

  def toJson: JsValue = Json.toJson(this)
}

object Employee {
  private implicit val implicitBankDetailsReads = Json.reads[BankDetails]
  private implicit val implicitEmployeeReads = Json.reads[Employee]

  def createFromJson(employeeJson: JsValue): Employee = employeeJson.as[Employee]
}

case class EmployeeWithUser(employee: Employee, user: Option[CreateUserRequest]) {
  private implicit val implicitBankDetailsWrites = Json.writes[BankDetails]
  private implicit val implicitEmployeeWrites = Json.writes[Employee]
  private implicit val implicitCreateUserRequestWrites = Json.writes[CreateUserRequest]
  private implicit val implicitEmployeeWithUserWrites = Json.writes[EmployeeWithUser]
  def toJson: JsValue = Json.toJson(this)
}

object EmployeeWithUser {
  private implicit val implicitBankDetailsReads = Json.reads[BankDetails]
  private implicit val implicitEmployeeReads = Json.reads[Employee]
  private implicit val implicitCreateUserRequestReads = Json.reads[CreateUserRequest]
  private implicit val implicitEmployeeWithUserReads = Json.reads[EmployeeWithUser]
  def createFromJson(employeeJson: JsValue): EmployeeWithUser = employeeJson.as[EmployeeWithUser]
}
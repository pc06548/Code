package model.employee

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class LoanPrepayment(id:Option[Int],
                          loanId:Option[Int],
                          amountPaid:Double,
                          datePaid:String,
                          modeOfPayment:String
                       ){
  private implicit val implicitLoanPrepaymentWrites = Json.writes[LoanPrepayment]
  def toJson: JsValue = Json.toJson(this)

}

object LoanPrepayment {
  private implicit val implicitLoanPrepaymentReads = Json.reads[LoanPrepayment]

  def createFromJson(json: JsValue): LoanPrepayment = json.as[LoanPrepayment]

  implicit val getSRResult = GetResult(r =>
    LoanPrepayment(Some(r.nextInt()),Some(r.nextInt()),r.nextDouble, r.nextString,r.nextString)
  )
}
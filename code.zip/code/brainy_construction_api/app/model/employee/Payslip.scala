package model.employee

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

object Payslip {
  def createFromPayslipDetails(payslip:Payslip,details:List[PayslipDetail]):Payslip = {
    val earnings = details.filter(_.detailType == "C")
    val deductions = details.filter(_.detailType == "D")
    val total = earnings.map(_.amount).sum - deductions.map(_.amount).sum
    payslip.copy(earnings = earnings,deductions = deductions, total = total)
  }
}

case class Payslip(id:Option[Int],
                   companyId:Int,
                   employeeId:Int,
                   month:String,
                   dateCreated:String,
                   total:Double,
                   amountPaid:Option[Double] = None,
                   earnings:List[PayslipDetail] = List.empty,
                   deductions:List[PayslipDetail] = List.empty

                          ){
  private implicit val implicitPayslipDetailWrites = Json.writes[PayslipDetail]
  private implicit val implicitPayslipWrites = Json.writes[Payslip]
  def toJson: JsValue = Json.toJson(this)

}

case class PayslipDetail(id:Option[Int],
                         payslipId:Option[Int],
                         loanId:Option[Int],
                         description:String,
                         detailType:String,
                         amount:Double
                        ){
  private implicit val implicitPayslipDetailWrites = Json.writes[PayslipDetail]
  def toJson: JsValue = Json.toJson(this)

}
object PayslipDetail {

  implicit val getSRResult = GetResult(r =>
    PayslipDetail(Some(r.nextInt()),Some(r.nextInt()),r.nextIntOption(),
      r.nextString, r.nextString,r.nextDouble())
  )

  def mapToPayslipDetail(sd : SalaryDetail) : PayslipDetail = {
    PayslipDetail(None,None,None,sd.description,sd.detailType,sd.amount)
  }
  def mapToPayslipDetail(l : Loan) : PayslipDetail = {
    PayslipDetail(None,None,l.id,s"${l.description} installment","D",l.monthlyEmi)
  }
}
package model.employee

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class Performance(id:Option[Int],
                        companyId:Option[Int],
                        employeeId:Option[Int],
                       note:Option[String],
                       date:String,
                       star:Double
                       ){
  private implicit val implicitPerformanceWrites = Json.writes[Performance]
  def toJson: JsValue = Json.toJson(this)

}

object Performance {
  private implicit val implicitPerformanceReads = Json.reads[Performance]

  def createFromJson(json: JsValue): Performance = json.as[Performance]

  implicit val getSRResult = GetResult(r =>
    Performance(Some(r.nextInt()),Some(r.nextInt()),Some(r.nextInt()),
      Some(Option(r.nextString).getOrElse("")),r.nextString(),r.nextDouble)
  )
}
package model

import play.api.libs.json.{JsValue, Json}

case class GetNameResponse(id: Option[Int], name: String,extraDetails: Option[String] = None) {
  implicit val implicitGetNameResponseWrites = Json.writes[GetNameResponse]
  def toJson: JsValue = Json.toJson(this)
}

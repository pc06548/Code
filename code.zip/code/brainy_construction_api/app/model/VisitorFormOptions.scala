package model

import play.api.libs.json.{JsValue, Json}

case class VisitorFormOptions(
                               typeOfProperties:List[String],
                               budget:List[String],
                               salaryRange:List[String],
                               projectInterestedIn:List[String],
                               possessionExpected:List[String],
                               purpose:List[String],
                               ageRange:List[String],
                               heardFrom:List[String],
                               occupation:List[String],
                               loanStatus:List[String]
                             ){
  implicit val implicitWrites = Json.writes[VisitorFormOptions]
  def toJson: JsValue = Json.toJson(this)
}

object VisitorFormOptions {
  def default = VisitorFormOptions(
    List("1 BHK","2 BHK", "2.5 BHK","3 BHK","4+ BHK","Row House","Pent house"),
    List("20L","20 to 30L", "30 to 40L","40 to 50L","50 to 70L","70L to 1CR","1CR+"),
    List("5L","5 to 8L", "8 to 12L","12 to 15L","15 to 20L","20L+","Do not want to specify"),
    List("All available"),
    List("Immediate","1 year", "2 years","3+ years","Do not want to specify"),
    List("Own Stay","Investment", "Do not want to specify"),
    List("20 to 25","25 to 30", "30 to 35","35 to 50","50+","Do not want to specify"),
    List("Friend","News paper", "Website","Online","Event","Do not want to specify"),
    List("Government Job","Private Job","Business", "Self Employed","Professional","Other","Do not want to specify"),
    List("Loan","Without Loan", "Do not want to specify")
  )
}
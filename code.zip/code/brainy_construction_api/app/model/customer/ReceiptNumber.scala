package model.customer

import model.VoucherNumber
import slick.jdbc.GetResult

case class ReceiptNumber(companyId: Int, lastModified: String, receiptNumber: String){
  def extractReceiptNumber = {
    receiptNumber match {
      case ReceiptNumber.regx(company, number, oldYear,newYear) => number.toInt
      case _ => 0
    }
  }
  def extractCompanyAbbrevation = {
    receiptNumber match {
      case ReceiptNumber.regx(company, number, oldYear,newYear) => company
      case _ => ""
    }
  }
  def extractYear = {
    receiptNumber match {
      case ReceiptNumber.regx(company, number, oldYear,newYear) => s"${oldYear}-${newYear}"
      case _ => ""
    }
  }
}

object ReceiptNumber {
  implicit val getResult = GetResult(r => ReceiptNumber(r.nextInt(),r.nextString,r.nextString()))

  val regx = VoucherNumber.regx
  def checkIfVocherNumberValid(inputString : String) = {
    regx.findFirstIn(inputString) match {
      case Some(_) => true
      case None => false
    }
  }

}
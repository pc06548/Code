package model.customer

import play.api.libs.json.Json

case class FlatDetails(id:Option[Int],
                       projectId: Int,
                       buildingName: Option[String],
                       flatNumber: Option[String],
                       flatDetails: Option[String]){
  implicit val implicitFlatDetailsWrites = Json.writes[FlatDetails]
}

object FlatDetails {
  implicit val implicitFlatDetailsReads = Json.reads[FlatDetails]
}

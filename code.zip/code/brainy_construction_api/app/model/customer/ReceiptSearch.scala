package model.customer

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class ReceiptSearch(id:Int,
                         receiptNumber: String,
                         name:String,
                         buildingName:String,
                         flatNumber:String,
                         flatDetails:String,
                         receiptTotalAmount:Double,
                         isTemporary:Boolean){
  implicit val implicitReceiptSearchWrites = Json.writes[ReceiptSearch]

  def toJson: JsValue = Json.toJson(this)
}


object ReceiptSearch {
  implicit val getInvoiceSearchResult = GetResult(r =>
    ReceiptSearch(r.nextInt(),r.nextString(),r.nextString(),r.nextString(),r.nextString(),
      r.nextString(),r.nextDouble(),r.nextBoolean())
  )
}

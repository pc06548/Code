package model.customer

import model.invoices.InvoiceDetails
import play.api.libs.json.{JsValue, Json}

case class SaveExtraWorkInvoice(id: Option[Int],
                       invoiceNumber : String,
                                subject:Option[String],
                       amountBeforeTax: Double,
                       cgst: Double,
                       sgst: Double,
                       cgstPercentage: Double,
                       sgstPercentage: Double,
                       discount:Option[Double] = Some(0),
                       totalAmount: Double,
                       invoiceDate: String= "",
                       createdDate: String = "",
                       lastUpdated: Option[String],
                       gstn: Option[String] ,
                       remark: Option[String],
                       imageRef : Option[List[String]],
                       projectId: Int,
                       companyId: Int,
                       customerId: Int,
                       details: Seq[InvoiceDetails],
                       isTemporary:Option[Boolean],
                       amountPaid: Option[Double] = None) {

  private implicit val implicitInvoiceDetailsWrites = Json.writes[InvoiceDetails]
  private implicit val implicitInvoiceWrites = Json.writes[SaveExtraWorkInvoice]

  def toJson: JsValue = Json.toJson(this)
}

object SaveExtraWorkInvoice {
  private implicit val implicitIDReads = Json.reads[InvoiceDetails]
  private implicit val implicitInvoiceReads = Json.reads[SaveExtraWorkInvoice]

  def createFromJson(invoiceJson: JsValue): SaveExtraWorkInvoice = invoiceJson.as[SaveExtraWorkInvoice]
}


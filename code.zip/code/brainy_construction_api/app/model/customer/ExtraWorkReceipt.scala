package model.customer

import play.api.libs.json.{JsValue, Json}

case class ExtraWorkReceipt(id: Option[Int],
                   customerId: Int,
                   receiptNumber:String,
                   dateCreated: String,
                   paymentRefNumber:Option[String],
                   paymentDate: String,
                   bankName: Option[String],
                   mode: String,
                   remarks: Option[String] ,
                   amountBeforeTax:Double,
                   receiptTotalAmount:Double,
                   isTemporary:Option[Boolean],
                   extraWorkInvoiceId:Int,
                   subject:Option[String],
                   cgst: Double,
                   sgst: Double,
                   cgstPercentage: Double,
                   sgstPercentage: Double,
                   details : Seq[ExtraWorkReceiptDetail] = Seq.empty[ExtraWorkReceiptDetail]) {

  private implicit val implicitRDWrites = Json.writes[ExtraWorkReceiptDetail]
  private implicit val implicitRWrites = Json.writes[ExtraWorkReceipt]

  def toJson: JsValue = Json.toJson(this)
}

case class ExtraWorkReceiptDetail(id : Option[Int],
                                  receiptId:Option[Int],
                                  description: String = "",
                                  unit: String = "",
                                  quantity: Double = 0.0,
                                  rate: Double = 0.0,
                                  discount: Double = 0.0,
                                  amount: Double = 0.0)

object ExtraWorkReceipt {

  private implicit val implicitRDReads = Json.reads[ExtraWorkReceiptDetail]
  private implicit val implicitRReads = Json.reads[ExtraWorkReceipt]

  def createFromJson(json: JsValue): ExtraWorkReceipt = json.as[ExtraWorkReceipt]

}




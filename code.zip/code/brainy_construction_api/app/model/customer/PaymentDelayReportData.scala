package model.customer

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import utils.JsonImplicites._
import config.ScalaHelpers._

case class PaymentDelayReport(customer: Option[Customer],
                              amountTotal:Double,
                              sgstTotal:Double,
                              cgstTotal:Double,
                              interestTotal:Double,
                              totalAmount: Double,
                              totalDelayInDays:Int,
                              details : Seq[PaymentDelayReportData] = Seq.empty[PaymentDelayReportData]) {

  private implicit val implicitPaymentDelayReportDataWrites = Json.writes[PaymentDelayReportData]
  private implicit val implicitPaymentDelayReportWrites = Json.writes[PaymentDelayReport]

  def toJson: JsValue = Json.toJson(this)
}

object PaymentDelayReport {
  def create(customer: Option[Customer],
             details : Seq[PaymentDelayReportData]= Seq.empty[PaymentDelayReportData]) = {
    val totals: (Double, Double,Double,Double,Double,Int) = details.foldLeft((0.0,0.0,0.0,0.0,0.0,0)){
      (totals,detail) => {
        (
          totals._1 + detail.amount,
          totals._2 + detail.sgst,
          totals._3 + detail.cgst,
          totals._4 + detail.interest,
          totals._5 + detail.totalAmount,
          totals._6 + detail.delayInDays
        )
      }
    }
    PaymentDelayReport(customer,totals._1.roundTo2(),totals._2.roundTo2(),totals._3.roundTo2(),totals._4.roundTo2(),
      totals._5.roundTo2,totals._6,details)
  }
}
case class PaymentDelayReportData(receiptNumber:String,
                                   dateCreated: String,
                                   content: String,
                                   amount: Double,
                                   sgst: Double,
                                   sgstPercentage: Double,
                                   cgst: Double,
                                   cgstPercentage: Double,
                                   totalAmount: Double,
                                  paymentDate: String,
                                  mode: String,
                                  paymentRefNumber:Option[String],
                                  dueDate:String,
                                  delayInDays:Int,
                                  interest:Double,
                                 )

object PaymentDelayReportData {

  implicit val getResult = GetResult(r =>
    PaymentDelayReportData(r.nextString(),r.nextString(),r.nextString(),
      r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),
      r.nextString(),r.nextString(),r.nextStringOption(),r.nextString(), r.nextInt(),r.nextDoubleOption().getOrElse(0.0))
  )

}




package model.customer

import model.{BankDetails, Project}
import play.api.libs.json.{JsValue, Json}
import utils.JsonImplicites._

case class DefaultDemandLetter(project: Project,
                               demands: Seq[DefaultDemand]
                       ) {
  def toJson: JsValue = Json.toJson(this)

}

case class DefaultDemand(id: Option[Int],
                         companyId:Int,
                         projectId: Int,
                         detail: String,
                         percentage:Double,
                         isComplated:Boolean = false,
                         progressImages:Option[List[String]] = None) {
  def toJson: JsValue = Json.toJson(this)
}


object DefaultDemand {
  private implicit val implicitDLDReads = Json.reads[DefaultDemand]
  def createFromJson(dlJson: JsValue): DefaultDemand = dlJson.as[DefaultDemand]
}
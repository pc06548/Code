package model.customer

import play.api.libs.json.{JsValue, Json}

case class Receipt(id: Option[Int],
                   customerId: Int,
                   receiptNumber:String,
                   dateCreated: String,
                   paymentRefNumber:Option[String],
                   paymentDate: String,
                   bankName: Option[String],
                   mode: String,
                   remarks: Option[String] ,
                   receiptTotalAmount:Double,
                   isTemporary:Option[Boolean],
                   details : Seq[ReceiptDetail] = Seq.empty[ReceiptDetail]) {

  private implicit val implicitRDWrites = Json.writes[ReceiptDetail]
  private implicit val implicitRWrites = Json.writes[Receipt]

  def toJson: JsValue = Json.toJson(this)
}

case class ReceiptDetail(id : Option[Int],
                         receiptId:Option[Int],
                         content: String,
                         amount: Double,
                         landDeduction : Double,
                         taxableAmount : Double,
                         sgst: Double,
                         sgstPercentage: Double,
                         cgst: Double,
                         cgstPercentage: Double,
                         totalAmount: Double)

object Receipt {

  private implicit val implicitRDReads = Json.reads[ReceiptDetail]
  private implicit val implicitRReads = Json.reads[Receipt]

  def createFromJson(json: JsValue): Receipt = json.as[Receipt]

}




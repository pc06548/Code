package model.customer

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class DemandLetterSearch(customerId : Int,
                              customerName : String,
                              projectName:String,
                              buildingName: String,
                              flatNumber: String,
                              flatDetails: String,
                              bankName: String,
                              netAmount: Double,
                              agreementDate: String,
                              saledeedDate: String,
                              dueDate:String,
                              AmountPaid: Double,
                              delayInDays: Option[Int] = None,
                              pendingAmount: Option[Double] = None
                             ) {

  private implicit val implicitWrites = Json.writes[DemandLetterSearch]
  def toJson: JsValue = Json.toJson(this)
}

object DemandLetterSearch {
  private implicit val implicitReads = Json.reads[DemandLetterSearch]

  def createFromJson(json: JsValue): DemandLetterSearch = json.as[DemandLetterSearch]

  implicit val getResult = GetResult(r => DemandLetterSearch(r.nextInt(),r.nextString,r.nextString()
    ,r.nextString,r.nextString(),r.nextString,r.nextString(),r.nextDouble(),
    r.nextStringOption().getOrElse(""),r.nextStringOption().getOrElse(""),
    r.nextStringOption().getOrElse(""),r.nextDouble()))

}

package model.customer

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class Customer(id: Option[Int],
                    companyId: Int,
                    ownerDetails:CoOwnerDetails,
                    projectDetails:FlatDetails,
                    agreementDetails: AgreementDetails,
                    saledeedDetails: SaledeedDetails,
                    possessionDetails: PossessionDetails,
                    bankDetails: BankReferenceDetails,
                    additionalNotes: Option[String],
                    customerReferredBy: Option[CustomerReferredBy],
                    coOwners : Option[Seq[CoOwnerDetails]] = None) {

  private implicit val implicitProjectDetailsWrites = Json.writes[FlatDetails]
  private implicit val implicitAgreementDetailsWrites = Json.writes[AgreementDetails]
  private implicit val implicitSaledeedDetailsWrites = Json.writes[SaledeedDetails]
  private implicit val implicitPossessionDetailsWrites = Json.writes[PossessionDetails]
  private implicit val implicitBankDetailsWrites = Json.writes[BankReferenceDetails]
  private implicit val implicitCoOwnerDetailsWrites = Json.writes[CoOwnerDetails]
  private implicit val implicitCustomerReferredByWrites = Json.writes[CustomerReferredBy]
  private implicit val implicitCustomerWrites = Json.writes[Customer]

  def toJson: JsValue = Json.toJson(this)
}

case class CoOwnerDetails(id: Option[Int],
                          name: String,
                          phoneNumber1: Option[String],
                          phoneNumber2: Option[String],
                          email: Option[String],
                          address: Option[String],
                          dateOfBirth : Option[String],
                          aadharNbr : Option[String],
                          pan : Option[String],
                          maritalStatus:Option[String],
                          anniversaryDate:Option[String],
                          occupation:Option[String],
                          customerId: Option[Int])

case class CustomerReferredBy(referredByName : Option[String] ,
                              referredByAddress : Option[String]  ,
                              referredByPhone : Option[String] ,
                             referredByEmail : Option[String] )

case class AgreementDetails(agreementDate: Option[String],
                             agreementNumber : Option[String],
                             agreementCost:Option[Double],
                            approvedLoan: Option[Double],
                            cgstPercentage: Option[Double],
                            sgstPercentage:Option[Double])

case class SaledeedDetails(saledeedNumber : Option[String],
                           saledeedDate: Option[String])

case class PossessionDetails(possessionReceiptNumber: Option[String],
                             possessionDate : Option[String])

case class BankReferenceDetails(bankName:Option[String],
                                bankRepresentativeName:Option[String],
                                phoneNumber:Option[String],
                                email:Option[String])

object Customer {
  private implicit val implicitProjectDetailsReads = Json.reads[FlatDetails]
  private implicit val implicitAgreementDetailsReads = Json.reads[AgreementDetails]
  private implicit val implicitSaledeedDetailsReads = Json.reads[SaledeedDetails]
  private implicit val implicitPossessionDetailsReads = Json.reads[PossessionDetails]
  private implicit val implicitBankDetailsReads = Json.reads[BankReferenceDetails]
  private implicit val implicitCoOwnerDetailsReads = Json.reads[CoOwnerDetails]
  private implicit val implicitCustomerReferredByReads = Json.reads[CustomerReferredBy]
  private implicit val implicitCustomerReads = Json.reads[Customer]

  def createFromJson(json: JsValue): Customer = json.as[Customer]

  implicit val getCustomerResult = GetResult(r =>
    Customer(
      r.nextIntOption(),r.nextInt(),
      CoOwnerDetails(None,r.nextString(),r.nextStringOption(),r.nextStringOption(),r.nextStringOption()
        ,r.nextStringOption(),r.nextStringOption(),r.nextStringOption(),r.nextStringOption(),r.nextStringOption(),
        r.nextStringOption(),r.nextStringOption(),None),
      FlatDetails(r.nextIntOption(),r.nextInt(),r.nextStringOption(),r.nextStringOption(),r.nextStringOption()),
      AgreementDetails(r.nextStringOption(),r.nextStringOption(),r.nextDoubleOption(),r.nextDoubleOption(),r.nextDoubleOption(),r.nextDoubleOption()),
      SaledeedDetails(r.nextStringOption(),r.nextStringOption()),
      PossessionDetails(r.nextStringOption(),r.nextStringOption()),
      BankReferenceDetails(r.nextStringOption(),r.nextStringOption(),r.nextStringOption(),r.nextStringOption()),
      r.nextStringOption(),
      Option(CustomerReferredBy(r.nextStringOption(),r.nextStringOption(),r.nextStringOption(),r.nextStringOption()))
    )
  )
}

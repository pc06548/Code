package model.customer

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class ExtraWorkReceiptSearch(id:Int,
                         receiptNumber: String,
                         name:String,
                         subject:Option[String],
                         buildingName:String,
                         flatNumber:String,
                         flatDetails:String,
                         receiptTotalAmount:Double,
                         isTemporary:Boolean){
  implicit val implicitExtraWorkReceiptSearchWrites = Json.writes[ExtraWorkReceiptSearch]

  def toJson: JsValue = Json.toJson(this)
}


object ExtraWorkReceiptSearch {
  implicit val getInvoiceSearchResult = GetResult(r =>
    ExtraWorkReceiptSearch(r.nextInt(),r.nextString(),r.nextString(),
      Some(r.nextStringOption().getOrElse("")),r.nextString(),r.nextString(),
      r.nextString(),r.nextDouble(),r.nextBoolean())
  )
}

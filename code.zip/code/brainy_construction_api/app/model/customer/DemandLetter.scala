package model.customer

import config.ScalaHelpers._
import model.{BankDetails, Project}
import play.api.libs.json.{JsValue, Json}

case class DemandLetter(project: Project,
                        customer: Customer,
                               amountTotal: Double = 0.0,
                               landDeductionTotal : Double = 0.0,
                               taxableAmountTotal : Double = 0.0,
                               cgstTotal: Double = 0.0,
                               sgstTotal: Double = 0.0,
                               netAmountTotal: Double = 0.0,
                               receivedAmount:Double = 0.0,
                        balanceAmount:Double = 0.0,
                               demands: Seq[CustomerDemand]
                              ) {

  implicit val implicitBankDetailsWrites = Json.writes[BankDetails]

  implicit val implicitProjectWrites = Json.writes[Project]

  private implicit val implicitProjectDetailsWrites = Json.writes[FlatDetails]
  private implicit val implicitAgreementDetailsWrites = Json.writes[AgreementDetails]
  private implicit val implicitSaledeedDetailsWrites = Json.writes[SaledeedDetails]
  private implicit val implicitPossessionDetailsWrites = Json.writes[PossessionDetails]
  private implicit val implicitBankRefDetailsWrites = Json.writes[BankReferenceDetails]
  private implicit val implicitCoOwnerDetailsWrites = Json.writes[CoOwnerDetails]
  private implicit val implicitCustomerReferredByWrites = Json.writes[CustomerReferredBy]
  private implicit val implicitCustomerWrites = Json.writes[Customer]

  implicit val implicitDLDWrites = Json.writes[CustomerDemand]
  implicit val implicitDLWrites = Json.writes[DemandLetter]

  def toJson: JsValue = Json.toJson(this)

}

case class CustomerDemand(id: Option[Int],
                          companyId:Int,
                          projectId: Int,
                          customerId:Int,
                          detail: String,
                          dueDate: String,
                          amount:Double = 0.0,
                          landDeduction :Double = 0.0,
                          taxableAmount : Double = 0.0,
                          cgstPercentage: Double = 0.0,
                          cgst: Double = 0.0,
                          sgstPercentage: Double = 0.0,
                          sgst: Double = 0.0,
                          interest:Option[Double],
                          netAmount: Double = 0.0,
                          receivedAmount: Option[Double] = Some(0.0),
                          balanceAmount: Option[Double] = None,
                          derivedFrom:Option[Int]
                        ) {
  implicit val implicitDLDWrites = Json.writes[CustomerDemand]
  def toJson: JsValue = Json.toJson(this)
}


object CustomerDemand {
  private implicit val implicitDLDReads = Json.reads[CustomerDemand]
  def createFromJson(dlJson: JsValue): CustomerDemand = dlJson.as[CustomerDemand]

  def createFromDefaultDemand(defaultDemand: DefaultDemand,customers : Seq[Customer],dueDate:String):Seq[CustomerDemand] = {
    defaultDemand.id match {
      case Some(_) => {
        import defaultDemand._
        customers.map(customer => {
          val cgstPercentage:Double =  customer.agreementDetails.cgstPercentage.getOrElse(0)
          val sgstPercentage:Double = customer.agreementDetails.sgstPercentage.getOrElse(0)
          val agreementCost:Double = customer.agreementDetails.agreementCost.getOrElse(0)
          val amount = ((agreementCost * defaultDemand.percentage)/100).roundTo2()
          val landDeduction:Double = (amount / 3).roundTo2
          val taxableAmount:Double = (amount - landDeduction).roundTo2
          val cgst :Double= ((taxableAmount * cgstPercentage)/100).roundTo2
          val sgst:Double = ((taxableAmount * sgstPercentage)/100).roundTo2
          val netAmount: Double = (amount + cgst + sgst).roundTo2()

          CustomerDemand(
            None,
            companyId,
            projectId,
            customer.id.get,
            detail,
            dueDate,
            amount,
            landDeduction,
            taxableAmount,
            cgstPercentage,
            cgst,
            sgstPercentage,
            sgst,
            Some(0),
            netAmount,
            None,
            Some(netAmount),
            id
          )
        })
      }
      case None => Seq.empty[CustomerDemand]
    }
  }

  def createFromDefaultDemand(defaultDemand: Seq[DefaultDemand],customer : Customer,dueDate:String):Seq[CustomerDemand] = {
    defaultDemand.flatMap(d => createFromDefaultDemand(d,Seq(customer),dueDate))
  }
}
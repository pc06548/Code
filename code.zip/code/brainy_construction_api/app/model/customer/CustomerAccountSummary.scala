package model.customer

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult
import utils.JsonImplicites._

case class CustomerAccountSummary(customer: Option[Customer],
                                   details:Seq[CustomerAccountSummaryData]) {

  private implicit val implicitCustomerAccountSummaryDataWrites = Json.writes[CustomerAccountSummaryData]
  private implicit val implicitAccountSummaryWrites = Json.writes[CustomerAccountSummary]
  def toJson: JsValue = Json.toJson(this)
}

case class CustomerAccountSummaryData(receiptNumber:String,
                                      dateCreated: String,
                                      content: String,
                                      amount: Double,
                                      cgst: Double,
                                      cgstPercentage: Double,
                                      sgst: Double,
                                      sgstPercentage: Double,
                                      totalAmount: Double,
                                      mode: String,
                                      paymentRefNumber:Option[String],
                                      paymentDate: String,
                                      bankName: Option[String],
                                      customerId: Int,
                                      isTemporary:Option[Boolean]){

}
object CustomerAccountSummaryData {
  implicit val getSRResult = GetResult(r =>
    CustomerAccountSummaryData(r.nextString, r.nextString,r.nextString(),
      r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),r.nextDouble(),
      r.nextString(),
      Some(r.nextStringOption().flatMap(s => if(s.trim.isEmpty) None else Some(s) ).getOrElse("-")),
      r.nextString(),r.nextStringOption(),r.nextInt(),r.nextBooleanOption()
    )
  )
}
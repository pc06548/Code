package model

import slick.jdbc.GetResult

case class ExpenseVoucherData(companyId:Option[Int],
                       projectId: Option[Int],
                       employeeId: Option[Int],
                       name: String,
                       amount: Double)

object ExpenseVoucherData {
  implicit val getResult = GetResult(r =>
    ExpenseVoucherData(Some(r.nextInt()),r.nextIntOption(),r.nextIntOption(),
      r.nextString(), r.nextDouble())
  )

}

package model.consultant

import java.sql.ResultSet
import utils.JsonImplicites._
import model.{BankDetails, BasicDetails}
import play.api.libs.json.{JsValue, Json}

case class Consultant(id: Option[Int],
                      companyId :Option[Int],
                      name: String,
                      basicDetails: BasicDetails,
                      consultantType: Option[String],
                      serviceTaxNbr: Option[String],
                      gstNbr: Option[String],
                      pfCode: Option[String],
                      labourLicenseNbr: Option[String],
                      ownerName:Option[String],
                      ownerPhoneNumber:Option[String],
                      bankDetails: Option[BankDetails]) {

  private implicit val implicitBankDetailsWrites = Json.writes[BankDetails]
  private implicit val implicitConsultantWrites = Json.writes[Consultant]

  def toJson: JsValue = Json.toJson(this)
}

object Consultant {

  private implicit val implicitBankDetailsReads = Json.reads[BankDetails]
  private implicit val implicitConsultantReads = Json.reads[Consultant]

  def createFromJson(consultantJson: JsValue): Consultant = consultantJson.as[Consultant]

  def getDepartment(rs: ResultSet) : String = {
    rs.getString("DEPARTMENT")
  }

  def getIdName(rs: ResultSet) : (Int,String) = {
    (rs.getInt("ID"),rs.getString("NAME"))
  }
}
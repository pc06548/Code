package model

import model.contractor.WeeklyStatusReport
import play.api.libs.json.{JsValue, Json, OWrites, Reads}
import slick.jdbc.GetResult

case class Transaction(id: Option[Int],
                       companyId:Option[Int],
                       projectId: Option[Int],
                       employeeId: Option[Int],
                       name: String,
                       typeOfTransaction: String,
                       amount: Double,
                       transactionDate: String,
                       paymentMode: String,
                       description: Option[String],
                       balanceAmount: Option[Double] = None
                       ) {

  require(typeOfTransaction.length == 1 && (typeOfTransaction == "C" | typeOfTransaction == "D"))

  private implicit val implicitTransactionWrites: OWrites[Transaction] = Json.writes[Transaction]

  def toJson: JsValue = Json.toJson(this)
}

object Transaction {
  implicit val getResult = GetResult(r =>
    Transaction(Some(r.nextInt()),Some(r.nextInt()),r.nextIntOption(),r.nextIntOption(),
      r.nextString(), r.nextString,r.nextDouble(),r.nextString(),r.nextString(),
      Some(Option(r.nextString()).getOrElse("")),None))

  private implicit val implicitTransactionReads: Reads[Transaction] = Json.reads[Transaction]

  def calculateBalance(openingBalance: Double, transactions: List[Transaction]): (Double, List[Transaction]) = {

    transactions.foldLeft((openingBalance, List.empty[Transaction])) {
      (ob, t) => {
        if (t.typeOfTransaction == "C") {
          val newOb = ob._1 + t.amount
          val newList = ob._2 :+ t.copy(balanceAmount = Some(newOb))
          (newOb, newList)
        } else {
          val newOb = ob._1 - t.amount
          val newList = ob._2 :+ t.copy(balanceAmount = Some(newOb))
          (newOb, newList)
        }
      }
    }
  }

  def createFromJson(json: JsValue): Transaction = json.as[Transaction]

}

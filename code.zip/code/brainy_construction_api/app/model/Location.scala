package model

import play.api.libs.json.{JsValue, Json}

case class Location(id: Option[Int],
                    companyId: Option[Int],
                    name: String,
                    friendlyAddress: Option[String],
                    longitude:Double,
                    latitude:Double){

  implicit val implicitLocationWrites = Json.writes[Location]
  def toJson: JsValue = Json.toJson(this)
}

object Location {
  implicit val implicitLocationReads = Json.reads[Location]
  def createFromJson(companyJson: JsValue): Location = companyJson.as[Location]
}


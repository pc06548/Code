package model

case class TaxDetails(cgst: Double = 0.0,
                      sgst: Double = 0.0,
                      tds: Option[Double],
                      gstn: Option[String]) {

}

object TaxDetails {

}

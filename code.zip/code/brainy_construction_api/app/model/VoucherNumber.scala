package model

import slick.jdbc.GetResult

case class VoucherNumber(companyId: Int, lastModified: String, voucherNumber: String){
  def extractVoucherNumber = {
    voucherNumber match {
      case VoucherNumber.regx(company, number, oldYear,newYear) => number.toInt
      case _ => 0
    }
  }
  def extractCompanyAbbrevation = {
    voucherNumber match {
      case VoucherNumber.regx(company, number, oldYear,newYear) => company
      case _ => ""
    }
  }
  def extractYear = {
    voucherNumber match {
      case VoucherNumber.regx(company, number, oldYear,newYear) => s"${oldYear}-${newYear}"
      case _ => ""
    }
  }
}

object VoucherNumber {
  implicit val getResult = GetResult(r => VoucherNumber(r.nextInt(),r.nextString,r.nextString()))

  val regx = """([\w]{1,6})-([0-9]{1,5})/([0-9]{4,4})-([0-9]{2,2})""".r
  def checkIfVocherNumberValid(inputString : String) = {
    regx.findFirstIn(inputString) match {
      case Some(_) => true
      case None => false
    }
  }

}
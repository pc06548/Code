package model

case class BankDetails(bankAccountNbr: String,
                       ifscCode: String ,
                       bankName: String,
                       bankAddress: String)

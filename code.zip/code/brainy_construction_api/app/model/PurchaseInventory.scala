package model

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class PurchaseInventory(id:Option[Int],
                             companyId:Option[Int],
                             projectId:Option[Int],
                             material:String,
                             date:String,
                             purchaseOrderNumber:Option[String],
                             vehicleNumber:Option[String],
                             inTime:Option[String],
                             outTime:Option[String],
                             chalanNumber:Option[String],
                             quantity:Option[Double],
                             unit:Option[String],
                             source:Option[String],
                             receivedBy:Option[String],
                             note:Option[String],
                             transporterName:Option[String],
                             transportCharges:Option[Double],
                             hamaliCharges:Option[Double],
                             rating:Option[Double]){
  private implicit val implicitPurchaseInventoryWrites = Json.writes[PurchaseInventory]
  def toJson: JsValue = Json.toJson(this)

}

object PurchaseInventory {
  private implicit val implicitPurchaseInventoryReads = Json.reads[PurchaseInventory]

  def createFromJson(json: JsValue): PurchaseInventory = json.as[PurchaseInventory]

  implicit val getSRResult = GetResult(r =>
    PurchaseInventory(Some(r.nextInt()),Some(r.nextInt()),Some(r.nextInt()),r.nextString(),r.nextString(),
      Some(Option(r.nextString).getOrElse("")),Some(Option(r.nextString).getOrElse("")),
      Some(Option(r.nextString).getOrElse("")), Some(Option(r.nextString).getOrElse("")),
      Some(Option(r.nextString).getOrElse("")),
      Some(Option(r.nextDouble()).getOrElse(0.0)),
      Some(Option(r.nextString).getOrElse("")),
      Some(Option(r.nextString).getOrElse("")),
      Some(Option(r.nextString).getOrElse("")),
      Some(Option(r.nextString).getOrElse("")),
      Some(Option(r.nextString).getOrElse("")),
      Some(Option(r.nextDouble()).getOrElse(0.0)),
      Some(Option(r.nextDouble()).getOrElse(0.0)),
      Some(Option(r.nextDouble()).getOrElse(0.0))
    )
  )
}
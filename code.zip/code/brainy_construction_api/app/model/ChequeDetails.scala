package model

case class ChequeDetails(templateFileName:String,
                          name : String,
                          accNbr : String,
                          amountInWords : String,
                          amount : String,
                          chequeDate : String)
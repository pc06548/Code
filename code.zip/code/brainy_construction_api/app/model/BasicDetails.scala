package model

import play.api.libs.json.Json

case class BasicDetails(email: Option[String] ,
                        address: Option[String],
                        phoneNumber1: Option[String],
                        phoneNumber2: Option[String],
                        panNumber: Option[String],
                        aadharNumber: Option[String],
                        relationStartDate : Option[String]) {

  implicit val implicitBasicDetailsWrites = Json.writes[BasicDetails]
}

object BasicDetails {
  implicit val implicitBasicDetailsReads = Json.reads[BasicDetails]

  def tupled = (BasicDetails.apply _).tupled
}
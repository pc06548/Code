package model.supplier

import java.sql.ResultSet
import utils.JsonImplicites._
import model.{BankDetails, BasicDetails}
import play.api.libs.json.{JsValue, Json}

case class Supplier(id: Option[Int],
                    companyId :Option[Int],
                    name: String ,
                    basicDetails: BasicDetails,
                    supplierType: Option[String],
                    gstNbr: Option[String],
                    contactPerson: Option[String],
                    ownerName:Option[String],
                    ownerPhoneNumber:Option[String],
                    bankDetails: Option[BankDetails]) {

  private implicit val implicitBankDetailsWrites = Json.writes[BankDetails]
  private implicit val implicitSupplierWrites = Json.writes[Supplier]

  def toJson: JsValue = Json.toJson(this)
}

object Supplier {

  private implicit val implicitBankDetailsReads = Json.reads[BankDetails]
  private implicit val implicitSupplierReads = Json.reads[Supplier]

  def createFromJson(SupplierJson: JsValue): Supplier = SupplierJson.as[Supplier]

  def getSupplierType(rs: ResultSet) : String = {
    rs.getString("SUPPLIER_TYPE")
  }

  def getIdName(rs: ResultSet) : (Int,String) = {
    (rs.getInt("ID"),rs.getString("NAME"))
  }
}
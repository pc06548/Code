package model.supplier

import play.api.libs.json.{JsValue, Json}


case class PurchaseOrder(
                          id: Option[Int],
                          projectId: Int,
                          supplierId: Int,
                          grossTotal: Double,
                          vat: Double,
                          discount: Option[Double] = Some(0.0),
                          totalAmount: Double,
                          department: Option[String],
                          createdDate: Option[String],
                          deliveryDate: Option[String],
                          deliveryTime: Option[String],
                          preparedBy: Option[String],
                          paymentCondition: Option[String],
                          lastModified: Option[String],
                          status:Option[String],
                          details: Seq[PurchaseOrderDetails]
                        ) {
  private implicit val implicitPODWrites = Json.writes[PurchaseOrderDetails]
  private implicit val implicitPOWrites = Json.writes[PurchaseOrder]

  def toJson: JsValue = Json.toJson(this)

}

object PurchaseOrder {

  private implicit val implicitPODReads = Json.reads[PurchaseOrderDetails]
  private implicit val implicitPOReads = Json.reads[PurchaseOrder]

  def createFromJson(poJson: JsValue): PurchaseOrder = poJson.as[PurchaseOrder]
}

case class PurchaseOrderDetails(id: Option[Int],
                                description: String,
                                unit: Option[String],
                                quantity: Double,
                                rate: Double,
                                discount: Option[Double],
                                tax: Option[Double],
                                amount: Double,
                                remark: Option[String],
                                purchaseOrderId: Option[Int])

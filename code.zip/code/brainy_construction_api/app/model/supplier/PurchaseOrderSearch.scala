package model.supplier

import model.ApprovalStatus
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class PurchaseOrderSearch(id:Int,supplierName : String,totalAmount: Double,status:String,createdOn: String){
  private implicit val implicitPurchaseOrderSearchWrites = Json.writes[PurchaseOrderSearch]

  def toJson: JsValue = Json.toJson(this)
}

object PurchaseOrderSearch{

  implicit val getPurchaseOrderSearchResult = GetResult(r =>
    PurchaseOrderSearch(r.nextInt(), r.nextString,r.nextDouble(),Option(r.nextString()).getOrElse(ApprovalStatus.APPROVAL_PENDING),r.nextString())
  )
}
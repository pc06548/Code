package model.company

import model.BankDetails
import play.api.libs.json._
import slick.jdbc.GetResult

case class Company(id: Option[Int],
                   name: String ,
                   orgId : Option[Int],
                   address : String,
                   email : Option[String],
                   phoneNumber1: String ,
                   phoneNumber2: Option[String],
                   logo : Option[String] = Some(" "),
                   slogan: Option[String]= Some(" "),
                   startDate : Option[String]= Some(" "),
                   lastModified: Option[String]= Some(" "),
                   letterHead:Option[String] =  None,
                   footer:Option[String] = None,
                   panNumber: Option[String] ,
                   gstNbr: Option[String] ,
                   bankDetails: Option[BankDetails]) {

  implicit val implicitBankDetailsWrites = Json.writes[BankDetails]
  implicit val implicitCompanyWrites = Json.writes[Company]

  def toJson: JsValue = Json.toJson(this)

  def getAbbreviation = name.split(" ").map(_.charAt(0)).mkString
}
object Company {
  implicit val implicitBankDetailsReads = Json.reads[BankDetails]
  implicit val implicitCompanyReads = Json.reads[Company]

  def createFromJson(companyJson: JsValue): Company = companyJson.as[Company]

  implicit val getVoucherResult = GetResult(r =>
    Company(r.nextIntOption(), r.nextString, r.nextIntOption(),r.nextString,
      Some(Option(r.nextString()).getOrElse("")),r.nextString(), Some(Option(r.nextString()).getOrElse("")),
      Some(Option(r.nextString()).getOrElse("")), Some(Option(r.nextString()).getOrElse("")), Some(Option(r.nextString()).getOrElse("")),
      Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),Some(Option(r.nextString()).getOrElse("")),
      Some(Option(r.nextString()).getOrElse("")), Some(Option(r.nextString()).getOrElse("")),
      Some(BankDetails(Option(r.nextString()).getOrElse(""), Option(r.nextString()).getOrElse(""),Option(r.nextString()).getOrElse(""),
        Option(r.nextString()).getOrElse("")))
    )
  )
}
package model

import java.sql.Date

import play.api.libs.json.Json

// @TODO change id to option and change date to sql date
case class User(id: Int, name: String, mobileNumber: String,
                emailId: String = "",
                createTimestamp: Date,
                updateTimestamp: Date,
                loginId: Int = -10,
                userName:Option[String] = None,
                isActive:Option[String] = None){
  private implicit val implicitUserWrites = Json.writes[User]
  def toJson = Json.toJson(this)
}

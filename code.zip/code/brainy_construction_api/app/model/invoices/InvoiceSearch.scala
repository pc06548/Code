package model.invoices

import config.DateUtil
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class InvoiceSearch(id:Int, name : String, invoiceNumber : String, totalAmount: Double,category:Option[String], amountPaid: Double,
                         invoiceDate: String, imgRef:List[String], isTemporary:Boolean, creditDays : Option[Int] = None){
  implicit val implicitInvoiceSearchWrites = Json.writes[InvoiceSearch]

  def toJson: JsValue = Json.toJson(this)
}
object InvoiceSearch{
  val INVOICE_STATUS_UNPAID = "unpaid"
  val INVOICE_STATUS_PAID = "paid"

  implicit val getInvoiceSearchResult = GetResult(r => {

    val invoice = InvoiceSearch(r.nextInt(), r.nextString, r.nextString,
      r.nextDouble(),r.nextStringOption(),r.nextDouble(),Option(r.nextString).getOrElse(""),
      Option(r.nextString).map(_.split(",").toList).getOrElse(List.empty[String]),r.nextBoolean())

    val daysDiff = DateUtil.getDiffernceInDays(invoice.invoiceDate,DateUtil.today)
    val amountPending = invoice.totalAmount - invoice.amountPaid
    val credit = (daysDiff, amountPending) match {
      case _ if (daysDiff > 0 && amountPending > 0) => daysDiff
      case _ => 0
    }
    invoice.copy(creditDays = Some(credit))
  }
  )
}
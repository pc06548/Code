package model.invoices

import play.api.libs.json.{JsValue, Json}

case class SaveOtherInvoice(id: Option[Int],
                            invoiceNumber : String,
                            amountBeforeTax: Double,
                            cgst: Double,
                            sgst: Double,
                            cgstPercentage: Double,
                            sgstPercentage: Double,
                            totalAmount: Double,
                            invoiceDate: String,
                            createdDate: String,
                            lastUpdated: Option[String],
                            gstn: Option[String],
                            remark: Option[String],
                            imageRef : Option[List[String]],
                            projectId: Option[Int],
                            companyId: Int,
                            categoryId: Int,
                            personalDetails:OtherInvoicePersonDetails,
                            details: Seq[InvoiceDetails],
                            isTemporary:Option[Boolean] ,
                            amountPaid: Option[Double] = None) {

private implicit val implicitInvoiceDetailsWrites = Json.writes[InvoiceDetails]
private implicit val implicitInvoiceOtherPersonDetailsWrites = Json.writes[OtherInvoicePersonDetails]
private implicit val implicitInvoiceWrites = Json.writes[SaveOtherInvoice]

def toJson: JsValue = Json.toJson(this)

}

case class OtherInvoicePersonDetails(name : String,
                                     address : Option[String],
                                     phoneNumber1 : Option[String],
                                     phoneNumber2 : Option[String])

object SaveOtherInvoice {
  private implicit val implicitIDReads = Json.reads[InvoiceDetails]
  private implicit val implicitOtherInvoicePersonDetailsReads = Json.reads[OtherInvoicePersonDetails]
  private implicit val implicitInvoiceReads = Json.reads[SaveOtherInvoice]

  def createFromJson(invoiceJson: JsValue): SaveOtherInvoice = invoiceJson.as[SaveOtherInvoice]
}
package model.invoices

import play.api.libs.json.{JsValue, Json}

case class SaveInvoice(id: Option[Int],
                       invoiceNumber : String,
                       amountBeforeTax: Double,
                       cgst: Double,
                       sgst: Double,
                       cgstPercentage: Double,
                       sgstPercentage: Double,
                       totalAmount: Double,
                       invoiceDate: String= "",
                       createdDate: String = "",
                       lastUpdated: Option[String],
                       gstn: Option[String] ,
                       remark: Option[String],
                       imageRef : Option[List[String]],
                       docRefNumber: Option[String],
                       projectId: Option[Int],
                       companyId: Int,
                       entityId: Int,
                       details: Seq[InvoiceDetails],
                       isTemporary:Option[Boolean],
                       amountPaid: Option[Double] = None) {

  private implicit val implicitInvoiceDetailsWrites = Json.writes[InvoiceDetails]
  private implicit val implicitInvoiceWrites = Json.writes[SaveInvoice]

  def toJson: JsValue = Json.toJson(this)
}

object SaveInvoice {
  private implicit val implicitIDReads = Json.reads[InvoiceDetails]
  private implicit val implicitInvoiceReads = Json.reads[SaveInvoice]

  def createFromJson(invoiceJson: JsValue): SaveInvoice = invoiceJson.as[SaveInvoice]
}


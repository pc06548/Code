package model.invoices

case class InvoiceDetails(id: Option[Int] = None,
                          description: String = "",
                          unit: String = "",
                          quantity: Double = 0.0,
                          rate: Double = 0.0,
                          discount: Double = 0.0,
                          amount: Double = 0.0,
                          invoiceId: Option[Int])

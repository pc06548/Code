package model.contractor

import play.api.libs.json.{JsValue, Json}

case class PaymentSchedule(id: Option[Int],
                           projectId: Int,
                           contractorId: Int,
                           totalAmount: Double,
                           workOrderNumber: Option[String],
                           created_on: Option[String],
                           department: Option[String],
                           lastModified: Option[String],
                           details: Seq[PaymentScheduleDetails]){
  private implicit val implicitDetailsWrites = Json.writes[PaymentScheduleDetails]
  private implicit val implicitPsWrites = Json.writes[PaymentSchedule]

  def toJson: JsValue = Json.toJson(this)
}

case class PaymentScheduleDetails(id: Option[Int], workStage: String, percentage: Double, amount: Double, paymentScheduleId : Option[Int])

object PaymentSchedule {
  private implicit val implicitPSDReads = Json.reads[PaymentScheduleDetails]
  private implicit val implicitPSReads = Json.reads[PaymentSchedule]

  def createFromJson(wsrJson: JsValue): PaymentSchedule = wsrJson.as[PaymentSchedule]

}
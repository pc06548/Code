package model.contractor

import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class PaymentScheduleSearch(id:Int,contractorName : String, workOrderNumber : String,totalAmount: Double,createdOn: String){
  private implicit val implicitPaymentScheduleSearchWrites = Json.writes[PaymentScheduleSearch]

  def toJson: JsValue = Json.toJson(this)
}
object PaymentScheduleSearch{

  implicit val getPaymentScheduleSearchResult = GetResult(r =>
    PaymentScheduleSearch(r.nextInt(), r.nextString, r.nextString,
      r.nextDouble(),r.nextString())
  )
}
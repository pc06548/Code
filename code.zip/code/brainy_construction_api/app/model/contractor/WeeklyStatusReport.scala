package model.contractor

import config.DateUtil
import play.api.libs.json.{JsValue, Json}
import slick.jdbc.GetResult

case class WeeklyStatusReport(id: Option[Int],
                              projectId: Int,
                              reportCreatedDate: Option[String],
                              startDate: String,
                              endDate: String,
                              createdBy: Option[String],
                              details: Seq[WSRDetails] = Seq.empty[WSRDetails]){

  implicit val implicitSaveWsrResourceWrites = Json.writes[WsrResource]
  implicit val implicitSaveWSRDetailsWrites = Json.writes[WSRDetails]
  implicit val implicitWeeklyStatusReportWrites = Json.writes[WeeklyStatusReport]
  def toJson: JsValue = Json.toJson(this)
}

object WeeklyStatusReport {

  implicit val implicitWSRDetailsResouceReads = Json.reads[WsrResource]
  implicit val implicitWSRDetailsReads = Json.reads[WSRDetails]
  implicit val implicitWSRReads = Json.reads[WeeklyStatusReport]

  def createFromJson(wsrJson: JsValue): WeeklyStatusReport = wsrJson.as[WeeklyStatusReport]

  implicit val getResult = GetResult(r =>
    WeeklyStatusReport(Some(r.nextInt()),r.nextInt(), Some(Option(r.nextString()).getOrElse("")), r.nextString,r.nextString,
      Some(Option(r.nextString()).getOrElse("")))
  )
}

case class WSRDetails(id: Option[Int],
                      contractorId: Int,
                      deptName: Option[String],
                      typeOfWork: Option[String],
                      wsrId: Int,
                      contractorName:Option[String] = None,
                      resources: Seq[WsrResource] = List.empty[WsrResource]){

  implicit val implicitSaveWsrResourceWrites = Json.writes[WsrResource]
  implicit val implicitSaveWSRDetailsWrites = Json.writes[WSRDetails]

  def toJson: JsValue = Json.toJson(this)
}

case class WsrResource(id: Option[Int],
                       date: String,
                       count: Double,
                       wsrDetailId: Option[Int],
                       dayOfWeek:Option[String] = None)

object WsrResource {
  val softByDate =  (w1: WsrResource, w2: WsrResource) => {
    DateUtil.dateFormat.parse(w1.date).before(DateUtil.dateFormat.parse(w2.date))
  }
}

object WSRDetails {

  implicit val implicitWSRDetailsResouceReads = Json.reads[WsrResource]
  implicit val implicitWSRDetailsReads = Json.reads[WSRDetails]

  def createFromJson(wsrJson: JsValue): WSRDetails = wsrJson.as[WSRDetails]

  implicit val getWSRDetailsResult = GetResult(r =>
    WSRDetails(r.nextIntOption(),r.nextInt(),r.nextStringOption(),r.nextStringOption(),
      r.nextInt(),r.nextStringOption())
  )
}

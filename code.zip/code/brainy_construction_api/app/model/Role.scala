package model

import play.api.libs.json.{JsValue, Json}

import scala.util.Try

case class Role(id: Int, name: String){
  implicit val implicitRoleWrites = Json.writes[Role]
  def toJson = Json.toJson(this)
}

case class RoleMapping(roleId: Int, loginId: Int, companyId: Int){
  implicit val implicitRoleMappingWrites = Json.writes[RoleMapping]
  def toJson = Json.toJson(this)
}

case class GetRoleMapping(roleId: Int, roleName: String, companyId: Int, companyName: String){
  implicit val implicitGetRoleMappingWrites = Json.writes[GetRoleMapping]
  def toJson = Json.toJson(this)
}


case class GetRoleMappingDetail(roleId: Int, roleName: String, companyId: Int, companyName: String, userName: String, userId: Int, loginId: Int)

case class GetRoleMappings(userId: Int,userName: String, loginId: Int,companyId: Int, companyName: String,  roles: List[Role]){

  implicit val implicitRoleWrites = Json.writes[Role]
  implicit val implicitGetRoleMappingWrites = Json.writes[GetRoleMappings]
  def toJson = Json.toJson(this)
}

case class RoleMappingsRequest(roleMappings: List[RoleMapping])
object RoleMappingsRequest {
  private implicit val implicitRoleMappingsReads = Json.reads[RoleMapping]
  private implicit val implicitRoleMappingsRequestReads = Json.reads[RoleMappingsRequest]

  def createFromJson(json: JsValue): Option[RoleMappingsRequest] = Try(Some(json.as[RoleMappingsRequest])).getOrElse(None)
}

case class UpdateRoleMappingsRequest(addRoleMappings: List[RoleMapping], removeRoleMappings: List[RoleMapping])
object UpdateRoleMappingsRequest {
  private implicit val implicitRoleMappingsReads = Json.reads[RoleMapping]
  private implicit val implicitUpdateRoleMappingRequestReads = Json.reads[UpdateRoleMappingsRequest]

  def createFromJson(json: JsValue): Option[UpdateRoleMappingsRequest] = Try(Some(json.as[UpdateRoleMappingsRequest])).getOrElse(None)
}
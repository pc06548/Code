package model

import java.util.Date

case class Login(id: Int, userId: Int, orgId: Int, userName: String, password: String, createTimestamp: Date, updateTimestamp: Date, activeUntil: Date)

case class LoginToken(loginId: Int, token: String, updateTimestamp: Date)

case class Feature(featureName: String,numberOfCompanies:Int, numberOfUsers:Int,totalProjects:Int, totalActiveProjects: Int)

object Feature {
  val FEATURE_BASE = "BASE"
  val FEATURE_ADVANCE = "ADVANCE"
  val FEATURE_COMMERCIAL = "COMMERCIAL"
  val FEATURE_CORPORATE = "CORPORATE"


  def getFeature(featureName: String) : Feature = {
    featureName match {
      case FEATURE_BASE => Feature(FEATURE_BASE,1,2,2,2)
      case FEATURE_ADVANCE => Feature(FEATURE_ADVANCE,2,10,4,2)
      case FEATURE_COMMERCIAL => Feature(FEATURE_COMMERCIAL,3,15,9,3)
      case FEATURE_CORPORATE => Feature(FEATURE_CORPORATE,5,30,5,25)
      case _ => Feature("-",0,0,0,0)
    }
  }
}
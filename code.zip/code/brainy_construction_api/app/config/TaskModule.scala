package config

import actors.QuartzSchedular
import play.api.inject.SimpleModule
import play.api.inject._

class TaskModule extends SimpleModule(bind[QuartzSchedular].toSelf.eagerly())
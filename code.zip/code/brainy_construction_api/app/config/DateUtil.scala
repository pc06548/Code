package config

import java.text.SimpleDateFormat
import java.time.{LocalDate, YearMonth, ZoneOffset}
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit
import java.util.{Calendar, Date}

import exceptions.{BadDateFormat, BadFYearFormat, BadMonthFormat}

import scala.util.Try

object DateUtil {
  val dateFormatString = "dd-MM-yyyy"
  val dateTimeFormatString = "dd-MM-yyyy HH:mm:ss"
  val monthFormatString = "MMMM-yyyy"
  val yearFormatString = "yyyy"
  val fYearFormatString = "yyyy-yyyy"
  val dateFormat = new SimpleDateFormat(dateFormatString)
  val dateTimeFormat = new SimpleDateFormat(dateTimeFormatString)
  val monthFormat = new SimpleDateFormat(monthFormatString)
  val yearFormat = new SimpleDateFormat(yearFormatString)

  def today : String = dateFormat.format(new Date())
  def currentTimestamp : String = dateTimeFormat.format(new Date())
  def currentMonth = monthFormat.format(new Date())

  def getDateFromDateTime(dateInDateTimeFormat: String): String = {
    val inputDateInstance = dateTimeFormat.parse(dateInDateTimeFormat)
    dateFormat.format(inputDateInstance)
  }

  def validate(date: String,field:String): Either[BadDateFormat,String] = {
    Try(dateFormat.parse(date)).toOption match {
      case Some(_) => Right[BadDateFormat,String](date)
      case None   => Left(BadDateFormat(field))
    }
  }
  def validateMonthFormat(date: String,field:String): Either[BadMonthFormat,String] = {
    Try(monthFormat.parse(date)).toOption match {
      case Some(_) => Right[BadMonthFormat,String](date)
      case None   => Left(BadMonthFormat(field))
    }
  }
  def validateFyearFormat(date: String,field:String): Either[BadFYearFormat,String] = {
    val year1 = Try(date.split("-").head.toInt).toOption
    val year2 = Try(date.split("-").last.toInt).toOption

    (year1,year2) match {
      case (Some(y1),Some(y2)) if (y1 > 2000 && y1 < 2060 &&
        y2 > 2000 && y2 < 2060) && (y2 - y1)  == 1 => {
        Right[BadFYearFormat,String](date)
      }
      case _ => Left(BadFYearFormat(field))
    }

  }

  def getFirstDayOfMonth(date: String): String = {
    val inputDateInstance = dateFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDateInstance)
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    val firstDayDate = calendar.getTime
    dateFormat.format(firstDayDate)
  }

  def getFirstDayFromMonth(date: String): String = {
    val inputDateInstance = monthFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDateInstance)
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    val firstDayDate = calendar.getTime
    dateFormat.format(firstDayDate)
  }

  def  getDateInStringDate(date: Date) = dateFormat.format(date)

  def getDateFromMonthString(dateString:String):Date = {
    monthFormat.parse(dateString)
  }
  def getDateFromString(dateString:String):Date = {
    dateFormat.parse(dateString)
  }

  def getLastDay(date: String): String = {
    val inputDateInstance = dateFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDateInstance)
    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
    val lastDayDate = calendar.getTime
    dateFormat.format(lastDayDate)
  }

  def getLastDayOfMonth(monthFormatDate: String): String = {
    val inputDateInstance = monthFormat.parse(monthFormatDate)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDateInstance)
    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
    val lastDayDate = calendar.getTime
    dateFormat.format(lastDayDate)
  }

  def decrementDateByMonths(date: String, months: Int): String = {
    val uiDateInstance = dateFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(uiDateInstance)
    calendar.add(Calendar.MONTH, -1 * months)
    val firstDayDate = calendar.getTime
    dateFormat.format(firstDayDate)
  }

  def getDayOfWeek(date:String): Option[String] = {
    val uiDateInstance: Date = dateFormat.parse(date)
    Try(new SimpleDateFormat("EEEEE").format(uiDateInstance)).toOption
  }
  def endOfTimeDate = "31-12-9999"

  def incrementByDays(date: String, days: Int): String = {
    val inputDateInstance = dateFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDateInstance)
    calendar.add(Calendar.DAY_OF_MONTH,days)
    val newDate = calendar.getTime
    dateFormat.format(newDate)
  }
  def incrementByMonths(date: String, months: Int): String = {
    val uiDateInstance = dateFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(uiDateInstance)
    calendar.add(Calendar.MONTH, 1 * months)
    val firstDayDate = calendar.getTime
    dateFormat.format(firstDayDate)
  }
  def incrementByYears(date: String, years: Int): String = {
    val uiDateInstance = dateFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(uiDateInstance)
    calendar.add(Calendar.YEAR, 1 * years)
    val firstDayDate = calendar.getTime
    dateFormat.format(firstDayDate)
  }

  def incrementTodayByDays(days: Int): String = {
    incrementByDays(today,days)
  }

  def getMonthFormatFromDate(date: String) : String = {
    monthFormat.format(dateFormat.parse(date))
  }
  def getMonthFormatFromDate(date: Date) : String = {
    monthFormat.format(date)
  }
  def getYearFormatFromDate(date: Date) : Int = {
    yearFormat.format(date).toInt
  }
  def getYearFormatFromDate(date: String) : Int = {
    yearFormat.format(dateFormat.parse(date)).toInt
  }

  def getCurrentFinancialYear() : String = {
    val calendar = Calendar.getInstance
    calendar.setTime(new Date())
    if (calendar.get(Calendar.MONTH) >= 3){
      s"${calendar.get(Calendar.YEAR)}-${(calendar.get(Calendar.YEAR) + 1)%100}"
    }else{
      s"${(calendar.get(Calendar.YEAR) - 1)}-${calendar.get(Calendar.YEAR)%100}"
    }
  }

  def getDiffernceInDays(date1:String,date2:String): Int = {
    val date1Cal: Date = dateFormat.parse(date1)
    val date2Cal: Date = dateFormat.parse(date2)
    val diffInMillies = date2Cal.getTime() - date1Cal.getTime()
    TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS).toInt
  }

  def getDifferenceInMonths(date1:String,date2:String): Int = {

    val date1Cal: Date = dateFormat.parse(date1)
    val date2Cal: Date = dateFormat.parse(date2)
    val m1 = YearMonth.from(date1Cal.toInstant().atZone(ZoneOffset.UTC))
    val m2 = YearMonth.from(date2Cal.toInstant().atZone(ZoneOffset.UTC))
    (m1.until(m2, ChronoUnit.MONTHS)).toInt
  }
  def getDifferenceInYears(date1:String,date2:String): Int = {

    val date1Cal: Date = dateFormat.parse(date1)
    val date2Cal: Date = dateFormat.parse(date2)
    val m1 = YearMonth.from(date1Cal.toInstant().atZone(ZoneOffset.UTC))
    val m2 = YearMonth.from(date2Cal.toInstant().atZone(ZoneOffset.UTC))
    (m1.until(m2, ChronoUnit.YEARS)).toInt
  }

  def getFirstDateOfFyear(year:String) : String = {
    val year1: Int = Try(year.split("-").head.toInt).toOption.getOrElse(1999)
    val calendar = Calendar.getInstance
    calendar.set(Calendar.YEAR, year1)
    calendar.set(Calendar.MONDAY, 3)
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    val lastDayDate = calendar.getTime
    dateFormat.format(lastDayDate)
  }

  def getLastDateOfFyear(year:String) : String = {
    val year2: Int = Try(year.split("-").last.toInt).toOption.getOrElse(2000)
    val calendar = Calendar.getInstance
    calendar.set(Calendar.YEAR, year2)
    calendar.set(Calendar.MONDAY, 2)
    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
    val lastDayDate = calendar.getTime
    dateFormat.format(lastDayDate)
  }
}

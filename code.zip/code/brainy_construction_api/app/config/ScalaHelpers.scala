package config

import scala.util.Try

object ScalaHelpers {

  def sequence[A, B](s: Seq[Either[A, B]]): Either[A, Seq[B]] =
    s.foldRight(Right(Nil): Either[A, List[B]]) {
      (e, acc) => for (xs <- acc.right; x <- e.right) yield x :: xs
    }

  implicit class OptionExtension[A](str : Option[String]) {

    def toOptionString : Option[String] = str.flatMap(s => if(s.trim.isEmpty) None else Some(s))

    def toOptionDateString : Option[String] = str.flatMap(s => if(s.trim.isEmpty) None else DateUtil.validate(s,"Date").toOption)

    def toOptionMonth : Option[String] = str.flatMap(s => if(s.trim.isEmpty) None else DateUtil.validateMonthFormat(s,"Month").toOption)

    def toOptionFYear : Option[String] = str.flatMap(s => if(s.trim.isEmpty) None else DateUtil.validateFyearFormat(s,"Financial year").toOption)

    def toOptionBoolean : Option[Boolean] = str match {
      case Some(s) if(s.trim.isEmpty) => None
      case Some(s) => Try(s.trim.toBoolean).toOption
      case None => None
    }
    def toOptionInt : Option[Int] = str match {
      case Some(s) if(s.trim.isEmpty) => None
      case Some(s) => Try(s.trim.toInt).toOption
      case None => None
    }
    def toOptionDouble : Option[Double] = str match {
      case Some(s) if(s.trim.isEmpty) => None
      case Some(s) => Try(s.trim.toDouble).toOption
      case None => None
    }
  }

  implicit class DoubleExtension(x : Double){
    def roundTo2():Double = {
      BigDecimal(x).setScale(2, BigDecimal.RoundingMode.HALF_UP).toDouble
    }
  }

}

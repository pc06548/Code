package config

import java.sql
import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.{Calendar, Date}

import org.joda.time.format.{DateTimeFormat, DateTimeFormatter}
import org.joda.time.{DateTime, Days}

object DateHelperDeprecated {

  val uiDateFormatString = "dd-MM-yyyy"
  val uiDateFormat = new SimpleDateFormat(uiDateFormatString)
  val dateFormatString = "yyyy-MM-dd"
  val dateFormat = new SimpleDateFormat(dateFormatString)
  val monthDateFormatString = "MMM-yyyy"
  val monthDateFormat = new SimpleDateFormat(monthDateFormatString)
  val dayFormat = new SimpleDateFormat("EEE")

  def getDateInString(date: Date): String = {
    if (date != null )
      uiDateFormat.format(date)
    else
      ""
  }

  def getDbDateInString(date: Date): String = {
    if (date != null)
      dateFormat.format(date)
    else
      ""
  }

  def now: String = dateFormat.format(new Date())

  def incrementByDays(date: String, days: Int): String = LocalDate.parse(date).plusDays(days).toString

  def decrementByDays(date: String, days: Int): String = LocalDate.parse(date).minusDays(days).toString

  def getDate(date: String): Date = dateFormat.parse(date)

  def getDate(date: String,format : String): Date = new SimpleDateFormat(format).parse(date)

  def getDayFrom(date: Date): String = dayFormat.format(date)

  def getDayFrom(date: String): String = dayFormat.format(getDate(date))

  def isDateFallInCurrentWeek(date: String): Boolean = getMonToSunDates(date).contains(now)

  def getMonToSunDates(date: String): Seq[String] = {
    val today = LocalDate.parse(date)
    val week = getDaysTillMonday(today, Seq.empty[LocalDate]) ++ getDaysTillSunday(today.plusDays(1), Seq.empty[LocalDate])
    week.map(x => x.toString)
  }

  def MMddyyyyToyyyyMMdd(date: String): String = {
    val originalFormat = new SimpleDateFormat("MM/dd/yyyy")
    val originalDate = originalFormat.parse(date)
    dateFormat.format(originalDate)
  }


  private def getDaysTillMonday(day: LocalDate, dates: Seq[LocalDate]): Seq[LocalDate] = {
    if (day.getDayOfWeek.toString == "MONDAY")
      (dates :+ day).reverse
    else
      getDaysTillMonday(day.minusDays(1), dates :+ day)

  }

  private def getDaysTillSunday(day: LocalDate, dates: Seq[LocalDate]): Seq[LocalDate] = {
    if (day.getDayOfWeek.toString == "SUNDAY")
      dates :+ day
    else
      getDaysTillSunday(day.plusDays(1), dates :+ day)

  }

  def convertFromUiFormatToDbFormat(uiDate: String): String = {
    if(uiDate != null && uiDate.nonEmpty) {
      val originalDate = uiDateFormat.parse(uiDate)
      dateFormat.format(originalDate)
    }else{
      ""
    }
  }

  def decrementDateByMonths(uiDate: String, months: Int): String = {
    val uiDateInstance = uiDateFormat.parse(uiDate)
    val calendar = Calendar.getInstance
    calendar.setTime(uiDateInstance)
    calendar.add(Calendar.MONTH, -1 * months)
    val firstDayDate = calendar.getTime
    uiDateFormat.format(firstDayDate)
  }

  def getFirstDay(date: String,inputDateFormat : SimpleDateFormat,outputDateFormat : SimpleDateFormat): String = {
    val inputDateInstance = inputDateFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDateInstance)
    calendar.set(Calendar.DAY_OF_MONTH, 1)
    val firstDayDate = calendar.getTime
    outputDateFormat.format(firstDayDate)
  }

  def getLastDay(date: String,inputDateFormat : SimpleDateFormat,outputDateFormat : SimpleDateFormat): String = {
    val inputDateInstance = inputDateFormat.parse(date)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDateInstance)
    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
    val lastDayDate = calendar.getTime
    outputDateFormat.format(lastDayDate)
  }

  def convertFromUiFormateToMonthFormat(uiDate: String): String = {
    if(uiDate != null && uiDate.nonEmpty) {
      val originalDate = uiDateFormat.parse(uiDate)
      monthDateFormat.format(originalDate)
    }else{
      ""
    }
  }

  def convertFromDbFormatToUiFormat(dbDate: String): String = {
    if(dbDate != null && dbDate.nonEmpty){
      val originalDate = dateFormat.parse(dbDate)
      uiDateFormat.format(originalDate)
    }else
      ""
  }

  def getLatestDate(dates : List[String]) : String =
    dates.filterNot(_.trim.isEmpty).sortBy(date => DateHelperDeprecated.getDate(date,DateHelperDeprecated.uiDateFormatString).getTime).lastOption.getOrElse("")

  def getDifferenceInDays(date : String) : Int = {
    if(date != null && date.nonEmpty) {
      val formatter: DateTimeFormatter = DateTimeFormat.forPattern(uiDateFormatString)
      val dt: DateTime = formatter.parseDateTime(date)
      Days.daysBetween(dt, DateTime.now).getDays
    }else{
      0
    }
  }

  def nowSqlTimeStamp = new Timestamp((Calendar.getInstance()).getTime.getTime)
  def nowSqlDate: sql.Date = new java.sql.Date(System.currentTimeMillis())

  val endOfTimeSqlTimeStamp: Timestamp = {
    val calendar = Calendar.getInstance()
    calendar.set(9999, 10, 10)
    new Timestamp(calendar.getTime.getTime)
  }

  val endOfTimeString: String = {
    val calendar = Calendar.getInstance()
    calendar.set(9999, 10, 10)
    new Date(calendar.getTime.getTime).toString
  }

  def nowSqlTimeStampString = nowSqlTimeStamp.toString




}

package config

import java.sql.ResultSet

import org.slf4j.LoggerFactory


class ResultSetIterator(rs: ResultSet) extends Iterator[ResultSet] {

  private val logger = LoggerFactory.getLogger(this.getClass)
  var count = 0
  def hasNext: Boolean = rs.next()
  def next(): ResultSet = {
    count += 1
    logger.info(s"Fetching next result $count")
    rs
  }
}

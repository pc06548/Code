package config

import java.sql.DriverManager
import javax.inject.Inject
import play.api.{Configuration}

class SqlConnectionManager @Inject()(configuration: Configuration){

  def getConnection = {
    val databaseConnection = configuration.get[String](AppConstants.databaseConnection)
    val databaseName = configuration.get[String](AppConstants.databaseName)
    val databaseUser = configuration.get[String](AppConstants.databaseUser)
    val databasePassword = configuration.get[String](AppConstants.databasePassword)
    val database = databaseConnection + databaseName
    Class.forName("org.postgresql.Driver")
    DriverManager.getConnection(database, databaseUser, databasePassword)
  }
}
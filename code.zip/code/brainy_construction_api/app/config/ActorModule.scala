package config

import actors.NotificationsActor
import com.google.inject.AbstractModule
import play.api.libs.concurrent.AkkaGuiceSupport
import com.google.auth.oauth2.GoogleCredentials
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import java.io.FileInputStream

import scala.util.Try


class ActorModule extends AbstractModule with AkkaGuiceSupport {
  override def configure = {
    bindActor[NotificationsActor]("notifications-actor")
  }

  val serviceAccount = new FileInputStream("brainy-construction-firebase-adminsdk-vnrgd-11bc3e57bb.json")

  val options: FirebaseOptions = new FirebaseOptions.Builder()
    .setCredentials(GoogleCredentials.fromStream(serviceAccount))
    .setDatabaseUrl("https://brainy-construction.firebaseio.com").build

  Try(FirebaseApp.initializeApp(options)).toEither match {
    case Left(err) => //println("Firebase initilize failed : " + err.getMessage)
    case Right(_) => //println("Firebase initilized ")
  }

}
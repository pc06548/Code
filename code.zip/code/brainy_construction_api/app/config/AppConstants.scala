package config

object AppConstants {
  val JwtSecretKey = "E1633DE7D1F2A825DE00FA621B2A0BB2B890C33944BA89E71896BB13A79DBD36"
  val LoginTokenExpirationTimeInSecs = "LOGIN_TOKEN_EXP_TIME_IN_SECS"
  val UserLoginExpirationTimeInSecs = "USER_LOGIN_EXP_TIME_IN_SECS"

  val databaseConnection = "database.connection"
  val databaseUser = "database.user"
  val databasePassword =  "database.password"
  val databaseName= "database.name"

  val environmentName = "environment.name"

  val s3FolderPath = "public/s3/"

  val excelFolderPath = "public/excel/"

  val superAdminSecret = "I_AM_SUPER_ADMIN"
}

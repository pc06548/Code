package utils

import model.company.Company
import model.contractor.Contractor
import model.customer._
import model.{BankDetails, BasicDetails, Project, TaxDetails}
import play.api.libs.json.{DefaultWrites, JsValue, Json, Writes}

object JsonImplicites extends DefaultWrites{

  implicit def tuple2[A : Writes, B : Writes]: Writes[(A, B)] = new
      Writes[(A, B)] {
    def writes(o: (A, B)): JsValue = Json.arr(o._1, o._2)
  }

  implicit val implicitBankDetailsWrites = Json.writes[BankDetails]
  implicit val implicitBasicDetailsWrites = Json.writes[BasicDetails]
  implicit val implicitContractorWrites = Json.writes[Contractor]
  implicit val implicitTaxDetailsWrites = Json.writes[TaxDetails]
  implicit val implicitCompanyWrites = Json.writes[Company]

  implicit val implicitProjectWrites = Json.writes[Project]


  implicit val implicitDefaultWrites = Json.writes[DefaultDemand]
  implicit val implicitDefaultLWrites = Json.writes[DefaultDemandLetter]

  implicit val implicitProjectDetailsWrites = Json.writes[FlatDetails]
  implicit val implicitAgreementDetailsWrites = Json.writes[AgreementDetails]
  implicit val implicitSaledeedDetailsWrites = Json.writes[SaledeedDetails]
  implicit val implicitPossessionDetailsWrites = Json.writes[PossessionDetails]
  implicit val implicitBankRefDetailsWrites = Json.writes[BankReferenceDetails]
  implicit val implicitCoOwnerDetailsWrites = Json.writes[CoOwnerDetails]
  implicit val implicitCustomerReferredByWrites = Json.writes[CustomerReferredBy]
  implicit val implicitCustomerWrites = Json.writes[Customer]

  implicit val implicitDLDWrites = Json.writes[CustomerDemand]
  implicit val implicitDLWrites = Json.writes[DemandLetter]

}

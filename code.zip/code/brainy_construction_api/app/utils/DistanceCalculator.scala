package utils

import model.Location

object DistanceCalculator {

  private val AVERAGE_RADIUS_OF_EARTH_KM = 6371

  def calculateDistanceInKilometer(inputLogitude: Double,inputLatitude:Double, officeLocation: Location): Int = {
    val latDistance = Math.toRadians(inputLatitude - officeLocation.latitude)
    val lngDistance = Math.toRadians(inputLogitude - officeLocation.longitude)
    val sinLat = Math.sin(latDistance / 2)
    val sinLng = Math.sin(lngDistance / 2)
    val a = sinLat * sinLat +
      (Math.cos(Math.toRadians(inputLatitude))
        * Math.cos(Math.toRadians(officeLocation.latitude))
        * sinLng * sinLng)
    val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    (AVERAGE_RADIUS_OF_EARTH_KM * c).toInt
  }

  def calculateDistanceInMeter(inputLogitude: Double,inputLatitude:Double, officeLocation: Location): Int = {
    calculateDistanceInKilometer(inputLogitude,inputLatitude,officeLocation) * 1000
  }
}

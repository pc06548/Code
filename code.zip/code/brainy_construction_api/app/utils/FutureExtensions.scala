package utils

import exceptions.{RuntimeException, ServerError}
import org.slf4j.{Logger, MarkerFactory}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.{Failure, Success, Try}


trait FutureExtensions {

  implicit class FutureOps[A](f: Future[Either[ServerError, A]]) {

    def handleExceptionWithLog(implicit logger: Logger): Future[Either[ServerError,A]] = {
      f.recover{
        case e: Exception => {
          logger.error(MarkerFactory.getMarker("RUNTIME_ERROR"),logger.getName,e)
          Left[ServerError,A](RuntimeException(e))
        }
      }
    }

  }
  implicit class FutureOps2[A](f: Future[Right[Nothing, A]]) {

    def handleExceptionWithLog(implicit logger: Logger): Future[Either[ServerError,A]] = {
      f.recover{
        case e: Exception => {
          logger.error(MarkerFactory.getMarker("RUNTIME_ERROR"),logger.getName,e)
          Left[ServerError,A](RuntimeException(e))
        }
      }
    }

  }
  implicit class TryOps[A](f: Try[A]) {

    def handleExceptionWithLog(implicit logger: Logger): Either[ServerError,A] = {

      f match {
        case Success(value) => Right[ServerError,A](value)
        case Failure(exception) => {
          logger.error(MarkerFactory.getMarker("RUNTIME_ERROR"),logger.getName,exception)
          Left[ServerError,A](RuntimeException(exception))
        }
      }
    }

  }
}

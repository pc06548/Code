package utils

import config.DateUtil
import model.vouchers.Voucher

object Test extends App {


  println(DateUtil.getDiffernceInDays("05-06-2020","05-05-2020"))
}

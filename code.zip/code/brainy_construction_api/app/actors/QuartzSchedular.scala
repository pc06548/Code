package actors

import java.util.Date

import javax.inject.Inject
import akka.actor.ActorSystem
import com.typesafe.akka.extension.quartz.QuartzSchedulerExtension
import services.OtherInvoiceService
import services.db.contractor.{ContractorDbUpdator, ContractorVoucherDbUpdator}
import services.db.{CategoryDbUpdator, CompanyDbUpdator, TransactionDbUpdator, VoucherDb}
import services.db.employee.EmployeeDbUpdator
import services.employees.PayslipService
import services.reports.DirectorReportService

import scala.concurrent.ExecutionContext

class QuartzSchedular @Inject()(actorSystem: ActorSystem,
                                employeeDbUpdator: EmployeeDbUpdator,
                                payslipService: PayslipService,
                                voucherDb: ContractorVoucherDbUpdator,
                                companyDbUpdator: CompanyDbUpdator,
                                categoryDbUpdator: CategoryDbUpdator,
                                otherInvoiceService: OtherInvoiceService,
                                transactionDbUpdator: TransactionDbUpdator,
                                directorReportService: DirectorReportService
                               )(implicit executionContext: ExecutionContext) {

  val payslipGeneratorActor =
    actorSystem.actorOf(PayslipGeneratorActor.props(employeeDbUpdator,payslipService,companyDbUpdator), "PayslipGenerator")
  val expenseInvoiceGeneratorActor =
    actorSystem.actorOf(ExpenseInvoiceGeneratorActor.props(companyDbUpdator,categoryDbUpdator,transactionDbUpdator,otherInvoiceService), "expenseInvoiceGenerator")

  val tdsInvoiceGeneratorActor =
    actorSystem.actorOf(TDSInvoiceGeneratorActor.props(voucherDb,companyDbUpdator,categoryDbUpdator,otherInvoiceService), "tdsInvoiceGenerator")

  val directorReportActor =
    actorSystem.actorOf(DirectorReportActor.props(directorReportService,companyDbUpdator), "DirectorReportActor")


  private val quartzSchedulerExtension = QuartzSchedulerExtension(actorSystem)

  val nextPayslipGenerationDate: Date = quartzSchedulerExtension.schedule("PayslipGenerator", payslipGeneratorActor, PayslipGeneratorActor.GeneratePayslips)
  val tdsInvoiceGeneration: Date = quartzSchedulerExtension.schedule("TDSInvoiceGenerator", tdsInvoiceGeneratorActor, TDSInvoiceGeneratorActor.GenerateTDSInvoice)
  val expenseInvoiceGenerator: Date = quartzSchedulerExtension.schedule("ExpenseInvoiceGenerator", tdsInvoiceGeneratorActor, TDSInvoiceGeneratorActor.GenerateTDSInvoice)
  val directorReportGenerator: Date = quartzSchedulerExtension.schedule("DirectorReportGenerator", directorReportActor, DirectorReportActor.GenerateDirectorReport)

  println(s"****************************************************************************")
  println(s"----- Next payslip job will run on :  ${nextPayslipGenerationDate}")
  println(s"----- Next TDS invoice job will run on :  ${tdsInvoiceGeneration}")
  println(s"----- Next director report job will run on :  ${directorReportGenerator}")

}
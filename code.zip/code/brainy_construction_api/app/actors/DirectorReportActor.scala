package actors

import actors.DirectorReportActor.GenerateDirectorReport
import akka.actor.{Actor, ActorLogging, Props}
import config.DateUtil
import exceptions.RuntimeException
import services.db.CompanyDbUpdator
import services.reports.DirectorReportService

import scala.concurrent.ExecutionContext

object DirectorReportActor {

  case object GenerateDirectorReport

  def props(directorReportService: DirectorReportService,companyDbUpdator: CompanyDbUpdator)(implicit executionContext: ExecutionContext): Props = {
    Props(new DirectorReportActor(directorReportService,companyDbUpdator))
  }

}

class DirectorReportActor(directorReportService: DirectorReportService,
                          companyDbUpdator: CompanyDbUpdator)
                         (implicit executionContext: ExecutionContext) extends Actor with ActorLogging {

  override def receive: Receive = {
    case GenerateDirectorReport => {

      for{
        lastRunDate <- companyDbUpdator.getBatchJobLastRunDate("director_report")
      }yield {
        lastRunDate match {
          case Some(_) => println("Director Report already created")
          case None => generateReport()
        }
      }
    }
  }

  def generateReport(): Unit ={
    val result = directorReportService.getDirectorReport().map(Right(_)).recover{
      case e: Throwable => Left(RuntimeException(e))
    }
    result.map(res => {
      res match {
        case Right(_)   => println("Director report Job successful")
        case Left(e)    => println( "Director report Job unsuccessful "+ e.errorMessage)
      }
    })
  }

}

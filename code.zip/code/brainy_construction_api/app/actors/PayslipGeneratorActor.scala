package actors
import actors.PayslipGeneratorActor.GeneratePayslips
import akka.actor.{Actor, ActorLogging, Props}
import config.DateUtil
import services.db.CompanyDbUpdator
import services.db.employee.EmployeeDbUpdator
import services.employees.PayslipService

import scala.concurrent.ExecutionContext

object PayslipGeneratorActor {

  case object GeneratePayslips

  def props(employeeDbUpdator: EmployeeDbUpdator,
            payslipService: PayslipService,
            companyDbUpdator: CompanyDbUpdator)(implicit executionContext: ExecutionContext): Props = {
    Props(new PayslipGeneratorActor(employeeDbUpdator,payslipService,companyDbUpdator))
  }

}

class PayslipGeneratorActor(employeeDbUpdator: EmployeeDbUpdator,
                            payslipService: PayslipService,
                            companyDbUpdator: CompanyDbUpdator)(implicit executionContext: ExecutionContext) extends Actor with ActorLogging {

  override def receive: Receive = {
    case GeneratePayslips => {

      for{
        lastRunDate <- companyDbUpdator.getBatchJobLastRunDate("payslip_creation")
      }yield {
        lastRunDate match {
          case Some(_) => println("Payslip already created")
          case None => generatePayslip()
        }
      }
    }
  }

  def generatePayslip(){
    log.info("Payslip generation: job started")
    employeeDbUpdator.getAllActiveIds().map(ids => ids.map(tuple => {
      val employeeId = tuple._1
      val companyId = tuple._2
      payslipService.createPayslip(companyId,employeeId,DateUtil.currentMonth)
        .recover{
          case e:Throwable => Right()
        }
    }))
  }

}

package actors

import actors.NotificationsActor.NotifyPOUpdate
import akka.actor.{Actor, ActorLogging}
import auth.db.UserDb
import javax.inject.Inject
import com.google.firebase.messaging.{FirebaseMessaging, Message, Notification}
import consts.Roles
import services.NotificationService
import services.db.FcmTokenDbUpdator

import scala.concurrent.{ExecutionContext, Future}
import scala.util.Try

object NotificationsActor {

  case class NotifyPOUpdate(companyId:Int,userId:Int,poId:Int,supplierName:String)

}

class NotificationsActor @Inject()(fcmTokenDbUpdator: FcmTokenDbUpdator,
                                   notificationService: NotificationService,
                                   userDb: UserDb)(implicit executionContext: ExecutionContext) extends Actor with ActorLogging {

  override def receive: Receive = {
    case NotifyPOUpdate(companyId:Int,userId:Int,poId:Int,supplierName:String) => {

       for{
          userWithTokens <- notificationService.getTokens(companyId,userId)
          finalReceipients = userWithTokens.filter(r => (r.roleName != Roles.EMPLOYEE))
          tokens <- fcmTokenDbUpdator.get(finalReceipients.map(_.userId))
        }yield {
          tokens.map(t => {
            Try(sendNotification(t.token,"New Purchase order generated",
              "New Purchase order generated",
              Map("poId" -> poId.toString,"supplierName" -> supplierName)))
          })
        }
    }
  }

  def sendNotification(token:String,body:String,title:String,data:Map[String,String]) = {

    val notification = Notification.builder().setBody(body)
      .setTitle(title).build()

    val message: Message.Builder = Message.builder()
      .setNotification(notification)
      .setToken(token)

    data.foreach[Message.Builder]{
      case (key,v) => {
        message.putData(key,v)
      }
    }

    FirebaseMessaging.getInstance().send(message.build())
  }

}

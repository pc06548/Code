package services

import exceptions.{IDGenerationFailed, RuntimeException,ServerError}
import javax.inject.Inject
import model.{EntityId, GetNameResponse}
import model.contractor.Contractor
import play.api.libs.json.{JsValue, Json}
import services.db.contractor.ContractorDbUpdator
import utils.JsonImplicites._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class ContractorService @Inject()(contractorDbUpdator: ContractorDbUpdator) extends LoggerService{

  def searchContractors(companyId: Int,name: Option[String],deptName : Option[String]) = {

    contractorDbUpdator.search(companyId,name,deptName).map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }

  def getAllNames(companyId: Int): Future[Either[ServerError, Seq[GetNameResponse]]] = {
    contractorDbUpdator.getAllNames(companyId).map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }

  def getContractor(id: Int,companyId: Int): Future[Either[ServerError, Option[Contractor]]] = {
    contractorDbUpdator.getById(id,companyId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveContractor(contractor: Contractor) = {
    contractorDbUpdator.createContractor(contractor).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog

  }

  def updateContractor(contractor: Contractor) = {
    contractorDbUpdator.updateContractor(contractor).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,companyId: Int) = {
    contractorDbUpdator.delete(id,companyId).map(Right(_)).handleExceptionWithLog

  }

}

package services

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject.Inject
import model.{Location, EntityId}
import services.db.LocationDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class LocationService @Inject()(locationDbUpdator: LocationDbUpdator) extends LoggerService{

  def getLocation(companyId : Int,id:Int): Future[Either[ServerError,Option[Location]]] = {

    locationDbUpdator.get(companyId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).handleExceptionWithLog
  }

  def getAll(companyId:Int): Future[Either[ServerError, List[Location]]] =  {
    locationDbUpdator.search(companyId).map(Right(_)).handleExceptionWithLog
  }
  def updateLocation(location: Location) = {
    locationDbUpdator.updateLocation(location).map(Right(_)).handleExceptionWithLog
  }

  def saveLocation(location: Location):Future[Either[ServerError,EntityId]] = {
    locationDbUpdator.createLocationAndGetLocationId(location).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def delete(companyId:Int,id : Int) = locationDbUpdator.delete(companyId,id).map(Right(_)).handleExceptionWithLog

}

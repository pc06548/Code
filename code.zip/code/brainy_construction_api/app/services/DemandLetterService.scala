package services

import config.DateUtil
import javax.inject._
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import model._
import model.customer.{Customer, CustomerDemand, DemandLetter}
import services.db.{CompanyConfigDbUpdator, ProjectDbUpdator}
import services.db.customer.{CustomerDbUpdater, CustomerDemandDbUpdater, DefaultDemandDbUpdater, ReceiptDbUpdater}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._

import scala.util.Try

class DemandLetterService @Inject()(companyConfigDbUpdator: CompanyConfigDbUpdator,
                                    customerDemandDbUpdator: CustomerDemandDbUpdater,
                                    defaultDemandDbUpdator: DefaultDemandDbUpdater,
                                    projectDbUpdator: ProjectDbUpdator,
                                    customerDbUpdator: CustomerDbUpdater,
                                    receiptDbUpdator: ReceiptDbUpdater)extends LoggerService {


  def getDemand(id: Int,projectId: Int,customerId:Int): Future[Either[ServerError, Option[CustomerDemand]]] = {
    customerDemandDbUpdator.getById(id,projectId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveDemand(defaultDemand: CustomerDemand) = {
    customerDemandDbUpdator.createDemand(defaultDemand).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog

  }

  def updateDemand(defaultDemand: CustomerDemand) = {
    customerDemandDbUpdator.updateDemand(defaultDemand).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,projectId: Int,customerId:Int) = {
    customerDemandDbUpdator.delete(id,projectId).map(Right(_)).handleExceptionWithLog

  }

  def searchDemandLetters(companyId:Int,projectId: Int,name:Option[String]) = {
    customerDemandDbUpdator.searchDemandLetters(companyId,projectId,name)
      .map(demands => {
        Right(
          demands.map(demand => {
            val delayInDays = DateUtil.getDiffernceInDays(demand.dueDate,DateUtil.today)
            demand.copy(delayInDays = Some(delayInDays),pendingAmount = Option(demand.netAmount - demand.AmountPaid))
          }).filter(d => d.pendingAmount.getOrElse(d.netAmount) > 0)
            .sortBy(d => Try(d.flatNumber.toInt).getOrElse(0))
        )
      })
      .handleExceptionWithLog
  }

  def getDemandLetter(companyId : Int,projectId:Int,customerId:Int):Future[Either[ServerError,Option[DemandLetter]]]  = {

    val eventualmayBeProject  = projectDbUpdator.getById(projectId,companyId)
    val eventualmayBecustomer = customerDbUpdator.getById(projectId,customerId)
    val eventualamountPaid    = receiptDbUpdator.getSumOfMoneyPaid(customerId)

    val mayBeDemandLetter: Future[Option[DemandLetter]] = for{
      mayBeProject    <- eventualmayBeProject
      mayBecustomer   <- eventualmayBecustomer
      amountPaid      <- eventualamountPaid
      demands         <- getDemandsForCustomer(projectId,mayBecustomer)
    }yield{
      val updateDemands: (Double, List[CustomerDemand]) = (demands.foldLeft((amountPaid,List.empty[CustomerDemand])){
        (tuple,d) => {
          if(tuple._1 > 0){
            if(tuple._1 >= d.netAmount){
              val updatedDemand = d.copy(receivedAmount = Some(d.netAmount),balanceAmount = Some(0))
              val newList = tuple._2 :+ updatedDemand
              ((tuple._1 - d.netAmount),newList)
            }else{
              val updatedDemand = d.copy(receivedAmount = Some(tuple._1),balanceAmount = Some(d.netAmount - tuple._1))
              val newList = tuple._2 :+ updatedDemand
              (0,newList)
            }
          }else{
            (tuple._1,tuple._2 :+ d.copy(receivedAmount = Some(0),balanceAmount = Some(d.netAmount)))
          }
        }
      })
      val filteredDemands = updateDemands._2.filter(
        d => d.balanceAmount.getOrElse(d.netAmount) > 0)
      val totals: (Double, Double, Double, Double, Double, Double,Double,Double) = filteredDemands.foldLeft((0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0)){
        (totals,demand) => {
          (
            totals._1 + demand.amount,
            totals._2 + demand.landDeduction,
            totals._3 + demand.taxableAmount,
            totals._4 + demand.cgst,
            totals._5 + demand.sgst,
            totals._6 + demand.netAmount,
            totals._7 + demand.receivedAmount.getOrElse(0.0),
            totals._8 + demand.balanceAmount.getOrElse(demand.netAmount)

          )
        }
      }
      mayBeProject.flatMap(
        project => mayBecustomer.map(
          customer => DemandLetter(project,customer,totals._1.roundTo2(),totals._2.roundTo2(),
            totals._3.roundTo2(),totals._4.roundTo2(),totals._5.roundTo2(),
            totals._6.roundTo2(),totals._7.roundTo2(),totals._8.roundTo2(),
            filteredDemands)
        )
      )

    }
    mayBeDemandLetter.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }


  def getDemandsForCustomer(projectId:Int,customer : Option[Customer]) : Future[Seq[CustomerDemand]] = {

    customer.flatMap(_.id) match {
      case Some(customerId) => {
        (for{
          existingDemands <- customerDemandDbUpdator.getAllDemandsForCustomer(customerId)
        }yield {
          if(existingDemands.isEmpty){
            for{
              projectDemands <- defaultDemandDbUpdator.getAllDefaultDemandsForProject(projectId)
              companyConfig <- companyConfigDbUpdator.get(customer.map(_.companyId).getOrElse(0))
              dueDate = DateUtil.incrementTodayByDays(companyConfig.map(_.dueDateLimit).getOrElse(CompanyConfig.DEFAULT_DATE_LIMIT))
              customerDemands = CustomerDemand.createFromDefaultDemand(projectDemands.filter(_.isComplated),customer.get,dueDate)
              savedCustomerDemands <- customerDemandDbUpdator.createDemands(customerDemands)
            }yield {
              savedCustomerDemands
            }
          }else{
            Future(existingDemands)
          }
        }).flatten
      }
      case None => Future(Seq.empty[CustomerDemand])
    }
  }
}

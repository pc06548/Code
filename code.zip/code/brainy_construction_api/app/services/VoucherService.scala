package services

import config.DateUtil
import javax.inject._
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import model.{Category, EntityId, VoucherNumber}
import model.vouchers.{SaveVoucher, Voucher, VoucherSearch}
import services.db.consultant.ConsultantVoucherDbUpdator
import services.db.contractor.ContractorVoucherDbUpdator
import services.db.supplier.SupplierVoucherDbUpdator
import services.db.{CompanyDbUpdator, OtherVoucherDbUpdator, VoucherDb}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class VoucherService @Inject()(contractorVoucherDbUpdator: ContractorVoucherDbUpdator,
                               supplierVoucherDbUpdator: SupplierVoucherDbUpdator,
                               consultantVoucherDbUpdator: ConsultantVoucherDbUpdator,
                               otherVoucherDbUpdator: OtherVoucherDbUpdator,
                               companyDbUpdator: CompanyDbUpdator)extends LoggerService {

  def saveVoucher(companyId: Int,voucher: SaveVoucher,invoiceType: String): Future[Either[ServerError, EntityId]] = {

    getVoucherDbUpdator(invoiceType).createVoucher(companyId,voucher).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def getVoucher(companyId: Int,id: Int,invoiceType: String): Future[Either[ServerError, Option[Voucher]]] = {

    getVoucherDbUpdator(invoiceType).getById(companyId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def searchVoucher(companyId:Int,name: Option[String], projectId: Option[Int],category : Option[String],invoiceType: String,
                    startDate:Option[String],endDate:Option[String],voucherNumber:Option[String],isTemporary:Option[Boolean]):Future[Either[ServerError, List[VoucherSearch]]]  = {

    val vouchers = invoiceType match {
      case Category.all => searchAllVoucher(companyId,name,projectId,category,invoiceType,startDate,endDate,voucherNumber,isTemporary)
      case _ => getVoucherDbUpdator(invoiceType).searchVouchers(companyId,name,projectId,startDate,endDate,voucherNumber,isTemporary,category)
    }
    vouchers.map(Right(_)).handleExceptionWithLog
  }
  private def searchAllVoucher(companyId:Int,name: Option[String], projectId: Option[Int],category : Option[String],invoiceType: String,
                    startDate:Option[String],endDate:Option[String],voucherNumber:Option[String],isTemporary:Option[Boolean])  = {

    val contractorPR = contractorVoucherDbUpdator
      .searchVouchers(companyId,name,projectId,startDate,endDate,voucherNumber,isTemporary,category)

    val supplierPR = supplierVoucherDbUpdator
      .searchVouchers(companyId,name,projectId,startDate,endDate,voucherNumber,isTemporary,category)

    val consultantPR = consultantVoucherDbUpdator
      .searchVouchers(companyId,name,projectId,startDate,endDate,voucherNumber,isTemporary,category)

    val otherPR = otherVoucherDbUpdator
      .searchVouchers(companyId,name,projectId,startDate,endDate,voucherNumber,isTemporary,category)
    for{
      contractor <- contractorPR
      supplier <- supplierPR
      consultant <- consultantPR
      other <- otherPR
    }yield contractor ++ supplier ++ consultant ++ other
  }


  def deleteVoucher(companyId: Int,id: Int,invoiceType: String): Future[Either[ServerError, Int]] =  {
    getVoucherDbUpdator(invoiceType).delete(id).map(Right(_)).handleExceptionWithLog
  }

  private def getVoucherDbUpdator(invoiceType: String): VoucherDb = {
    invoiceType match {
      case Category.contractor => contractorVoucherDbUpdator
      case Category.supplier => supplierVoucherDbUpdator
      case Category.consultant => consultantVoucherDbUpdator
      case _ => otherVoucherDbUpdator
    }
  }
  
  def getVoucherNumber(companyId:Int,invoiceType: String) :Future[Either[ServerError, String]] = {

    val voucherNumber: Future[String] = for{
      lastVoucherNumbers <- getVoucherDbUpdator(invoiceType).getLastTenVoucherNumbers(companyId)
      companyAbbreviation <- companyDbUpdator.getById(companyId).map(_.map(_.getAbbreviation))
    }yield {
      val validNumbers: List[VoucherNumber] =  lastVoucherNumbers.filter(n => VoucherNumber.checkIfVocherNumberValid(n.voucherNumber))
      val maxVoucher: Option[VoucherNumber] =  validNumbers.headOption
      maxVoucher match {
        case (Some(voucherNumber)) => {
          if(voucherNumber.extractYear == DateUtil.getCurrentFinancialYear){
            s"${companyAbbreviation.getOrElse(voucherNumber.extractCompanyAbbrevation)}-${voucherNumber.extractVoucherNumber + 1}/${DateUtil.getCurrentFinancialYear}"
          }else{
            s"${companyAbbreviation.getOrElse(voucherNumber.extractCompanyAbbrevation)}-1/${DateUtil.getCurrentFinancialYear}"
          }
        }
        case None => s"${companyAbbreviation.getOrElse("WRONG")}-1/${DateUtil.getCurrentFinancialYear}"
      }
    }

    voucherNumber.map(Right(_)).handleExceptionWithLog
  }

  def deleteAllTemporaryInvoicesAndVouchers(companyId:Int,projectId:Option[Int]) = {
    otherVoucherDbUpdator.deleteAllTemporaryInvoicesAndVouchers(companyId,projectId).map(Right(_)).handleExceptionWithLog
  }

}

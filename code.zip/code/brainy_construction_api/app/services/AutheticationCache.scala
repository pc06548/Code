package services

object AutheticationCache {

  val map : Map[Int,AuthorizationDetails] = Map()

  def update() = {
    map
  }
}

case class AuthorizationDetails(companyIds : List[Int],projectIds: List[Int])
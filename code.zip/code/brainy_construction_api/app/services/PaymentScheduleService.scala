package services

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject.Inject
import model.EntityId
import model.contractor.PaymentSchedule
import services.db.contractor.PaymentScheduleDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PaymentScheduleService @Inject()(paymentScheduleDbUpdator: PaymentScheduleDbUpdator) extends LoggerService{

  def savePaymentSchedule(paymentSchedule: PaymentSchedule): Future[Either[ServerError, EntityId]] = {

    val newEntityId = paymentScheduleDbUpdator.createPaymentSchedule(paymentSchedule).flatMap(
      newPsId => {
        val updatedDetails = paymentSchedule.details.map(_.copy(paymentScheduleId = newPsId))
        paymentScheduleDbUpdator.saveDetails(updatedDetails).map(_ => newPsId)
      })
    newEntityId.map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def searchPaymentSchedule(contractorName: Option[String], workOrderNumber: Option[String],projectId:Int,
                            startDate:Option[String],endDate:Option[String]) = {
    paymentScheduleDbUpdator.searchPaymentSchedules(contractorName,projectId,workOrderNumber,startDate,endDate).map(Right(_)).handleExceptionWithLog
  }

  def updatePs(paymentSchedule: PaymentSchedule) = {
    val updateRes = for{
      _ <- paymentScheduleDbUpdator.updateDetails(paymentSchedule.details)
      update <- paymentScheduleDbUpdator.updatePaymentSchedule(paymentSchedule)
    }yield update
    updateRes.map(Right(_)).handleExceptionWithLog
  }

  def getPaymentSchedule(projectId:Int, id: Int): Future[Either[ServerError, Option[PaymentSchedule]]] = {
    val evetualPs = paymentScheduleDbUpdator.getById(projectId,id)
    val eventualDetails = paymentScheduleDbUpdator.getDetails(id)

    val paymentSchedule = for{
      ps <- evetualPs
      details <- eventualDetails
    }yield ps.map(_.copy(details = details))

    paymentSchedule.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def deletePS(psId: Int,projectId: Int) = {
    paymentScheduleDbUpdator.deletePaymentSchedule(psId,projectId).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }

  def deletePsDetails(psDetailsId: Int,psId:Int) = {
    paymentScheduleDbUpdator.deletePaymentScheduleDetail(psId,psDetailsId).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }


}

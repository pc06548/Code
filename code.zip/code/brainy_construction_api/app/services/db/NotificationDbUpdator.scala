package services.db

import javax.inject.Inject
import model.notifications.NotificationRecipients
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.SlickTables

import scala.concurrent.ExecutionContext.Implicits.global

class NotificationDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends SlickTables{

  import dbConfig._
  import profile.api._
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

 def getNotificationReceivers(companyId:Int,userId:Int) ={

   val query =
     s"""SELECT l.USER_ID as USER_ID, r.NAME as ROLE_NAME, ft.token as TOKEN
        |FROM LOGIN_ROLE_MAPPING as rm
        |INNER JOIN COMPANY AS c ON rm.COMPANY_ID = c.ID
        |INNER JOIN ROLE as r ON rm.ROLE_ID = r.ID
        |INNER JOIN LOGIN as l ON rm.login_id = l.id
        |INNER JOIN fcm_token as ft ON ft.user_id = l.USER_ID
        |WHERE rm.COMPANY_ID = $companyId AND l.USER_ID != ${userId}""".stripMargin
   //println(query)
   val res = sql"#$query".as[NotificationRecipients]
   db.run(res).map(_.toList)
 }

}
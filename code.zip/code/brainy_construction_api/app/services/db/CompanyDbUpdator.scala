package services.db

import auth.db.RoleDb
import config.DateUtil
import javax.inject.Inject
import model.GetNameResponse
import model.company.Company
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.CompanyTable
import slick.sql.SqlAction

import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future

class CompanyDbUpdator @Inject()(configProvider: DatabaseConfigProvider,roleDb: RoleDb) extends CompanyTable{

  import dbConfig._
  import profile.api._
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = companies returning companies.map(_.id) into ((item, id) => item.copy(id = id))

  def getAllIds() = db.run{
    companies.map(_.id).result.map(_.flatten)
  }

  def createCompanyAndGetCompanyId(newCompany: Company): Future[Option[Int]]= db.run {
    for {
      newCompany <- insertQuery += newCompany
    } yield newCompany.id
  }

  def updateCompany(company: Company) = db.run {
    companies.filter(_.id === company.id).update(company).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getById(id: Int): Future[Option[Company]] = db.run {
    companies.filter(c => (c.id === id ) ).result.headOption
  }

  def search(loginId:Int,orgId : Int, name: Option[String]) = {
    val query =
      s"""
         |select distinct c.id,c.name,c.org_id,c.address,c.email,c.phone_number1,c.phone_number2,
         |c.logo,c.slogan,c.start_date,c.last_modified,c.letter_head,c.footer,c.pan_number,c.gst_nbr,
         |c.bank_account_nbr,c.ifsc_code,c.bank_name,c.bank_address
         |from company as c
         |inner join LOGIN_ROLE_MAPPING lm on lm.company_id = c.id
         |where c.org_id = ${orgId} and lm.login_id = ${loginId}
         |${optionalLikeFilter("c.name",name)}
      """.stripMargin
    val res = sql"#$query".as[Company]
    db.run(res).map(_.toList)

  }
  def getAll() = {
    val query =
      s"""
         |select distinct c.id,c.name,c.org_id,c.address,c.email,c.phone_number1,c.phone_number2,
         |c.logo,c.slogan,c.start_date,c.last_modified,c.letter_head,c.footer,c.pan_number,c.gst_nbr,
         |c.bank_account_nbr,c.ifsc_code,c.bank_name,c.bank_address
         |from company as c
         |where org_id not in (1,6) and c.email is not null
      """.stripMargin
    val res = sql"#$query".as[Company]
    db.run(res).map(_.toList)

  }

  def getAllForBatchJob(reportName:Option[String],reportDate:Option[String]) = {
    val query =
      s"""
         |select distinct c.id,c.name,c.org_id,c.address,c.email,c.phone_number1,c.phone_number2,
         |c.logo,c.slogan,c.start_date,c.last_modified,c.letter_head,c.footer,c.pan_number,c.gst_nbr,
         |c.bank_account_nbr,c.ifsc_code,c.bank_name,c.bank_address
         |from company as c
         |left join batch_job_status b on b.company_id = c.company_id
         |where org_id not in (1,6) and c.email is not null
         |${optionalLikeFilter("b.report_name",reportName)}
         ${optionalDateFilter("b.last_report_created_date",reportDate)}
         |and b.status != 'SUCCESS'
      """.stripMargin
    val res = sql"#$query".as[Company]
    db.run(res).map(_.toList)

  }

  def getAllNames(orgId : Int) = db.run {

    val query = for{
      c <- companies if (c.orgId === orgId)
    }yield (c.id,c.name,c.logo)

    query.sortBy(_._2).result.map(names => names.map(name => GetNameResponse(name._1,name._2,name._3)))
  }

  def delete(id: Int) ={

    val companyDeletequery: SqlAction[Int, NoStream, Effect] = sqlu"delete from company where id = ${id}"
    val roleDeleteQuery = sqlu"""#${roleDb.getRemoveRoleLoginCompanyMappingQuery(id)}"""
    val finalRes: DBIOAction[Int, NoStream, Effect with Effect] = for{
      _ <- roleDeleteQuery
      c <- companyDeletequery
    }yield c
    db.run(finalRes.transactionally.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    })
  }

  def getBatchJobLastRunDate(reportName: String) ={
    val query =
      s"""
         |select last_time_run_date from batch_job_status
         |where batch_job_name like '%${reportName}%'
      """.stripMargin
    val selectQuery = sql"#$query".as[Option[String]]

    val finalRes = for{
      date <- selectQuery
      _ <- updateBatchJobStatus(reportName)
    }yield date

    db.run(finalRes.transactionally).map(r => {
      r.head match {
        case Some(lastD) if(DateUtil.today == DateUtil.getDateFromDateTime(lastD)) => {
          Some(lastD)
        }
        case _ => None
      }
    })
  }

  private def updateBatchJobStatus(reportName: String) ={

    val query =
      s"""
         |update batch_job_status set last_time_run_date = '${DateUtil.currentTimestamp}'
         |where batch_job_name like '%${reportName}%'
      """.stripMargin
    sql"#$query".as[Int]
  }
}
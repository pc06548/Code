package services.db

import javax.inject.Inject
import model.PurchaseInventory
import model.reports.DirectorReportPurchaseInventoryData
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.PurchaseInventoryTable

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PurchaseInventoryDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends PurchaseInventoryTable {

  import dbConfig._
  import profile.api._
  
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = purchaseInventories returning purchaseInventories.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(projectId:Int,id: Int): Future[Option[PurchaseInventory]] = db.run{
    purchaseInventories.filter(c => (c.id === id && c.projectId === projectId)).result.headOption
  }

  def createPurchaseInventory(newPurchaseInventory: PurchaseInventory): Future[Option[Int]] = db.run {
    for{
      newPurchaseInventory <- insertQuery += newPurchaseInventory
    }yield newPurchaseInventory.id

  }

  def update(purchaseInventory: PurchaseInventory) = db.run {
    purchaseInventories.filter(_.id === purchaseInventory.id).update(purchaseInventory).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def searchPurchaseInventorys(companyId:Int,projectId: Int,
                               startDate:Option[String],endDate:Option[String],
                               supplierName:Option[String],transporterName:Option[String]): Future[List[PurchaseInventory]] ={

    val query =
      s"""
         |select p.id,p.company_id,p.project_id,p.material,p.date,p.purchase_order_number,p.vehicle_number,
         |p.in_time,p.out_time,p.chalan_number,p.quantity,p.unit,p.source,p.received_by,p.note,
         |p.transporter_name,p.transport_charges,p.hamali_charges,p.rating
         |from purchase_inventory p
         |where p.project_id = ${projectId} and p.company_id = ${companyId}
         ${optionalLikeFilter("p.source",supplierName)}
         ${optionalLikeFilter("p.transporter_name",transporterName)}
         |${dateBetweenColumn("p.date",startDate,endDate)}
         ${orderByDateAsc("p.date")}
       """.stripMargin
    val res = sql"#$query".as[PurchaseInventory]
    ////println(query)
    db.run(res).map(_.toList)
  }

  def directorReportData(): Future[List[DirectorReportPurchaseInventoryData]] ={

    val query =
      s"""
         |select p.company_id,p.name,
         |pi.material,pi.source,pi.vehicle_number,pi.in_time,pi.out_time,pi.chalan_number,
         |pi.purchase_order_number
         |from purchase_inventory pi
         |inner join project p on p.id = pi.project_id
         |where TO_DATE(pi.date,'dd-MM-yyyy') = CURRENT_DATE
       """.stripMargin
    val res = sql"#$query".as[DirectorReportPurchaseInventoryData]
    db.run(res).map(_.toList)
  }

  def delete(id: Int,projectId: Int) = db.run{
    purchaseInventories.filter(c => c.id === id && c.projectId === projectId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

}
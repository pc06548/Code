package services.db

import javax.inject.Inject
import model.Location
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.LocationTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class LocationDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends LocationTable{

  import dbConfig._
  import profile.api._
  private val locations = lifted.TableQuery[LocationT]
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = locations returning locations.map(_.id) into ((item, id) => item.copy(id = id))

  def createLocationAndGetLocationId(newLocation: Location): Future[Option[Int]]= db.run {
    for {
      newLocation <- insertQuery += newLocation
    } yield newLocation.id
  }

  def search(companyId:Int): Future[List[Location]] = db.run {
    locations.filter(c => c.companyId === companyId).result.map(_.toList)
  }

  def get(companyId : Int, id:Int) = db.run {
    locations.filter(c => (c.id === id && c.companyId === companyId)).result.headOption
  }

  def delete(companyId:Int,id: Int) = db.run{
    locations.filter(c => c.id === id && c.companyId === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def updateLocation(location: Location) = db.run {
    locations.filter(c => c.id === location.id && c.companyId === location.companyId).update(location).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }
}
package services.db

import akka.Done
import model.invoices.{InvoiceDetails, InvoiceSearch, SaveInvoice}
import model.reports.{DirectorReportPurchaseOverviewData, DueReportDetailsDb}
import services.db.queries.DirectorReportPurchaseOverviewQuery
import services.db.tables.SlickTables
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

trait InvoiceDbUpdator { self : SlickTables =>
  import dbConfig._
  import profile.api._
  def getById(companyId: Int, id: Int): Future[Option[SaveInvoice]]

  def getDetails(invoiceId: Int): Future[Seq[InvoiceDetails]]

  def createInvoice(newContractorInvoice: SaveInvoice): Future[Option[Int]]

  def saveDetails(details : Seq[InvoiceDetails]): Future[Unit]

  def updateDetails(details : Seq[InvoiceDetails]): Future[Done]

  def updateInvoice(consultant: SaveInvoice): Future[Int]

  def searchInvoices(companyId:Int,name: String, projectId: Option[Int], status : String,
                     startDate:Option[String],endDate:Option[String],isTemporary:Option[Boolean],invoiceNumber:Option[String]): Future[List[InvoiceSearch]]

  def deleteInvoice(id: Int, companyId: Int): Future[Int]

  def deleteInvoiceDetail(invoiceId : Int,id: Int): Future[Int]

  def directorReportPurchaseOverviewData() = {
    val query = DirectorReportPurchaseOverviewQuery.query()
    val res = sql"#$query".as[DirectorReportPurchaseOverviewData]
    db.run(res).map(_.toList)
  }
}

// . TODO cleanup of use
/*
package services.db

import javax.inject.{Inject, Singleton}
import model.User
import org.slf4j.LoggerFactory
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile
import slick.lifted.ProvenShape

import scala.concurrent.{ExecutionContext, Future}


@Singleton
class UserDbUpdater @Inject()(dbConfigProvider: DatabaseConfigProvider)(implicit ec: ExecutionContext) {

  private val logger = LoggerFactory.getLogger(this.getClass)

  private val dbConfig = dbConfigProvider.get[JdbcProfile]

  import dbConfig._
  import profile.api._


  private class UserTable(tag: Tag) extends Table[User](tag, "user") {

    /** The ID column, which is auto incremented */
    def id = column[Int]("id", O.AutoInc)

    def userName = column[String]("username")

    def pk = primaryKey("user_pkey", (id, userName))

    def password = column[String]("password")

    def name = column[String]("name")

    def accessType = column[String]("access_type")

    def defaultProjectID = column[Int]("default_project_id")

    def adminProjectID = column[Int]("admin_project_id")

    def defaultProjectName = column[String]("default_project_name")


    def * : ProvenShape[User] = (id, userName, password, name, accessType, defaultProjectID, defaultProjectName,adminProjectID) <> ((User.apply _).tupled, User.unapply)
  }

  /**
    * The starting point for all queries on the people table.
    */
  private val user = TableQuery[UserTable]


  def create(newUser: User): Future[Int] = db.run {
    user.insertOrUpdate(newUser)
  }

  def loadUsers: Future[Seq[User]] = db.run {
    user.result
  }

  def getUser(userName: String, password: String): Future[Seq[User]] = db.run {
    val selectQuery = user.filter(usr => usr.userName === userName && usr.password === password)
    logger.info("getUser userName: {}, password: {}\n query: '{}'", userName, password, selectQuery.result.statements.head)
    selectQuery.result
  }

  def updateDefaultProject(userName: String, defaultPrjId: Int, defaultPrjName: String): Future[Int] = {
    val q = for {u <- user if u.userName === userName} yield (u.defaultProjectID, u.defaultProjectName)
    val updateAction = q.update((defaultPrjId, defaultPrjName))
    logger.info("updateDefaultProject userName: {}, defaultProjectId: {}, defaultProjectName: {}\n update query: '{}'",
      userName, defaultPrjId.toString, defaultPrjName, updateAction.statements.head)
    db.run(updateAction)
  }
}
*/

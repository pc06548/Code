package services.db

import javax.inject._
import config.ResultSetIterator
import model.reports.{CustomerCollection, Purchase, RecoveryFromDb, Sales}

class ReportsDbUpdator @Inject()(databaseUpdatorService: DatabaseUpdatorService) {

  private def projectFilter(dbColumnName : String,projectId : Int): String = projectId match {
    case 0 => ""
    case _ => s" AND $dbColumnName = $projectId"
  }



}

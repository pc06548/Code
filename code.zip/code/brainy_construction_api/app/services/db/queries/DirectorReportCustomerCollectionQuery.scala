package services.db.queries

object DirectorReportCustomerCollectionQuery {

  def query() =
    s"""
       |select c.company_id,p.name,cd.customer_id, c.name,fd.flat_details,fd.flat_number,
       |SUM(net_amount)as total_amount_due,r.receipt_total_amount as receipt_amount,
       |(select SUM(receipt.receipt_total_amount) from receipt where receipt.customer_id = cd.customer_id) as total_amount_paid
       |from customer_demands cd
       |inner join receipt r on r.customer_id = cd.customer_id
       |inner join customer c on r.customer_id = c.id
       |inner join flat_details fd on c.flat_detail_id = fd.id
       |inner join project p on p.id = c.project_id
       |where
       |TO_DATE(cd.due_date,'dd-MM-yyyy') <= CURRENT_DATE and
       |TO_DATE(r.date_created,'dd-MM-yyyy') = CURRENT_DATE
       |group by cd.customer_id, p.name,c.name,fd.flat_details,fd.flat_number,r.receipt_total_amount,c.company_id
    """.stripMargin
}

package services.db.queries

object MonthlyTdsQuery {

  def query(dateComparision : String):String = {
    s"""
       |select ci.company_id,'Contractor' as category, SUM(cv.tds) as total_tds
       |from contractor_voucher cv
       |inner join contractor_invoice ci on ci.id = cv.invoice_id
       |where $dateComparision
       |group by ci.company_id
       |UNION
       |select ci.company_id,'Supplier' as category, SUM(cv.tds) as total_tds
       |from supplier_voucher cv
       |inner join supplier_invoice ci on ci.id = cv.invoice_id
       |where $dateComparision
       |group by ci.company_id
       |UNION
       |select ci.company_id,'Consultant' as category, SUM(cv.tds) as total_tds
       |from consultant_voucher cv
       |inner join consultant_invoice ci on ci.id = cv.invoice_id
       |where $dateComparision
       |group by ci.company_id
       |UNION
       |select ci.company_id,'Other' as category, SUM(cv.tds) as total_tds
       |from other_voucher cv
       |inner join other_invoice ci on ci.id = cv.invoice_id
       |where $dateComparision
       |group by ci.company_id
     """.stripMargin
  }
}

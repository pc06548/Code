package services.db.queries

object DirectorReportPurchaseOverviewQuery {

  def query() =
    s"""
       |--contractor
       |select p.company_id,p.name,'Contractor' as category, c.name,
       |i.total_amount,i.invoice_number,STRING_AGG(d.description,',') as description
       |from contractor_invoice as i
       |INNER JOIN contractor_invoice_details as d on d.invoice_id = i.id
       |inner join contractor c on c.id = i.contractor_id
       |inner join project p on p.id = i.project_id
       |where TO_DATE(i.invoice_date,'dd-MM-yyyy') = CURRENT_DATE
       |group by p.company_id,p.name, c.name,i.total_amount,i.invoice_number
       |UNION
       |--consultant
       |select p.company_id,p.name,'Consultant' as category, c.name,
       |i.total_amount,i.invoice_number,STRING_AGG(d.description,',') as description
       |from consultant_invoice as i
       |INNER JOIN consultant_invoice_details as d on d.invoice_id = i.id
       |inner join consultant c on c.id = i.consultant_id
       |inner join project p on p.id = i.project_id
       |where TO_DATE(i.invoice_date,'dd-MM-yyyy') = CURRENT_DATE
       |group by p.company_id,p.name, c.name,i.total_amount,i.invoice_number
       |UNION
       |--supplier
       |select p.company_id,p.name,'Supplier' as category, c.name,
       |i.total_amount,i.invoice_number,STRING_AGG(d.description,',') as description
       |from supplier_invoice as i
       |INNER JOIN supplier_invoice_details as d on d.invoice_id = i.id
       |inner join supplier c on c.id = i.supplier_id
       |inner join project p on p.id = i.project_id
       |where TO_DATE(i.invoice_date,'dd-MM-yyyy') = CURRENT_DATE
       |group by p.company_id,p.name, c.name,i.total_amount,i.invoice_number
       |UNION
       |--other
       |select p.company_id,p.name,c.name, i.name,
       |i.total_amount,i.invoice_number,STRING_AGG(d.description,',') as description
       |from other_invoice i
       |INNER JOIN other_invoice_details as d on d.invoice_id = i.id
       |inner join category c on c.id = i.category_id
       |inner join project p on p.id = i.project_id
       |where TO_DATE(i.invoice_date,'dd-MM-yyyy') = CURRENT_DATE
       |group by p.company_id,p.name, c.name,i.name,i.total_amount,i.invoice_number
       |UNION
       |--office
       |select i.company_id,'Office' as project_name,c.name, i.name,
       |i.total_amount,i.invoice_number,STRING_AGG(d.description,',') as description
       |from other_invoice i
       |INNER JOIN other_invoice_details as d on d.invoice_id = i.id
       |inner join category c on c.id = i.category_id
       |where TO_DATE(i.invoice_date,'dd-MM-yyyy') = CURRENT_DATE and i.project_id is null
       |group by i.company_id,c.name,i.name,i.total_amount,i.invoice_number
    """.stripMargin
}

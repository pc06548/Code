package services.db.queries

object DirectorReportExpenseQuery {

  def query() =
    s"""
      |--contractor
      |select p.company_id,p.name,'Contractor' as category, c.name, cv.total_amount,cv.voucher_number,cv.payment_ref_number
      |from contractor_voucher cv
      |inner join contractor_invoice ci on ci.id = cv.invoice_id
      |inner join contractor c on c.id = ci.contractor_id
      |inner join project p on p.id = ci.project_id
      |where TO_DATE(cv.voucher_date,'dd-MM-yyyy') = CURRENT_DATE 
      |UNION
      |--consultant
      |select p.company_id,p.name,'Consultant' as category, c.name, cv.total_amount,cv.voucher_number,cv.payment_ref_number
      |from consultant_voucher cv
      |inner join consultant_invoice ci on ci.id = cv.invoice_id
      |inner join consultant c on c.id = ci.consultant_id
      |inner join project p on p.id = ci.project_id
      |where TO_DATE(cv.voucher_date,'dd-MM-yyyy') = CURRENT_DATE 
      |UNION
      |--supplier
      |select p.company_id,p.name,'Supplier' as category, c.name, cv.total_amount,cv.voucher_number,cv.payment_ref_number
      |from supplier_voucher cv
      |inner join supplier_invoice ci on ci.id = cv.invoice_id
      |inner join supplier c on c.id = ci.supplier_id
      |inner join project p on p.id = ci.project_id
      |where TO_DATE(cv.voucher_date,'dd-MM-yyyy') = CURRENT_DATE 
      |UNION
      |--other
      |select p.company_id,p.name,c.name, ci.name, cv.total_amount,cv.voucher_number,cv.payment_ref_number
      |from other_voucher cv
      |inner join other_invoice ci on ci.id = cv.invoice_id
      |inner join category c on c.id = ci.category_id
      |inner join project p on p.id = ci.project_id
      |where TO_DATE(cv.voucher_date,'dd-MM-yyyy') = CURRENT_DATE
      |UNION
      |--office
      |select ci.company_id,'Office' as project_name,c.name, ci.name, cv.total_amount,cv.voucher_number,cv.payment_ref_number
      |from other_voucher cv
      |inner join other_invoice ci on ci.id = cv.invoice_id
      |inner join category c on c.id = ci.category_id
      |where TO_DATE(cv.voucher_date,'dd-MM-yyyy') = CURRENT_DATE and ci.project_id is null
    """.stripMargin
}

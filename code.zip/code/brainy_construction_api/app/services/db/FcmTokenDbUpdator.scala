package services.db

import javax.inject.Inject
import model.notifications.FcmToken
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.FcmTokenTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class FcmTokenDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends FcmTokenTable{

  import dbConfig._
  import profile.api._
  private val fcmTokens = lifted.TableQuery[FcmTokenT]
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = fcmTokens returning fcmTokens.map(_.token) into ((item, id) => item.copy(token = id))

  def create(newFcmToken: FcmToken): Future[String]= db.run {
    for {
      newFcmToken <- insertQuery += newFcmToken
    } yield newFcmToken.token
  }

  def updateFcmToken(fcmToken: FcmToken) = db.run {
    fcmTokens.filter(f => f.userId === fcmToken.userId && f.deviceId === fcmToken.deviceId ).update(fcmToken).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def get(userId:Int): Future[Seq[FcmToken]] = db.run {
    fcmTokens.filter(_.userId === userId).result
  }

  def get(userId:Seq[Int]): Future[Seq[FcmToken]] = db.run {
    fcmTokens.filter(_.userId.inSet(userId)).result
  }

  def delete(userId:Int) = {
    fcmTokens.filter(_.userId === userId).delete
  }
}
package services.db

import javax.inject._
import model.{GetNameResponse, Project}
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.ProjectTable
import slick.lifted
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class ProjectDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends ProjectTable {

  import dbConfig._
  import profile.api._
  override val projects: TableQuery[ProjectT] = lifted.TableQuery[ProjectT]
  val insertQuery = projects returning projects.map(_.id) into ((item, id) => item.copy(id = id))

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  def createProject(newProject: Project) = db.run {
    for {
      newProject <- insertQuery += newProject
    } yield newProject.id
  }

  def updateProject(project: Project) = db.run {
    projects.filter(p => p.id === project.id && p.companyId === project.companyId).update(project).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getById(id: Int,companyId: Int): Future[Option[Project]] = db.run {
    projects.filter(c => (c.id === id && c.companyId === companyId)).result.headOption
  }

  def search(companyId: Int, name: Option[String], status : Option[String]) = db.run {

    val query = for {
      c <- projects if (c.companyId === companyId) &&
        (c.name.toLowerCase like s"%${name.map(_.toLowerCase).getOrElse("")}%") &&
        (c.status.toUpperCase like s"%${status.map(_.toUpperCase).getOrElse("")}%")
    }yield c
    query.result
  }

  def getAllNames(companyId: Int,status:List[String]) = db.run {

    val query = for{
      c <- projects if (c.companyId === companyId) &&
                  (c.status.toUpperCase.inSet(status))
    }yield (c.id,c.name)

    query.sortBy(_._2).result.map(names => names.map(name => GetNameResponse(name._1,name._2)))
  }

  def delete(id: Int,companyId: Int) = db.run{
    projects.filter(c => c.id === id && c.companyId === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }
}

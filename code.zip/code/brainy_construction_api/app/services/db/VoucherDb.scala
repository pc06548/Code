package services.db

import java.sql.ResultSet

import config.DateUtil
import model.VoucherNumber
import model.reports._
import model.vouchers.{SaveVoucher, Voucher, VoucherSearch}
import services.db.queries.{DirectorReportExpenseQuery, MonthlyTdsQuery}
import services.db.tables.SlickTables
import slick.jdbc.SQLActionBuilder

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

trait VoucherDb {  self : SlickTables =>

  import dbConfig._
  import profile.api._
  def getById(companyId: Int, id: Int): Future[Option[Voucher]]

  def getAmountPaidForInvoice(invoiceId : Int) : Future[Option[Double]]

  def createVoucher(companyId:Int,newContractorVoucher: SaveVoucher): Future[Option[Int]]

  def searchVouchers(companyId:Int,name: Option[String], projectId: Option[Int],
                     startDate:Option[String],endDate:Option[String],voucherNumber:Option[String],isTemporary:Option[Boolean],
                     category : Option[String] = None): Future[List[VoucherSearch]]

  def getVouchers(companyId:Int,name: Option[String], projectId: Option[Int],
                  startDate:Option[String],endDate:Option[String],category : Option[String] = None,
                  modeOfPayment:Option[String],sortBy:Option[String],onlyOfficeData:Boolean): Future[List[Voucher]]

  def delete(id: Int): Future[Int]

  def getAccountSummaryData(companyId:Int, projectId:Option[Int], name:String,
                            startDate:Option[String], endDate:Option[String],
                            category:Option[String] = None,onlyOfficeData:Boolean) :Future[List[AccountSummaryData]]

  def getCollectiveSummaryData(companyId:Int, projectId:Option[Int],
                            startDate:Option[String], endDate:Option[String],onlyOfficeData:Boolean) :Future[List[CollectiveSummaryData]]


  def getTdsDetails(companyId:Int,name: Option[String], projectId: Option[Int],
                  startDate:Option[String],endDate:Option[String],category : Option[String] = None,onlyOfficeData:Boolean): Future[List[TdsData]]

  def getLastTenVoucherNumbers(companyId: Int): Future[List[VoucherNumber]] = {
    // [A-Z]{1,6}-[0-9]{1,5}/[0-9]{4,4}-[0-9]{2,2}
    val query =
      s"""
         |select v.company_id,v.last_modified,v.voucher_number
         |from voucher_number v
         |where v.company_id = ${companyId}
         |order by ${toDateTimeFromColumn("v.last_modified")} DESC
         |LIMIT 10
      """.stripMargin
    val res = sql"#$query".as[VoucherNumber]
    db.run(res).map(_.toList)
  }

  def orderByClause(soryBy:Option[String]) = soryBy.map(sort => sort.toUpperCase match {
    case "VOUCHERDATE" => s"order by ${toDateFromColumn("v.voucher_date")}"
    case "PAYMENTDATE" => s"order by ${toDateFromColumn("v.payment_date")}"
    case "" => ""
  }).getOrElse("")

  def deleteAllTemporaryInvoicesAndVouchers(companyId:Int,projectId:Option[Int]) = {
    val voucherQuery: SQLActionBuilder = projectId match {
      case Some(p) => sql"""SELECT public."DELETE_TEMPORARY_VOUCHER_BY_PROJECT"(${companyId},${p});"""
      case None => sql"""SELECT public."DELETE_TEMPORARY_VOUCHER_BY_COMPANY"(${companyId});"""
    }

    val invoiceQuery = projectId match {
      case Some(p) => sql"""SELECT public."DELETE_TEMPORARY_INVOICE_BY_PROJECT"(${companyId},${p});"""
      case None => sql"""SELECT public."DELETE_TEMPORARY_INVOICE_BY_COMPANY"(${companyId});"""
    }

    db.run(voucherQuery.as[String]).flatMap(v => {
      db.run(invoiceQuery.as[String])
    })

  }

  def directorReportExpenseOverview() = {
    val query = DirectorReportExpenseQuery.query()
    val res = sql"#$query".as[ExpenseOverviewData]
    db.run(res).map(_.toList)
  }

  def getMonthlyTdsPerCategory(month:String) = {
    val dateComparision  = s"""
                              |${toDateFromColumn("cv.payment_date")} >= ${toDateFromValue(DateUtil.getFirstDayFromMonth(month))}
                              |and ${toDateFromColumn("cv.payment_date")} <= ${toDateFromValue(DateUtil.getLastDayOfMonth(month))}
         """.stripMargin
    val query = MonthlyTdsQuery.query(dateComparision)
    val res = sql"#$query".as[MonthWiseTdsPerCategory]
    db.run(res).map(_.toList.map(_.copy(month = Some(month))))
  }
}

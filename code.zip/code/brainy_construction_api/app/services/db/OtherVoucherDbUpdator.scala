package services.db

import config.DateUtil
import javax.inject.Inject
import model.VoucherNumber
import model.reports.{AccountSummaryData, CollectiveSummaryData, TdsData, TdsDetail}
import model.vouchers._
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.{OtherVoucherTable, VoucherNumberTable}
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class OtherVoucherDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends OtherVoucherTable with VoucherDb with VoucherNumberTable {

  import dbConfig._
  import profile.api._
  override val otherVouchers = lifted.TableQuery[OtherVoucherT]
  override val voucherNumbers: TableQuery[VoucherNumberT] = lifted.TableQuery[VoucherNumberT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = otherVouchers returning otherVouchers.map(_.id) into ((item, id) => item.copy(id = id))

  override def getById(companyId: Int, id: Int): Future[Option[Voucher]] = {

   val query =
     s"""
        |select project.name,v.id,v.voucher_number,v.reason,v.amount_before_tax,v.cgst,v.sgst,v.amount_after_tax,v.tds,v.total_amount,
        |v.voucher_date,v.remark,c.name as category,v.payment_ref_number,v.account_number,v.payment_date,v.mode,i.id,i.invoice_number, i.name, i.is_temporary
        |from other_voucher v
        |INNER JOIN other_invoice as i on v.invoice_id = i.id
        |INNER JOIN category as c on c.id = i.category_id
        |LEFT JOIN project on project.id = i.project_id
        |where v.id = ${id}
      """.stripMargin
    val res = sql"#$query".as[Voucher]
    db.run(res).map(_.toList.headOption)
  }

  override def getAmountPaidForInvoice(invoiceId : Int) : Future[Option[Double]] = db.run {
    val amount = otherVouchers.filter(v => v.invoice_id === invoiceId).map(_.amountAfterTax).sum
    amount.result
  }

  override def createVoucher(companyId:Int,newOtherVoucher: SaveVoucher): Future[Option[Int]] = db.run {
    (for{
      newVoucher <- insertQuery += newOtherVoucher
      _ <- voucherNumbers += VoucherNumber(companyId,DateUtil.currentTimestamp,newOtherVoucher.voucherNumber)
    }yield newVoucher.id).transactionally

  }

  override def searchVouchers(companyId:Int,name: Option[String], projectId: Option[Int],
                              startDate:Option[String],endDate:Option[String],
                              voucherNumber:Option[String],isTemporary:Option[Boolean],category : Option[String] = None): Future[List[VoucherSearch]] = {
    def projectFilter = projectId.map(pid => s"and i.project_id = $pid").getOrElse("AND i.project_id IS NULL")

    val query =
      s"""
         |select v.id,v.voucher_number,i.name,v.reason,i.invoice_number,v.total_amount,v.voucher_date,c.name as category,i.is_temporary
         |from other_voucher v, other_invoice as i, category as c
         |where v.invoice_id = i.id and i.company_id = ${companyId}
         |${dateBetweenColumn("v.payment_date",startDate,endDate)}
         |and i.category_id = c.id ${projectFilter} ${optionalFilter("i.is_temporary", isTemporary)}
         |and i.name like '%${name.getOrElse("")}%' and
         |c.name like '%${category.getOrElse("")}%' ${optionalLikeFilter("v.voucher_number",voucherNumber)}
      """.stripMargin
    val res = sql"#$query".as[VoucherSearch]
    db.run(res).map(_.toList)
  }

  override def delete(id: Int): Future[Int] = db.run{
    otherVouchers.filter(c => c.id === id).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  override def getAccountSummaryData(companyId: Int, projectId: Option[Int], name: String,
                                     startDate: Option[String], endDate: Option[String],
                                     category: Option[String],onlyOfficeData:Boolean): Future[List[AccountSummaryData]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select i.name,v.reason, p.name,v.tds,v.total_amount, v.payment_ref_number,v.payment_date,
         |i.invoice_number,c.name,i.invoice_date,i.total_amount,i.amount_before_tax,
         |i.cgst,i.sgst,'N/A' as doc_ref_number,v.voucher_number,i.is_temporary
         |from other_voucher v
         |INNER JOIN other_invoice as i on v.invoice_id = i.id
         |INNER JOIN category as c on c.id = i.category_id
         |LEFT JOIN project as p on i.project_id = p.id
         |where i.company_id = ${companyId} ${optionalLikeFilter("c.name",category)}
         |${dateBetweenColumn("v.payment_date",startDate,endDate)}
         |${optionalFilter("i.project_id",projectId)}
         |${onlyOfficeDataFilter}
         |${orderByDateAsc("v.payment_date")}
      """.stripMargin

    val res = sql"#$query".as[AccountSummaryData]
    db.run(res).map(_.toList)
  }

  override def getCollectiveSummaryData(companyId: Int, projectId: Option[Int],
                                        startDate: Option[String], endDate: Option[String],onlyOfficeData:Boolean): Future[List[CollectiveSummaryData]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select p.name,c.name,SUM(v.total_amount), 'Other' as department
         |from other_voucher v
         |INNER JOIN other_invoice as i on v.invoice_id = i.id
         |INNER JOIN category as c on c.id = i.category_id
         |LEFT JOIN project as p on p.id = i.project_id
         |where i.company_id = ${companyId}
         |${dateBetweenColumn("v.payment_date",startDate,endDate)}
         |${optionalFilter("i.project_id",projectId)}
         | ${onlyOfficeDataFilter}
         |group by p.name,c.name
         |order by p.name,c.name
      """.stripMargin

    val res = sql"#$query".as[CollectiveSummaryData]
    db.run(res).map(_.toList)
  }

  override def getVouchers(companyId: Int, name: Option[String], projectId: Option[Int], startDate: Option[String],
                           endDate: Option[String], category: Option[String],modeOfPayment:Option[String],
                           sortBy:Option[String],onlyOfficeData:Boolean): Future[List[Voucher]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select project.name,v.id,v.voucher_number,v.reason,v.amount_before_tax,v.cgst,v.sgst,v.amount_after_tax,v.tds,v.total_amount,
         |v.voucher_date,v.remark,c.name as category,v.payment_ref_number,v.account_number,v.payment_date,v.mode,i.id,i.invoice_number, i.name, i.is_temporary
         |from other_voucher v
         |INNER JOIN other_invoice as i on v.invoice_id = i.id
         |INNER JOIN category as c on c.id = i.category_id
         |LEFT JOIN project on project.id = i.project_id
         |where i.company_id = ${companyId}
        ${dateBetweenColumn("v.payment_date", startDate, endDate)}
         |${optionalLikeFilter("c.name",name)}
         | ${onlyOfficeDataFilter}
         |${optionalLikeFilter("v.mode", modeOfPayment)}
         |${optionalFilter("i.project_id",projectId)} ${orderByClause(sortBy)}
      """.stripMargin
    val res = sql"#$query".as[Voucher]
    db.run(res).map(_.toList)
  }

  override def getTdsDetails(companyId: Int, name: Option[String], projectId: Option[Int], startDate: Option[String],
                             endDate: Option[String], category: Option[String],onlyOfficeData:Boolean): Future[List[TdsData]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select i.name,v.voucher_date,v.amount_before_tax,v.tds,null as pan,c.name
         |from other_voucher v, other_invoice as i, category as c
         |where v.invoice_id = i.id and c.id = i.category_id
         |${dateBetweenColumn("v.payment_date", startDate, endDate)}
         |and i.company_id = ${companyId} and v.tds > 0
         |${optionalLikeFilter("i.name",name)}
         | ${onlyOfficeDataFilter}
         |${optionalLikeFilter("c.name",category)}
         |${optionalFilter("i.project_id",projectId)}
      """.stripMargin
    val res = sql"#$query".as[TdsData]
    db.run(res).map(_.toList)
  }
}
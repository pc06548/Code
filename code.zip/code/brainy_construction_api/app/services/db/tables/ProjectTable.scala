package services.db.tables
import model.{BankDetails, Project}

trait ProjectTable extends SlickTables {

  import dbConfig._
  import profile.api._

  val projects : TableQuery[ProjectT]

  protected class ProjectT(tag: Tag) extends Table[Project](tag,"project"){
    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def companyId = column[Option[Int]]("company_id")
    def name = column[String]("name")
    def description = column[Option[String]]("description")
    def address = column[Option[String]]("address")
    def pk = primaryKey("project_pkey", (id))
    def email = column[Option[String]]("email")
    def projectStartDate = column[Option[String]]("start_date")
    def projectEndDate = column[Option[String]]("end_date")
    def contactPerson = column[Option[String]]("contact_person")
    def contactPerPhonenNbr = column[Option[String]]("contact_person_number")
    def siteContactPerson = column[Option[String]]("site_contact_person")
    def siteContactPerPhonenNbr = column[Option[String]]("site_contact_person_number")
    def rera_number = column[Option[String]]("rera_number")
    def last_modified = column[Option[String]]("last_modified")
    def status = column[String]("status")
    def pan = column[Option[String]]("pan_number")
    def gst_nbr = column[Option[String]]("gst_nbr")
    def bank_acc_nbr = column[String]("bank_account_nbr")
    def ifsc_code = column[String]("ifsc_code")
    def bank_name = column[String]("bank_name")
    def bank_address = column[String]("bank_address")
    def imageRef = column[Option[String]]("image_ref")


    def *  =(
      id,companyId, name,description,address,email,projectStartDate,projectEndDate,
      contactPerson,contactPerPhonenNbr,siteContactPerson,siteContactPerPhonenNbr,
      rera_number,pan,gst_nbr,last_modified,status,
      (bank_acc_nbr,ifsc_code,bank_name,bank_address),
      imageRef
      ).shaped <> (
      {
      case (id,companyId, name,description,address,email,projectStartDate,projectEndDate,
      contactPerson,contactPerPhonenNbr,siteContactPerson,siteContactPerPhonenNbr,
      rera_number,pan,gst_nbr,last_modified,status,bankDetials,imageRef) =>
        Project(
          id,companyId,name,
          Some(description.getOrElse("")), Some(address.getOrElse("")), Some(email.getOrElse("")),
          Some(projectStartDate.getOrElse("")), Some(projectEndDate.getOrElse("")),
          Some(contactPerson.getOrElse("")), Some(contactPerPhonenNbr.getOrElse("")),
          Some(siteContactPerson.getOrElse("")), Some(siteContactPerPhonenNbr.getOrElse("")),
          Some(rera_number.getOrElse("")), Some(pan.getOrElse("")), Some(gst_nbr.getOrElse("")),
          Some(last_modified.getOrElse("")),status,
          Some(Option(BankDetails.tupled.apply(bankDetials)).getOrElse(BankDetails("","","",""))),
          Some(imageRef.getOrElse(""))
        )
      },
      {
        c : Project =>
          def bank(bd : Option[BankDetails]) ={
            val emptyResponse: (String, String, String, String) = ("","","","")
            bd match {
              case Some(b) => BankDetails.unapply(b).get
              case None   => emptyResponse
            }
          }
          Some(c.id,c.companyId,c.name,c.description,c.address,
            c.email,c.projectStartDate,c.projectEndDate,
            c.contactPerson,c.contactPerPhonenNbr,c.siteContactPerson,c.siteContactPerPhoneNbr,
            c.reraNbr,c.panNumber,c.gstNbr,c.last_modified,c.status,
            bank(c.bankDetails),c.imageRef
          )
      }
    )
  }

}






package services.db.tables

import model.CompanyConfig
import slick.lifted.ProvenShape

trait CompanyConfigTable extends SlickTables {

  import dbConfig._
  import profile.api._

  protected class CompanyConfigT(tag: Tag) extends Table[CompanyConfig](tag,"company_config"){

    def companyId = column[Option[Int]]("company_id")
    def dueDateLimit = column[Int]("customer_demand_due_date_limit")
    
    def pk = primaryKey("company_config_pkey", (companyId))

    def * : ProvenShape[CompanyConfig] = (companyId,dueDateLimit) <> ((CompanyConfig.apply _).tupled,CompanyConfig.unapply)

  }

}






package services.db.tables

import model.BankDetails
import model.company.Company
import slick.lifted
import slick.lifted.ProvenShape

trait CompanyTable extends SlickTables {

  import dbConfig._
  import profile.api._

  protected class CompanyT(tag: Tag) extends Table[Company](tag,"company"){
    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def orgId = column[Option[Int]]("org_id")
    def name = column[String]("name")
    def pk = primaryKey("company_pkey", (id))
    def address = column[String]("address")
    def email = column[Option[String]]("email")
    def phoneNumber1 = column[String]("phone_number1")
    def phoneNumber2 = column[Option[String]]("phone_number2")
    def start_date = column[Option[String]]("start_date")
    def last_modified = column[Option[String]]("last_modified")
    def logo = column[Option[String]]("logo")
    def slogan = column[Option[String]]("slogan")
    def letter_head = column[Option[String]]("letter_head")
    def footer = column[Option[String]]("footer")
    def pan = column[Option[String]]("pan_number")
    def gst_nbr = column[Option[String]]("gst_nbr")
    def bank_acc_nbr = column[Option[String]]("bank_account_nbr")
    def ifsc_code = column[Option[String]]("ifsc_code")
    def bank_name = column[Option[String]]("bank_name")
    def bank_address = column[Option[String]]("bank_address")

    def * : ProvenShape[Company] = (id, name, orgId, address,email,phoneNumber1,phoneNumber2,
                                    logo,slogan,start_date,last_modified,letter_head,footer,pan,gst_nbr,
      (bank_acc_nbr,ifsc_code,bank_name,bank_address)) <> (

      {
        case (id, name, orgId, address,email,phoneNumber1,phoneNumber2,
        logo,slogan,start_date,last_modified,letter_head,footer,pan,gst_nbr,bankDetails) =>
          Company(id, name, orgId, address,Some(email.getOrElse("")),phoneNumber1,Some(phoneNumber2.getOrElse("")),
            Some(logo.getOrElse("")),Some(slogan.getOrElse("")),Some(start_date.getOrElse("")),
            Some(last_modified.getOrElse("")),Some(letter_head.getOrElse("")),Some(footer.getOrElse("")),
            Some(pan.getOrElse("")),Some(gst_nbr.getOrElse("")),
            Some(BankDetails(bankDetails._1.getOrElse(""),bankDetails._2.getOrElse(""),
              bankDetails._3.getOrElse(""),bankDetails._4.getOrElse("")))

          )
      },
      {
        c : Company =>
          def bank(bd : Option[BankDetails]) ={
            val emptyResponse = (Some(""),Some(""),Some(""),Some(""))
            bd match {
              case Some(b) => (Option(b.bankAccountNbr),Option(b.ifscCode),Option(b.bankName),Option(b.bankAddress))
              case None   => emptyResponse
            }
          }
          Some(c.id,c.name,c.orgId,c.address,
            c.email,c.phoneNumber1,c.phoneNumber2,
            c.logo,c.slogan,c.startDate,c.lastModified,
            c.letterHead,c.footer,c.panNumber,c.gstNbr,
            bank(c.bankDetails)
          )
      }
    )
  }
  final protected val companies = lifted.TableQuery[CompanyT]

}






package services.db.tables

import model.notifications.FcmToken
import slick.lifted.ProvenShape

trait FcmTokenTable extends SlickTables {

  import dbConfig._
  import profile.api._

  protected class FcmTokenT(tag: Tag) extends Table[FcmToken](tag,"fcm_token"){
    /** The ID column, which is auto incremented */
    def userId = column[Option[Int]]("user_id")
    def deviceId = column[String]("device_id")
    def token = column[String]("token")

    def lastModified = column[Option[String]]("last_modified")
    def status = column[Option[String]]("status")

    def pk = primaryKey("company_config_pkey", (userId,deviceId))

    def * : ProvenShape[FcmToken] = (userId,deviceId,token,lastModified,status) <> ((FcmToken.apply _).tupled,FcmToken.unapply)

  }

}






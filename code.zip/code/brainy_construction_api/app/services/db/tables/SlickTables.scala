package services.db.tables

import config.DateUtil._
import play.api.db.slick.DatabaseConfigProvider
import slick.jdbc.JdbcProfile

trait SlickTables {

  def dbConfigProvider :DatabaseConfigProvider

  val dbConfig = dbConfigProvider.get[JdbcProfile]

  def toDateFromValue(date:String) = s"TO_DATE('${date}','${dateFormatString}')"

  def toDateFromColumn(columnName:String) = s"TO_DATE($columnName,'${dateFormatString}')"

  def toDateTimeFromColumn(columnName:String) = s"TO_TIMESTAMP($columnName,'dd-MM-yyyy HH24:MI:SS')"

  def dateBetweenColumn(columnName:String,startDate:Option[String],endDate:Option[String]) = {
    (startDate, endDate) match {
      case (Some(start), Some(end)) => {
        s"""
           |and ${toDateFromColumn(columnName)} >= ${toDateFromValue(start)}
           |and ${toDateFromColumn(columnName)} <= ${toDateFromValue(end)}
         """.stripMargin
      }
      case (None, Some(end)) => {
        s" and ${toDateFromColumn(columnName)} <= ${toDateFromValue(end)}"
      }
      case (Some(start), None) => {
        s" and ${toDateFromColumn(columnName)} >= ${toDateFromValue(start)} "
      }
      case _ => ""
    }
  }

  def orderByDateDesc(columnName:String) = s"order by ${toDateFromColumn(columnName)} desc"

  def orderByDateAsc(columnName:String) = s"order by ${toDateFromColumn(columnName)}"

  def optionalFilter[A](columnName:String,mayBeValue:Option[A]): String = {
    mayBeValue match {
      case Some(v) => s"AND ${columnName} = ${v}"
      case None => ""
    }
  }
  def optionalLikeFilter(columnName:String,mayBeValue:Option[String]): String = {
    mayBeValue match {
      case Some(v) => s"AND LOWER(${columnName}) like '%${mayBeValue.getOrElse("").toLowerCase}%'"
      case None => ""
    }
  }
  def likeFilter(columnName:String,value:String): String = {
    s"AND LOWER(${columnName}) like '%${value.toLowerCase}%'"
  }

  def optionalDateFilter(columnName:String,mayBeValue:Option[String]): String = {
    mayBeValue match {
      case Some(v) => s"AND ${toDateFromValue(v)} = ${toDateFromColumn(columnName)}"
      case None => ""
    }
  }
  def dateFilter(columnName:String,value:String): String = {
    s"AND ${toDateFromValue(value)} = ${toDateFromColumn(columnName)}"
  }
}

package services.db.tables

import model.Location
import slick.lifted.ProvenShape

trait LocationTable extends SlickTables {

  import dbConfig._
  import profile.api._

  protected class LocationT(tag: Tag) extends Table[Location](tag,"company_locations"){
    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def companyId = column[Option[Int]]("company_id")
    def friendlyAddress = column[Option[String]]("friendly_address")
    def name = column[String]("name")
    def longitude = column[Double]("longitude")
    def latitude = column[Double]("latitude")
    def pk = primaryKey("location_pkey", (id))

    def * : ProvenShape[Location] = (id,companyId,name,friendlyAddress,longitude,latitude) <> ((Location.apply _).tupled,Location.unapply)

  }

}
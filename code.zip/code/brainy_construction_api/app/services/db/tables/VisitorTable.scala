package services.db.tables

import model.{VisitorDetails}
import slick.lifted.ProvenShape

trait VisitorTable extends SlickTables {

  import dbConfig._
  import profile.api._

  protected class VisitorT(tag: Tag) extends Table[VisitorDetails](tag,"visitor"){
    def id = column[Option[Int]]("id", O.PrimaryKey, O.AutoInc)

    def companyId = column[Option[Int]]("company_id")

    def name = column[String]("name")

    def phoneNumber = column[String]("phone_number")

    def visitingDate = column[String]("visiting_date")

    def email = column[Option[String]]("email")

    def address = column[Option[String]]("address")

    def visitingTime = column[Option[String]]("visiting_time")

    def interestedInpromotion = column[Option[String]]("interested_in_promotion")

    def typeOfProperty = column[Option[String]]("type_of_property")

    def budget = column[Option[String]]("budget")

    def occupation = column[Option[String]]("occupation")

    def occupationDetails = column[Option[String]]("occupation_details")

    def salaryRange = column[Option[String]]("salary_range")

    def loanStatus = column[Option[String]]("loan_status")

    def projectInterestedIn = column[Option[String]]("project_interested_in")

    def possessionExpected = column[Option[String]]("possession_expected")

    def purpose = column[Option[String]]("purpose")

    def ageRange = column[Option[String]]("age_range")

    def heardFrom = column[Option[String]]("heard_from")


    def * : ProvenShape[VisitorDetails] = (id,companyId, name, email, address, phoneNumber, visitingDate,
      visitingTime, interestedInpromotion, typeOfProperty, budget,
      occupation,occupationDetails, salaryRange, loanStatus, projectInterestedIn,
      possessionExpected, purpose, ageRange, heardFrom) <> ({
      case (id,companyId, name, email, address, phoneNumber, visitingDate,
      visitingTime, interestedInpromotion, typeOfProperty, budget,
      occupation,occupationDetails, salaryRange, loanStatus, projectInterestedIn,
      possessionExpected, purpose, ageRange, heardFrom) => VisitorDetails(
        id,companyId, name, Some(email.getOrElse("")), Some(address.getOrElse("")), phoneNumber, visitingDate,
          Some(visitingTime.getOrElse("")), Some(interestedInpromotion.getOrElse("")), Some(typeOfProperty.getOrElse("")), Some(budget.getOrElse("")),
            Some(occupation.getOrElse("")),Some(occupationDetails.getOrElse("")), Some(salaryRange.getOrElse("")), Some(loanStatus.getOrElse("")), Some(projectInterestedIn.getOrElse("")),
              Some(possessionExpected.getOrElse("")), Some(purpose.getOrElse("")), Some(ageRange.getOrElse("")), Some(heardFrom.getOrElse(""))
      )
    }, VisitorDetails.unapply)
  }

}
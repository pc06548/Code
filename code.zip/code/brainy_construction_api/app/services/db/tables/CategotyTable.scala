package services.db.tables

import model.Category
import slick.lifted.ProvenShape

trait CategoryTable extends SlickTables {

  import dbConfig._
  import profile.api._

  protected class CategoryT(tag: Tag) extends Table[Category](tag,"category"){
    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def companyId = column[Option[Int]]("company_id")
    def categoryType = column[String]("category_type")
    def name = column[String]("name")
    
    def pk = primaryKey("category_pkey", (id))

    def * : ProvenShape[Category] = (id,companyId,categoryType,name) <> ((Category.apply _).tupled,Category.unapply)

  }

}






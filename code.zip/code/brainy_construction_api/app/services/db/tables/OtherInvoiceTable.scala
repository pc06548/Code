package services.db.tables

import model.invoices.{InvoiceDetails, OtherInvoicePersonDetails, SaveOtherInvoice}
import slick.lifted.{ProvenShape, TableQuery}

trait OtherInvoiceTable extends SlickTables { 

  val otherInvoices : TableQuery[OtherInvoiceT]
  val otherInvoiceDetails : TableQuery[OtherInvoiceDetailsT]

  import dbConfig._
  import profile.api._

  protected class OtherInvoiceT(tag: Tag) extends Table[SaveOtherInvoice](tag,"other_invoice"){

    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def name= column[String]("name")
    def address= column[Option[String]]("address")
    def phone_number1= column[Option[String]]("phone_number_1")
    def phone_number2= column[Option[String]]("phone_number_2")

    def invoice_number = column[String]("invoice_number")

    def amount_before_tax = column[Double]("amount_before_tax")
    def cgst = column[Double]("cgst")
    def sgst = column[Double]("sgst")
    def cgstPercentage = column[Double]("cgst_percentage")
    def sgstPercentage = column[Double]("sgst_percentage")
    def total_amount = column[Double]("total_amount")

    def project_id = column[Option[Int]]("project_id")
    def company_id = column[Int]("company_id")
    def category_id = column[Int]("category_id")

    def invoiceDate= column[String]("invoice_date")
    def last_updated= column[Option[String]]("last_updated")
    def createdDate = column[String]("created_date")

    def gstn = column[Option[String]]("gstn")
    def remark = column[Option[String]]("remark")
    def imageRef = column[Option[String]]("image_ref")
    def isTemporary = column[Option[Boolean]]("is_temporary")

    def pk = primaryKey("invoice_pkey", (id))

    def *  =(id, invoice_number, amount_before_tax, cgst,sgst,cgstPercentage,sgstPercentage,total_amount,
      invoiceDate,createdDate,last_updated,gstn,remark,imageRef,project_id,company_id,category_id,isTemporary,
      (name,address,phone_number1,phone_number2)
      ).shaped <> (
      {
        case (id, invoice_number, amount_before_tax, cgst,sgst,cgstPercentage,sgstPercentage,total_amount,
        invoiceDate,createdDate,last_updated,gstn,remark,imageRef,project_id,company_id,category_id,isTemporary,basicDetails) =>
          def personalDetails() = {
            OtherInvoicePersonDetails(
              basicDetails._1,
              Some(basicDetails._2.getOrElse("")),
              Some(basicDetails._3.getOrElse("")),
              Some(basicDetails._4.getOrElse(""))
            )
          }
          SaveOtherInvoice(id, invoice_number, amount_before_tax, cgst,sgst,cgstPercentage,sgstPercentage,total_amount,
            invoiceDate,createdDate,last_updated,gstn,remark,
            Some(imageRef.map(_.split(",").toList).getOrElse(List.empty[String])),project_id,company_id,category_id,personalDetails(),
            Seq.empty[InvoiceDetails],Some(isTemporary.getOrElse(false)),None
          )
      },
      {
        c : SaveOtherInvoice =>
          def basic(bd : OtherInvoicePersonDetails): (String, Some[String], Some[String], Some[String]) = {
            (bd.name,
              Some(bd.address.getOrElse("")),Some(bd.phoneNumber1.getOrElse("")),Some(bd.phoneNumber2.getOrElse(""))
            )
          }
          Option(c.id, c.invoiceNumber, c.amountBeforeTax, c.cgst,c.sgst,c.cgstPercentage,c.sgstPercentage,c.totalAmount,
            c.invoiceDate,c.createdDate,Some(c.lastUpdated.getOrElse("")),
            Some(c.gstn.getOrElse("")),Some(c.remark.getOrElse("")),
            c.imageRef.flatMap(l => if (l.isEmpty) None else Some(l.mkString(","))),c.projectId,c.companyId,c.categoryId,Some(c.isTemporary.getOrElse(false)),
            basic(c.personalDetails)
          )
      }
    )

  }

  protected class OtherInvoiceDetailsT(tag: Tag) extends Table[InvoiceDetails](tag,"other_invoice_details"){
    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def description = column[String]("description")

    def unit= column[String]("unit")
    def quantity = column[Double]("quantity")
    def rate = column[Double]("rate")
    def discount = column[Double]("discount")

    def amount = column[Double]("amount")
    def invoice_id = column[Option[Int]]("invoice_id")

    def pk = primaryKey("id", (id))

    def * : ProvenShape[InvoiceDetails] = (id, description, unit,quantity,rate,discount,amount,invoice_id) <> ((InvoiceDetails.apply _).tupled, InvoiceDetails.unapply)

  }
}

package services.db.tables

import model.VoucherNumber
import slick.lifted.{ProvenShape, TableQuery}

trait VoucherNumberTable extends SlickTables {

  val voucherNumbers : TableQuery[VoucherNumberT]
  import dbConfig._
  import profile.api._

  protected class VoucherNumberT(tag: Tag) extends Table[VoucherNumber](tag,"voucher_number"){

    def companyId = column[Int]("company_id")
    def lastModified = column[String]("last_modified")
    def voucherNumber = column[String]("voucher_number")
    
    def pk = primaryKey("category_pkey", (companyId,voucherNumber))

    def * : ProvenShape[VoucherNumber] = (companyId,lastModified,voucherNumber) <> ((VoucherNumber.apply _).tupled,VoucherNumber.unapply)

  }

}

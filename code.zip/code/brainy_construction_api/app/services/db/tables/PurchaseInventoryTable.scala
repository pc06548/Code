package services.db.tables

import model.PurchaseInventory
import slick.lifted

trait PurchaseInventoryTable extends SlickTables {

  import dbConfig._
  import profile.api._

  final protected val purchaseInventories = lifted.TableQuery[PurchaseInventoryT]

  protected class PurchaseInventoryT(tag: Tag) extends Table[PurchaseInventory](tag, "purchase_inventory"){
    /** The ID column, which is auto incremented */
    def id =  column[Option[Int]]("id", O.AutoInc)
    def companyId = column[Option[Int]]("company_id")
    def projectId = column[Option[Int]]("project_id")

    def material = column[String]("material")
    def date = column[String]("date")
    def purchaseOrderNumber = column[Option[String]]("purchase_order_number")
    def vehicleNumber = column[Option[String]]("vehicle_number")
    def inTime = column[Option[String]]("in_time")
    def outTime = column[Option[String]]("out_time")
    def chalanNumber = column[Option[String]]("chalan_number")
    def quantity = column[Option[Double]]("quantity")
    def unit = column[Option[String]]("unit")
    def source = column[Option[String]]("source")

    def receivedBy = column[Option[String]]("received_by")
    def note = column[Option[String]]("note")
    def transporter_name = column[Option[String]]("transporter_name")
    def transport_charges = column[Option[Double]]("transport_charges")
    def hamali_charges = column[Option[Double]]("hamali_charges")
    def rating = column[Option[Double]]("rating")

    def pk = primaryKey("pi_pkey", id)

    def *  = (id,companyId,projectId,material,date,purchaseOrderNumber,vehicleNumber,inTime,outTime,chalanNumber,quantity,unit,source,receivedBy,note,transporter_name,transport_charges,hamali_charges,rating).shaped <> (
      {
      case (id,companyId,projectId,material,date,purchaseOrderNumber,vehicleNumber,inTime,outTime,chalanNumber,quantity,unit,source,receivedBy,note,transporter_name,transport_charges,hamali_charges,rating) =>
        PurchaseInventory(id,companyId,projectId, material,date, Some(purchaseOrderNumber.getOrElse("")),
          Some(vehicleNumber.getOrElse("")),Some(inTime.getOrElse("")),Some(outTime.getOrElse("")),Some(chalanNumber.getOrElse("")),
          Some(quantity.getOrElse(0.0)),Some(unit.getOrElse("")),Some(source.getOrElse("")),Some(receivedBy.getOrElse("")),
          Some(note.getOrElse("")),Some(transporter_name.getOrElse("")),Some(transport_charges.getOrElse(0.0)),Some(hamali_charges.getOrElse(0.0)),Some(rating.getOrElse(0.0))
          )
      },{
       c:PurchaseInventory => Some(c.id,c.companyId,c.projectId,c.material,c.date,c.purchaseOrderNumber,c.vehicleNumber,
         c.inTime,c.outTime,c.chalanNumber,c.quantity,c.unit,c.source,c.receivedBy,c.note,c.transporterName,c.transportCharges,c.hamaliCharges,
         Some(c.rating.getOrElse(2.5)))
      }
    )
  }

}

package services.db.tables

import model.{BankDetails, ExpenseSheet, Transaction}

trait TransactionTable extends SlickTables {

  import dbConfig._
  import profile.api._

  val transactions : TableQuery[TransactionT]
  val expenseSheets : TableQuery[ExpenseSheetT]

  protected class TransactionT(tag: Tag) extends Table[Transaction](tag,"transaction"){
    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def companyId = column[Option[Int]]("company_id")
    def projectId = column[Option[Int]]("project_id")
    def employeeId = column[Option[Int]]("employee_id")

    def name = column[String]("name")
    def typeOfTransaction = column[String]("type_of_transaction")
    def amount = column[Double]("amount")
    def transactionDate = column[String]("transaction_date")
    def paymentMode = column[String]("payment_mode")
    def description = column[Option[String]]("description")

    def pk = primaryKey("transaction_pkey", (id))

    def *  =(
      id,companyId,projectId,employeeId, name,typeOfTransaction,amount,transactionDate,paymentMode, description).shaped <> (
      {
      case (id,companyId,projectId,employeeId, name,typeOfTransaction,amount,transactionDate,paymentMode, description) =>
        Transaction(
          id,companyId,projectId,employeeId, name,typeOfTransaction,amount,transactionDate,paymentMode, description
        )
      },
      {
        c : Transaction =>
          Some(c.id,c.companyId,c.projectId,c.employeeId,c.name,c.typeOfTransaction,c.amount,c.transactionDate,c.paymentMode, Some(c.description.getOrElse("")))
      }
    )
  }

  protected class ExpenseSheetT(tag: Tag) extends Table[ExpenseSheet](tag,"expense_sheet"){
    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def companyId = column[Int]("company_id")
    def projectId = column[Option[Int]]("project_id")
    def employeeId = column[Option[Int]]("employee_id")

    def start_date = column[String]("start_date")
    def end_date = column[String]("end_date")
    def opening_balance = column[Double]("opening_balance")
    def closing_balance = column[Double]("closing_balance")
    def last_modified_on = column[String]("last_modified_on")

    def pk = primaryKey("transaction_pkey", (id))

    def *  =(
      id,companyId,projectId,employeeId,start_date,end_date, opening_balance,closing_balance,last_modified_on).shaped <> (
      {
        case (id,companyId,projectId,employeeId,start_date,end_date, opening_balance,closing_balance,last_modified_on) =>
          ExpenseSheet(
            id,companyId,projectId,employeeId,start_date, end_date,opening_balance,closing_balance,last_modified_on,List.empty[Transaction]
          )
      },
      {
        c : ExpenseSheet =>
          Some(c.id,c.companyId,c.projectId,c.employeeId,c.startDate,c.endDate,c.openingBalance,c.closingBalance,c.lastModified)
      }
    )
  }

}






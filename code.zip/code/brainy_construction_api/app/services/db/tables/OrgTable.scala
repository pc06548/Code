package services.db.tables

import java.sql.Date

import model.Org

trait OrgTable extends SlickTables {

  import dbConfig._
  import profile.api._

  protected class OrgT(tag: Tag) extends Table[Org](tag,"org"){
    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def name = column[String]("name")
    def logo = column[Option[String]]("logo")
    def pk = primaryKey("employee_pkey", (name))
    def createTimestamp = column[Option[Date]]("create_timestamp")
    def updateTimestamp = column[Option[Date]]("update_timestamp")

    def *  =(id, name,logo, createTimestamp, updateTimestamp).shaped <> ((Org.apply _).tupled, Org.unapply)
  }

}

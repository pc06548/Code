package services.db.tables

import config.DateUtil
import model.vouchers.SaveVoucher
import slick.lifted.TableQuery

trait OtherVoucherTable extends SlickTables {

  val otherVouchers : TableQuery[OtherVoucherT]

  import dbConfig._
  import profile.api._

  protected class OtherVoucherT(tag: Tag) extends Table[SaveVoucher](tag,"other_voucher"){

    /** The ID column, which is auto incremented */
    def id = column[Option[Int]]("id", O.AutoInc)
    def voucher_number = column[String]("voucher_number")
    def reason = column[String]("reason")
    def invoice_id = column[Int]("invoice_id")
    def company_id = column[Option[Int]]("company_id")

    def amount_before_tax = column[Double]("amount_before_tax")
    def cgst = column[Double]("cgst")
    def sgst = column[Double]("sgst")
    def amountAfterTax = column[Double]("amount_after_tax")
    def tds = column[Double]("tds")
    def total_amount = column[Double]("total_amount")

    def paymentRefNumber = column[Option[String]]("payment_ref_number")
    def accountNumber = column[Option[String]]("account_number")
    def paymentDate = column[String]("payment_date")

    def mode = column[String]("mode")
    def voucherDate= column[String]("voucher_date")
    def remark = column[Option[String]]("remark")
    def lastModified= column[Option[String]]("last_modified")
    def pk = primaryKey("voucher_pkey", (id))

    def *  =(id,company_id, voucher_number,reason,invoice_id, amount_before_tax, cgst,sgst,amountAfterTax,tds,total_amount,
      paymentRefNumber,accountNumber,paymentDate,mode,voucherDate,remark,lastModified).shaped <> (
      {
        case (id,company_id, voucher_number,reason,invoice_id, amount_before_tax, cgst,sgst,amountAfterTax,tds,total_amount,
        chequeNumber,accountNumber,chequeDate,mode,voucherDate,remark,_) =>
          SaveVoucher(id,company_id, voucher_number,reason,invoice_id, amount_before_tax, cgst,sgst,amountAfterTax,tds,total_amount,
            chequeNumber,accountNumber,chequeDate,mode,voucherDate,remark)
      },
      {
        c : SaveVoucher =>
          Option(c.id,c.companyId, c.voucherNumber,c.reason,c.invoiceId, c.amountBeforTax, c.cgst,c.sgst,c.amountAfterTax,c.tds,c.totalAmount,
            c.paymentRefNumber,c.accountNumber,c.paymentDate,c.mode,c.voucherDate,c.remark,Some(c.lastModified.getOrElse(DateUtil.today)))
      }
    )

  }
}

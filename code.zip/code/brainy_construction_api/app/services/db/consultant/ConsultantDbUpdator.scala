package services.db.consultant

import javax.inject.Inject
import model.GetNameResponse
import model.consultant.Consultant
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.consultant.ConsultantTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class ConsultantDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends ConsultantTable{

  import dbConfig._
  import profile.api._
  override val consultants: TableQuery[ConsultantT] = lifted.TableQuery[ConsultantT]
  val insertQuery = consultants returning consultants.map(_.id) into ((item, id) => item.copy(id = id))

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  def createConsultant(newConsultant: Consultant) = db.run {
    for {
      newConsultant <- insertQuery += newConsultant
    } yield newConsultant.id
  }

  def updateConsultant(consultant: Consultant) = db.run {
    consultants.filter(c => c.id === consultant.id && c.companyId === consultant.companyId).update(consultant).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getById(id: Int,companyId: Int): Future[Option[Consultant]] = db.run {
    consultants.filter(c => (c.id === id && c.companyId === companyId)).result.headOption
  }

  def search(companyId: Int,name: Option[String],deptName : Option[String]) = db.run {

    val query = for {
      c <- consultants if (c.companyId === companyId) &&
        (c.name.toLowerCase like s"%${name.map(_.toLowerCase).getOrElse("")}%") &&
        (c.consultantType.toLowerCase like s"%${deptName.map(_.toLowerCase).getOrElse("")}%")
    }yield c
    query.result
  }

  def getAllNames(companyId: Int) = db.run {

    val query = for{
      c <- consultants if (c.companyId === companyId)
    }yield (c.id,c.name)

    query.sortBy(_._2).result.map(names => names.map(name => GetNameResponse(name._1,name._2)))
  }

  def delete(id: Int,companyId: Int) = db.run{
    consultants.filter(c => c.id === id && c.companyId === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }


}
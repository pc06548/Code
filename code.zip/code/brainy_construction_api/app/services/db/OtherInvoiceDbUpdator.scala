package services.db

import akka.Done
import javax.inject.Inject
import model.invoices.{InvoiceDetails, InvoiceSearch, SaveOtherInvoice}
import model.reports.{DueReportDetailsDb, Purchase}
import play.api.db.slick.DatabaseConfigProvider
import services.db.reports.InvoiceReportsDb
import services.db.tables.OtherInvoiceTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class OtherInvoiceDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends OtherInvoiceTable with InvoiceReportsDb {

  import dbConfig._
  import profile.api._
  override val otherInvoices = lifted.TableQuery[OtherInvoiceT]
  override val otherInvoiceDetails = lifted.TableQuery[OtherInvoiceDetailsT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = otherInvoices returning otherInvoices.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(companyId: Int, id: Int): Future[Option[SaveOtherInvoice]] = db.run {
    otherInvoices.filter(c => c.id === id && c.company_id === companyId).result.headOption
  }
  def getDetails(invoiceId: Int): Future[Seq[InvoiceDetails]] = db.run {
    otherInvoiceDetails.filter(_.invoice_id === invoiceId).sortBy(_.id).result
  }

  def createInvoice(newOtherInvoice: SaveOtherInvoice): Future[Option[Int]] = db.run {
    for{
      newInvoice <- insertQuery += newOtherInvoice
    }yield newInvoice.id

  }

  def saveDetails(details : Seq[InvoiceDetails]):Future[Unit] = {
    val inserts = for{
      detail <- details
    }yield otherInvoiceDetails += detail

    db.run(DBIO.seq(inserts: _*).transactionally)
  }

  def updateDetails(details : Seq[InvoiceDetails]):Future[Done] = {
    val actions = DBIO.sequence(details.map(current => {
      otherInvoiceDetails.insertOrUpdate(current)
    }))
    val updateResult = db.run(actions)
    updateResult.map(_ => Done)
  }

  def updateInvoice(invoice: SaveOtherInvoice) = db.run {
    otherInvoices.filter(_.id === invoice.id).update(invoice).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def searchInvoices(name: String,companyId:Int, projectId: Option[Int], status : String,categoryName:String,
                     startDate:Option[String],endDate:Option[String],isTemporary:Option[Boolean],invoiceNumber:Option[String]): Future[List[InvoiceSearch]] = {
    def projectFilter = projectId.map(pid => s"and i.project_id = $pid").getOrElse("AND i.project_id IS NULL")

    def statusFilter() = status match {
      case InvoiceSearch.INVOICE_STATUS_UNPAID => "AND i.total_amount > COALESCE(SUM(other_voucher.amount_after_tax),0)"
      case InvoiceSearch.INVOICE_STATUS_PAID => "AND i.total_amount <= COALESCE(SUM(other_voucher.amount_after_tax),0)"
      case _ => ""
    }

    val query =
        s"""
           |select i.id,i.name, i.invoice_number, i.total_amount,category.name as category,COALESCE(SUM(other_voucher.amount_after_tax),0) as amount_received,
           |i.invoice_date, i.image_ref,i.is_temporary
           |from other_invoice as i
           |LEFT JOIN other_voucher on other_voucher.invoice_id = i.id
           |INNER JOIN category on category.id = i.category_id
           |WHERE i.company_id = $companyId and LOWER(category.name) like '%${categoryName.toLowerCase}%' $projectFilter
           |${dateBetweenColumn("i.invoice_date", startDate, endDate)}
           |${optionalFilter("i.is_temporary", isTemporary)}
           |group by category.name,i.name, i.id, i.invoice_number, i.total_amount
           |having LOWER(i.name) like '%${name.toLowerCase}%' ${statusFilter()}
           |${optionalLikeFilter("i.invoice_number",invoiceNumber)}
      """.stripMargin
    //println(query)
    val res = sql"#$query".as[InvoiceSearch]
    db.run(res).map(_.toList)
  }

  def deleteInvoice(id: Int, companyId: Int):Future[Int] = db.run{
    (for{
      _ <- otherInvoiceDetails.filter(c => c.invoice_id === id ).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }
      i <- otherInvoices.filter(c => c.id === id && c.company_id === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }
    }yield i).transactionally
  }

  def deleteInvoiceDetail(invoiceId : Int,id: Int):Future[Int] = db.run{
    otherInvoiceDetails.filter(c => c.id === id && c.invoice_id === invoiceId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  override def getPurchaseReportReport(companyId: Int, projectId: Option[Int], name: String,
                                       startDate: Option[String], endDate: Option[String],
                                       mayBeCategory: Option[String],onlyOfficeData:Boolean): Future[Seq[Purchase]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select project.name,i.name,STRING_AGG(d.description,',') as description,i.invoice_number,
         |i.invoice_date,i.amount_before_tax,i.cgst,i.sgst, i.total_amount, category.name as category
         |from other_invoice as i
         |INNER JOIN category on category.id = i.category_id
         |INNER JOIN other_invoice_details as d on d.invoice_id = i.id
         |LEFT JOIN project on project.id = i.project_id
         |WHERE  i.company_id= ${companyId}
         |${dateBetweenColumn("i.invoice_date",startDate,endDate)}
         |${optionalFilter("i.project_id", projectId)}
         |${onlyOfficeDataFilter}
         |group by project.name,i.name,i.invoice_number,i.invoice_date,i.amount_before_tax,i.cgst,i.sgst, i.total_amount,category.name
         |having i.name like '%${name}%' and LOWER(category.name) like '%${mayBeCategory.getOrElse("").toLowerCase}%'
         |${orderByDateDesc("i.invoice_date")}
      """.stripMargin

    val res = sql"#$query".as[Purchase]
    db.run(res).map(_.toSeq)
  }

  override def dueReportInvoices(name: String, companyId: Int, projectId: Option[Int], mayBeCategory: Option[String],
                                 startDate: Option[String], endDate: Option[String],
                                 isTemporary: Option[Boolean],onlyOfficeData:Boolean): Future[List[DueReportDetailsDb]] = {

    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query = s"""
           |select project.name,i.id,i.name, i.invoice_number, i.total_amount,category.name as category,COALESCE(SUM(other_voucher.amount_after_tax),0) as amount_received,
           |i.invoice_date, i.image_ref,i.is_temporary
           |from other_invoice as i
           |LEFT JOIN other_voucher on other_voucher.invoice_id = i.id
           |INNER JOIN category on category.id = i.category_id
           |LEFT JOIN project on project.id = i.project_id
           |WHERE i.company_id = $companyId and LOWER(category.name) like '%${mayBeCategory.getOrElse("").toLowerCase}%'
           |${optionalFilter("i.project_id", projectId)}
           |${onlyOfficeDataFilter}
           |${dateBetweenColumn("i.invoice_date", startDate, endDate)}
           |${optionalFilter("i.is_temporary", isTemporary)}
           |group by project.name,category.name,i.name, i.id, i.invoice_number, i.total_amount
           |having LOWER(i.name) like '%${name.toLowerCase}%' AND i.total_amount > COALESCE(SUM(other_voucher.amount_after_tax),0)
         """.stripMargin

    val res = sql"#$query".as[DueReportDetailsDb]
    db.run(res).map(_.toList)
  }

  def searchAutoGeneratedInvoices(categoryId:Seq[Int], date:String):Future[List[(Int,String)]] = {
    val query = s"""
                   |select i.company_id,i.name
                   |from other_invoice as i
                   |WHERE i.category_id in (${categoryId.mkString(",")})
                   |and ${toDateFromValue(date)} = ${toDateFromColumn("i.invoice_date")}
                   |
         """.stripMargin

    val res = sql"#$query".as[(Int,String)]
    db.run(res).map(_.toList)
  }
}
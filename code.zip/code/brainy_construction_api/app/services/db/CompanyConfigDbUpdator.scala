package services.db

import javax.inject.Inject
import model.CompanyConfig
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.CompanyConfigTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class CompanyConfigDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends CompanyConfigTable{

  import dbConfig._
  import profile.api._
  private val companyConfigs = lifted.TableQuery[CompanyConfigT]
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = companyConfigs returning companyConfigs.map(_.companyId) into ((item, id) => item.copy(companyId = id))

  def create(newCompanyConfig: CompanyConfig): Future[Option[Int]]= db.run {
    for {
      newCompanyConfig <- insertQuery += newCompanyConfig
    } yield newCompanyConfig.companyId
  }

  def updateCompanyConfig(companyConfig: CompanyConfig) = db.run {
    companyConfigs.filter(_.companyId === companyConfig.companyId).update(companyConfig).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def get(companyId:Int) = db.run {
    companyConfigs.filter(_.companyId === companyId).result.headOption
  }

}
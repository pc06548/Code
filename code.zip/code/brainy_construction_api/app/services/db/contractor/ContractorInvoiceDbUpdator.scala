package services.db.contractor

import akka.Done
import javax.inject.Inject
import model.invoices.{InvoiceDetails, InvoiceSearch, SaveInvoice}
import model.reports.{DueReportDetailsDb, Purchase}
import play.api.db.slick.DatabaseConfigProvider
import services.db.InvoiceDbUpdator
import services.db.reports.InvoiceReportsDb
import services.db.tables.contractors.{ContractorInvoiceTable, ContractorTable}
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class ContractorInvoiceDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends ContractorTable
        with ContractorInvoiceTable with InvoiceDbUpdator with InvoiceReportsDb {

  import dbConfig._
  import profile.api._
  override val contractorInvoices = lifted.TableQuery[ContractorInvoiceT]
  override val contractorInvoiceDetails = lifted.TableQuery[ContractorInvoiceDetailsT]
  override val contractors: TableQuery[ContractorT] = lifted.TableQuery[ContractorT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = contractorInvoices returning contractorInvoices.map(_.id) into ((item, id) => item.copy(id = id))

  override def getById(companyId: Int, id: Int): Future[Option[SaveInvoice]] = db.run {
    contractorInvoices.filter(c => c.id === id && c.company_id === companyId).result.headOption
  }
  override def getDetails(invoiceId: Int): Future[Seq[InvoiceDetails]] = db.run {
    contractorInvoiceDetails.filter(_.invoice_id === invoiceId).sortBy(_.id).result
  }

  override def createInvoice(newContractorInvoice: SaveInvoice): Future[Option[Int]] = db.run {
    for{
      newInvoice <- insertQuery += newContractorInvoice
    }yield newInvoice.id

  }

  override def saveDetails(details : Seq[InvoiceDetails]):Future[Unit] = {
    val inserts = for{
      detail <- details
    }yield contractorInvoiceDetails += detail

    db.run(DBIO.seq(inserts: _*).transactionally)
  }
  
  override def updateDetails(details : Seq[InvoiceDetails]):Future[Done] = {

    val actions = DBIO.sequence(details.map(current => {
      contractorInvoiceDetails.insertOrUpdate(current)
    }))
    val updateResult = db.run(actions)
    updateResult.map(_ => Done)
  }
  override def updateInvoice(invoice: SaveInvoice) = db.run {
    contractorInvoices.filter(_.id === invoice.id).update(invoice).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  override def searchInvoices(companyId:Int,name: String, projectId: Option[Int], status : String,
                              startDate:Option[String],endDate:Option[String],isTemporary:Option[Boolean],invoiceNumber:Option[String]): Future[List[InvoiceSearch]] = {
    def projectFilter = projectId.map(pid => s"and i.project_id = $pid").getOrElse("AND i.project_id IS NULL")

    def statusFilter() = status match {
      case InvoiceSearch.INVOICE_STATUS_UNPAID => "AND i.total_amount > COALESCE(SUM(contractor_voucher.amount_after_tax),0)"
      case InvoiceSearch.INVOICE_STATUS_PAID => "AND i.total_amount <= COALESCE(SUM(contractor_voucher.amount_after_tax),0)"
      case _ => ""
    }
    val query =
        s"""
           |select i.id,contractor.name, i.invoice_number, i.total_amount,'Contractor' as category,COALESCE(SUM(contractor_voucher.amount_after_tax),0) as amount_received,
           |i.invoice_date, i.image_ref,i.is_temporary
           |from contractor_invoice as i
           |LEFT JOIN contractor_voucher on contractor_voucher.invoice_id = i.id
           |INNER JOIN contractor on contractor.id = i.contractor_id
           |WHERE i.company_id = ${companyId} $projectFilter ${dateBetweenColumn("i.invoice_date",startDate,endDate)}
           |${optionalFilter("i.is_temporary", isTemporary)}
           |group by contractor.name, i.id, i.invoice_number, i.total_amount
           |having contractor.name like '%${name}%' ${statusFilter()} ${optionalLikeFilter("i.invoice_number",invoiceNumber)}
           |${orderByDateDesc("i.invoice_date")}
      """.stripMargin

    val res = sql"#$query".as[InvoiceSearch]
    db.run(res).map(_.toList)
  }

  // :TODO : Make this transaction in all invoices
  override def deleteInvoice(id: Int, companyId: Int):Future[Int] = db.run{
    (for{
      _ <- contractorInvoiceDetails.filter(c => c.invoice_id === id ).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }
      i <- contractorInvoices.filter(c => c.id === id && c.company_id === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }
    }yield i).transactionally
  }

  override def deleteInvoiceDetail(invoiceId : Int,id: Int):Future[Int] = db.run{
    contractorInvoiceDetails.filter(c => c.id === id && c.invoice_id === invoiceId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  override def getPurchaseReportReport(companyId: Int, projectId: Option[Int], name: String,
                                       startDate: Option[String], endDate: Option[String],
                                       mayBeCategory: Option[String],onlyOfficeData:Boolean): Future[Seq[Purchase]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select project.name, contractor.name,STRING_AGG(d.description,',') as description,i.invoice_number,
         |i.invoice_date,i.amount_before_tax,i.cgst,i.sgst, i.total_amount, 'Contractor' as category
         |from contractor_invoice as i
         |INNER JOIN contractor on contractor.id = i.contractor_id
         |INNER JOIN contractor_invoice_details as d on d.invoice_id = i.id
         |LEFT JOIN project on project.id = i.project_id
         |WHERE i.company_id= ${companyId}
         |${dateBetweenColumn("i.invoice_date",startDate,endDate)}
         |${optionalFilter("i.project_id", projectId)}
         |${onlyOfficeDataFilter}
         |group by project.name,contractor.name,i.invoice_number,i.invoice_date,i.amount_before_tax,i.cgst,i.sgst, i.total_amount
         |having contractor.name like '%${name}%'
         |${orderByDateDesc("i.invoice_date")}
      """.stripMargin
    val res = sql"#$query".as[Purchase]
    db.run(res).map(_.toSeq)
  }

  override def dueReportInvoices(name: String, companyId: Int, projectId: Option[Int],mayBeCategory: Option[String],
                                 startDate: Option[String], endDate: Option[String], isTemporary: Option[Boolean],onlyOfficeData:Boolean): Future[List[DueReportDetailsDb]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query = s"""
           |select project.name,i.id,contractor.name, i.invoice_number, i.total_amount,'Contractor' as category,COALESCE(SUM(contractor_voucher.amount_after_tax),0) as amount_received,
           |i.invoice_date, i.image_ref,i.is_temporary
           |from contractor_invoice as i
           |LEFT JOIN contractor_voucher on contractor_voucher.invoice_id = i.id
           |INNER JOIN contractor on contractor.id = i.contractor_id
           |LEFT JOIN project on project.id = i.project_id
           |WHERE i.company_id = ${companyId} ${optionalFilter("i.project_id",projectId)}
           |${onlyOfficeDataFilter}
           |${dateBetweenColumn("i.invoice_date",startDate,endDate)}
           |${optionalFilter("i.is_temporary", isTemporary)}
           |group by project.name,contractor.name, i.id, i.invoice_number, i.total_amount
           |having contractor.name like '%${name}%' AND i.total_amount > COALESCE(SUM(contractor_voucher.amount_after_tax),0)
           |${orderByDateDesc("i.invoice_date")}
         """.stripMargin

    val res = sql"#$query".as[DueReportDetailsDb]
    db.run(res).map(_.toList)
  }
}
package services.db.contractor

import javax.inject.Inject
import model.GetNameResponse
import model.contractor.Contractor
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.contractors.ContractorTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits._
import scala.concurrent.Future

class ContractorDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends ContractorTable{

  import dbConfig._
  import profile.api._
  override val contractors: TableQuery[ContractorT] = lifted.TableQuery[ContractorT]
  val insertQuery = contractors returning contractors.map(_.id) into ((item, id) => item.copy(id = id))

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  def createContractor(newContractor: Contractor) = db.run {
    for {
      newContractor <- insertQuery += newContractor
    } yield newContractor.id
  }

  def updateContractor(contractor: Contractor) = db.run {
    contractors.filter(c => c.id === contractor.id && c.companyId === contractor.companyId).update(contractor).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getById(id: Int,companyId: Int): Future[Option[Contractor]] = db.run {
    contractors.filter(c => (c.id === id && c.companyId === companyId)).result.headOption
  }

  def search(companyId: Int,name: Option[String],deptName : Option[String]) = db.run {

    val query = for {
      c <- contractors if (c.companyId === companyId) &&
                          (c.name.toLowerCase like s"%${name.map(_.toLowerCase).getOrElse("")}%") &&
                          (c.department.toLowerCase like s"%${deptName.map(_.toLowerCase).getOrElse("")}%")
    }yield c
    query.sortBy(_.name).result
  }

  def getAllNames(companyId: Int) = db.run {

    val query = for{
      c <- contractors if (c.companyId === companyId)
    }yield (c.id,c.name)

    query.sortBy(_._2).result.map(names => names.map(name => GetNameResponse(name._1,name._2)))
  }

  def delete(id: Int,companyId: Int) = db.run{
    contractors.filter(c => c.id === id && c.companyId === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

}
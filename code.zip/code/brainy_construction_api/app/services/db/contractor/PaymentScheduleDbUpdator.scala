package services.db.contractor

import akka.Done
import javax.inject._
import model.contractor.{PaymentSchedule, PaymentScheduleDetails, PaymentScheduleSearch}
import play.api.db.slick.DatabaseConfigProvider
import services.db.DatabaseUpdatorService
import services.db.tables.contractors.{ContractorTable, PaymentScheduleTable}
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PaymentScheduleDbUpdator @Inject()(configProvider: DatabaseConfigProvider,
                                         databaseUpdatorService: DatabaseUpdatorService) extends ContractorTable
                                    with PaymentScheduleTable {

  import dbConfig._
  import profile.api._
  override val paymentSchedules = lifted.TableQuery[PaymentScheduleT]
  override val paymentScheduleDetails = lifted.TableQuery[PaymentScheduleDetailsT]
  override val contractors: TableQuery[ContractorT] = lifted.TableQuery[ContractorT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = paymentSchedules returning paymentSchedules.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(projectId: Int, id: Int): Future[Option[PaymentSchedule]] = db.run {
    paymentSchedules.filter(c => c.id === id && c.project_id === projectId).result.headOption
  }
  def getDetails(psId: Int): Future[Seq[PaymentScheduleDetails]] = db.run {
    paymentScheduleDetails.filter(_.paymentScheduleid === psId).sortBy(_.id).result
  }

  def createPaymentSchedule(newPaymentSchedule: PaymentSchedule): Future[Option[Int]] = db.run {
    for{
      newPaymentSchedule <- insertQuery += newPaymentSchedule
    }yield newPaymentSchedule.id

  }

  def saveDetails(details : Seq[PaymentScheduleDetails]):Future[Unit] = {
    val inserts = for{
      detail <- details
    }yield paymentScheduleDetails += detail

    db.run(DBIO.seq(inserts: _*).transactionally)
  }

  def updateDetails(details : Seq[PaymentScheduleDetails]):Future[Done] = {

    val actions = DBIO.sequence(details.map(current => {
      paymentScheduleDetails.insertOrUpdate(current)
    }))
    val updateResult = db.run(actions)
    updateResult.map(_ => Done)
  }
  def updatePaymentSchedule(ps: PaymentSchedule) = db.run {
    paymentSchedules.filter(_.id === ps.id).update(ps)
  }

  def searchPaymentSchedules(contractorName: Option[String],projectId: Int,workOrderNumber : Option[String],
                             startDate:Option[String],endDate:Option[String]): Future[List[PaymentScheduleSearch]] = {
    val query = s"""
                   |select ps.id,contractor.name, ps.work_order_number, ps.total_amount,ps.created_on
                   |from payment_schedule as ps
                   |INNER JOIN contractor on contractor.id = ps.contractor_id
                   |WHERE ps.project_id = ${projectId} AND contractor.name like '%${contractorName.getOrElse("")}%'
                   |AND ps.work_order_number like '%${workOrderNumber.getOrElse("")}%'
                   |${dateBetweenColumn("ps.created_on",startDate,endDate)}
                   |${orderByDateDesc("ps.created_on")}
         """.stripMargin

    val res = sql"#$query".as[PaymentScheduleSearch]
    db.run(res).map(_.toList)
  }

  def deletePaymentSchedule(id: Int, projectId: Int):Future[Int] = db.run{
    for{
      _ <- paymentScheduleDetails.filter(c => c.paymentScheduleid === id ).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
      i <- paymentSchedules.filter(c => c.id === id && c.project_id === projectId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
    }yield i

  }

  def deletePaymentScheduleDetail(psId : Int,id: Int):Future[Int] = db.run{
    paymentScheduleDetails.filter(c => c.id === id && c.paymentScheduleid === psId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

}

package services.db.contractor

import akka.Done
import javax.inject._
import config.{DateHelperDeprecated, DateUtil}
import model.contractor._
import model.reports.DirectorReportAttendanceData
import play.api.db.slick.DatabaseConfigProvider
import services.db.DatabaseUpdatorService
import services.db.tables.contractors.{ContractorTable, WeeklyStatusReportTable}
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class WsrDbUpdator @Inject()(configProvider: DatabaseConfigProvider,
                             databaseUpdatorService: DatabaseUpdatorService) extends ContractorTable with WeeklyStatusReportTable {


  import dbConfig._
  import profile.api._
  override val weeklyStatusReports = lifted.TableQuery[WeeklyStatusReportT]
  override val weeklyStatusReportDetails = lifted.TableQuery[WeeklyStatusReportDetailsT]
  override val WsrResources = lifted.TableQuery[WsrResourceT]
  override val contractors: TableQuery[ContractorT] = lifted.TableQuery[ContractorT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = weeklyStatusReports returning weeklyStatusReports.map(_.id) into ((item, id) => item.copy(id = id))
  val insertDetailQuery = weeklyStatusReportDetails returning weeklyStatusReportDetails.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(projectId: Int, date: String): Future[Option[WeeklyStatusReport]] =  {
    val query =
      s"""
         |select * from weekly_status_report as wsr
         |where wsr.project_id = ${projectId}
         |and ${toDateFromValue(date)} >= ${toDateFromColumn("wsr.start_date")}
         |and ${toDateFromValue(date)} <= ${toDateFromColumn("wsr.end_date")}
      """.stripMargin

    val res = sql"#$query".as[WeeklyStatusReport]
    db.run(res).map(_.toList.headOption)
  }

  def getAllDetails(wsrId: Option[Int],contractorId:Option[Int]): Future[Seq[WSRDetails]] = {
    val query =
      s"""
         |select wd.id,wd.contractor_id,wd.department,wd.type_of_work,wd.wsr_id,c.name
         |from wsr_details as wd
         |inner join contractor c on c.id = wd.contractor_id
         |where wd.wsr_id = ${wsrId.getOrElse(0)}
         ${optionalFilter("wd.contractor_id",contractorId)}
      """.stripMargin

    val res = sql"#$query".as[WSRDetails]
    db.run(res).map(_.toList)
  }

  def getDetails(wsrId: Int,detailId : Int): Future[Option[WSRDetails]] = db.run {
    weeklyStatusReportDetails.filter(w => w.wsrId === wsrId && w.id ===detailId).sortBy(_.id).result.headOption
  }

  def getResources(detailIdList: List[Int]): Future[Seq[WsrResource]] = db.run{
    WsrResources.filter(_.wsrDetailId.inSet(detailIdList)).result
  }
  def getResources(detailId: Int): Future[Seq[WsrResource]] = db.run{
    WsrResources.filter(_.wsrDetailId === detailId).result
  }

  def createWeeklyStatusReport(newWeeklyStatusReport: WeeklyStatusReport): Future[Option[Int]] = db.run {
    for{
      newWeeklyStatusReport <- insertQuery += newWeeklyStatusReport
    }yield newWeeklyStatusReport.id

  }

  def saveResources(resources : Seq[WsrResource]):Future[Unit] = {
    val inserts = for{
      resource <- resources
    }yield WsrResources += resource

    db.run(DBIO.seq(inserts: _*).transactionally)
  }
  def saveDetails(newDetail : WSRDetails):Future[Option[Int]] = db.run {
    for{
      newWeeklyStatusReport <- insertDetailQuery += newDetail
    }yield newWeeklyStatusReport.id
  }

  def updateResources(resources : Seq[WsrResource]):Future[Done] = {

    val actions = DBIO.sequence(resources.map(current => {
      WsrResources.insertOrUpdate(current)
    }))
    val updateResult = db.run(actions)
    updateResult.map(_ => Done)
  }

  def updateWeeklyStatusReport(ps: WeeklyStatusReport) = db.run {
    weeklyStatusReports.filter(_.id === ps.id).update(ps)
  }

  def updateWeeklyStatusReportDetail(wsrDetail: WSRDetails) = db.run {
    weeklyStatusReportDetails.filter(_.id === wsrDetail.id).update(wsrDetail)
  }

  def deleteWeeklyStatusReport(id: Int, projectId: Int):Future[Int] = db.run{
    for{
      _ <- weeklyStatusReportDetails.filter(c => c.wsrId === id ).delete.flatMap { updatedRows =>
            if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
            else DBIO.successful(updatedRows)
          }.transactionally
      i <- weeklyStatusReports.filter(c => c.id === id && c.project_id === projectId).delete.flatMap { updatedRows =>
            if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
            else DBIO.successful(updatedRows)
          }.transactionally
    }yield i

  }

  def deleteWeeklyStatusReportDetail(wsrId : Int,wsrDetailsId: Int):Future[Int] = db.run{
    for{
      _ <- WsrResources.filter(c => c.wsrDetailId === wsrDetailsId ).delete.flatMap { updatedRows =>
            if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
            else DBIO.successful(updatedRows)
          }.transactionally
      i <- weeklyStatusReportDetails.filter(c => c.id === wsrDetailsId && c.wsrId === wsrId).delete.flatMap { updatedRows =>
            if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
            else DBIO.successful(updatedRows)
          }.transactionally
    }yield i
  }

  def getDirectorReportData() = {
    val query =
      s"""
         |select c.company_id,p.name,wd.department,c.name,wr.count,'-' as shift_time,wsr.created_by
from  wsr_resource wr
inner join wsr_details wd on wd.id = wr.wsr_detail_id
inner join contractor c on c.id = wd.contractor_id
inner join weekly_status_report wsr on wsr.id = wd.wsr_id
inner join project p on p.id = wsr.project_id
where TO_DATE(wr.date,'dd-MM-yyyy') = CURRENT_DATE and wr.count > 0
union
select a.company_id,'Office' as project_name,e.department,e.name,1 as count,CONCAT(a.start_time,'-',a.end_time),'Auto' as created_by
from attendance a
inner join employee e on e.id = a.employee_id
where TO_DATE(a.date,'dd-MM-yyyy') = CURRENT_DATE
      """.stripMargin

    val res = sql"#$query".as[DirectorReportAttendanceData]
    db.run(res).map(_.toList)
  }
}
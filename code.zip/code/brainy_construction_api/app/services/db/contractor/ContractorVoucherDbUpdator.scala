package services.db.contractor

import config.DateUtil
import javax.inject.Inject
import model.VoucherNumber
import model.reports.{AccountSummaryData, CollectiveSummaryData, TdsData}
import model.vouchers._
import play.api.db.slick.DatabaseConfigProvider
import services.db.VoucherDb
import services.db.tables.VoucherNumberTable
import services.db.tables.contractors.{ContractorTable, ContractorVoucherTable}
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class ContractorVoucherDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends ContractorTable
  with ContractorVoucherTable with VoucherDb with VoucherNumberTable  {

  import dbConfig._
  import profile.api._
  override val contractorVouchers = lifted.TableQuery[ContractorVoucherT]
  override val contractors: TableQuery[ContractorT] = lifted.TableQuery[ContractorT]
  override val voucherNumbers: TableQuery[VoucherNumberT] = lifted.TableQuery[VoucherNumberT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = contractorVouchers returning contractorVouchers.map(_.id) into ((item, id) => item.copy(id = id))

  override def getById(companyId: Int, id: Int): Future[Option[Voucher]] = {

   val query =
     s"""
        |select p.name,v.id,v.voucher_number,v.reason,v.amount_before_tax,v.cgst,v.sgst,v.amount_after_tax,v.tds,v.total_amount,
        |v.voucher_date,v.remark,'Contractor' as category,v.payment_ref_number,v.account_number,v.payment_date,v.mode,i.id,i.invoice_number, c.name, i.is_temporary
        |from contractor_voucher v
        |INNER JOIN contractor_invoice as i on v.invoice_id = i.id
        |INNER JOIN contractor as c on c.id = i.contractor_id
        |LEFT JOIN project as p on i.project_id = p.id
        |where i.company_id = ${companyId} and v.id = ${id}
      """.stripMargin
    val res = sql"#$query".as[Voucher]
    db.run(res).map(_.toList.headOption)
  }

  override def getAmountPaidForInvoice(invoiceId : Int) : Future[Option[Double]] = db.run {
    val amount = contractorVouchers.filter(v => v.invoice_id === invoiceId).map(_.amountAfterTax).sum
    amount.result
  }

  override def createVoucher(companyId:Int,newContractorVoucher: SaveVoucher): Future[Option[Int]] = db.run {
    (for{
      newVoucher <- insertQuery += newContractorVoucher
      _ <- voucherNumbers += VoucherNumber(companyId,DateUtil.currentTimestamp,newContractorVoucher.voucherNumber)
    }yield newVoucher.id).transactionally

  }

  override def searchVouchers(companyId:Int,name: Option[String], projectId: Option[Int],startDate:Option[String],
                              endDate:Option[String],voucherNumber:Option[String],isTemporary:Option[Boolean],category : Option[String] = None): Future[List[VoucherSearch]] = {

    def projectFilter = projectId.map(pid => s"and i.project_id = $pid").getOrElse("AND i.project_id IS NULL")

    val query =
      s"""
         |select v.id,v.voucher_number,c.name,v.reason,i.invoice_number,v.total_amount,v.voucher_date,'Contractor' as category, i.is_temporary
         |from contractor_voucher v, contractor_invoice as i, contractor as c
         |where v.invoice_id = i.id $projectFilter
         |and c.id = i.contractor_id and i.company_id = ${companyId} ${optionalFilter("i.is_temporary", isTemporary)}
         |${dateBetweenColumn("v.payment_date",startDate,endDate)}
         |and c.name like '%${name.getOrElse("")}%' ${optionalLikeFilter("v.voucher_number",voucherNumber)}
      """.stripMargin
    val res = sql"#$query".as[VoucherSearch]
    db.run(res).map(_.toList)
  }

  override def delete(id: Int): Future[Int] = db.run{
    contractorVouchers.filter(c => c.id === id).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  override def getAccountSummaryData(companyId: Int, projectId: Option[Int], name: String,
                                     startDate: Option[String], endDate: Option[String],
                                     category: Option[String],onlyOfficeData:Boolean): Future[List[AccountSummaryData]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select c.name,v.reason, p.name,v.tds,v.total_amount, v.payment_ref_number,v.payment_date,
         |i.invoice_number,'Contractor' as category,i.invoice_date,i.total_amount,i.amount_before_tax,
         |i.cgst,i.sgst,i.doc_ref_number,v.voucher_number,i.is_temporary
         |from contractor_voucher v
         |INNER JOIN contractor_invoice as i on v.invoice_id = i.id
         |INNER JOIN contractor as c on c.id = i.contractor_id
         |LEFT JOIN project as p on i.project_id = p.id
         |where i.company_id = ${companyId}
         |${dateBetweenColumn("v.payment_date",startDate,endDate)}
         |and c.name like '%${name}%'
         |${optionalFilter("i.project_id",projectId)}
         ${onlyOfficeDataFilter}
         |${orderByDateAsc("v.payment_date")}
      """.stripMargin
    val res = sql"#$query".as[AccountSummaryData]
    db.run(res).map(_.toList)
  }

  override def getCollectiveSummaryData(companyId: Int, projectId: Option[Int],
                                        startDate: Option[String], endDate: Option[String],onlyOfficeData:Boolean): Future[List[CollectiveSummaryData]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select p.name,c.name,SUM(v.total_amount), c.department
         |from contractor_voucher v
         |INNER JOIN contractor_invoice as i on v.invoice_id = i.id
         |INNER JOIN contractor as c on c.id = i.contractor_id
         |LEFT JOIN project as p on i.project_id = p.id
         |where i.company_id = ${companyId}
         |${dateBetweenColumn("v.payment_date",startDate,endDate)}
         |${optionalFilter("i.project_id",projectId)}
         | ${onlyOfficeDataFilter}
         |group by p.name,c.name,c.department
         |order by p.name,c.name
      """.stripMargin

    val res = sql"#$query".as[CollectiveSummaryData]
    db.run(res).map(_.toList)
  }

  override def getVouchers(companyId: Int, name: Option[String], projectId: Option[Int], startDate: Option[String],
                           endDate: Option[String], category: Option[String],modeOfPayment:Option[String],
                           sortBy:Option[String],onlyOfficeData:Boolean): Future[List[Voucher]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select p.name,v.id,v.voucher_number,v.reason,v.amount_before_tax,v.cgst,v.sgst,v.amount_after_tax,v.tds,v.total_amount,
         |v.voucher_date,v.remark,'Contractor' as category,v.payment_ref_number,v.account_number,v.payment_date,v.mode,i.id,i.invoice_number, c.name, i.is_temporary
         |from contractor_voucher v
         |inner join contractor_invoice as i on v.invoice_id = i.id
         |inner join contractor as c on c.id = i.contractor_id
         |LEFT join project as p on p.id = i.project_id
         |where i.company_id = ${companyId}
         |${dateBetweenColumn("v.payment_date", startDate, endDate)}
         |${optionalLikeFilter("c.name",name)}
         |${optionalLikeFilter("v.mode", modeOfPayment)}
         | ${onlyOfficeDataFilter}
         |${optionalFilter("i.project_id",projectId)} ${orderByClause(sortBy)}
      """.stripMargin
    val res = sql"#$query".as[Voucher]
    db.run(res).map(_.toList)
  }

  override def getTdsDetails(companyId: Int, name: Option[String], projectId: Option[Int], startDate: Option[String],
                             endDate: Option[String], category: Option[String],onlyOfficeData:Boolean): Future[List[TdsData]] = {

    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select c.name,v.voucher_date,v.amount_before_tax,v.tds,c.pan_number,'Contractor' as category
         |from contractor_voucher v
         |inner join contractor_invoice as i on v.invoice_id = i.id
         |inner join contractor as c on c.id = i.contractor_id
         |LEFT join project as p on p.id = i.project_id
         |where i.company_id = ${companyId} and v.tds > 0
         |${dateBetweenColumn("v.payment_date", startDate, endDate)}
         |${optionalLikeFilter("c.name",name)}
         | ${onlyOfficeDataFilter}
         |${optionalFilter("i.project_id",projectId)}
      """.stripMargin
    val res = sql"#$query".as[TdsData]
    db.run(res).map(_.toList)

  }
}
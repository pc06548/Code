package services.db.supplier

import javax.inject.Inject
import model.GetNameResponse
import model.supplier.Supplier
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.suppliers.SupplierTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class SupplierDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends SupplierTable{

  import dbConfig._
  import profile.api._
  override val suppliers = lifted.TableQuery[SupplierT]
  val insertQuery = suppliers returning suppliers.map(_.id) into ((item, id) => item.copy(id = id))

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  def createSupplier(newSupplier: Supplier) = db.run {
    for {
      newSupplier <- insertQuery += newSupplier
    } yield newSupplier.id
  }

  def updateSupplier(supplier: Supplier) = db.run {
    suppliers.filter(s => s.id === supplier.id && s.companyId === supplier.companyId).update(supplier).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getById(id: Int,companyId: Int): Future[Option[Supplier]] = db.run {
    suppliers.filter(c => (c.id === id && c.companyId === companyId)).result.headOption
  }

  def search(companyId: Int, name: Option[String], supplierType : Option[String]) = db.run {

    val query = for {
      c <- suppliers if (c.companyId === companyId) &&
        (c.name.toLowerCase like s"%${name.map(_.toLowerCase).getOrElse("")}%") &&
        (c.supplier_type.toLowerCase like s"%${supplierType.map(_.toLowerCase).getOrElse("")}%")
    }yield c
    query.sortBy(_.name).result
  }

  def getAllNames(companyId: Int) = db.run {

    val query = for{
      c <- suppliers if (c.companyId === companyId)
    }yield (c.id,c.name)

    query.sortBy(_._2).result.map(names => names.map(name => GetNameResponse(name._1,name._2)))
  }

  def delete(id: Int,companyId: Int) = db.run{
    suppliers.filter(c => c.id === id && c.companyId === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

}
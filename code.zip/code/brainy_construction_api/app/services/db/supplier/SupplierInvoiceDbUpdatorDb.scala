package services.db.supplier

import akka.Done
import javax.inject.Inject
import model.invoices.{InvoiceDetails, InvoiceSearch, SaveInvoice}
import model.reports.{DueReportDetailsDb, Purchase}
import play.api.db.slick.DatabaseConfigProvider
import services.db.InvoiceDbUpdator
import services.db.reports.InvoiceReportsDb
import services.db.tables.suppliers.{SupplierInvoiceTable, SupplierTable}
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class SupplierInvoiceDbUpdatorDb @Inject()(configProvider: DatabaseConfigProvider) extends SupplierTable
        with SupplierInvoiceTable with InvoiceDbUpdator with InvoiceReportsDb{

  import dbConfig._
  import profile.api._
  override val supplierInvoices = lifted.TableQuery[SupplierInvoiceT]
  override val supplierInvoiceDetails = lifted.TableQuery[SupplierInvoiceDetailsT]
  override val suppliers: TableQuery[SupplierT] = lifted.TableQuery[SupplierT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = supplierInvoices returning supplierInvoices.map(_.id) into ((item, id) => item.copy(id = id))

  override def getById(companyId: Int, id: Int): Future[Option[SaveInvoice]] = db.run {
    supplierInvoices.filter(c => c.id === id && c.company_id === companyId).result.headOption
  }
  override def getDetails(invoiceId: Int): Future[Seq[InvoiceDetails]] = db.run {
    supplierInvoiceDetails.filter(_.invoice_id === invoiceId).sortBy(_.id).result
  }

  override def createInvoice(newSupplierInvoice: SaveInvoice): Future[Option[Int]] = db.run {
    for{
      newInvoice <- insertQuery += newSupplierInvoice
    }yield newInvoice.id

  }

  override def saveDetails(details : Seq[InvoiceDetails]):Future[Unit] = {
    val inserts = for{
      detail <- details
    }yield supplierInvoiceDetails += detail

    db.run(DBIO.seq(inserts: _*).transactionally)
  }
  
  override def updateDetails(details : Seq[InvoiceDetails]):Future[Done] = {
    val actions = DBIO.sequence(details.map(current => {
      supplierInvoiceDetails.insertOrUpdate(current)
    }))
    val updateResult = db.run(actions)
    updateResult.map(_ => Done)
  }
  override def updateInvoice(invoice: SaveInvoice) = db.run {
    supplierInvoices.filter(_.id === invoice.id).update(invoice).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  override def searchInvoices(companyId:Int,name: String, projectId: Option[Int], status : String,
                              startDate:Option[String],endDate:Option[String],
                              isTemporary:Option[Boolean],invoiceNumber:Option[String]): Future[List[InvoiceSearch]] = {
    def projectFilter = projectId.map(pid => s"and i.project_id = $pid").getOrElse("AND i.project_id IS NULL")

    def statusFilter() = status match {
        case InvoiceSearch.INVOICE_STATUS_UNPAID => "AND i.total_amount > COALESCE(SUM(supplier_voucher.amount_after_tax),0)"
        case InvoiceSearch.INVOICE_STATUS_PAID => "AND i.total_amount <= COALESCE(SUM(supplier_voucher.amount_after_tax),0)"
        case _ => ""
    }
    val query =
      s"""
         |select i.id,supplier.name, i.invoice_number, i. total_amount, 'Supplier' as category,COALESCE(SUM(supplier_voucher.amount_after_tax),0) as amount_received,
         |i.invoice_date, i.image_ref,i.is_temporary
         |from supplier_invoice as i
         |LEFT JOIN supplier_voucher on supplier_voucher.invoice_id = i.id
         |INNER JOIN supplier on supplier.id = i.supplier_id
         |WHERE i.company_id = ${companyId} $projectFilter  ${dateBetweenColumn("i.invoice_date",startDate,endDate)}
         |${optionalFilter("i.is_temporary", isTemporary)}
         |group by supplier.name, i.id, i.invoice_number, i.total_amount
         |having supplier.name like '%${name}%' ${statusFilter()} ${optionalLikeFilter("i.invoice_number",invoiceNumber)}
         |${orderByDateDesc("i.invoice_date")}
      """.stripMargin

    val res = sql"#$query".as[InvoiceSearch]
    db.run(res).map(_.toList)
  }

  override def deleteInvoice(id: Int, companyId: Int):Future[Int] = db.run{
    (for{
      _ <- supplierInvoiceDetails.filter(c => c.invoice_id === id ).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }
      i <- supplierInvoices.filter(c => c.id === id && c.company_id === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }
    }yield i).transactionally
  }

  override def deleteInvoiceDetail(invoiceId : Int,id: Int):Future[Int] = db.run{
    supplierInvoiceDetails.filter(c => c.id === id && c.invoice_id === invoiceId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  override def getPurchaseReportReport(companyId: Int, projectId: Option[Int], name: String,
                                       startDate: Option[String], endDate: Option[String],
                                       mayBeCategory: Option[String],onlyOfficeData:Boolean): Future[Seq[Purchase]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query =
      s"""
         |select project.name,supplier.name,STRING_AGG(d.description,',') as description,i.invoice_number,
         |i.invoice_date,i.amount_before_tax,i.cgst,i.sgst, i.total_amount, 'Supplier' as category
         |from supplier_invoice as i
         |INNER JOIN supplier on supplier.id = i.supplier_id
         |INNER JOIN supplier_invoice_details as d on d.invoice_id = i.id
         |LEFT JOIN project on project.id = i.project_id
         |WHERE i.company_id= ${companyId}
         |${dateBetweenColumn("i.invoice_date",startDate,endDate)}
         |${optionalFilter("i.project_id", projectId)}
         |${onlyOfficeDataFilter}
         |group by project.name,supplier.name,i.invoice_number,i.invoice_date,i.amount_before_tax,i.cgst,i.sgst, i.total_amount
         |having supplier.name like '%${name}%'
         |${orderByDateDesc("i.invoice_date")}
      """.stripMargin

    val res = sql"#$query".as[Purchase]
    db.run(res).map(_.toSeq)
  }

  override def dueReportInvoices(name: String, companyId: Int, projectId: Option[Int], mayBeCategory: Option[String],
                                 startDate: Option[String], endDate: Option[String], isTemporary: Option[Boolean],onlyOfficeData:Boolean): Future[List[DueReportDetailsDb]] = {
    val onlyOfficeDataFilter = if(onlyOfficeData) s"and i.project_id is NULL" else ""
    val query = s"""
           |select project.name,i.id,supplier.name, i.invoice_number, i.total_amount,'Supplier' as category,COALESCE(SUM(supplier_voucher.amount_after_tax),0) as amount_received,
           |i.invoice_date, i.image_ref,i.is_temporary
           |from supplier_invoice as i
           |LEFT JOIN supplier_voucher on supplier_voucher.invoice_id = i.id
           |INNER JOIN supplier on supplier.id = i.supplier_id
           |LEFT JOIN project on project.id = i.project_id
           |WHERE i.company_id = ${companyId} ${optionalFilter("i.project_id",projectId)}
           |${onlyOfficeDataFilter}
           |${dateBetweenColumn("i.invoice_date",startDate,endDate)}
           |${optionalFilter("i.is_temporary", isTemporary)}
           |group by project.name,supplier.name, i.id, i.invoice_number, i.total_amount
           |having supplier.name like '%${name}%' AND i.total_amount > COALESCE(SUM(supplier_voucher.amount_after_tax),0)
           |${orderByDateDesc("i.invoice_date")}
         """.stripMargin

    val res = sql"#$query".as[DueReportDetailsDb]
    db.run(res).map(_.toList)
  }
}
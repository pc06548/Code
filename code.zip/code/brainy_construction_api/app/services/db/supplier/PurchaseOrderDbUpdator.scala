package services.db.supplier

import akka.Done
import javax.inject._
import model.reports.DirectorReportPurchaseOrderData
import model.supplier.{PurchaseOrder, PurchaseOrderDetails, PurchaseOrderSearch}
import play.api.db.slick.DatabaseConfigProvider
import services.db.DatabaseUpdatorService
import services.db.tables.suppliers.{PurchaseOrderTable, SupplierTable}
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class PurchaseOrderDbUpdator @Inject()(configProvider: DatabaseConfigProvider,
                                       databaseUpdatorService: DatabaseUpdatorService) extends SupplierTable with PurchaseOrderTable {

  import dbConfig._
  import profile.api._
  override val purchaseOrders = lifted.TableQuery[PurchaseOrderT]
  override val purchaseOrderDetails = lifted.TableQuery[PurchaseOrderDetailsT]
  override val suppliers: TableQuery[SupplierT] = lifted.TableQuery[SupplierT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = purchaseOrders returning purchaseOrders.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(projectId: Int, id: Int): Future[Option[PurchaseOrder]] = db.run {
    purchaseOrders.filter(c => c.id === id && c.project_id === projectId).result.headOption
  }
  def getDetails(psId: Int): Future[Seq[PurchaseOrderDetails]] = db.run {
    purchaseOrderDetails.filter(_.purchaseOrderId === psId).sortBy(_.id).result
  }

  def createPurchaseOrder(newPurchaseOrder: PurchaseOrder): Future[Option[Int]] = db.run {
    for{
      newPurchaseOrder <- insertQuery += newPurchaseOrder
    }yield newPurchaseOrder.id

  }

  def saveDetails(details : Seq[PurchaseOrderDetails]):Future[Unit] = {
    val inserts = for{
      detail <- details
    }yield purchaseOrderDetails += detail

    db.run(DBIO.seq(inserts: _*).transactionally)
  }

  def updateDetails(details : Seq[PurchaseOrderDetails]):Future[Done] = {

    val actions = DBIO.sequence(details.map(current => {
      purchaseOrderDetails.insertOrUpdate(current)
    }))
    val updateResult = db.run(actions)
    updateResult.map(_ => Done)
  }
  def updatePurchaseOrder(ps: PurchaseOrder) = db.run {
    purchaseOrders.filter(_.id === ps.id).update(ps)
  }

  def searchPurchaseOrders(supplierName: Option[String],projectId: Int,
                           startDate:Option[String],endDate:Option[String],poId: Option[Int]): Future[List[PurchaseOrderSearch]] = {
    val query = s"""
                   |select po.id,supplier.name, po.total_amount,po.status,po.created_date
                   |from purchase_order as po
                   |INNER JOIN supplier on supplier.id = po.supplier_id
                   |WHERE po.project_id = ${projectId} AND supplier.name like '%${supplierName.getOrElse("")}%'
                   |${dateBetweenColumn("po.created_date",startDate,endDate)}
                   ${optionalFilter("po.id",poId)}
                   |${orderByDateDesc("po.created_date")}
         """.stripMargin

    val res = sql"#$query".as[PurchaseOrderSearch]
    db.run(res).map(_.toList)
  }

  def deletePurchaseOrder(id: Int, projectId: Int):Future[Int] = db.run{
    for{
      _ <- purchaseOrderDetails.filter(c => c.purchaseOrderId === id ).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
      i <- purchaseOrders.filter(c => c.id === id && c.project_id === projectId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
    }yield i

  }

  def deletePurchaseOrderDetail(psId : Int,id: Int):Future[Int] = db.run{
    purchaseOrderDetails.filter(c => c.id === id && c.purchaseOrderId === psId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }
  def directorReportData() = {
    val query =
      """
        |select p.company_id,p.name,po.id,s.name,po.total_amount,po.prepared_by,
        |(case when po.status = 'APPROVED' then 'Admin' else 'Pending' end) as approved_by
        |from purchase_order po
        |inner join supplier s on s.id = po.supplier_id
        |inner join project p on p.id = po.project_id
        |where TO_DATE(po.created_date,'dd-MM-yyyy') = CURRENT_DATE
      """.stripMargin
    val res = sql"#$query".as[DirectorReportPurchaseOrderData]
    db.run(res).map(_.toList)
  }
}
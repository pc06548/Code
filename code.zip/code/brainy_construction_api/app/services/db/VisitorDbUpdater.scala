package services.db

import javax.inject.{Inject, Singleton}
import model.VisitorDetails
import model.reports.DirectorReportVisitorsData
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.VisitorTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{ExecutionContext, Future}


@Singleton
class VisitorDbUpdater @Inject()(configProvider: DatabaseConfigProvider)extends VisitorTable {

  import dbConfig._
  import profile.api._
  private val visitors = lifted.TableQuery[VisitorT]
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = visitors returning visitors.map(_.id) into ((item, id) => item.copy(id = id))

  def createVisitorsAndGetVisitorsId(newVisitors: VisitorDetails)= db.run {
    for {
      newVisitors <- insertQuery += newVisitors
    } yield newVisitors.id
  }

  def getById(companyId:Int,id: Int) = db.run {
    val query = visitors.filter(visitor => visitor.id === id && visitor.companyId === companyId)
    query.result.headOption
  }

  def search(companyId:Int,name: String,
             startDate: Option[String], endDate: Option[String],
             projectInterestedIn:Option[String],typeOfProperty:Option[String],
             occupation:Option[String],purpose:Option[String],
             budget:Option[String],possessionExpected:Option[String],
             loanStatus:Option[String],interestedInpromotion:Option[String]): Future[Seq[VisitorDetails]] =  {

    val query =
      s"""
         |select v.id,v.company_id,v.name,v.email,v.address,v.phone_number,v.visiting_date,
         |v.visiting_time,v.interested_in_promotion,v.type_of_property,v.budget,v.occupation,v.occupation_details,
         |v.salary_range,v.loan_status,v.project_interested_in,v.possession_expected,v.purpose,v.age_range,v.heard_from
         |from visitor v
         |where v.company_id = ${companyId} and v.name like '%${name}%'
         |${optionalLikeFilter("v.project_interested_in",projectInterestedIn)}
         |${optionalLikeFilter("v.type_of_property",typeOfProperty)}
         |${optionalLikeFilter("v.occupation",occupation)}
         |${optionalLikeFilter("v.purpose",purpose)}
         |${optionalLikeFilter("v.budget",budget)}
         |${optionalLikeFilter("v.possession_expected",possessionExpected)}
         |${optionalLikeFilter("v.loan_status",loanStatus)}
         |${optionalLikeFilter("v.interested_in_promotion",interestedInpromotion)}
         |${dateBetweenColumn("v.visiting_date",startDate,endDate)}
      """.stripMargin

    val res = sql"#$query".as[VisitorDetails]
    db.run(res).map(_.toList)
  }

  def updateVisitorDetails(v: VisitorDetails) = db.run {
    visitors.filter(c => c.id === v.id && c.companyId === v.companyId).update(v).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }
  
  def delete(companyId:Int,id: Int) = db.run {
    val query = visitors.filter(visitor => visitor.id === id && visitor.companyId === companyId)
    query.delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getDirectorReportData(): Future[List[DirectorReportVisitorsData]] =  {

    val query =
      s"""
         |select v.company_id,v.project_interested_in,v.type_of_property,v.name,v.phone_number,v.email,
         |v.purpose,v.visiting_time,v.occupation
         |from visitor v
         |where ${toDateFromColumn("v.visiting_date")} = CURRENT_DATE
      """.stripMargin

    val res = sql"#$query".as[DirectorReportVisitorsData]
    db.run(res).map(_.toList)
  }
}


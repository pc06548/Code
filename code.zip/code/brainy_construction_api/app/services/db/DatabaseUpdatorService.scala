package services.db

import java.sql.ResultSet

import config.SqlConnectionManager
import javax.inject.Inject
import play.api.Environment

class DatabaseUpdatorService @Inject()(sqlConnectionManager: SqlConnectionManager) {

  import sqlConnectionManager._
  def runInsertOrUpdate(query: String): Int = {
    val connection = getConnection
    try {
      val statement = connection.createStatement
      statement.executeUpdate(query)
    }
    finally {
      connection.close()
    }
  }

  def runInsertAndReturnId(query: String): Int = {
    val connection = getConnection
    try {
      val statement = connection.createStatement()
      statement.executeUpdate(query, 1)
      statement.getGeneratedKeys.next()
      statement.getGeneratedKeys.getInt(1)
    }
    finally {
      connection.close()
    }
  }

  def runSelectQuery(query: String): ResultSet = {
    val connection = getConnection
    try {
      val statement = connection.createStatement
      statement.executeQuery(query)
    }
    finally {
      connection.close()
    }
  }

}
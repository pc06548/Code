package services.db

import javax.inject.Inject
import model.{Category}
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.CategoryTable
import slick.lifted
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class CategoryDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends CategoryTable{

  import dbConfig._
  import profile.api._
  private val categories = lifted.TableQuery[CategoryT]
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = categories returning categories.map(_.id) into ((item, id) => item.copy(id = id))

  def createCategoryAndGetCategoryId(newCategory: Category): Future[Option[Int]]= db.run {
    for {
      newCategory <- insertQuery += newCategory
    } yield newCategory.id
  }

  def searchAllCategories(companyId : Int, categoryType: Option[String], name:Option[String]) = db.run {

    val query = for {
      c <- categories if (c.companyId === companyId) &&
                        (c.name.toLowerCase like s"%${name.map(_.toLowerCase).getOrElse("")}%") &&
                        (c.categoryType.toLowerCase like s"%${categoryType.map(_.toLowerCase).getOrElse("")}%")
    }yield c
    val adminCategories = categories.filter(_.categoryType.toLowerCase like("%admin%"))
    (query union adminCategories).result
  }

  def searchOnlyCompanyCategories(companyId : Int, categoryType: Option[String], name:Option[String]) = db.run {

    val query = for {
      c <- categories if (c.companyId === companyId) &&
        (c.name.toLowerCase like s"%${name.map(_.toLowerCase).getOrElse("")}%") &&
        (c.categoryType.toLowerCase like s"%${categoryType.map(_.toLowerCase).getOrElse("")}%")
    }yield c
    query.result
  }

  def searchAdminCategories(name:Option[String]) = db.run {

    val query = for {
      c <- categories if (c.name.toLowerCase like s"%${name.map(_.toLowerCase).getOrElse("")}%") &&
                        (c.categoryType.toLowerCase like s"%admin%")
    }yield c
    query.result
  }

  def delete(companyId:Int,id: Int) = db.run{
    categories.filter(c => c.id === id && c.companyId === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

}
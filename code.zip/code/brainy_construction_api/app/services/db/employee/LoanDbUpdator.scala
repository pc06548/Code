package services.db.employee

import javax.inject.Inject
import model.employee.Loan
import model.reports.AccountSummaryData
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.employee.LoanTable

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class LoanDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends LoanTable {

  import dbConfig._
  import profile.api._
  
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = loans returning loans.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(employeeId:Int,id: Int): Future[Option[Loan]] = db.run{
    loans.filter(c => (c.id === id && c.employeeId === employeeId)).result.headOption
  }

  def createLoan(newLoan: Loan): Future[Option[Int]] = db.run {
    for{
      newLoan <- insertQuery += newLoan
    }yield newLoan.id

  }

  def searchLoans(companyId:Int,employeeName:Option[String],
                  employeeId: Option[Int],isActive:Option[Boolean],
                  status:Option[String]): Future[List[Loan]] = {

    val statusQuery = status match {
      case Some("Paid") => """AND ((select COALESCE(SUM(lp.amount_paid),0) from loan_prepayments lp where lp.loan_id = l.id) +
                             |(select COALESCE(SUM(ld.amount),0) from payslip_details ld where ld.loan_id = l.id)) >= l.total_amount"""
      case Some("Unpaid") => """AND ((select COALESCE(SUM(lp.amount_paid),0) from loan_prepayments lp where lp.loan_id = l.id) +
                             |(select COALESCE(SUM(ld.amount),0) from payslip_details ld where ld.loan_id = l.id)) < l.total_amount"""
      case _ => ""
    }

    val query =
      s"""
         |select l.id,l.company_id,l.employee_id,l.description,l.monthly_emi,l.valid_from,
         |l.valid_till,l.loan_amount,l.interest_percentage,l.interest_amount, l.total_amount,l.is_active,l.date_created,
         |l.payment_date,l.payment_mode,l.payment_ref_number,
         |((select COALESCE(SUM(lp.amount_paid),0) from loan_prepayments lp where lp.loan_id = l.id) +
         |(select COALESCE(SUM(ld.amount),0) from payslip_details ld where ld.loan_id = l.id)) as amount_received,e.name
         |from loans l
         |inner join employee e on e.id = l.employee_id
         |where l.company_id = ${companyId}
         ${optionalFilter("l.employee_id",employeeId)}
         ${optionalLikeFilter("e.name",employeeName)}
         ${optionalFilter("l.is_active",isActive)}
         ${statusQuery}
       """.stripMargin
    //println(query)
    val res = sql"#$query".as[Loan]
    db.run(res).map(_.toList)
  }

  def updateLoan(loan: Loan) = db.run {

    loans.filter(e => e.id === loan.id &&
      e.companyId === loan.companyId).update(loan).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def delete(id: Int,employeeId: Int) = db.run{
    loans.filter(c => c.id === id && c.employeeId === employeeId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getAccountSummaryData(companyId: Int, name: String,
                            startDate: Option[String], endDate: Option[String]): Future[List[AccountSummaryData]] = {
    val query =
      s"""
         |select e.name,concat('Advance salary (' ,l.description , ')'),null as project_name, 0.0 as tds, l.total_amount,l.payment_ref_number,l.payment_date,
         |CAST (l.id AS text),'Employee' as category,l.payment_date,l.total_amount,0.0,0.0,0.0,'-','',false as is_temporary
         |from loans l
         |inner join employee e on e.id = l.employee_id
         |where l.company_id = ${companyId} ${likeFilter("e.name",name)}
         |${dateBetweenColumn("l.payment_date",startDate,endDate)}
         ${orderByDateAsc("l.payment_date")}
      """.stripMargin

    val res = sql"#$query".as[AccountSummaryData]
    db.run(res).map(_.toList)
  }
}
package services.db.employee

import javax.inject.Inject
import model.employee.{Payslip, PayslipDetail, PayslipSearch}
import model.reports.{AmountReceived, CustomerCollection, Sales}
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.employee.PayslipTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PayslipDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends PayslipTable {

  import dbConfig._
  import profile.api._
  override val payslips = lifted.TableQuery[PayslipT]
  override val payslipDetails = lifted.TableQuery[PayslipDetailT]

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = payslips returning payslips.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(id: Int): Future[Option[Payslip]] = db.run{
    payslips.filter(c => (c.id === id)).result.headOption
  }

  def getPayslip(companyId:Int,employeeId:Int,month: String): Future[Option[Int]] = db.run{
    payslips.filter(p => p.companyId === companyId && p.employeeId === employeeId && p.month === month)
      .result
      .headOption
      .map(_.flatMap(_.id))
  }
  def getDetails(payslipId: Int): Future[Seq[PayslipDetail]] = db.run {
    payslipDetails.filter(_.payslipId === payslipId).sortBy(_.id).result
  }
  def createPayslip(newPayslip: Payslip): Future[Option[Int]] = db.run {
    for{
      newPayslip <- insertQuery += newPayslip
    }yield newPayslip.id

  }

  def saveDetails(details : Seq[PayslipDetail]):Future[Unit] = {
    val inserts = for{
      detail <- details
    }yield payslipDetails += detail

    db.run(DBIO.seq(inserts: _*).transactionally)
  }

  def searchPayslips(companyId:Int,employeeId:Option[Int],month: Option[String],status:Option[String],
                     startDate:Option[String],endDate:Option[String],payslipId:Option[Int]): Future[List[PayslipSearch]] = {

    val baseQuery =
      s"""
         |select p.id,p.month,employee.id,employee.name,p.total,COALESCE(SUM(payslip_voucher.total_amount),0) as amount_received
         |from payslips as p
         |LEFT JOIN payslip_voucher on payslip_voucher.payslip_id = p.id
         |inner join employee on employee.id = p.employee_id
         |where p.company_id = ${companyId} ${optionalLikeFilter("p.month",month)}
         |${optionalFilter("p.employee_id",employeeId)}
          ${dateBetweenColumn("p.date_created", startDate, endDate)}
         ${optionalFilter("p.id",payslipId)}
         group by p.id,p.month,employee.id,employee.name,p.total
      """.stripMargin
    val query = status match {
      case Some(PayslipSearch.PAYSLIP_STATUS_UNPAID) => s"$baseQuery having COALESCE(SUM(payslip_voucher.total_amount),0) < p.total"
      case Some(PayslipSearch.PAYSLIP_STATUS_PAID) => s"$baseQuery having COALESCE(SUM(payslip_voucher.total_amount),0) >= p.total"
      case _ => baseQuery
    }
    val res = sql"#$query".as[PayslipSearch]
    db.run(res).map(_.toList)
  }

  def delete(id: Int): Future[Int] = db.run{
    (for{
      _ <- payslipDetails.filter(c => c.payslipId === id ).delete
      i <- payslips.filter(c => c.id === id).delete.flatMap { updatedRows =>
              if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
              else DBIO.successful(updatedRows)
          }
    } yield i).transactionally
  }
}
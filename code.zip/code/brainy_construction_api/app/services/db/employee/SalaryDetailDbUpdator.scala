package services.db.employee

import javax.inject.Inject
import model.employee.{SalaryDetail, SalaryStructureSearch}
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.employee.SalaryDetailTable

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class SalaryDetailDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends SalaryDetailTable {

  import dbConfig._
  import profile.api._
  
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = salaryDetails returning salaryDetails.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(employeeId:Int,id: Int): Future[Option[SalaryDetail]] = db.run{
    salaryDetails.filter(c => (c.id === id && c.employeeId === employeeId)).result.headOption
  }

  def createSalaryDetail(newSalaryDetail: SalaryDetail): Future[Option[Int]] = db.run {
    for{
      newSalaryDetail <- insertQuery += newSalaryDetail
    }yield newSalaryDetail.id

  }

  def searchSalaryDetails(companyId:Int,employeeId: Int,date:String): Future[List[SalaryDetail]] = {
    val query =
      s"""
         |select p.id,p.company_id,p.employee_id,p.description,p.detail_type,p.amount,p.valid_from,p.valid_till
         |from salary_detail p
         |where p.employee_id = ${employeeId} and p.company_id = ${companyId}
         |and ${toDateFromValue(date)} >= ${toDateFromColumn("p.valid_from")}
         and ${toDateFromValue(date)} <= ${toDateFromColumn("p.valid_till")}
       """.stripMargin
    val res = sql"#$query".as[SalaryDetail]
    db.run(res).map(_.toList)
  }

  def searchSalaryStructures(companyId:Int,name:Option[String]): Future[List[SalaryStructureSearch]] = {
    val query =
      s"""select s.employee_id,e.name,
          SUM(CASE WHEN s.detail_type = 'C' THEN s.amount ELSE 0 END) as EARNINGS,
          SUM(CASE WHEN s.detail_type = 'D' THEN s.amount ELSE 0 END) as DEDUCTIONS,
          ((SUM(CASE WHEN s.detail_type = 'C' THEN s.amount ELSE 0 END)) - (SUM(CASE WHEN s.detail_type = 'D' THEN s.amount ELSE 0 END))) as total
          from salary_detail s
          inner join employee e on e.id = s.employee_id
          group by s.employee_id,e.name,s.company_id
          having s.company_id = ${companyId} ${optionalLikeFilter("e.name",name)}""".stripMargin
    val res = sql"#$query".as[SalaryStructureSearch]
    db.run(res).map(_.toList)
  }

  def updateSalaryDetail(salaryDetail: SalaryDetail) = db.run {

    salaryDetails.filter(e => e.id === salaryDetail.id &&
      e.companyId === salaryDetail.companyId).update(salaryDetail).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def delete(id: Int,employeeId: Int) = db.run{
    salaryDetails.filter(c => c.id === id && c.employeeId === employeeId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

}
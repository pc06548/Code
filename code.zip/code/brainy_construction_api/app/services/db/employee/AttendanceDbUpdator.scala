package services.db.employee

import javax.inject.Inject
import model.employee.Attendance
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.employee.AttendanceTable

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class AttendanceDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends AttendanceTable {

  import dbConfig._
  import profile.api._
  
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = attendances returning attendances.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(id: Int): Future[Option[Attendance]] = db.run{
    attendances.filter(c => (c.id === id)).result.headOption
  }

  def getByEmployee(companyId:Int,employeeId:Option[Int],date:String):Future[Option[Attendance]] = {
    val query =
      s"""
         |select a.id,a.company_id,a.employee_id,e.name,a.date,a.start_time,a.end_time,a.work_details
         |from attendance a, employee e
         |where a.employee_id = e.id and a.company_id = ${companyId} ${optionalFilter("a.employee_id",employeeId)}
         |and ${toDateFromValue(date)} = ${toDateFromColumn("a.date")}
       """.stripMargin
    val res = sql"#$query".as[Attendance]
    db.run(res).map(_.headOption)
  }

  def createAttendance(newAttendance: Attendance): Future[Option[Int]] = db.run {
    for{
      newAttendance <- insertQuery += newAttendance
    }yield newAttendance.id

  }

  def searchAttendances(companyId:Int,employeeId: Option[Int],
                     startDate:Option[String],endDate:Option[String]): Future[List[Attendance]] = {

    val query =
      s"""
         |select a.id,a.company_id,a.employee_id,e.name,a.date,a.start_time,a.end_time,a.work_details
         |from attendance a, employee e
         |where a.employee_id = e.id and a.company_id = ${companyId} ${optionalFilter("a.employee_id",employeeId)}
         |${dateBetweenColumn("a.date",startDate,endDate)}
       """.stripMargin
    val res = sql"#$query".as[Attendance]
    db.run(res).map(_.toList)
  }

  def updateAttendance(attendance: Attendance) = db.run {

    attendances.filter(e => e.id === attendance.id &&
      e.companyId === attendance.companyId).update(attendance).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }
}
package services.db.employee

import javax.inject.Inject
import model.employee.{LoanPrepayment, LoanInstallmentFromDB}
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.employee.LoanPrepaymentTable

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class LoanPrepaymentDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends LoanPrepaymentTable {

  import dbConfig._
  import profile.api._
  
  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  val insertQuery = loans returning loans.map(_.id) into ((item, id) => item.copy(id = id))

  def getById(loanId:Int,id: Int): Future[Option[LoanPrepayment]] = db.run{
    loans.filter(c => (c.id === id && c.loanId === loanId)).result.headOption
  }

  def createLoanPrepayment(newLoanPrepayment: LoanPrepayment): Future[Option[Int]] = db.run {
    for{
      newLoanPrepayment <- insertQuery += newLoanPrepayment
    }yield newLoanPrepayment.id

  }

  def searchLoanPrepayments(loanId:Int): Future[List[LoanPrepayment]] = db.run{
    loans.filter(c => (c.loanId === loanId)).result.map(_.toList)
  }

  def delete(id: Int,loanId: Int) = db.run{
    loans.filter(c => c.id === id && c.loanId === loanId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getLoanStatementData(companyId:Int,employeeId:Int,loanId:Option[Int]): Future[List[LoanInstallmentFromDB]] = {

    val query =
      s"""
         |select lp.loan_id,l.company_id,l.employee_id,l.description as loan_description,l.monthly_emi,l.valid_from,l.valid_till,
         |l.loan_amount,l.is_active,l.date_created,l.payment_date,l.payment_mode,l.payment_ref_number,l.interest_percentage,l.interest_amount,l.total_amount,
         |'Pre-payment' as description, null as month,
         |lp.date_paid,lp.amount_paid,null as voucher_number
         |from loan_prepayments lp
         |inner join loans l on l.id = lp.loan_id
         |where l.employee_id = ${employeeId} and l.company_id = ${companyId} ${optionalFilter("l.id",loanId)}
      """.stripMargin

    val res = sql"#$query".as[LoanInstallmentFromDB]
    db.run(res).map(_.toList)
  }
}
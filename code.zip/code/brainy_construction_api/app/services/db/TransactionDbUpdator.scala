package services.db

import javax.inject._
import config.{DateHelperDeprecated, DateUtil, ResultSetIterator}
import model._
import model.reports.DirectorReportSiteExpensesData
import play.api.db.slick.DatabaseConfigProvider
import services.db.tables.TransactionTable
import slick.lifted

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class TransactionDbUpdator @Inject()(configProvider: DatabaseConfigProvider) extends TransactionTable{

  import dbConfig._
  import profile.api._
  override val transactions: TableQuery[TransactionT] = lifted.TableQuery[TransactionT]
  override val expenseSheets: TableQuery[ExpenseSheetT] = lifted.TableQuery[ExpenseSheetT]

  val insertQuery = transactions returning transactions.map(_.id) into ((item, id) => item.copy(id = id))
  val insertQueryExpenseSheet = expenseSheets returning expenseSheets.map(_.id) into ((item, id) => item.copy(id = id))

  override def dbConfigProvider: DatabaseConfigProvider = configProvider

  def createTransaction(newTransaction: Transaction) = db.run {
    for {
      newTransaction <- insertQuery += newTransaction
    } yield newTransaction.id
  }

  def updateTransaction(transaction: Transaction) = db.run {
    transactions.filter(p => p.id === transaction.id && p.companyId === transaction.companyId).update(transaction).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getById(id: Int,companyId: Int): Future[Option[Transaction]] = db.run {
    transactions.filter(c => (c.id === id && c.companyId === companyId)).result.headOption
  }

  def getAllTransactionForMonth(companyId: Int,projectId: Option[Int],employeeId:Option[Int], reportDate: String) = {
    def projectFilter = projectId.map(pid => s"and t.project_id = $pid").getOrElse("AND t.project_id is null")
    def employeeFilter = employeeId.map(pid => s"and t.employee_id = $pid").getOrElse("")

    val startDate = DateUtil.getFirstDayOfMonth(reportDate)
    val endDate = DateUtil.getLastDay(reportDate)

    val query =
      s"""
         |select t.id,t.company_id,t.project_id,t.employee_id,t.name,t.type_of_transaction,
         |t.amount,t.transaction_date,t.payment_mode,t.description from transaction as t
         |where t.company_id = ${companyId} ${employeeFilter} ${projectFilter}
         |AND ${toDateFromColumn("transaction_date")} BETWEEN ${toDateFromValue(startDate)} AND ${toDateFromValue(endDate)}
         |${projectFilter}
      """.stripMargin

    val res = sql"#$query".as[Transaction]
    db.run(res).map(_.toList)

  }

  def delete(id: Int,companyId: Int) = db.run{
    transactions.filter(c => c.id === id && c.companyId === companyId).delete.flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows deleted"))
      else DBIO.successful(updatedRows)
    }.transactionally
  }

  def getExpenseSheet(companyId:Int,projectId:Option[Int],employeeId:Option[Int], date: String): Future[Option[ExpenseSheet]] = {
    def projectFilter = projectId.map(pid => s"and e.project_id = $pid").getOrElse("AND e.project_id is null")

    def employeeFilter = employeeId.map(pid => s"and e.employee_id = $pid").getOrElse("")
    val reportStartDate = DateUtil.getFirstDayOfMonth(date)
    val query =
      s"""
         |select e.id,e.company_id,e.project_id,e.employee_id,
         |e.start_date,e.end_date,e.opening_balance,e.closing_balance,e.last_modified_on from expense_sheet as e
         |where e.company_id = ${companyId} AND e.start_date = '${reportStartDate}'
         |${employeeFilter} ${projectFilter}
      """.stripMargin

    val res = sql"#$query".as[ExpenseSheet]
    db.run(res).map(_.headOption)

  }

  def insertExpenseSheet(newExpenseSheet: ExpenseSheet) = db.run {
    for {
      newExpenseSheet <- insertQueryExpenseSheet += newExpenseSheet
    } yield newExpenseSheet.id
  }

  def updateExpenseSheet(expenseSheet: ExpenseSheet) = db.run {
    expenseSheets.filter(p => p.id === expenseSheet.id && p.companyId === expenseSheet.companyId).update(expenseSheet).flatMap { updatedRows =>
      if (updatedRows == 0) DBIO.failed(new Exception("0 rows updated"))
      else DBIO.successful(Option(updatedRows))
    }.transactionally
  }

  def getDirectorReportData() = {
    val query =
      s"""
         |select t.company_id,p.name,t.description,t.name,t.type_of_transaction,t.amount,t.payment_mode
         |from  transaction t
         |left join project p on p.id = t.project_id
         |where TO_DATE(t.transaction_date,'dd-MM-yyyy') = CURRENT_DATE
      """.stripMargin

    val res = sql"#$query".as[DirectorReportSiteExpensesData]
    db.run(res).map(_.toList)
  }

  def getCreditTransactionData(reportDate: String) = {
    val startDate = DateUtil.getFirstDayOfMonth(reportDate)
    val endDate = DateUtil.getLastDay(reportDate)
    val query =
      s"""
         |select t.company_id,t.project_id ,t.employee_id,t.name,SUM(t.amount)
         |from transaction t
         |where t.type_of_transaction = 'C'
         |${dateBetweenColumn("transaction_date",Option(startDate),Option(endDate))}
         |and t.project_id is null
         |group by t.company_id,t.project_id ,t.employee_id,t.name
         |UNION
         |select t.company_id,t.project_id ,t.employee_id,t.name,SUM(t.amount)
         |from transaction t
         |where t.type_of_transaction = 'C'
         |${dateBetweenColumn("transaction_date",Option(startDate),Option(endDate))}
         |and t.project_id is not null
         |group by t.company_id,t.project_id ,t.employee_id,t.name
         |
      """.stripMargin

    val res = sql"#$query".as[ExpenseVoucherData]
    db.run(res).map(_.toList)
  }


}
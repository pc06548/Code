package services

import model.reports.{ExcelReport, Row, Table}

object EmailBodyGenerator {

  def generateEmailBody(excelReport: ExcelReport): String = {
    s"""
       |<h2 style="text-align:center;">${excelReport.name}</h2>
       |${createTables(excelReport.tables)}
       |<h4>Thanks </h4>
       """.stripMargin
  }

  def createTables(tables:List[Table]) = {
    tables.map(table => createTable(table)).mkString("")
  }
  def createTable(table: Table) = {

    s"""
       |<table style="width:100% ; border: 1px solid black; border-collapse: collapse;">
       |  <caption><h4>${table.caption.getOrElse("")}</h4></caption>
       |  ${createHeading(table.headings)}
          ${createRows(table.rows)}
       |</table>
     """.stripMargin
  }

  def createHeading(headings:List[String]) = {
    s"""
       |<tr>
       |${headings.map(h => s"""<th style="border: 1px solid black; border-collapse: collapse;" >${h}</th>""".stripMargin).mkString("")}
       |</tr>
     """.stripMargin
  }

  def createRows(rows:List[Row]) = {
    rows.map(row => createRow(row)).mkString("")
  }

  def createRow(row: Row): String = {
    s"""
       |<tr>
       |${row.values.map(v => s"""<td style="border: 1px solid black; border-collapse: collapse;">${v}</td>""".stripMargin).mkString("")}
       |</tr>
     """.stripMargin
  }
}

package services

import config.DateUtil
import javax.inject._
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import model.EntityId
import model.customer.{Receipt, ReceiptNumber, ReceiptSearch}
import services.db.CompanyDbUpdator
import services.db.customer.ReceiptDbUpdater

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class ReceiptService @Inject()(receiptDbUpdator: ReceiptDbUpdater,companyDbUpdator: CompanyDbUpdator) extends LoggerService{

  def saveReceipt(companyId:Int,receipt: Receipt): Future[Either[ServerError, EntityId]] = {

    val newEntityId = receiptDbUpdator.createReceipt(companyId,receipt).flatMap(
      newId => {
        val updatedDetails = receipt.details.map(_.copy(receiptId = newId))
        receiptDbUpdator.saveDetails(updatedDetails).map(_ => newId)
      })
    newEntityId.map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def getReceipt(id: Int): Future[Either[ServerError, Option[Receipt]]] = {

    val evetualReceipt = receiptDbUpdator.getById(id)
    val eventualDetials = receiptDbUpdator.getDetails(id)

    val receipt = for{
      invoice <- evetualReceipt
      details <- eventualDetials
    }yield invoice.map(_.copy(details = details))

    receipt.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }

  }

  def searchReceipts(companyId:Int,projectId:Int,name: Option[String],
                     startDate:Option[String],endDate:Option[String],
                     isTemporary:Option[Boolean],receiptNumber:Option[String]):Future[Either[ServerError, List[ReceiptSearch]]]  = {
    receiptDbUpdator.searchReceipts(companyId,projectId,name,startDate,endDate,isTemporary,receiptNumber).map(Right(_)).handleExceptionWithLog
  }

  def deleteReceipt(id: Int): Future[Either[ServerError, Int]] =  {
    receiptDbUpdator.delete(id).map(Right(_)).handleExceptionWithLog
  }

  def getReceiptNumber(companyId:Int) :Future[Either[ServerError, String]] = {

    val receiptNumber: Future[String] = (for{
      lastReceiptNumbers <- receiptDbUpdator.getLastFiveReceiptNumbers(companyId)
      companyAbbreviation <- companyDbUpdator.getById(companyId).map(_.map(_.getAbbreviation))
    }yield {
      val validNumbers: List[ReceiptNumber] =  lastReceiptNumbers.filter(n => ReceiptNumber.checkIfVocherNumberValid(n.receiptNumber))
      val maxReceipt: Option[ReceiptNumber] =   validNumbers.headOption
      maxReceipt match {
        case Some(receiptNumber) => {
          if(receiptNumber.extractYear == DateUtil.getCurrentFinancialYear){
            s"${companyAbbreviation.getOrElse(receiptNumber.extractCompanyAbbrevation)}-${receiptNumber.extractReceiptNumber + 1}/${DateUtil.getCurrentFinancialYear}"
          }else{
            s"${companyAbbreviation.getOrElse(receiptNumber.extractCompanyAbbrevation)}-1/${DateUtil.getCurrentFinancialYear}"
          }
        }
        case None => s"${companyAbbreviation.getOrElse("WRONG")}-1/${DateUtil.getCurrentFinancialYear}"
      }
    })

    receiptNumber.map(Right(_)).handleExceptionWithLog
  }
}

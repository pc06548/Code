package services

import config.DateUtil
import javax.inject._
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import model._
import model.customer.{CustomerDemand, DefaultDemand, DefaultDemandLetter, DemandLetter}
import services.db.{CompanyConfigDbUpdator, ProjectDbUpdator}
import services.db.customer.{CustomerDbUpdater, CustomerDemandDbUpdater, DefaultDemandDbUpdater}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class DefaultDemandLetterService @Inject()(companyConfigDbUpdator: CompanyConfigDbUpdator,
                                           defaultDemandDbUpdator: DefaultDemandDbUpdater,
                                           customerDemandDbUpdator: CustomerDemandDbUpdater,
                                           customerDbUpdator: CustomerDbUpdater,
                                           projectDbUpdator: ProjectDbUpdator)extends LoggerService {


  def getDefaultDemand(id: Int,projectId: Int): Future[Either[ServerError, Option[DefaultDemand]]] = {
    defaultDemandDbUpdator.getById(id,projectId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveDefaultDemand(defaultDemand: DefaultDemand) = {

    val res = if(defaultDemand.isComplated){
      for{
        createdId <-  defaultDemandDbUpdator.createDefaultDemand(defaultDemand)
        customers <- customerDbUpdator.searchCustomers(None,defaultDemand.projectId)
        companyConfig <- companyConfigDbUpdator.get(defaultDemand.companyId)
        dueDate = DateUtil.incrementTodayByDays(companyConfig.map(_.dueDateLimit).getOrElse(CompanyConfig.DEFAULT_DATE_LIMIT))
        customerDemands = CustomerDemand.createFromDefaultDemand(defaultDemand.copy(id = createdId),customers,dueDate)
        _ <- customerDemandDbUpdator.createDemands(customerDemands)
      }yield createdId
    }else{
      defaultDemandDbUpdator.createDefaultDemand(defaultDemand)
    }
    res.map(createdId => createdId match {
        case Some(id) => Right[ServerError,EntityId](EntityId(id))
        case None     => Left[ServerError,EntityId](IDGenerationFailed())
      }
    ).recover{
      case e: Throwable => Left[ServerError,EntityId](RuntimeException(e))
    }
  }

  def updateDefaultDemand(defaultDemand: DefaultDemand) = {

    val updateRes = (for{
      oldDemand <- defaultDemandDbUpdator.getById(defaultDemand.id.get,defaultDemand.projectId)
    }yield {
      oldDemand match {
        case Some(old) => {
          (old.isComplated,defaultDemand.isComplated) match {
            case (true,true) => {
              for{
                _ <- defaultDemandDbUpdator.updateDefaultDemand(defaultDemand)
                customers <- customerDbUpdator.searchCustomers(None,defaultDemand.projectId)
                companyConfig <- companyConfigDbUpdator.get(defaultDemand.companyId)
                dueDate = DateUtil.incrementTodayByDays(companyConfig.map(_.dueDateLimit).getOrElse(CompanyConfig.DEFAULT_DATE_LIMIT))
                customerDemands = CustomerDemand.createFromDefaultDemand(defaultDemand,customers,dueDate)
                update <- customerDemandDbUpdator.updateDemands(customerDemands,defaultDemand.id)
              }yield update
            }
            case (true,false) => {
              for{
                _ <- defaultDemandDbUpdator.updateDefaultDemand(defaultDemand)
                deleted <- customerDemandDbUpdator.deleteDemands(old.id.get,old.projectId)
              }yield deleted
            }
            case (false,true) => {
              for{
                _ <- defaultDemandDbUpdator.updateDefaultDemand(defaultDemand)
                customers <- customerDbUpdator.searchCustomers(None,defaultDemand.projectId)
                companyConfig <- companyConfigDbUpdator.get(defaultDemand.companyId)
                dueDate = DateUtil.incrementTodayByDays(companyConfig.map(_.dueDateLimit).getOrElse(CompanyConfig.DEFAULT_DATE_LIMIT))
                customerDemands = CustomerDemand.createFromDefaultDemand(defaultDemand,customers,dueDate)
                update <- customerDemandDbUpdator.createDemands(customerDemands)
              }yield update
            }
            case (false,false) => defaultDemandDbUpdator.updateDefaultDemand(defaultDemand)
          }
        }
        case None => Future.failed(new Exception(s"No demand found for id : ${defaultDemand.id}"))
      }
    }).flatten

    updateRes.map(Right(_)).handleExceptionWithLog

  }

  def delete(id : Int,projectId: Int) = {
    defaultDemandDbUpdator.delete(id,projectId)
      .map(Right(_)).handleExceptionWithLog
  }

  def getDefaultDemandLetter(companyId : Int,projectId:Int):Future[Either[ServerError,Option[DefaultDemandLetter]]]  = {

    val mayBeDemandLetter = for{
      mayBeProject <- projectDbUpdator.getById(projectId,companyId)
      demands <- defaultDemandDbUpdator.getAllDefaultDemandsForProject(projectId)
    }yield{
      mayBeProject.map(
        project => DefaultDemandLetter(project,demands)
      )
    }

    mayBeDemandLetter.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }
}

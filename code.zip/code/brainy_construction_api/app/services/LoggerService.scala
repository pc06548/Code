package services

import org.slf4j.{Logger, LoggerFactory}
import utils.FutureExtensions

trait LoggerService extends FutureExtensions{
  self =>
  implicit val logger: Logger = LoggerFactory.getLogger(self.getClass)
}

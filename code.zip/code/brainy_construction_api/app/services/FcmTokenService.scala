package services

import exceptions.{RuntimeException, ServerError}
import javax.inject.Inject
import model.notifications.FcmToken
import services.db.FcmTokenDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class FcmTokenService @Inject()(fcmTokenDbUpdator: FcmTokenDbUpdator)extends LoggerService {

  def saveFcmToken(fcmToken: FcmToken):Future[Either[ServerError,String]] = {
    fcmTokenDbUpdator.create(fcmToken).map(Right(_)).handleExceptionWithLog
  }

  def updateFcmToken(fcmToken: FcmToken) = {
    fcmTokenDbUpdator.updateFcmToken(fcmToken).map(Right(_)).handleExceptionWithLog
  }
}

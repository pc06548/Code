package services.employees

import akka.Done
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model.EntityId
import model.vouchers.{PayslipVoucher, SavePayslipVoucher}
import services.LoggerService
import services.db.employee.PayslipVoucherDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PayslipVoucherService @Inject()(payslipVoucherDbUpdator: PayslipVoucherDbUpdator) extends LoggerService{

  def savePayslipVoucher(companyId:Int,payslipVouchers: Seq[SavePayslipVoucher]): Future[Either[ServerError, Done]] = {

    payslipVoucherDbUpdator.createPayslipVouchers(payslipVouchers)
      .map(_ => Right(Done)).handleExceptionWithLog
  }
  

  def getPayslipVoucher(companyId:Int,id: Int): Future[Either[ServerError, Option[PayslipVoucher]]] = {
    payslipVoucherDbUpdator.getById(companyId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def searchPayslipVouchers(companyId:Int,employeeId:Option[Int],
                            startDate:Option[String],endDate:Option[String],voucherNumber:Option[String]):Future[Either[ServerError, List[PayslipVoucher]]]  = {
    payslipVoucherDbUpdator.searchPayslipVouchers(companyId,employeeId,startDate,endDate,voucherNumber).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,companyId: Int) = {
    payslipVoucherDbUpdator.delete(id).map(Right(_)).handleExceptionWithLog
  }
}

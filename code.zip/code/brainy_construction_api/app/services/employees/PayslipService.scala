package services.employees

import config.DateUtil
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model.EntityId
import model.employee.{Payslip, PayslipSearch}
import services.{CompanyConfigService, LoggerService}
import services.db.employee.{LoanDbUpdator, PayslipDbUpdator, PayslipVoucherDbUpdator, SalaryDetailDbUpdator}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PayslipService @Inject()(payslipDbUpdator: PayslipDbUpdator,
                               salaryDetailDbUpdator: SalaryDetailDbUpdator,
                               loanDbUpdator: LoanDbUpdator,
                               payslipVoucherDbUpdator: PayslipVoucherDbUpdator,
                               companyConfigService: CompanyConfigService) extends LoggerService{

  def createPayslip(companyId:Int,employeeId:Int,month:String):Future[Either[ServerError,EntityId]] = {

    val existingPayslipId = payslipDbUpdator.getPayslip(companyId,employeeId,month)
    val payslipId = existingPayslipId.flatMap(id => {
      id match {
        case Some(_) => Future(id)
        case None => {
          for {
            paylsip <- generatePayslip(companyId,employeeId,month)
            entityId <- savePayslip(paylsip)
          }yield entityId
        }
      }
    })

    payslipId.map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  private def savePayslip(payslip: Payslip): Future[Option[Int]] = {
    val details = payslip.earnings ++ payslip.deductions
    if(details.nonEmpty){
      payslipDbUpdator.createPayslip(payslip).flatMap(
        newId => {
          val updatedDetails = details.map(_.copy(payslipId = newId))
          payslipDbUpdator.saveDetails(updatedDetails).map(_ => newId)
        })
    }else{
      Future(None)
    }

  }

  private def generatePayslip(companyId:Int,employeeId:Int,month:String) = {
    val date = DateUtil.getLastDayOfMonth(month)
    for{
      salaryDetails <- salaryDetailDbUpdator.searchSalaryDetails(companyId,employeeId,date)
      loans <- loanDbUpdator.searchLoans(companyId,None,Some(employeeId),Some(true),Some("Unpaid"))
    }yield {
      import model.employee.PayslipDetail._
      val earnings = salaryDetails.filter(_.detailType == "C").map(mapToPayslipDetail)
      val salaryDeductions = salaryDetails.filter(_.detailType == "D").map(mapToPayslipDetail)
      val loanDeductions = loans.filter(l => ((l.loanAmount > l.amountPaid.getOrElse(0.0)))).map(loan => {
        val pendingAmount = loan.loanAmount - loan.amountPaid.getOrElse(0.0)
        if(loan.monthlyEmi > pendingAmount){
          loan.copy(monthlyEmi = pendingAmount)
        }else{
          loan
        }
      }).map(mapToPayslipDetail)

      val deductions = salaryDeductions ++ loanDeductions
      val total = earnings.map(_.amount).sum - deductions.map(_.amount).sum
      Payslip(None,companyId,employeeId,DateUtil.getMonthFormatFromDate(date),DateUtil.today,total,None,earnings,deductions)
    }
  }

  def getPayslip(id: Int): Future[Either[ServerError, Option[Payslip]]] = {

    val evetualPayslip = payslipDbUpdator.getById(id)
    val evetualAmountPaid = payslipVoucherDbUpdator.getAmountPaidForPayslip(id)
    val eventualDetials = payslipDbUpdator.getDetails(id)

    val payslip = for{
      payslip <- evetualPayslip
      amountPaid <- evetualAmountPaid
      details <- eventualDetials
    }yield payslip.map(p => Payslip.createFromPayslipDetails(p,details.toList).copy(amountPaid = Option(amountPaid)))

    payslip.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }

  }

  def searchPayslips(companyId:Int,employeeId:Option[Int],month: Option[String],status:Option[String],
                     startDate:Option[String],endDate:Option[String],payslipId:Option[Int]):Future[Either[ServerError, List[PayslipSearch]]]  = {
    payslipDbUpdator.searchPayslips(companyId,employeeId,month,status,startDate,endDate,payslipId)
      .map(payslips => {
        Right(
            payslips.map(payslip =>{
              val status = if(payslip.amountPaid >= payslip.totalAmount) "Paid" else "Unpaid"
              payslip.copy(status = Some(status))
          })
        )
      })
      .handleExceptionWithLog
  }


  def deletePayslip(id: Int): Future[Either[ServerError, Int]] =  {
    payslipDbUpdator.delete(id).map(Right(_)).handleExceptionWithLog
  }

}

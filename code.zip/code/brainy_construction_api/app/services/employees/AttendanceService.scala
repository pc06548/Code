package services.employees

import exceptions.{IDGenerationFailed, LocationDidNotMatch, RuntimeException, ServerError}
import javax.inject._
import model.EntityId
import model.employee.Attendance
import model.reports.AttendanceReport
import services.LoggerService
import services.db.LocationDbUpdator
import services.db.employee.AttendanceDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class AttendanceService @Inject()(attendanceDbUpdator: AttendanceDbUpdator,
                                  locationDbUpdator: LocationDbUpdator)extends LoggerService {

  def saveAttendance(companyId:Int,attendance: Attendance): Future[Either[ServerError, EntityId]] = {
    locationDbUpdator.search(companyId).flatMap(locations => {
      if(attendance.checkIfValid(locations)){
        attendanceDbUpdator.createAttendance(attendance)
          .map(id => id match {
            case Some(id) => Right(EntityId(id))
            case None     => Left(IDGenerationFailed())
          }).handleExceptionWithLog
      }else{
        Future(Left[ServerError,EntityId](LocationDidNotMatch()))
      }
    })
  }

  def updateAttendance(attendance: Attendance) = {
    attendanceDbUpdator.updateAttendance(attendance).map(Right(_)).handleExceptionWithLog
  }


  def getAttendance(id: Int): Future[Either[ServerError, Option[Attendance]]] = {
    attendanceDbUpdator.getById(id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def getAttendanceForEmployee(companyId:Int,employeeId:Option[Int],date:String): Future[Either[ServerError, Option[Attendance]]] = {
    attendanceDbUpdator.getByEmployee(companyId,employeeId,date).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def searchAttendances(companyId:Int,employeeId:Option[Int],startDate:Option[String],endDate:Option[String]):Future[Either[ServerError, List[Attendance]]]  = {
    attendanceDbUpdator.searchAttendances(companyId,employeeId,startDate,endDate).map(Right(_)).handleExceptionWithLog
  }

  def attendanceReport(companyId:Int,employeeId:Option[Int],startDate:Option[String],endDate:Option[String]):Future[Either[ServerError, AttendanceReport]]  = {
    val report = for{
      attendances <- attendanceDbUpdator.searchAttendances(companyId,employeeId,startDate,endDate)
    }yield {
      AttendanceReport.createFromAttendances(attendances)
    }

    report.map(Right(_)).handleExceptionWithLog
  }

}

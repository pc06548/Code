package services.employees

import auth.action.UserRequest
import auth.db.RoleDb
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject.Inject
import model.employee.{Employee, EmployeeWithUser}
import model.{EntityId, GetNameResponse}
import play.api.mvc.AnyContent
import services.{LoggerService, UserService}
import services.db.employee.EmployeeDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class EmployeeService @Inject()(employeeDbUpdator: EmployeeDbUpdator, userService: UserService,roleDb: RoleDb)extends LoggerService {
  def createEmployeeWithUser(employeeWithUser: EmployeeWithUser,  userRequest: UserRequest[AnyContent])= {
    (employeeWithUser.user match {
      case Some(user) => {
        val (userId,loginId) = userService.createUser(user, userRequest)
        val mayRoleId = roleDb.getRoleIdByName("EMPLOYEE")
        mayRoleId.map(roleId => roleDb.createRoleLoginCompanyMapping(roleId,loginId,employeeWithUser.employee.companyId))
        employeeDbUpdator.createEmployeeAndGetEmployeeId(employeeWithUser.employee.copy(userId = userId))
      }
      case None => Future.failed(new Exception("User is empty while creating employee with user"))
    }).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def createEmployeeWithExistingUser(employee: Employee) = {
    employeeDbUpdator.createEmployeeAndGetEmployeeId(employee).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def updateEmployee(employee: Employee) = {
    employeeDbUpdator.updateEmployee(employee).map(Right(_)).handleExceptionWithLog
  }

  def getEmployeeByIdAndCompanyId(companyId: Int,employeeId: Int) = {
    employeeDbUpdator.getEmployeeByIdAndCompanyId(employeeId, companyId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }
  def getEmployeeByUserIdAndCompanyId(userId: Int, companyId: Int) = {
    employeeDbUpdator.getEmployeeByUserIdAndCompanyId(userId, companyId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def search(companyId: Int, name:String) = {
    employeeDbUpdator.search(companyId,name).map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }

  def getAllNames(companyId: Int): Future[Either[ServerError, Seq[GetNameResponse]]] = {
    employeeDbUpdator.getAllNames(companyId).map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }
}

package services.employees

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model.EntityId
import model.employee.{SalaryDetail, SalaryStructure}
import services.LoggerService
import services.db.LocationDbUpdator
import services.db.employee.SalaryDetailDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class SalaryDetailService @Inject()(salaryDetailDbUpdator: SalaryDetailDbUpdator,
                                    locationDbUpdator: LocationDbUpdator)extends LoggerService {

  def saveSalaryDetail(companyId:Int,salaryDetail: SalaryDetail): Future[Either[ServerError, EntityId]] = {

    salaryDetailDbUpdator.createSalaryDetail(salaryDetail)
      .map(id => id match {
        case Some(id) => Right(EntityId(id))
        case None     => Left(IDGenerationFailed())
      }).handleExceptionWithLog
  }

  def updateSalaryDetail(salaryDetail: SalaryDetail) = {
    salaryDetailDbUpdator.updateSalaryDetail(salaryDetail).map(Right(_)).handleExceptionWithLog
  }

  def searchSalaryStructures(companyId:Int,name:Option[String]) = {
    salaryDetailDbUpdator.searchSalaryStructures(companyId,name).map(Right(_)).handleExceptionWithLog
  }

  def getSalaryDetail(employeeId:Int,id: Int): Future[Either[ServerError, Option[SalaryDetail]]] = {
    salaryDetailDbUpdator.getById(employeeId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def getSalaryStructure(companyId:Int,employeeId:Int,date:String):Future[Either[ServerError, SalaryStructure]]  = {
    val report = for{
      salaryDetails <- salaryDetailDbUpdator.searchSalaryDetails(companyId,employeeId,date)
    }yield {
      SalaryStructure.createFromSalaryDetails(salaryDetails)
    }
    report.map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,employeeId: Int) = {
    salaryDetailDbUpdator.delete(id,employeeId).map(Right(_)).handleExceptionWithLog

  }
}

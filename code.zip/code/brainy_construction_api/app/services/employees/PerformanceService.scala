package services.employees

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model.EntityId
import model.employee.Performance
import services.LoggerService
import services.db.LocationDbUpdator
import services.db.employee.PerformanceDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PerformanceService @Inject()(performanceDbUpdator: PerformanceDbUpdator) extends LoggerService{

  def savePerformance(companyId:Int,performance: Performance): Future[Either[ServerError, EntityId]] = {

    performanceDbUpdator.createPerformance(performance)
      .map(id => id match {
        case Some(id) => Right(EntityId(id))
        case None     => Left(IDGenerationFailed())
      }).handleExceptionWithLog
  }
  

  def getPerformance(employeeId:Int,id: Int): Future[Either[ServerError, Option[Performance]]] = {
    performanceDbUpdator.getById(employeeId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }
  def update(performance: Performance) = {
    performanceDbUpdator.update(performance).map(Right(_)).handleExceptionWithLog
  }

  def searchPerformances(companyId:Int,employeeId:Int,startDate:Option[String],endDate:Option[String]):Future[Either[ServerError, List[Performance]]]  = {
    performanceDbUpdator.searchPerformances(companyId,employeeId,startDate,endDate).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,employeeId: Int) = {
    performanceDbUpdator.delete(id,employeeId).map(Right(_)).handleExceptionWithLog
  }
}

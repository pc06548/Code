package services.employees

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model.EntityId
import model.employee.LoanPrepayment
import services.LoggerService
import services.db.LocationDbUpdator
import services.db.employee.LoanPrepaymentDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class LoanPrepaymentService @Inject()(loanDbUpdator: LoanPrepaymentDbUpdator,
                                      locationDbUpdator: LocationDbUpdator)extends LoggerService {

  def saveLoanPrepayment(companyId:Int,loan: LoanPrepayment): Future[Either[ServerError, EntityId]] = {

    loanDbUpdator.createLoanPrepayment(loan)
      .map(id => id match {
        case Some(id) => Right(EntityId(id))
        case None     => Left(IDGenerationFailed())
      }).handleExceptionWithLog
  }

  def getLoanPrepayment(loanId:Int,id: Int): Future[Either[ServerError, Option[LoanPrepayment]]] = {
    loanDbUpdator.getById(loanId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def searchLoanPrepayments(loanId:Int):Future[Either[ServerError, List[LoanPrepayment]]]  = {
    loanDbUpdator.searchLoanPrepayments(loanId).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,loanId: Int) = {
    loanDbUpdator.delete(id,loanId).map(Right(_)).handleExceptionWithLog
  }
}

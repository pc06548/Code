package services.employees

import config.DateUtil
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model.EntityId
import model.employee._
import services.LoggerService
import services.db.employee.{EmployeeDbUpdator, LoanDbUpdator, LoanPrepaymentDbUpdator, PayslipVoucherDbUpdator}

import scala.collection.immutable
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try

class LoanService @Inject()(loanDbUpdator: LoanDbUpdator,
                            loanPrepaymentDbUpdator: LoanPrepaymentDbUpdator,
                            payslipVoucherDbUpdator:PayslipVoucherDbUpdator,
                            employeeDbUpdator: EmployeeDbUpdator)extends LoggerService {

  def saveLoan(companyId:Int,loan: Loan): Future[Either[ServerError, EntityId]] = {

    loanDbUpdator.createLoan(loan.copy(dateCreated = Some(DateUtil.today),
      paymentDate = Some(loan.paymentDate.getOrElse(DateUtil.today))))
      .map(id => id match {
        case Some(id) => Right(EntityId(id))
        case None     => Left(IDGenerationFailed())
      }).handleExceptionWithLog
  }

  def updateLoan(loan: Loan) = {
    loanDbUpdator.updateLoan(loan).map(Right(_)).handleExceptionWithLog
  }

  def getLoan(employeeId:Int,id: Int): Future[Either[ServerError, Option[Loan]]] = {
    loanDbUpdator.getById(employeeId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def searchLoans(companyId:Int,employeeName:Option[String],
                  employeeId: Option[Int],isActive:Option[Boolean],
                  status:Option[String]):Future[Either[ServerError, List[LoansPerEmployee]]]  = {
    loanDbUpdator.searchLoans(companyId,employeeName,employeeId,isActive,status).map(loans => {
      val groupByEmp: immutable.Iterable[LoansPerEmployee] = loans.groupBy(_.employeeName).map(l => LoansPerEmployee(l._1,l._2))
      Right(groupByEmp.toList.sortBy(_.employeeName))
    }).handleExceptionWithLog
  }

  def delete(id : Int,employeeId: Int) = {
    loanDbUpdator.delete(id,employeeId).map(Right(_)).handleExceptionWithLog
  }

  def getLoanStatement(companyId:Int,employeeId:Int,loanId:Option[Int]) = {
    (for{
      employee <- employeeDbUpdator.getEmployeeByIdAndCompanyId(employeeId,companyId)
      payslipLoanData <- payslipVoucherDbUpdator.getLoanStatementData(companyId,employeeId,loanId)
      prepayments <- loanPrepaymentDbUpdator.getLoanStatementData(companyId,employeeId,loanId)
    }yield {
      val loanInstallments: List[LoanInstallmentFromDB] = payslipLoanData ::: prepayments.map(p => p.copy(month = DateUtil.getMonthFormatFromDate(p.paymentDate)))
      val groupByLoan = loanInstallments.groupBy(l => (l.loanId,l.companyId,l.employeeId,l.loanDescription,l.monthlyEmi,
      l.validFrom,l.validTill,l.loanAmount,l.isActive,l.dateCreated,l.loanPaymentDate,l.paymentMode,l.paymentRefNumber, l.interestPercentage,l.interestAmount,l.totalAmount))
      val loanStatementData: List[LoanStatementData] = groupByLoan.map{
        case ((loanId,companyId,employeeId,loanDescription,monthlyEmi,validFrom,validTill,loanAmount,isActive,dateCreated,loanPaymentDate,paymentMode,paymentRefNumber,interestPercentage,interestAmount,totalAmount)
          ,installments) => {
          val loanDetails = Loan(Some(loanId),companyId,employeeId,loanDescription,monthlyEmi,validFrom,validTill,loanAmount,interestPercentage,interestAmount,totalAmount,isActive,
            dateCreated,loanPaymentDate,paymentMode,paymentRefNumber,None,None,
            Try(DateUtil.getDifferenceInMonths(validFrom.getOrElse(""),validTill.getOrElse(""))).toOption)
          val updatedInstallment: List[LoanInstallment] = installments.map(l =>
            LoanInstallment(l.description,l.month,l.paymentDate,l.debitedAmount,Option(l.voucherNumber).getOrElse("-"))
          ).sortBy(l => DateUtil.getDateFromString(l.paymentDate).getTime)

          val installmentsWithBalance: (Double, List[LoanInstallment]) = (updatedInstallment.foldLeft((totalAmount.getOrElse(0.0),List.empty[LoanInstallment])){
            (tuple,d) => {
              if(tuple._1 > 0.0){
                val balance = tuple._1 - d.debitedAmount
                (balance,tuple._2 :+ d.copy(balanceAmount = Some(balance)))
              } else{
                (tuple._1,tuple._2 :+ d.copy(balanceAmount = Some(0.0)))
              }
            }
          })


          LoanStatementData(loanDetails,
            installmentsWithBalance._2.map(_.debitedAmount).sum,
            installmentsWithBalance._2)
        }
      }.toList
      LoanStatement(employee,loanStatementData)
    }).map(Right(_)).handleExceptionWithLog
  }

}

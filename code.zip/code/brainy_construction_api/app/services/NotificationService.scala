package services

import auth.db.RoleDb
import exceptions.{RuntimeException, ServerError}
import javax.inject.Inject
import model.GetRoleMappingDetail
import model.notifications.NotificationRecipients
import services.db.NotificationDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class NotificationService @Inject()(notificationSettingsDbUpdator: NotificationDbUpdator,roleDb: RoleDb) {

  def getTokens(companyId: Int,userId:Int):Future[Seq[NotificationRecipients]] = {

    for{
      userWithRolesAndToken <- notificationSettingsDbUpdator.getNotificationReceivers(companyId,userId)

    } yield {
      //println("user with roles ==> " + userWithRolesAndToken)
      userWithRolesAndToken
    }
  }

}

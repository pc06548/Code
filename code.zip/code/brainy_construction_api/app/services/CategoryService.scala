package services

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject.Inject
import model.{Category, EntityId}
import services.db.CategoryDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class CategoryService @Inject()(categoryDbUpdator: CategoryDbUpdator) extends LoggerService {

  def searchCategories(companyId : Int,categoryTye:Option[String], name: Option[String],adminCategories:Boolean): Future[Either[ServerError,Seq[Category]]] = {

    val categories = adminCategories match {
      case true => categoryDbUpdator.searchAllCategories(companyId,categoryTye,name)
      case _ => {
        categoryDbUpdator.searchAllCategories(companyId,categoryTye,name).map(categories =>
          categories.filterNot(c => Category.constantCategories.contains(c.name))
        )
      }
    }
    categories.map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }

  def saveCategory(category: Category):Future[Either[ServerError,EntityId]] = {
    categoryDbUpdator.createCategoryAndGetCategoryId(category).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }


  def delete(companyId:Int,id : Int) = categoryDbUpdator.delete(companyId,id).map(Right(_)).handleExceptionWithLog

}

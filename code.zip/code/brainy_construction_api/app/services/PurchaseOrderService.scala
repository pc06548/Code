package services

import actors.NotificationsActor.NotifyPOUpdate
import akka.actor.ActorRef
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject.{Inject, Named}
import model.EntityId
import model.supplier.PurchaseOrder
import services.db.supplier.{PurchaseOrderDbUpdator, SupplierDbUpdator}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class PurchaseOrderService @Inject()(purchaseOrderDbUpdator: PurchaseOrderDbUpdator,
                                     supplierDbUpdator: SupplierDbUpdator,
                                     @Named("notifications-actor") notificationsActor: ActorRef) extends LoggerService{

  def savePurchaseOrder(purchaseOrder: PurchaseOrder,userId:Int,companyId:Int): Future[Either[ServerError, EntityId]] = {

    val newEntityId = purchaseOrderDbUpdator.createPurchaseOrder(purchaseOrder).flatMap(
      newPsId => {
        val updatedDetails = purchaseOrder.details.map(_.copy(purchaseOrderId = newPsId))
        purchaseOrderDbUpdator.saveDetails(updatedDetails).map(_ => newPsId)
      })
    newEntityId.map(id => id match {
      case Some(id) => {
        supplierDbUpdator.getById(purchaseOrder.supplierId,companyId)
          .map(_.map(_.name))
          .map(supplierName => notificationsActor ! NotifyPOUpdate(companyId,userId,id,supplierName.getOrElse("")))
        Right(EntityId(id))
      }
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def searchPurchaseOrder(supplierName: Option[String],projectId:Int,
                          startDate:Option[String],endDate:Option[String],poId: Option[Int]) = {
    purchaseOrderDbUpdator.searchPurchaseOrders(supplierName,projectId,startDate,endDate,poId).map(Right(_)).handleExceptionWithLog
  }

  def updatePs(purchaseOrder: PurchaseOrder,userId:Int,companyId:Int) = {
    val updateRes = for{
      _ <- purchaseOrderDbUpdator.updateDetails(purchaseOrder.details.map(_.copy(purchaseOrderId = purchaseOrder.id)))
      update <- purchaseOrderDbUpdator.updatePurchaseOrder(purchaseOrder)
    }yield update
    updateRes.map(upo => {
      supplierDbUpdator.getById(purchaseOrder.supplierId,companyId)
        .map(_.map(_.name))
        .map(supplierName => notificationsActor ! NotifyPOUpdate(companyId,userId,purchaseOrder.id.getOrElse(0),supplierName.getOrElse("")))
      Right(upo)
    }).handleExceptionWithLog
  }

  def getPurchaseOrder(projectId:Int, id: Int): Future[Either[ServerError, Option[PurchaseOrder]]] = {
    val evetualPs = purchaseOrderDbUpdator.getById(projectId,id)
    val eventualDetails = purchaseOrderDbUpdator.getDetails(id)

    val purchaseOrder = for{
      ps <- evetualPs
      details <- eventualDetails
    }yield ps.map(_.copy(details = details))

    purchaseOrder.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def deletePS(psId: Int,projectId: Int) = {
    purchaseOrderDbUpdator.deletePurchaseOrder(psId,projectId).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }

  def deletePsDetails(psDetailsId: Int,psId:Int) = {
    purchaseOrderDbUpdator.deletePurchaseOrderDetail(psId,psDetailsId).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }
}

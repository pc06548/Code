package services

import javax.inject._
import config.{DateUtil}
import exceptions.{IDGenerationFailed, RuntimeException,ServerError}
import model._
import services.db.TransactionDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class TransactionService @Inject()(transactionDbUpdator: TransactionDbUpdator) extends LoggerService{


  def getTransaction(id: Int,companyId: Int): Future[Either[ServerError, Option[Transaction]]] = {
    transactionDbUpdator.getById(id,companyId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveTransaction(transaction: Transaction) = {
    transactionDbUpdator.createTransaction(transaction).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog

  }

  def updateTransaction(transaction: Transaction) = {
    transactionDbUpdator.updateTransaction(transaction).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,companyId: Int) = {
    transactionDbUpdator.delete(id,companyId).map(Right(_)).handleExceptionWithLog

  }

  private def getClosingBalanceFromPreviousMonth(companyId : Int,projectId:Option[Int],employeeId:Option[Int],reportDate: String): Future[Double] = {
    val previousMonthDate = DateUtil.decrementDateByMonths(reportDate, 1)
    for{
      maybeExpenseSheet <- transactionDbUpdator.getExpenseSheet(companyId,projectId,employeeId,previousMonthDate)
    } yield {
      if (maybeExpenseSheet.isDefined)
        maybeExpenseSheet.get.closingBalance
      else
        0.0
    }
  }

  private def updateExpenseSheet(expenseSheet: ExpenseSheet) = {

    transactionDbUpdator.getExpenseSheet(expenseSheet.companyId, expenseSheet.projectId,expenseSheet.employeeId,expenseSheet.startDate)
      .flatMap(maybeExpenseSheet => maybeExpenseSheet match {
        case Some(e) => transactionDbUpdator.updateExpenseSheet(e.copy(closingBalance = expenseSheet.closingBalance,lastModified = expenseSheet.lastModified))
        case None => transactionDbUpdator.insertExpenseSheet(expenseSheet)
      })
  }

  def getExpenseSheets(companyId : Int, projectId:Option[Int], employeeId:Option[Int], reportDate: String,
                       startDate: Option[String], endDate: Option[String]):Future[Either[ServerError,List[ExpenseSheet]]]  = {

    val sheet: Future[List[ExpenseSheet]] = (startDate,endDate) match {
      case (Some(s), Some(e)) => {
        val months = getAllBetweenMonths(List(s),e)
        val sheets: List[Future[List[ExpenseSheet]]] = months.map(r => {
          getExpenseSheetForMonth(companyId,projectId,employeeId,r)
        })
        Future.sequence(sheets).map(_.flatten)
      }
      case _ => getExpenseSheetForMonth(companyId,projectId,employeeId,reportDate)
    }
    sheet.map(Right(_)).handleExceptionWithLog
  }

  def getExpenseSheetForMonth(companyId : Int, projectId:Option[Int], employeeId:Option[Int], reportDate: String) = {
    for{
      transactions <- transactionDbUpdator.getAllTransactionForMonth(companyId,projectId,employeeId,reportDate)
      expenseSheets <- getExpenseSheet(companyId,projectId,reportDate,transactions)
    }yield expenseSheets
  }
  def getExpenseSheet(companyId : Int, projectId:Option[Int],reportDate: String,
                      transactions:List[Transaction]):Future[List[ExpenseSheet]] = {
    val map: Map[Option[Int], List[Transaction]] = transactions.groupBy(_.employeeId)
    val expenseSheets: List[Future[ExpenseSheet]] = map.keySet.toList.map(employeeId => {
      (for{
        openingBalance <- getClosingBalanceFromPreviousMonth(companyId,projectId,employeeId,reportDate)
        (closingBalance, updatedTransactions) = Transaction.calculateBalance(openingBalance, map(employeeId))
        startDate = DateUtil.getFirstDayOfMonth(reportDate)
        endDate = DateUtil.getLastDay(reportDate)
        expenseSheet = ExpenseSheet(None,companyId,projectId,employeeId,startDate,endDate,
          openingBalance, closingBalance,DateUtil.today, updatedTransactions).calculateTotals()
        _ <- updateExpenseSheet(expenseSheet)
      }yield expenseSheet)
    })
    Future.sequence(expenseSheets)
  }


  def getAllBetweenMonths(dates: List[String],lastDate:String): List[String] = {
    val lastDateInList = dates.last
    val nextMonth = DateUtil.incrementByMonths(lastDateInList,1)

    if(DateUtil.getDifferenceInMonths(nextMonth,lastDate) >= 0){
      getAllBetweenMonths((dates :+ nextMonth),lastDate)
    }else{
      dates
    }

  }
}

package services

import java.io.File
import java.nio.file.{Path, Paths}

import config.AppConstants
import javax.inject.Inject
import play.api.Configuration
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider
import software.amazon.awssdk.core.sync.RequestBody
import software.amazon.awssdk.regions.Region
import software.amazon.awssdk.services.s3.S3Client
import software.amazon.awssdk.services.s3.model._

import scala.util.{Failure, Success, Try}

class UploadService @Inject()(configuration: Configuration) extends LoggerService   {

  val key = "AKIA4CERQQXRWKJBK27H"
  val secretKey = "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"

  val environment = configuration.get[String](AppConstants.environmentName)
  val awsCreds = AwsBasicCredentials.create(key, secretKey)

  val s3Client = S3Client.builder().credentialsProvider(StaticCredentialsProvider
    .create(awsCreds)).region(Region.AP_SOUTH_1).build()

  val bucketConfig = CreateBucketConfiguration.builder().locationConstraint(Region.AP_SOUTH_1.id()).build()

  def upload(orgId:Int,companyId:Int,file:File,fileName:String) = {
    Try{
      val bucketName = s"${environment}-${orgId}-${companyId}"

      val createBucketRequest = CreateBucketRequest.builder().bucket(bucketName)
                                      .createBucketConfiguration(bucketConfig).build()

      val uniqueFileName = s"${System.currentTimeMillis().toString}_${fileName}"
      val putObjectRequest = PutObjectRequest.builder().bucket(bucketName).key(uniqueFileName).build()

      Try(s3Client.createBucket(createBucketRequest)) match {
        case Failure(e : S3Exception) if e.statusCode() == 409 => s3Client.putObject(putObjectRequest, RequestBody.fromFile(file))
        case Success(_) => s3Client.putObject(putObjectRequest, RequestBody.fromFile(file))
        case Failure(e) => throw e
      }
      uniqueFileName
    }.handleExceptionWithLog
  }

  def getFile(orgId:Int,companyId:Int,filename: String) = {
    Try{
      val bucketName = s"${environment}-${orgId}-${companyId}"
      val s3ObjectRequest: GetObjectRequest = GetObjectRequest.builder().bucket(bucketName).key(filename).build()
      val path = Paths.get(AppConstants.s3FolderPath + filename)
      s3Client.getObject(s3ObjectRequest,path)
      path
    }.handleExceptionWithLog
  }
}

package services

import config.DateUtil
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject.Inject
import model.EntityId
import model.contractor.{WSRDetails, WeeklyStatusReport, WsrResource}
import services.db.contractor.WsrDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class WsrService @Inject()(wsrDbUpdator: WsrDbUpdator) extends LoggerService{

  def getWsr(projectId: Int,date:String,contractorId:Option[Int]):Future[Either[ServerError,Option[WeeklyStatusReport]]] = {

    val wsrReport = for{
      wsr <- wsrDbUpdator.getById(projectId,date)
      details <- wsrDbUpdator.getAllDetails(wsr.flatMap(_.id),contractorId)
      allResources <- wsrDbUpdator.getResources(details.map(_.id).flatten.toList)
      resourcesWithDay = allResources.map(r =>r.copy(dayOfWeek = DateUtil.getDayOfWeek(r.date)))
    }yield {
      val detailsWithResources: Seq[WSRDetails] = details
        .map(detail => detail.copy(
          resources = resourcesWithDay.filter(_.wsrDetailId == detail.id).sortWith(WsrResource.softByDate)
        )).sortBy(_.contractorName)
      wsr.map(_.copy(details = detailsWithResources))
    }

    wsrReport.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }


  def getWsrDetail(wsrId:Int,detailId: Int): Future[Either[ServerError,Option[WSRDetails]]] = {
    val evetualWsrDetail = wsrDbUpdator.getDetails(wsrId,detailId)
    val eventualResources = wsrDbUpdator.getResources(detailId)

    val wsrDetail = for{
      ps <- evetualWsrDetail
      rs <- eventualResources
      resourcesWithDay = rs.map(r =>r.copy(dayOfWeek = DateUtil.getDayOfWeek(r.date)))
    }yield ps.map(_.copy(resources = resourcesWithDay))

    wsrDetail.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }
  def saveWeeklyStatusReport(weeklyStatusReport: WeeklyStatusReport): Future[Either[ServerError, EntityId]] = {

    wsrDbUpdator.createWeeklyStatusReport(weeklyStatusReport).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }
  def saveWeeklyStatusReportDetail(newDetail: WSRDetails): Future[Either[ServerError, EntityId]] = {

    val newEntityId = wsrDbUpdator.saveDetails(newDetail).flatMap(
      newId => {
        val updatedDetails = newDetail.resources.map(_.copy(wsrDetailId = newId))
        wsrDbUpdator.saveResources(updatedDetails).map(_ => newId)
      })
    newEntityId.map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def updateWsr(weeklyStatusReport: WeeklyStatusReport) = {
    wsrDbUpdator.updateWeeklyStatusReport(weeklyStatusReport).map(Right(_)).handleExceptionWithLog
  }

  def updateWsrDetail(detail: WSRDetails) = {
    val updateRes = for{
      _ <- wsrDbUpdator.updateResources(detail.resources.map(_.copy(wsrDetailId = detail.id)))
      update <- wsrDbUpdator.updateWeeklyStatusReportDetail(detail)
    }yield update
    updateRes.map(Right(_)).handleExceptionWithLog
  }


  def deleteWsr(wsrId: Int,projectId: Int) = {
    wsrDbUpdator.deleteWeeklyStatusReport(wsrId,projectId).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }

  def deleteWsrDetails(wsrDetailsId: Int,wsrId:Int) = {
    wsrDbUpdator.deleteWeeklyStatusReportDetail(wsrId,wsrDetailsId).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }
}
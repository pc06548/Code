package services

import auth.action.UserRequest
import javax.inject._
import exceptions.{IDGenerationFailed, PlanLimitReached, RuntimeException, ServerError}
import model.{EntityId, Feature, GetNameResponse, Project}
import play.api.mvc.AnyContent
import services.db.ProjectDbUpdator

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.Try

class ProjectService @Inject()(projectDbUpdator: ProjectDbUpdator) extends LoggerService {

  def searchProjects(companyId: Int,name: Option[String],status : Option[String]) = {

    projectDbUpdator.search(companyId,name,status).map(Right(_)).handleExceptionWithLog
  }

  def getAllNames(companyId: Int,status:List[String] = Project.allStatuses): Future[Either[ServerError, Seq[GetNameResponse]]] = {
    projectDbUpdator.getAllNames(companyId,status).map(Right(_)).handleExceptionWithLog
  }

  def getProject(id: Int,companyId: Int): Future[Either[ServerError, Option[Project]]] = {
    projectDbUpdator.getById(id,companyId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveProject(project: Project, userRequest: UserRequest[AnyContent]) = {
    projectDbUpdator.search(project.companyId.getOrElse(0),None,None).flatMap(projects => {
      val activeProjects = projects.filter(_.status == Project.PROJECT_STATUS_ACTIVE)
      val feature = Feature.getFeature(userRequest.feature)
      if(projects.length >= feature.totalProjects || activeProjects.length >= feature.totalActiveProjects){
        Future(Left[PlanLimitReached,EntityId](PlanLimitReached()))
      }else{
        projectDbUpdator.createProject(project).map(id => id match {
          case Some(id) => Right(EntityId(id))
          case None     => Left(IDGenerationFailed())
        })
      }
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def updateProject(project: Project) = {
    projectDbUpdator.updateProject(project).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,companyId: Int) = {
    projectDbUpdator.delete(id,companyId).map(Right(_)).handleExceptionWithLog

  }
}

package services

import java.nio.file.Path

import exceptions.{IDGenerationFailed, RuntimeException,ServerError}
import javax.inject.Inject
import model._
import model.reports.{ExcelReport, GreyBackground, Row, Table}
import model.vouchers.Voucher
import services.db.{ProjectDbUpdator, VisitorDbUpdater}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class VisitorService @Inject()(visitorDbUpdator: VisitorDbUpdater,
                               projectDbUpdator: ProjectDbUpdator,
                               excelReportService: ExcelReportService) extends LoggerService{

  def search(companyId:Int, name: String,
             startDate: Option[String], endDate: Option[String],
             projectInterestedIn:Option[String],typeOfProperty:Option[String],
             occupation:Option[String],purpose:Option[String],
             budget:Option[String],possessionExpected:Option[String],loanStatus:Option[String],
    interestedInpromotion:Option[String]
            ): Future[Either[ServerError, Seq[VisitorDetails]]] = {
    visitorDbUpdator.search(companyId,name,startDate,endDate,projectInterestedIn,
      typeOfProperty,occupation,purpose,budget,possessionExpected,loanStatus,interestedInpromotion).map(Right(_)).handleExceptionWithLog
  }

  def searchById(companyId:Int,id: Int) = {
    visitorDbUpdator.getById(companyId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveVisitor(visitorDetails: VisitorDetails) = {
    visitorDbUpdator.createVisitorsAndGetVisitorsId(visitorDetails).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def updateVisitor(visitor: VisitorDetails) = {
    visitorDbUpdator.updateVisitorDetails(visitor).map(Right(_)).handleExceptionWithLog
  }

  def delete(companyId:Int,id: Int) = visitorDbUpdator.delete(companyId,id).map(Right(_)).handleExceptionWithLog


  def getVisitorsFormOptions(companyId:Int)  ={

    (for{
      projectNames <- projectDbUpdator.getAllNames(companyId,Project.allStatuses)
    }yield {
      VisitorFormOptions.default.copy(projectInterestedIn = projectNames.map(_.name).toList)
    }).map(Right(_)).handleExceptionWithLog
  }

  def generateExcelReport(entity : Seq[VisitorDetails],startDate: Option[String], endDate: Option[String]):Path = {

    val rows: Seq[Row] = entity.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.name,e.email.getOrElse(""),
        e.address.getOrElse(""),e.phoneNumber,e.visitingDate,e.visitingTime.getOrElse(""),e.interestedInpromotion.getOrElse(""),
        e.typeOfProperty.getOrElse(""),
        e.budget.getOrElse(""),e.occupation.getOrElse(""),e.occupationDetails.getOrElse(""),e.salaryRange.getOrElse(""),e.loanStatus.getOrElse(""),
        e.projectInterestedIn.getOrElse(""),e.possessionExpected.getOrElse(""),e.purpose.getOrElse(""),e.ageRange.getOrElse(""),
        e.heardFrom.getOrElse("")))
    }

    val headings = List("Sr. No.","Name","Email","Address","Phone Number","Visiting Date","Visiting Time",
      "Interested In promotion","Type Of Property","Budget","Occupation","Occupation Details","Salary Range","Loan status",
      "Project Interested In","Possession Expected",
      "purpose","Age Range","Heard From")

    val caption = (startDate,endDate) match {
      case (Some(s),Some(e)) => Some(s"Visitors between ${s} and ${e}")
      case (Some(s),None) => Some(s"Visitors from ${s}")
      case (None,Some(e)) => Some(s"Visitors till ${e}")
      case _ => None
    }
    val table = Table(caption,headings,rows.toList)

    val columnWidths = Map(0 -> 8,1 -> 30,2 -> 30,3 ->  30)
    val report = ExcelReport("Visitors Report",List(table),columnWidths)

    excelReportService.printReport(report,"visitors_report.xlsx")
  }
}

package services

import exceptions.{IDGenerationFailed, RuntimeException,ServerError}
import javax.inject.Inject
import model.{EntityId, GetNameResponse}
import model.supplier.Supplier
import services.db.supplier.SupplierDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future


class SupplierService @Inject()(supplierDbUpdator: SupplierDbUpdator) extends LoggerService{

  def searchSuppliers(companyId: Int,name: Option[String],supplierType : Option[String]) = {

    supplierDbUpdator.search(companyId,name,supplierType).map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }

  def getAllNames(companyId: Int): Future[Either[ServerError, Seq[GetNameResponse]]] = {
    supplierDbUpdator.getAllNames(companyId).map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }

  def getSupplier(id: Int,companyId: Int): Future[Either[ServerError, Option[Supplier]]] = {
    supplierDbUpdator.getById(id,companyId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveSupplier(supplier: Supplier) = {
    supplierDbUpdator.createSupplier(supplier).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog

  }

  def updateSupplier(supplier: Supplier) = {
    supplierDbUpdator.updateSupplier(supplier).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,companyId: Int) = {
    supplierDbUpdator.delete(id,companyId).map(Right(_)).handleExceptionWithLog

  }
}

package services

import javax.inject._
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import model._
import model.invoices.{InvoiceSearch, SaveInvoice}
import services.db._
import services.db.consultant.{ConsultantInvoiceUpdatorDb, ConsultantVoucherDbUpdator}
import services.db.contractor.{ContractorInvoiceDbUpdator, ContractorVoucherDbUpdator}
import services.db.supplier.{SupplierInvoiceDbUpdatorDb, SupplierVoucherDbUpdator}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class InvoiceService @Inject()(contractorInvoiceDbUpdator: ContractorInvoiceDbUpdator,
                               supplierInvoiceDbUpdator: SupplierInvoiceDbUpdatorDb,
                               consultantInvoiceDbUpdator: ConsultantInvoiceUpdatorDb,
                               contractorVoucherDbUpdator: ContractorVoucherDbUpdator,
                               supplierVoucherDbUpdator: SupplierVoucherDbUpdator,
                               consultantVoucherDbUpdator: ConsultantVoucherDbUpdator,
                               otherInvoiceDbUpdator: OtherInvoiceDbUpdator)extends LoggerService {

  def saveInvoice(invoice: SaveInvoice, invoiceType: String): Future[Either[ServerError, EntityId]] = {

    val newEntityId = getInvoiceDbUpdator(invoiceType).createInvoice(invoice).flatMap(
      newInvoiceId => {
        val updatedDetails = invoice.details.map(_.copy(invoiceId = newInvoiceId))
        getInvoiceDbUpdator(invoiceType).saveDetails(updatedDetails).map(_ => newInvoiceId)
      })
    newEntityId.map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def updateInvoice(invoice: SaveInvoice, invoiceType: String) = {
    val updateRes = for{
      _ <- getInvoiceDbUpdator(invoiceType).updateDetails(invoice.details)
      update <- getInvoiceDbUpdator(invoiceType).updateInvoice(invoice)
    }yield update
    updateRes.map(Right(_)).handleExceptionWithLog
  }

  def getInvoice(companyId: Int,id: Int, invoiceType: String): Future[Either[ServerError, Option[SaveInvoice]]] = {
    val evetualInvoice = getInvoiceDbUpdator(invoiceType).getById(companyId,id)
    val eventualAmountPaid = getVoucherDbUpdator(invoiceType).getAmountPaidForInvoice(id)
    val eventualDetials = getInvoiceDbUpdator(invoiceType).getDetails(id)

    val invoice = for{
      invoice <- evetualInvoice
      amountPaid <- eventualAmountPaid
      details <- eventualDetials
    }yield invoice.map(_.copy(details = details, amountPaid = Some(amountPaid.getOrElse(0))))

    invoice.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def searchInvoice(name: String,companyId:Int,projectId: Option[Int],status : String, invoiceType: String,
                    startDate:Option[String],endDate:Option[String],isTemporary:Option[Boolean],invoiceNumber:Option[String]) = {

    val invoices = invoiceType match {
      case Category.all => searchAllInvoices(companyId,name,projectId,status,startDate,endDate,isTemporary,invoiceNumber)
      case _ => getInvoiceDbUpdator(invoiceType).searchInvoices(companyId,name,projectId,status,startDate,endDate,isTemporary,invoiceNumber)
    }
    invoices.map(Right(_)).handleExceptionWithLog
  }

  private def searchAllInvoices(companyId:Int,name: String,projectId: Option[Int],status : String,
                    startDate:Option[String],endDate:Option[String],isTemporary:Option[Boolean],invoiceNumber:Option[String]) = {
    val contractorPR = contractorInvoiceDbUpdator
      .searchInvoices(companyId,name,projectId,status,startDate,endDate,isTemporary,invoiceNumber)

    val supplierPR = supplierInvoiceDbUpdator
      .searchInvoices(companyId,name,projectId,status,startDate,endDate,isTemporary,invoiceNumber)

    val consultantPR = consultantInvoiceDbUpdator
      .searchInvoices(companyId,name,projectId,status,startDate,endDate,isTemporary,invoiceNumber)

    val otherPR = otherInvoiceDbUpdator
      .searchInvoices(name,companyId,projectId,status,"",startDate,endDate,isTemporary,invoiceNumber)
    for{
      contractor <- contractorPR
      supplier <- supplierPR
      consultant <- consultantPR
      other <- otherPR
    }yield contractor ++ supplier ++ consultant ++ other
  }

  def deleteInvoice(companyId: Int,id: Int, invoiceType: String): Future[Either[ServerError, Int]] =  {
    getInvoiceDbUpdator(invoiceType).deleteInvoice(id,companyId).map(Right(_)).handleExceptionWithLog
  }

  def deleteDetail(invoiceId : Int,id: Int, invoiceType: String): Future[Either[ServerError, Int]] = {
    getInvoiceDbUpdator(invoiceType).deleteInvoiceDetail(invoiceId,id).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }

  private def getInvoiceDbUpdator(invoiceType: String): InvoiceDbUpdator = {
    invoiceType match {
      case Category.contractor => contractorInvoiceDbUpdator
      case Category.supplier  => supplierInvoiceDbUpdator
      case _ => consultantInvoiceDbUpdator
    }
  }
  private def getVoucherDbUpdator(invoiceType: String): VoucherDb = {
    invoiceType match {
      case Category.contractor => contractorVoucherDbUpdator
      case Category.supplier => supplierVoucherDbUpdator
      case _ => consultantVoucherDbUpdator
    }
  }
}

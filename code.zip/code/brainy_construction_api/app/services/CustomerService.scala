package services

import akka.Done
import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject.Inject
import model.{EntityId, GetNameResponse}
import model.customer.{Customer, FlatDetails}
import services.db.customer.{CustomerDbUpdater, FlatDetailsDbUpdator}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class CustomerService @Inject()(customerDbUpdator: CustomerDbUpdater,
                                flatDetailsDbUpdator: FlatDetailsDbUpdator)extends LoggerService {

  def saveCustomer(customer: Customer): Future[Either[ServerError, EntityId]] = {

    (for{
      flatId <- flatDetailsDbUpdator.createFlatDetailsAndGetFlatDetailsId(customer.projectDetails)
      newCustomer =  customer.copy(projectDetails = customer.projectDetails.copy(id = flatId))
      newCustomerId <- customerDbUpdator.createCustomer(newCustomer)
    }yield {
      customer.coOwners match {
        case Some(coOwners) => {
          customerDbUpdator.saveCoOwners(coOwners.map(_.copy(customerId = newCustomerId))).map(_ => newCustomerId)
        }
        case None => Future(newCustomerId)
      }
    }).flatten.map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def searchCustomers(projectId:Int,name: Option[String],
                      agreementStartDate: Option[String],agreementEndDate: Option[String],
                      saledeedStartDate: Option[String],saledeedEndDate: Option[String],
                      possessionStartDate: Option[String],possessionEndDate: Option[String]) = {
    customerDbUpdator.searchCustomers(name,projectId,agreementStartDate,agreementEndDate,
      saledeedStartDate,saledeedEndDate,possessionStartDate,possessionEndDate)
      .map(c => Right(c.sortBy(_.projectDetails.flatNumber))).handleExceptionWithLog
  }

  def getAllNames(projectId: Int): Future[Either[ServerError, Seq[GetNameResponse]]] = {
    customerDbUpdator.getAllNames(projectId).map(Right(_)).handleExceptionWithLog
  }

  def updateCustomer(customer: Customer) = {
    val coOwnerUpdate = customer.coOwners match {
      case Some(coOwners) => {
        customerDbUpdator.updateCoOwners(coOwners.map(_.copy(customerId = customer.id)))
      }
      case None => Future(Done)
    }
    val updateRes = for{
      _ <- coOwnerUpdate
      existingCustomer <- customerDbUpdator.getById(customer.projectDetails.projectId,customer.id.get)
      flatId <- updateOrCreate(existingCustomer,customer.projectDetails)
      update <- customerDbUpdator.updateCustomer(customer.copy(projectDetails = customer.projectDetails.copy(id = flatId)))
    }yield update
    updateRes.map(Right(_)).handleExceptionWithLog
  }

  private def updateOrCreate(existingCustomer: Option[Customer],flatDetails:FlatDetails) : Future[Option[Int]] = {
    existingCustomer match {
      case Some(c) if c.projectDetails.buildingName.getOrElse("") == "sample" =>
          flatDetailsDbUpdator.createFlatDetailsAndGetFlatDetailsId(flatDetails.copy(id = None))
      case _ => flatDetailsDbUpdator.updateFlatDetails(flatDetails).map(_ => flatDetails.id)
    }
  }

  def getCustomer(projectId:Int, id: Int): Future[Either[ServerError, Option[Customer]]] = {
    val evetualCustomer = customerDbUpdator.getById(projectId,id)
    val eventualDetails = customerDbUpdator.getCoOwners(id)
    val customer = for{
      c <- evetualCustomer
      details <- eventualDetails
    }yield c.map(_.copy(coOwners = Option(details)))

    customer.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def deleteCustomer(cId: Int,projectId: Int) = {
    customerDbUpdator.deleteCustomer(cId,projectId).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }

  def deleteCoOwnerDetails(customerId: Int, coOwnerId:Int) = {
    customerDbUpdator.deleteCoOwners(customerId,coOwnerId).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }
}

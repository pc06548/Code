// . TODO cleanup of use
package services

import auth.action.UserRequest
import auth.db.{LoginDb, OrgDb, UserDb}
import config.DateHelperDeprecated
import controllers.user.{CreateUserRequest, UpdateUserRequest}
import exceptions.PlanLimitReached
import javax.inject.Inject
import model.{Feature, Login, User}
import play.api.mvc.AnyContent

import scala.concurrent.ExecutionContext


class UserService @Inject()(userDb: UserDb, loginDb: LoginDb, orgDb: OrgDb)(implicit ec: ExecutionContext) {

  def createUser(createUserRequest: CreateUserRequest, userRequest: UserRequest[AnyContent]) = {

    val feature = Feature.getFeature(userRequest.feature)
    val existingUsers = getUsersByOrgId(userRequest.orgId,"")
    if(existingUsers.length >= feature.numberOfUsers){
      throw PlanLimitReached()
    }else{
      val userId = userDb.create(createUserRequest.name, createUserRequest.mobileNumber, createUserRequest.emailId.getOrElse(""))
      val currentDate = DateHelperDeprecated.nowSqlTimeStamp
      val login = Login(1, userId, userRequest.orgId, createUserRequest.userName, null, currentDate, currentDate, DateHelperDeprecated.endOfTimeSqlTimeStamp)
      val loginId = loginDb.createAndGetLoginId(login)
      (userId,loginId)
    }
  }

  def updateUser(updateUserRequest: UpdateUserRequest) = {
    userDb.update(updateUserRequest.id, updateUserRequest.name, updateUserRequest.mobileNumber, updateUserRequest.emailId)
  }

  def getUsersByOrgId(orgId: Int,name:String): List[User] = {
    userDb.getUsersByOrgId(orgId,name)
  }

  def getUsersByLoginId(loginId: Int): Either[Exception, Option[User]] = {
    userDb.getUserByLoginId(loginId)
  }

  def getUsersByUserId(userId: Int): Either[Exception, Option[User]] = {
    userDb.getUserByUserId(userId)
  }

  def getOrgById(orgId:Int) = {
    orgDb.getOrgById(orgId)
  }
}

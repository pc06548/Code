package services

import exceptions.{IDGenerationFailed, RuntimeException,ServerError}
import javax.inject.Inject
import model.{EntityId, GetNameResponse}
import model.consultant.Consultant
import services.db.consultant.ConsultantDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class ConsultantService @Inject()(consultantDbUpdator: ConsultantDbUpdator)extends LoggerService {

  def searchConsultants(companyId: Int,name: Option[String],deptName : Option[String]) = {

    consultantDbUpdator.search(companyId,name,deptName)
      .map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }

  def getAllNames(companyId: Int): Future[Either[ServerError, Seq[GetNameResponse]]] = {
    consultantDbUpdator.getAllNames(companyId).map(c => Right(c.sortBy(_.name))).handleExceptionWithLog
  }

  def getConsultant(id: Int,companyId: Int): Future[Either[ServerError, Option[Consultant]]] = {
    consultantDbUpdator.getById(id,companyId).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveConsultant(consultant: Consultant) = {
    consultantDbUpdator.createConsultant(consultant).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog

  }

  def updateConsultant(consultant: Consultant) = {
    consultantDbUpdator.updateConsultant(consultant).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,companyId: Int) = {
    consultantDbUpdator.delete(id,companyId).map(Right(_)).handleExceptionWithLog

  }
}

package services

import auth.db.RoleDb
import consts.Roles
import javax.inject.Inject
import model._

class RoleService @Inject()(roleDb : RoleDb) {
  def getRoles() = {
    roleDb.getRoles()
  }

  def getRoleMappingByLoginId(loginId: Int): List[GetRoleMapping] = {
    roleDb.getRoleMappings(loginId, None)
  }

  def getRoleMappingByCompanyId(companyId: Int): List[GetRoleMappings] = {
    val roles = roleDb.getRoleMappingsByCompanyId(companyId)
    roles.groupBy(d => (d.userId,d.userName,d.loginId,d.companyId,d.companyName)).map(roles => {
      GetRoleMappings(roles._1._1,roles._1._2,roles._1._3,roles._1._4,roles._1._5,roles._2.map(role => Role(role.roleId,role.roleName)))
    }).toList
  }

  def getRoleMappingByLoginIdCompanyId(loginId: Int, companyId: Int) = {
    roleDb.getRoleMappings(loginId, Some(companyId))
  }

  def getRoleMappingByOrgId(orgId: Int): List[GetRoleMappings] = {
    val roles = roleDb.getRoleMappingsByOrgId(orgId)
    roles.groupBy(d => (d.userId,d.userName,d.loginId,d.companyId,d.companyName)).map(roles => {
      GetRoleMappings(roles._1._1,roles._1._2,roles._1._3,roles._1._4,roles._1._5,roles._2.map(role => Role(role.roleId,role.roleName)))
    }).toList
  }

  def addAdminRole(loginId:Int,companyId:Int) = {
    val adminRoleId = roleDb.getRoleIdByName(Roles.ADMIN)
    adminRoleId.map(roleId => {
      addRoleMapping(RoleMapping(roleId,loginId,companyId))
    })
  }
  def addRoleMapping(roleMapping: RoleMapping) = {
    roleDb.createRoleLoginCompanyMapping(roleMapping.roleId, roleMapping.loginId, roleMapping.companyId)
  }

  def removeRoleMapping(roleMapping: RoleMapping) = {
    roleDb.removeRoleLoginCompanyMapping(roleMapping.roleId, roleMapping.loginId, roleMapping.companyId)
  }

  def updateRoleMapping(addRoleMappings: List[RoleMapping], removeRoleMappings: List[RoleMapping]) = {
    addRoleMappings.map(roleMappingToAdd => {
      addRoleMapping(roleMappingToAdd)
    })
    removeRoleMappings.map(roleMappingToRemove => {
      removeRoleMapping(roleMappingToRemove)
    })
  }
}

package services

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject.Inject
import model.{CompanyConfig, EntityId, GetNameResponse}
import services.db.CompanyConfigDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class CompanyConfigService @Inject()(companyConfigDbUpdator: CompanyConfigDbUpdator) extends LoggerService {

  def getCompanyConfig(companyId:Int): Future[Either[ServerError,Option[CompanyConfig]]] = {

    companyConfigDbUpdator.get(companyId).map(c => c match {
      case Some(company) => Right(Some(company))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveCompanyConfig(companyConfig: CompanyConfig):Future[Either[ServerError,EntityId]] = {
    companyConfigDbUpdator.create(companyConfig).map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def updateCompanyConfig(companyConfig: CompanyConfig) = {
    companyConfigDbUpdator.updateCompanyConfig(companyConfig).map(Right(_)).handleExceptionWithLog
  }
}

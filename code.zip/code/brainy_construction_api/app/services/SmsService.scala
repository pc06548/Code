package services

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.{URL, URLEncoder}
import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}

import scala.util.Try

class SmsService {

  def send(messageToBeSent:String = "Default message", numberList:String = "") ={

    Try{

      val apiKey: String = "apikey=" + URLEncoder.encode("T8P6YxtdMuc-FZD9IZGhTLhnf92Jc87m5ocIifyYv0", "UTF-8")
      val message: String = "&message=" + URLEncoder.encode(messageToBeSent, "UTF-8")
      val sender: String = "&sender=" + URLEncoder.encode("TXTLCL", "UTF-8")
      val numbers: String = "&numbers=" + URLEncoder.encode(numberList, "UTF-8")
      val data = "https://api.textlocal.in/send/?" + apiKey + numbers + message + sender
      val url = new URL(data)
      val conn = url.openConnection
      conn.setDoOutput(true)

      val bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream))
      val lines = List[String]()
      var line: String = null
      while ({line = bufferedReader.readLine; line != null}) {
        lines ::: List(line)
      }
      bufferedReader.close
      lines.mkString(" ")

    }.toEither match {
      case Left(e) => Left[ServerError,String](RuntimeException(e))
      case Right(p) => Right[ServerError,String](p)
    }
  }

}

package services

import auth.action.UserRequest
import exceptions.{IDGenerationFailed, PlanLimitReached, RuntimeException, ServerError}
import javax.inject.Inject
import model.{EntityId, Feature, GetNameResponse}
import model.company.Company
import play.api.mvc.AnyContent
import services.db.CompanyDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try

class CompanyService @Inject()(companyDbUpdator: CompanyDbUpdator,roleService: RoleService) extends LoggerService {

  def searchCompanies(loginId:Int,orgId : Int, name: Option[String]): Future[Either[ServerError,Seq[Company]]] = {

    companyDbUpdator.search(loginId,orgId,name).map(Right(_)).handleExceptionWithLog
  }

  def getAllNames(orgId : Int): Future[Either[ServerError,Seq[GetNameResponse]]] = {

    companyDbUpdator.getAllNames(orgId).map(Right(_)).handleExceptionWithLog
  }

  def getCompany(id: Int): Future[Either[ServerError,Option[Company]]] = {

    companyDbUpdator.getById(id).map(c => c match {
      case Some(company) => Right(Some(company))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def saveCompany(company: Company,userRequest: UserRequest[AnyContent]):Future[Either[ServerError,EntityId]] = {
    companyDbUpdator.search(userRequest.loginId,userRequest.orgId,None).flatMap(companies => {
      val feature = Feature.getFeature(userRequest.feature)
      if(companies.length >= feature.numberOfCompanies){
          Future(Left[PlanLimitReached,EntityId](PlanLimitReached()))
        }else{
          companyDbUpdator.createCompanyAndGetCompanyId(company).map(id => id match {
            case Some(id) => {
              Try(roleService.addAdminRole(userRequest.loginId,id)).toEither match {
                case Right(_) => Right(EntityId(id))
                case Left(e) => Left(RuntimeException(e))
              }
            }
            case None     => Left(IDGenerationFailed())
          })
        }
      }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def updateCompany(company: Company) = {
    companyDbUpdator.updateCompany(company).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int) = {
    companyDbUpdator.delete(id).map(Right(_)).handleExceptionWithLog
  }

}

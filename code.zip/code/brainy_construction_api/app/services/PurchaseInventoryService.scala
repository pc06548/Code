package services

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model.{EntityId, PurchaseInventory}
import services.db.PurchaseInventoryDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PurchaseInventoryService @Inject()(purchaseInventoryDbUpdator: PurchaseInventoryDbUpdator) extends LoggerService{

  def savePurchaseInventory(purchaseInventory: PurchaseInventory): Future[Either[ServerError, EntityId]] = {

    purchaseInventoryDbUpdator.createPurchaseInventory(purchaseInventory)
      .map(id => id match {
        case Some(id) => Right(EntityId(id))
        case None     => Left(IDGenerationFailed())
      }).handleExceptionWithLog
  }
  

  def getPurchaseInventory(projectId:Int,id: Int): Future[Either[ServerError, Option[PurchaseInventory]]] = {
    purchaseInventoryDbUpdator.getById(projectId,id).map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def update(purchaseInventory: PurchaseInventory) = {
    purchaseInventoryDbUpdator.update(purchaseInventory).map(Right(_)).handleExceptionWithLog
  }

  def searchPurchaseInventories(companyId:Int,projectId:Int,
                                startDate:Option[String],endDate:Option[String],
                                supplierName:Option[String],transporterName:Option[String]):Future[Either[ServerError, List[PurchaseInventory]]]  = {
    purchaseInventoryDbUpdator.searchPurchaseInventorys(companyId,projectId,startDate,endDate,supplierName,transporterName).map(Right(_)).handleExceptionWithLog
  }

  def delete(id : Int,projectId: Int) = {
    purchaseInventoryDbUpdator.delete(id,projectId).map(Right(_)).handleExceptionWithLog
  }
}

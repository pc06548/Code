package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.reports._
import services.LoggerService
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try
class DueReportService @Inject()(reportService : InvoiceReportService,
                                 excelReportService: ExcelReportService,
                                 companyChatDataService: CompanyChartDataService,
                                 projectChatDataService: ProjectChartDataService)extends LoggerService {

  import reportService._

  def getReport(name: String,companyId:Int,projectId: Option[Int],mayBeCategory:Option[String],
                startDate:Option[String],endDate:Option[String],isTemporary:Option[Boolean],onlyOfficeData:Boolean): Future[Either[ServerError, DueReport]] = {

    val report = mayBeCategory match {
      case Some(category) => getSpecificCategoryReport(name,companyId,projectId,category,startDate,endDate,isTemporary,onlyOfficeData)
      case None => getGenericReport(name,companyId,projectId,startDate,endDate,isTemporary,onlyOfficeData)
    }

    report.map(r => {
      val chartData = Try(createChartData(projectId,r)).toOption.flatten
      Right(r.copy(chartData = chartData))
    }).handleExceptionWithLog
  }

  def getSpecificCategoryReport(name: String,companyId:Int,projectId: Option[Int],category:String,
                                startDate:Option[String],endDate:Option[String],isTemporary:Option[Boolean],onlyOfficeData:Boolean) = {

    for{
      details <- getInvoiceReportDb(category)
        .dueReportInvoices(name,companyId,projectId,Some(category),startDate,endDate,isTemporary,onlyOfficeData)
    } yield DueReport.createDueReport(details)
  }


  def getGenericReport(name: String,companyId:Int,projectId: Option[Int],
                       startDate:Option[String],endDate:Option[String],isTemporary:Option[Boolean],onlyOfficeData:Boolean) = {
    val contractorPR = contractorInvoicesDb
      .dueReportInvoices(name,companyId,projectId,None,startDate,endDate,isTemporary,onlyOfficeData)

    val supplierPR = supplierInvoicesDb
      .dueReportInvoices(name,companyId,projectId,None,startDate,endDate,isTemporary,onlyOfficeData)

    val consultantPR = consultantInvoicesDB
      .dueReportInvoices(name,companyId,projectId,None,startDate,endDate,isTemporary,onlyOfficeData)

    val otherPR = otherInvoicesDb
      .dueReportInvoices(name,companyId,projectId,None,startDate,endDate,isTemporary,onlyOfficeData)

    for{
      contractor <- contractorPR
      supplier <- supplierPR
      consultant <- consultantPR
      other <- otherPR
    }yield {
      val all = contractor ++ supplier ++ consultant ++ other
      DueReport.createDueReport(all)
    }
  }

  def generateExcelReport(entity : DueReport):Path = {

    val rows: Seq[Row] = entity.details.zipWithIndex.flatMap{
      case (e,i) => {
        val detailsRows: Seq[Row] = e.details.map(d => Row(List(i+1,e.name,d.projectName,d.category,d.invoiceNumber,
          d.invoiceDate,d.totalAmount,d.amountPaid,d.pendingAmount.getOrElse(0.0),d.paymentStatus.getOrElse("-"),d.creditDays.getOrElse(0))))
        val totalRow = Row(List("","Sub-total","","","","",e.totalAmount,e.amountPaid,e.pendingAmount,"",""),YellowBackground)
        detailsRows.toList ::: List(totalRow)
      }
    }
    val totals = Row(List("","Total","","","","",entity.totalAmount,entity.amountPaid,entity.pendingAmount,"",""),GreyBackground)

    val headings = List("Sr. No.","Name","Project Name","Category","Invoice No.",
      "Invoice Date","Total Amount","Amount Paid","Amount pending", "Payment status", "Delay In days")

    val table = Table(None,headings,(rows :+ totals).toList)

    val report = ExcelReport("Due Report",List(table),Map(0 -> 7,1 -> 25,2->16))

    excelReportService.printReport(report,"due_report.xlsx")
  }

  def createChartData(projectId: Option[Int],report: DueReport) = {

    if(report.details.isEmpty)
      None
    else{
      projectId match {
        case Some(p) => {
          Some(projectChatDataService.createProjectLevelChartData(report.details.toList.flatMap(p => {
            p.details.map(r => {
              ChartRawDataForProject.createChartRawData(
                r.category,r.invoiceDate,r.totalAmount)
            })
          })))
        }
        case None => Some(companyChatDataService.createAllCompanyLevelChartData(
          report.details.toList.flatMap(p => {
            p.details.map(r => {
              ChartRawDataForCompany.createChartRawData(
                r.projectName,r.invoiceDate,r.totalAmount)
            })
          })
        ))
      }
    }
  }
}

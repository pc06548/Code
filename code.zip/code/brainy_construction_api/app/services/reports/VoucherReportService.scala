package services.reports

import javax.inject.Inject
import model.Category
import services.db.{OtherVoucherDbUpdator, VoucherDb}
import services.db.consultant.ConsultantVoucherDbUpdator
import services.db.contractor.ContractorVoucherDbUpdator
import services.db.supplier.SupplierVoucherDbUpdator

class VoucherReportService @Inject()(contractorVoucherDbUpdator: ContractorVoucherDbUpdator,
                                     supplierVoucherDbUpdator: SupplierVoucherDbUpdator,
                                     consultantVoucherDbUpdator: ConsultantVoucherDbUpdator,
                                     otherVoucherDbUpdator: OtherVoucherDbUpdator){

  def contractorVouchersDb = contractorVoucherDbUpdator
  def consultantVouchersDB = consultantVoucherDbUpdator
  def supplierVouchersDb = supplierVoucherDbUpdator
  def otherVouchersDb = otherVoucherDbUpdator

  def getVoucherReportDb(invoiceType: String): VoucherDb = {
    invoiceType match {
      case Category.contractor => contractorVoucherDbUpdator
      case Category.supplier => supplierVoucherDbUpdator
      case Category.consultant => consultantVoucherDbUpdator
      case _ => otherVoucherDbUpdator
    }
  }


}

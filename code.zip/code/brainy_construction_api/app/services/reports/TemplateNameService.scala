package services.reports

import exceptions.{RuntimeException, ServerError}
import model.reports.TemplateName
import services.LoggerService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class TemplateNameService extends LoggerService{

  def getTemplateNames(orgId:Int,companyId:Int,projectId:Option[Int]) = {

    val names = TemplateName(
      chequePrintTemplates = List("cheque_print_template.xlsx")
    )

    val eventualNames = Future(names)
    eventualNames.map(Right(_)).handleExceptionWithLog
  }


}

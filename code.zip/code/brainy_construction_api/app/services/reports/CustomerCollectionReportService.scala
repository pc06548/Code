package services.reports

import java.nio.file.Path

import exceptions.{NoDueCertificateCannotBeCreated, RuntimeException, ServerError}
import javax.inject._
import model.reports._
import services.LoggerService
import services.db.customer.{ExtraWorkReceiptDbUpdater, ReceiptDbUpdater}
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService
import scala.util.Try
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class CustomerCollectionReportService @Inject()(receiptDbUpdator: ReceiptDbUpdater,
                                                extraWorkReceiptDbUpdater: ExtraWorkReceiptDbUpdater,
                                                excelReportService: ExcelReportService,
                                                companyChatDataService: CompanyChartDataService,
                                                projectChatDataService: ProjectChartDataService) extends LoggerService{


  def getReport(companyId:Int,projectId: Option[Int],name:Option[String],
                startDate:Option[String],endDate:Option[String],
                isTemporary:Option[Boolean],extraWork:Option[Boolean]): Future[Either[ServerError, CustomerCollectionSummary]] = {

    val report: Future[CustomerCollectionSummary] = extraWork match {
      case Some(true) => extraWorkReceiptDbUpdater
        .getCustomerCollection(companyId, projectId,name,startDate,endDate,isTemporary)
        .map(CustomerCollectionSummary.createFromCollection)
      case _ => {
        for {
          collections <- receiptDbUpdator.getCustomerCollection(companyId, projectId,name,startDate,endDate,isTemporary)
          extraWorkCollections <- extraWorkReceiptDbUpdater.getCustomerCollection(companyId, projectId,name,startDate,endDate,isTemporary)
        }yield CustomerCollectionSummary.createFromCollection(collections ::: extraWorkCollections)

      }
    }

    report.map(r => {
      val chartData = Try(createChartData(projectId,r)).toOption.flatten
      Right(r.copy(chartData = chartData))
    }).handleExceptionWithLog
  }

  def getNoDueReport(companyId:Int,projectId: Int,customerId:Int): Future[Either[ServerError, NoDueReport]] = {

    val report = for {
      collections <- receiptDbUpdator.noDueReport(companyId, projectId,customerId)
    }yield NoDueReport.createDueReport(collections)

    report.map(r => {
      val amountPaid = r.details.map(_.totalAmount).sum
      if(amountPaid < r.agreementCost || r.agreementCost == 0){
        Left(NoDueCertificateCannotBeCreated(r.agreementCost,amountPaid))
      }else{
        Right(r)
      }
    }).handleExceptionWithLog
  }

  def generateExcelReport(entity : CustomerCollectionSummary):Path = {

    val rows: Seq[Row] = entity.collections.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.projectName,e.customerName,e.receiptNumber,e.receiptDate,
        e.installationAmount,e.cgst,e.sgst,e.totalAmount,e.paymentMode,e.paymentRefNumber,e.paymentDate))
    }

    val headings = List("Sr. No.","Project Name","Customer Name","Receipt No","Receipt Date",
      "Installment Amount","CGST","SGST","Total Amount","Payment Mode","Cheque / NEFT No.","Cheque / NEFT Date")

    val totals = Row(List("","","Total","","",entity.amountTotal,entity.cgstTotal,entity.sgstTotal,entity.totalAmount,"","",""),GreyBackground)

    val table = Table(None,headings,(rows :+ totals).toList)

    val columnWidths = Map(0 -> 8,1 -> 16,2 -> 32)
    val report = ExcelReport("Customer collection Report",List(table),columnWidths,List(0,1,2))

    excelReportService.printReport(report,"customer_collection_report.xlsx")
  }
  def createChartData(projectId: Option[Int],report: CustomerCollectionSummary) = {

    if(report.collections.isEmpty)
      None
    else{
      projectId match {
        case Some(p) => {
          Some(projectChatDataService.createProjectLevelChartData(report.collections.map(p => ChartRawDataForProject.createChartRawData(
            p.customerName,p.receiptDate,p.totalAmount))))
        }
        case None => Some(companyChatDataService.createAllCompanyLevelChartData(report.collections.map(p => ChartRawDataForCompany.createChartRawData(
          p.projectName,p.receiptDate,p.totalAmount))))
      }
    }
  }
}

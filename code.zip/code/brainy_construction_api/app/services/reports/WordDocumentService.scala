package services.reports

import java.io.{File, FileInputStream}
import java.nio.file.Paths

import collection.JavaConverters._
import com.google.common.io.Files
import org.apache.poi.xwpf.usermodel.{XWPFDocument, XWPFRun}
import java.io.FileOutputStream
class WordDocumentService {
  val excelFolderPath = "public/excel/"

  def dummyWordDoc() ={

    createDocument("Sample Agreement.docx","Agreement.docx",Map("Gandhar" -> "aditya"))
  }

  def createDocument(templateFileName:String,finalFileName:String,map : Map[String,String]) = {
    val templateFilepath = Paths.get(excelFolderPath,templateFileName)
    val templateFile = new File(templateFilepath.toUri)
    val finalFilePath = Paths.get(excelFolderPath + finalFileName)
    val finalFile = new File(finalFilePath.toUri)
    Files.copy(templateFile,finalFile)

    val fis = new FileInputStream(finalFile)
    val document = new XWPFDocument(fis)

    // --------- paragraphs ------------------
    for{
      p <- document.getParagraphs.asScala
      r <- p.getRuns.asScala
      if r != null
    }yield updateRun(r,map)

    //------------  Tables------------------------

    for{
      table <- document.getTables().asScala
      row <- table.getRows.asScala
      cell <- row.getTableCells().asScala
      para <- cell.getParagraphs.asScala
      r <- para.getRuns.asScala
      if r != null
    }yield updateRun(r,map)

    val out = new FileOutputStream(new File(finalFilePath.toUri))
    document.write(out)
    out.close()
    finalFilePath
  }
  private def updateRun(r:  XWPFRun,map : Map[String,String]):XWPFRun = {
    val text = r.getText(0)
    if(text != null){
      r.setText(replaceFromMap(text,map),0)
    }
    r
  }

  def replaceFromMap(text:String,map : Map[String,String]):String = {
    map.foldLeft(text)((a,b) => a.replaceAllLiterally(b._1, b._2))
  }
}

package services.reports

import java.nio.file.Path

import config.{DateHelperDeprecated, DateUtil}
import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.reports._

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import config.ScalaHelpers._
import services.LoggerService
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService
import scala.util.Try
class TdsReportService @Inject()(reportService: VoucherReportService,
                                 excelReportService: ExcelReportService,
                                 companyChatDataService: CompanyChartDataService,
                                 projectChatDataService: ProjectChartDataService)extends LoggerService {

  import reportService._

  def getReport(companyId:Int,projectId: Option[Int],name: Option[String],
                startDate:Option[String],endDate:Option[String],
                mayBeCategory: Option[String],onlyOfficeData:Boolean): Future[Either[ServerError, TdsReport]] = {

    val eventualVouchers: Future[List[TdsData]] = mayBeCategory match {
      case Some(category) => getSpecificCategoryReport(companyId,projectId,name,startDate,endDate,category,onlyOfficeData)
      case None => getGenericReport(companyId,projectId,name,startDate,endDate,onlyOfficeData)
    }

    val report: Future[TdsReport] = eventualVouchers.map(tdsData => {

      val nameWiseTds = (for{
        ((name,category,pan), nameWiseVouchers) <- tdsData.groupBy(v => (v.name,v.category,v.pan))
      }yield {
        val monthWiseVouchers = nameWiseVouchers.groupBy(d => DateUtil.getMonthFormatFromDate(d.date))
        val tdsDetails = monthWiseVouchers.map{case(month,list) => {
          TdsDetail(month,list.map(_.taxableValue).sum,list.map(_.tds).sum.roundTo2())
        }}
          .toList
          .sortBy(tds => DateUtil.getDateFromMonthString(tds.month).getTime)

        NameWiseTds(name,category,pan.getOrElse(""),tdsDetails)
      }).toList


      val monthWiseTds = (for{
        ((month), monthWiseVouchers) <- tdsData.groupBy(d => DateUtil.getMonthFormatFromDate(d.date))
      }yield {
        MonthWiseTds(month,monthWiseVouchers.map(_.taxableValue).sum,monthWiseVouchers.map(_.tds).sum.roundTo2())
      }).toList.sortBy(tds => DateUtil.getDateFromMonthString(tds.month).getTime)

      val tdsReport = TdsReport(nameWiseTds,monthWiseTds)

      tdsReport
    })

    report.map(r => {
      val chartData = Try(createChartData(projectId,r)).toOption.flatten
      Right(r.copy(chartData = chartData))
    }).handleExceptionWithLog
  }

  def getSpecificCategoryReport(companyId:Int,projectId: Option[Int],name: Option[String],
                                startDate:Option[String],endDate:Option[String],
                                category: String,onlyOfficeData:Boolean) = {

    getVoucherReportDb(category)
      .getTdsDetails(companyId,name,projectId,startDate,endDate,Some(category),onlyOfficeData)
  }


  def getGenericReport(companyId:Int,projectId: Option[Int],name: Option[String],
                       startDate:Option[String],endDate:Option[String],onlyOfficeData:Boolean) = {
    val contractorPR = contractorVouchersDb
      .getTdsDetails(companyId,name,projectId,startDate,endDate,None,onlyOfficeData)

    val consultantPR = consultantVouchersDB
      .getTdsDetails(companyId,name,projectId,startDate,endDate,None,onlyOfficeData)

    val otherPR = otherVouchersDb
      .getTdsDetails(companyId,name,projectId,startDate,endDate,None,onlyOfficeData)

    for{
      contractor <- contractorPR
      consultant <- consultantPR
      other <- otherPR
    }yield contractor ++ consultant ++ other

  }

  def generateExcelReport(entity : TdsReport):Path = {

    val nameRows: Seq[Row] = entity.nameWiseTds.zipWithIndex.flatMap{
      case (e,i) => { e.details.map(d => {
        Row(List(i+1,e.name,e.category,e.pan,
          d.month,d.taxableValue,d.tds))
        })
      }
    }

    val nameHeadings = List("Sr. No.","Name","Category","PAN",
      "Month","Taxable Value","TDS")

    val nameTotals = Row(List("","Total","","","",
      entity.nameWiseTds.flatMap(_.details.map(_.taxableValue)).sum,
      entity.nameWiseTds.flatMap(_.details.map(_.tds)).sum
    ),GreyBackground)

    val nameTable = Table(Some("Name wise TDS"),nameHeadings,(nameRows :+ nameTotals).toList)

    val monthRows: Seq[Row] = entity.monthWiseTds.zipWithIndex.map{
      case (e,i) => {
        Row(List(i+1,e.month,e.totalTaxableValue,e.totalTds))
      }
    }

    val monthHeadings = List("Sr. No.","Month","Taxable Value","TDS")

    val monthTotals = Row(List("","Total",
      entity.monthWiseTds.map(_.totalTaxableValue).sum,
      entity.monthWiseTds.map(_.totalTds).sum
    ),GreyBackground)

    val monthTable = Table(Some("Month wise TDS"),monthHeadings,(monthRows :+ monthTotals).toList)

    val columnWidths = Map(0 -> 8,1 -> 30,2 -> 16, 3-> 16,4 -> 20)
    val report = ExcelReport("TDS Report",List(nameTable,monthTable),columnWidths,List(0,1,2,3))

    excelReportService.printReport(report,"tds_report.xlsx")
  }

  def createChartData(projectId: Option[Int],report: TdsReport) = {

    if(report.nameWiseTds.isEmpty)
      None
    else{
      val catProjectTotals = report.nameWiseTds.groupBy(_.category).map{
        case (fieldName,list) => (fieldName,list.flatMap(_.details.map(_.tds)).sum)
      }.toList

      val catDataSet = catProjectTotals.map(_._2)
      val categoryDoughnutChart =  DoughnutChart("Project Report",catProjectTotals.map(_._1),List(DoughnutChartDataSet(catDataSet)))

      val projectTotals = report.nameWiseTds.groupBy(_.name).map{
        case (fieldName,list) => (fieldName,list.flatMap(_.details.map(_.tds)).sum)
      }.toList

      val dataSet = projectTotals.map(_._2)
      val nameDoughnutChart =  DoughnutChart("Project Report",projectTotals.map(_._1),List(DoughnutChartDataSet(dataSet)))

      Some(ChartData(List.empty[StackedBarChart],List(categoryDoughnutChart,nameDoughnutChart)))

    }
  }

}

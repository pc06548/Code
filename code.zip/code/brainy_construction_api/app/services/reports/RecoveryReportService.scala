package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.reports._
import services.LoggerService
import services.db.customer.{CustomerDemandDbUpdater, ReceiptDbUpdater}
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try
class RecoveryReportService @Inject()(receiptDbUpdator: ReceiptDbUpdater,
                                      demandLetterDbUpdator: CustomerDemandDbUpdater,
                                      excelReportService: ExcelReportService,
                                      companyChatDataService: CompanyChartDataService,
                                      projectChatDataService: ProjectChartDataService) extends LoggerService{


  def getReport(companyId:Int,projectId: Option[Int],name:Option[String],
                startDate:Option[String],endDate:Option[String]): Future[Either[ServerError, RecoveryReport]] = {


    val report = for {
      recoveries <- demandLetterDbUpdator.getDemandsForRecoveryReport(companyId, projectId,name,startDate,endDate)
      amountReceied <- receiptDbUpdator.getAmountReceived(companyId,projectId)
    }yield{

      val customerMap: Map[Int, List[RecoveryFromDb]] = recoveries.groupBy(_.customerId)
      val updatedRecoveries: List[RecoveryFromDb] = customerMap.keys.toList.flatMap(customerId => {

        val amountPaid: Double = amountReceied.filter(_.customerId == customerId).headOption.map(_.amountReceived).getOrElse(0.0)
        val updateDemands: (Double, List[RecoveryFromDb]) = customerMap.get(customerId).getOrElse(List.empty[RecoveryFromDb])
          .foldLeft((amountPaid,List.empty[RecoveryFromDb])){
          (tuple,d) => {
            if(tuple._1 > 0){
              if(tuple._1 >= d.netAmount){
                val receivedAmt = d.netAmount
                val pending = 0.0
                val updatedDemand = d.copy(receivedAmount = Some(receivedAmt),pendingAmount = Some(pending))
                val newList = tuple._2 :+ updatedDemand
                ((tuple._1 - d.netAmount),newList)
              }else{
                val receivedAmt = tuple._1
                val pending = d.netAmount - receivedAmt
                val updatedDemand = d.copy(receivedAmount = Some(receivedAmt),pendingAmount = Some(pending))
                val newList = tuple._2 :+ updatedDemand
                (0,newList)
              }
            }else{
              val receivedAmt = 0.0
              val pending = d.netAmount
              val updatedDemand = d.copy(receivedAmount = Some(receivedAmt),pendingAmount = Some(pending))
              val newList = tuple._2 :+ updatedDemand
              (tuple._1,newList)
            }
          }
        }
        updateDemands._2.filter(_.pendingAmount.getOrElse(0.0) > 0)
      })
      RecoveryReport.createFromRecoveries(updatedRecoveries)

    }

    report.map(r => {
      val chartData = Try(createChartData(projectId,r)).toOption.flatten
      Right(r.copy(chartData = chartData))
    }).handleExceptionWithLog
  }

  def generateExcelReport(entity : RecoveryReport):Path = {

    val rows: Seq[Row] = entity.recoveries.zipWithIndex.flatMap{
      case (e,i) => {
        val detailsRows: Seq[Row] = e.recoveries.map(d => Row(List(i+1,e.customerName,e.projectName,d.dueDate,d.amount,
          d.cgst,d.sgst,d.netAmount,d.receivedAmount.getOrElse(0.0),d.pendingAmount.getOrElse(0.0),d.delayInDays.getOrElse(0),e.bankName)))

        val totalRow = Row(List("","Sub-total","","",e.amount,e.cgst,e.sgst,e.netAmount,e.receivedAmount,e.pendingAmount,"",""),YellowBackground)
        detailsRows.toList ::: List(totalRow)
      }
    }

    val headings = List("Sr. No.","Customer Name","Project Name","Due Date","Installment Amount",
      "CGST","SGST","Total Amount","Received Amount","Balance Amount","Delay in Days","Financial Institute/Bank")

    val totals = Row(List("","Total","","",entity.amount,entity.cgst,entity.sgst,entity.netAmount,entity.receivedAmount,entity.pendingAmount,"",""),GreyBackground)

    val table = Table(None,headings,(rows :+ totals).toList)

    val report = ExcelReport("Recovery Report",List(table),Map(0 -> 7,1 -> 30,2->16))

    excelReportService.printReport(report,"Recovery_report.xlsx")
  }

  def createChartData(projectId: Option[Int],report: RecoveryReport) = {

    if(report.recoveries.isEmpty)
      None
    else{
      projectId match {
        case Some(p) => {
          Some(projectChatDataService.createProjectLevelChartData(report.recoveries.flatMap(p => {
            p.recoveries.map(r => {
              ChartRawDataForProject.createChartRawData(
                p.customerName,r.dueDate,r.pendingAmount.getOrElse(0.0))
            })
          })))
        }
        case None => Some(companyChatDataService.createAllCompanyLevelChartData(
          report.recoveries.flatMap(p => {
            p.recoveries.map(r => {
              ChartRawDataForCompany.createChartRawData(
                p.projectName,r.dueDate,r.pendingAmount.getOrElse(0.0))
            })
          })
        ))
      }
    }
  }
}

package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.reports._
import services.LoggerService
import services.db.customer.ReceiptDbUpdater
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try
import scala.util.Try
class SalesReportService @Inject()(receiptDbUpdator: ReceiptDbUpdater,
                                   excelReportService: ExcelReportService,
                                   companyChatDataService: CompanyChartDataService,
                                   projectChatDataService: ProjectChartDataService) extends LoggerService{


  def getReport(companyId:Int,projectId: Option[Int],
                startDate:Option[String],endDate:Option[String]): Future[Either[ServerError, SalesReport]] = {

    val report = for {
      sales <- receiptDbUpdator.getSalesReport(companyId, projectId,startDate,endDate)
    }yield {

      val report = SalesReport.createSalesReport(sales)
      val chartData = Try(createChartData(projectId,report)).toOption.flatten
      report.copy(chartData = chartData)
    }

    report.map(Right(_)).handleExceptionWithLog
  }

  def generateExcelReport(entity : SalesReport):Path = {

    val rows: Seq[Row] = entity.sales.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.projectName,e.customerName,e.flatNumber,e.agreementDate,
        e.agreementAmount,e.amountReceived,e.balanceAmount))
    }

    val totals = Row(List("","","Total","","",
      entity.agreementAmount,entity.amountReceived,entity.balanceAmount),GreyBackground)

    val headings = List("Sr. No.","Project Name","Customer Name","Flat Number","Agreement Date",
      "Agreement Amount","Amount Received","Balance Amount")

    val table = Table(None,headings,(rows :+ totals).toList)

    val columnWidths = Map(0 -> 8,1 -> 20,2 -> 30,3 ->13,4 -> 13,5 -> 13,6 -> 13,7 -> 13)
    val report = ExcelReport("Sales Report",List(table),columnWidths,List(0,1,2,3))

    excelReportService.printReport(report,"sales_report.xlsx")
  }

  def createChartData(projectId: Option[Int],report: SalesReport) = {

    if(report.sales.isEmpty)
      None
    else{
      projectId match {
        case Some(p) => {
          Some(projectChatDataService.createProjectLevelChartData(report.sales.map(p => ChartRawDataForProject.createChartRawData(
            p.customerName,p.agreementDate,p.amountReceived)).toList))
        }
        case None => Some(companyChatDataService.createAllCompanyLevelChartData(report.sales.map(p => ChartRawDataForCompany.createChartRawData(
          p.projectName,p.agreementDate,p.amountReceived)).toList))
      }
    }
  }
}

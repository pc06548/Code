package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.customer.PaymentDelayReport
import model.reports._
import services.LoggerService
import services.db.customer.{CustomerDbUpdater, ReceiptDbUpdater}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class PaymentDelayReportService @Inject()(receiptDbUpdator: ReceiptDbUpdater,
                                          customerDbUpdater: CustomerDbUpdater,
                                          excelReportService: ExcelReportService)extends LoggerService {


  def getReport(companyId:Int,projectId: Int,customerId:Int): Future[Either[ServerError, PaymentDelayReport]] = {

    val eventualData = receiptDbUpdator.paymentDelayReportData(companyId, projectId,customerId)
    val eventualCustomer = customerDbUpdater.getById(projectId,customerId)
    val eventualDetails =  customerDbUpdater.getCoOwners(customerId)
    val report = for {
      data <- eventualData
      customer <- eventualCustomer
      coOwners <- eventualDetails
    }yield PaymentDelayReport.create(customer.map(_.copy(coOwners = Option(coOwners))),data)

    report.map(Right(_)).handleExceptionWithLog
  }

  def generateExcelReport(entity : PaymentDelayReport):Path = {

    val rows: Seq[Row] = entity.details.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.receiptNumber,e.dateCreated,e.content,e.amount,e.cgst,e.sgst,
        e.interest,e.totalAmount,e.paymentDate,e.mode,e.paymentRefNumber.getOrElse("-"),e.dueDate,e.delayInDays))
    }

    val headings = List("Sr. No.","Receipt No.","Receipt Date","Detail","Installment Amount",
      "CGST Amount","SGST","Interest","Total Received Amount","Payment/ Cheque Date","Payment Mode",
      "Payment Reference No.","Due Date","Delay in Days")

    val totals = Row(List("","","","Total",entity.amountTotal,entity.cgstTotal,entity.sgstTotal,entity.interestTotal,entity.totalAmount,"","","","",""),GreyBackground)

    val table = Table(entity.customer.map(_.ownerDetails.name).map(name => s"Customer Name : ${name}"),
      headings,(rows :+ totals).toList)

    val columnWidths = Map(0 -> 8,1 -> 16,2 -> 14,3 -> 32)
    val report = ExcelReport("Payment Delay Report",List(table),columnWidths)

    excelReportService.printReport(report,"payment_delay_report.xlsx")
  }

}

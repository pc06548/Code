package services.reports

import javax.inject.Inject
import model.Category
import services.db.{OtherInvoiceDbUpdator}
import services.db.consultant.ConsultantInvoiceUpdatorDb
import services.db.contractor.ContractorInvoiceDbUpdator
import services.db.reports.InvoiceReportsDb
import services.db.supplier.SupplierInvoiceDbUpdatorDb

class InvoiceReportService @Inject()(contractorInvoiceDbUpdator: ContractorInvoiceDbUpdator,
                                     supplierInvoiceDbUpdator: SupplierInvoiceDbUpdatorDb,
                                     consultantInvoiceDbUpdator: ConsultantInvoiceUpdatorDb,
                                     otherInvoiceDbUpdator: OtherInvoiceDbUpdator){

  def contractorInvoicesDb = contractorInvoiceDbUpdator
  def consultantInvoicesDB = consultantInvoiceDbUpdator
  def supplierInvoicesDb = supplierInvoiceDbUpdator
  def otherInvoicesDb = otherInvoiceDbUpdator


  def getInvoiceReportDb(invoiceType: String): InvoiceReportsDb = {
    invoiceType match {
      case Category.contractor => contractorInvoiceDbUpdator
      case Category.supplier => supplierInvoiceDbUpdator
      case Category.consultant => consultantInvoiceDbUpdator
      case _ => otherInvoiceDbUpdator
    }
  }


}

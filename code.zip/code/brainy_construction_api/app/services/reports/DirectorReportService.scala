package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject.Inject
import model.reports._
import services.{EmailBodyGenerator, MailerService}
import services.db.{CompanyDbUpdator, PurchaseInventoryDbUpdator, TransactionDbUpdator, VisitorDbUpdater}
import services.db.contractor.{ContractorInvoiceDbUpdator, ContractorVoucherDbUpdator, WsrDbUpdator}
import services.db.customer.ReceiptDbUpdater
import services.db.supplier.PurchaseOrderDbUpdator
import services.reports.excel.ExcelReportService
import config.ScalaHelpers._
import model.company.Company

import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.Try

class DirectorReportService @Inject()(companyDbUpdator: CompanyDbUpdator,
                                       voucherDb: ContractorVoucherDbUpdator,
                                      receiptDbUpdater: ReceiptDbUpdater,
                                      invoiceDbUpdator: ContractorInvoiceDbUpdator,
                                      purchaseOrderDbUpdator: PurchaseOrderDbUpdator,
                                      purchaseInventoryDbUpdator: PurchaseInventoryDbUpdator,
                                      excelReportService: ExcelReportService,
                                      wsrDbUpdator:WsrDbUpdator,
                                      transactionDbUpdator: TransactionDbUpdator,
                                      visitorDbUpdater: VisitorDbUpdater,
                                      mailerService: MailerService) {

  private def getCompanies(companyId:Option[Int]) = {
    companyId match {
      case  Some(id) => companyDbUpdator.getById(id).map(_.map(List(_)).getOrElse(List.empty[Company]))
      case None => companyDbUpdator.getAll()
    }
  }
  def getDirectorReport(companyId:Option[Int] = None) = {

    val eventualCompanies = getCompanies(companyId)
    val eventualAllExpenseOverview =  voucherDb.directorReportExpenseOverview()
    val eventualAllCustomerCollection =  receiptDbUpdater.directorReportCustomerCollection()
    val eventualAllPurchaseOverviewData =  invoiceDbUpdator.directorReportPurchaseOverviewData()
    val eventualAllPurchaseOrderData =  purchaseOrderDbUpdator.directorReportData()
    val eventualAllPurchaseInventoryData =  purchaseInventoryDbUpdator.directorReportData()
    val eventualAllAttendanceData =  wsrDbUpdator.getDirectorReportData()
    val eventualAllSiteExpenseData =  transactionDbUpdator.getDirectorReportData()
    val eventualAllVisitorData =  visitorDbUpdater.getDirectorReportData()

    for{
      companies                 <- eventualCompanies
      allExpenseOverview        <- eventualAllExpenseOverview
      allCustomerCollection     <- eventualAllCustomerCollection
      allPurchaseOverviewData   <- eventualAllPurchaseOverviewData
      allPurchaseOrderData      <- eventualAllPurchaseOrderData
      allPurchaseInventoryData  <- eventualAllPurchaseInventoryData
      allAttendanceData         <- eventualAllAttendanceData
      allSiteExpenseeData       <- eventualAllSiteExpenseData
      allSiteVisitorData        <- eventualAllVisitorData
    }yield {
      companies.foreach(company => {

        val companyExpenseOverview       = allExpenseOverview.filter(_.companyId == company.id.getOrElse(0))
        val companyCustomerCollection    = allCustomerCollection.filter(_.companyId == company.id.getOrElse(0))
        val companyPurchaseOverviewData  = allPurchaseOverviewData.filter(_.companyId == company.id.getOrElse(0))
        val companyPurchaseOrderData     = allPurchaseOrderData.filter(_.companyId == company.id.getOrElse(0))
        val companyPurchaseInventoryData = allPurchaseInventoryData.filter(_.companyId == company.id.getOrElse(0))
        val companyAttendanceData = allAttendanceData.filter(_.companyId == company.id.getOrElse(0))
        val companySiteExpenseData = allSiteExpenseeData.filter(_.companyId == company.id.getOrElse(0))
        val companyVisitorData = allSiteVisitorData.filter(_.companyId == company.id.getOrElse(0))


        val customerCollectionRows = companyCustomerCollection.map(l => {
          Row(List(l.projectName,s"${l.flatDetails} (${l.flatNumber})",l.name,l.totalAmountPaid,l.receivedAmount,l.amountDue))
        })
        val customerCollectionTotals=createTotalRow(customerCollectionRows,{
          Row(List("","","Total",
            companyCustomerCollection.map(_.totalAmountPaid).sum.roundTo2(),
            companyCustomerCollection.map(_.receivedAmount).sum.roundTo2(),
            companyCustomerCollection.map(_.amountDue).sum.roundTo2()),GreyBackground)
        })

        val customerCollectionTable = Table(Some("Collection Overview"),
          List("Project","Flat details","Customer Name","Total Amount","Received Amount","Balance Amount"),(customerCollectionRows ::: customerCollectionTotals))

        val expenseOverviewRows = companyExpenseOverview.map(l => {
          Row(List(l.projectName,l.category,l.name,l.amount,l.voucherNumber,l.paymentRef))
        })
        val expenseOverviewTotals = createTotalRow(expenseOverviewRows,{
          Row(List("","","Total",companyExpenseOverview.map(_.amount).sum.roundTo2(),"",""),GreyBackground)
        })

        val expenseOverviewTable = Table(Some("Expense Overview"),
          List("Project","Category","Name","Total Amount","Voucher No.","Tranaction No."),expenseOverviewRows ::: expenseOverviewTotals)

        val purchaseOverviewRows = companyPurchaseOverviewData.map(l => {
          Row(List(l.projectName,l.category,l.name,l.totalAmount,l.invoiceNumber,l.description))
        })
        val purchaseOverviewTotals = createTotalRow(purchaseOverviewRows,{
          Row(List("","","Total",companyPurchaseOverviewData.map(_.totalAmount).sum.roundTo2(),"",""),GreyBackground)
        })

        val purchaseOverviewTable = Table(Some("Purchase Overview"),
          List("Project","Category","Name","Total Amount","Invoice No.","Description"),purchaseOverviewRows ::: purchaseOverviewTotals)

        val purchaseOrderOverviewRows = companyPurchaseOrderData.map(l => {
          Row(List(l.projectName,l.poId,l.name,l.totalAmount,l.generatedBy,l.approvedBy))
        })
        val purchaseOrderTotals = createTotalRow(purchaseOrderOverviewRows,{
          Row(List("","","Total",companyPurchaseOrderData.map(_.totalAmount).sum.roundTo2(),"",""),GreyBackground)
        })

        val purchaseOrderTable = Table(Some("Purchase Order report"),
          List("Project","Purchase order number","Name","Total Amount","Generated by","Approved By"),purchaseOrderOverviewRows ::: purchaseOrderTotals)

        val purchaseInventoryRows = companyPurchaseInventoryData.map(l => {
          Row(List(l.projectName,l.material,l.source,
            s"${l.vehicleNumber} (${l.inTime} - ${l.outTime})",l.chalanNumber,l.purchaseOrderNumber))
        })

        val purchaseInventoryTable = Table(Some("Purchase Inventory report"),
          List("Project","Material","Supplier Name","Vehical No.(In Time - Out Time)","Challan No." ,"Purchase order number"),purchaseInventoryRows)

        val attendanceRows = companyAttendanceData.map(l => {
          Row(List(l.projectName,l.department,l.name,l.count,l.shiftTime,l.createdBy))
        })

        val attendanceTable = Table(Some("Site Attendance Report"),
          List("Project","Department","Name","No. of Persons","Shift Time (In Time - Out Time)" ,"Generated By"),attendanceRows)

        val siteExpenseRows = companySiteExpenseData.map(l => {
          Row(List(l.projectName,l.reason,l.name,l.typeOfTransaction,l.amount,l.paymentMode))
        })

        val siteExpenseTotals = createTotalRow(siteExpenseRows,{
          Row(List("","","Total","",companySiteExpenseData.map(_.amount).sum.roundTo2(),""),GreyBackground)
        })

        val siteExpenseTable = Table(Some("Site & Office Expenses Report"),
          List("Project","Reason","Name","Type of transaction","Amount" ,"payment mode"),siteExpenseRows ::: siteExpenseTotals)

        val visitorRows = companyVisitorData.map(l => {
          Row(List(l.projectName,l.typeOfProperty,s"${l.name} (${l.phoneNumber}, ${l.email})",
            l.purpose,l.visitingTime,l.occupation))
        })

        val visitorTable = Table(Some("Visitors Report"),
          List("Project","Flat Interest","Visitors Name (Phone No & Email)","Purpose","Visited Time" ,"Occupation"),visitorRows)


        val report = ExcelReport("Daily Director Report",List(customerCollectionTable,expenseOverviewTable,
          purchaseOverviewTable,purchaseOrderTable,purchaseInventoryTable,attendanceTable,siteExpenseTable,visitorTable).filter(_.rows.length > 0),
          Map(0 -> 15,1 -> 15,2 -> 25, 3 -> 15, 4-> 15, 5 -> 15),
          List(0,1,2))

        if(report.tables.length > 0){
          mailerService.sendEmail(EmailBodyGenerator.generateEmailBody(report),company.email)
          /*Try{excelReportService.printReport(report,s"daily_director_report_${company.id.get}.xlsx") }.toEither match {
            case Left(e) => Left[ServerError,Path](RuntimeException(e))
            case Right(p)  => {
              mailerService.sendEmailWithAttachment(p.toFile(),s"daily_director_report_${company.id.get}.xlsx",
                EmailBodyGenerator.generateEmailBody(report),company.email)
            }
          }*/
        }else{
          println(s"Report not sent for ${company.name} because its empty")
        }
      })
    }

  }

  def createTotalRow[A](list:List[A], f: => Row) : List[Row] = {
    if(list.isEmpty){
      List.empty[Row]
    }else{
      List(f)
    }
  }


}

package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.Category
import model.reports._
import services.LoggerService
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try

class PurchaseReportService @Inject()(reportService : InvoiceReportService,
                                      excelReportService: ExcelReportService,
                                      companyChatDataService: CompanyChartDataService,
                                      projectChatDataService: ProjectChartDataService) extends LoggerService{

  import reportService._

  def getReport(companyId:Int,projectId: Option[Int],name: String,
                startDate:Option[String],endDate:Option[String],
                mayBeCategory: Option[String],onlyOfficeData:Boolean): Future[Either[ServerError, PurchaseReport]] = {

    val report = mayBeCategory match {
      case Some(category) => getSpecificCategoryReport(companyId,projectId,name,startDate,endDate,category,onlyOfficeData)
      case None => getGenericReport(companyId,projectId,name,startDate,endDate,onlyOfficeData)
    }

    report.map(r => {
      val chartData = Try(createChartData(projectId,r)).toOption.flatten
      Right(r.copy(chartData = chartData))
    }).handleExceptionWithLog
  }

  def getSpecificCategoryReport(companyId:Int,projectId: Option[Int],name: String,
                                startDate:Option[String],endDate:Option[String],
                                category: String,onlyOfficeData:Boolean) = {

    for{
      purchases <- getInvoiceReportDb(category)
                   .getPurchaseReportReport(companyId,projectId,name,startDate,endDate,Some(category),onlyOfficeData)
    } yield PurchaseReport.createPurchaseReport(purchases)
  }


  def getGenericReport(companyId:Int,projectId: Option[Int],name: String,
                       startDate:Option[String],endDate:Option[String],onlyOfficeData:Boolean) = {
    val contractorPR = contractorInvoicesDb
                        .getPurchaseReportReport(companyId,projectId,name,startDate,endDate,None,onlyOfficeData)

    val supplierPR = supplierInvoicesDb
                        .getPurchaseReportReport(companyId,projectId,name,startDate,endDate,None,onlyOfficeData)

    val consultantPR = consultantInvoicesDB
                        .getPurchaseReportReport(companyId,projectId,name,startDate,endDate,None,onlyOfficeData)

    val otherPR = otherInvoicesDb
                        .getPurchaseReportReport(companyId,projectId,name,startDate,endDate,None,onlyOfficeData)

    for{
      contractor <- contractorPR
      supplier <- supplierPR
      consultant <- consultantPR
      other <- otherPR
    }yield {
      val all = contractor ++ supplier ++ consultant ++ other
      PurchaseReport.createPurchaseReport(all)
    }
  }

  def createChartData(projectId: Option[Int],report: PurchaseReport) = {

    if(report.purchases.isEmpty)
      None
    else{
      projectId match {
        case Some(p) => {
          Some(projectChatDataService.createProjectLevelChartData(report.purchases.map(p => ChartRawDataForProject.createChartRawData(
            p.category,p.invoiceDate,p.totalAmount)).toList))
        }
        case None => Some(companyChatDataService.createAllCompanyLevelChartData(report.purchases.map(p => ChartRawDataForCompany.createChartRawData(
          p.projectName,p.invoiceDate,p.totalAmount)).toList))
      }
    }
  }

  def generateExcelReport(entity : PurchaseReport):Path = {

    val rows: Seq[Row] = entity.purchases.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.projectName,e.name,e.description,e.category,e.invoiceNumber,
        e.invoiceDate,e.grossTotal,e.cgst,e.sgst,e.totalAmount))
    }
    val totals = Row(List("","Total","","","","","",entity.grossTotal,entity.cgst,entity.sgst,entity.totalAmount),GreyBackground)

    val headings = List("Sr. No.","Project Name","Name","Description","Category","Invoice No.",
      "Invoice Date","Taxable Value","CGST","SGST","Total Amount")

    val table = Table(None,headings,(rows :+ totals).toList)

    val columnWidths = Map(0 -> 8,1 -> 16,2 -> 25,3 -> 35)
    val report = ExcelReport("Purchase Report",List(table),columnWidths)

    excelReportService.printReport(report,"purchase_report.xlsx")
  }
}

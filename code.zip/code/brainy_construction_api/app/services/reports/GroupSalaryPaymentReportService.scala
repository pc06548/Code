package services.reports

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.reports._
import services.LoggerService
import services.db.employee.PayslipVoucherDbUpdator

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class GroupSalaryPaymentReportService @Inject()(payslipVoucherDbUpdator: PayslipVoucherDbUpdator)extends LoggerService {


  def getReport(companyId: Int, paymentReference: Option[String],
                paymentDate: Option[String]): Future[Either[ServerError, Option[GroupSalaryPayment]]] = {

    val data: Future[List[GroupSalaryPaymentData]] = payslipVoucherDbUpdator.getGroupSalaryPaymentData(companyId,paymentReference,paymentDate)

    val groupStatement = data.map(payments => {
      payments.groupBy(payment => (payment.paymentRefNumber,payment.paymentDate,payment.mode,payment.voucherDate))
              .map{
                  case (paymentDetails,employees) => GroupSalaryPayment(
                    paymentDetails._1,paymentDetails._2,paymentDetails._3,paymentDetails._4,
                    getEmployeeDetails(employees),
                    employees.map(_.totalAmount).sum
                  )
              }
      }.toList.headOption)

    groupStatement.map(Right(_)).handleExceptionWithLog
  }

  def getEmployeeDetails(groupSalaryPaymentData: Seq[GroupSalaryPaymentData]) : Seq[EmployeeDetails] = {
    for(e <- groupSalaryPaymentData)yield {
      EmployeeDetails(e.employeeName,e.bankName,e.bankAddress,e.bankAccountNumber,e.ifscCode,
        e.phoneNumber,e.panNumber,e.aadharNumber,e.totalAmount,e.content)
    }
  }

}

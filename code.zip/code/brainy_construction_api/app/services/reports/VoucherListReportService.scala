package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.reports._
import model.vouchers.Voucher
import services.LoggerService
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try

class VoucherListReportService @Inject()(reportService: VoucherReportService,
                                         excelReportService: ExcelReportService,
                                         companyChatDataService: CompanyChartDataService,
                                         projectChatDataService: ProjectChartDataService)extends LoggerService {

  import reportService._

  def getReport(companyId:Int,projectId: Option[Int],name: Option[String],
                startDate:Option[String],endDate:Option[String],
                mayBeCategory: Option[String],modeOfPayment:Option[String],
                sortBy:Option[String],onlyOfficeData:Boolean): Future[Either[ServerError, VoucherListReport]] = {

    val eventualVouchers: Future[List[Voucher]] = mayBeCategory match {
      case Some(category) => getSpecificCategoryReport(companyId,projectId,name,startDate,endDate,category,modeOfPayment,sortBy,onlyOfficeData)
      case None => getGenericReport(companyId,projectId,name,startDate,endDate,modeOfPayment,sortBy,onlyOfficeData)
    }
    eventualVouchers.map(vouchers => {
      val r = VoucherListReport(vouchers)
      val chartData = Try(createChartData(projectId,r)).toOption.flatten
      Right(r.copy(chartData = chartData))
    }).handleExceptionWithLog
  }

  def getSpecificCategoryReport(companyId:Int,projectId: Option[Int],name: Option[String],
                                startDate:Option[String],endDate:Option[String],
                                category: String,modeOfPayment:Option[String],sortBy:Option[String],onlyOfficeData:Boolean) = {

    getVoucherReportDb(category)
      .getVouchers(companyId,name,projectId,startDate,endDate,Some(category),modeOfPayment,sortBy,onlyOfficeData)
  }


  def getGenericReport(companyId:Int,projectId: Option[Int],name: Option[String],
                       startDate:Option[String],endDate:Option[String],
                       modeOfPayment:Option[String],sortBy:Option[String],onlyOfficeData:Boolean) = {
    val contractorPR = contractorVouchersDb
      .getVouchers(companyId,name,projectId,startDate,endDate,None,modeOfPayment,sortBy,onlyOfficeData)

    val supplierPR = supplierVouchersDb
      .getVouchers(companyId,name,projectId,startDate,endDate,None,modeOfPayment,sortBy,onlyOfficeData)

    val consultantPR = consultantVouchersDB
      .getVouchers(companyId,name,projectId,startDate,endDate,None,modeOfPayment,sortBy,onlyOfficeData)

    val otherPR = otherVouchersDb
      .getVouchers(companyId,name,projectId,startDate,endDate,None,modeOfPayment,sortBy,onlyOfficeData)

    for{
      contractor <- contractorPR
      supplier <- supplierPR
      consultant <- consultantPR
      other <- otherPR
    }yield contractor ++ supplier ++ consultant ++ other

  }


  def getVoucherDetails(accountSummaryData: Seq[AccountSummaryData]) : Seq[VoucherDetails] = {
    for(acc <- accountSummaryData)yield {
      VoucherDetails(acc.content,acc.voucherNumber,acc.totalAmount,acc.tds,acc.chequeNumber,acc.chequeDate)
    }
  }

  def generateExcelReport(entity : List[Voucher]):Path = {

    val rows: Seq[Row] = entity.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.projectName,e.category,e.invoiceDetails.name,e.reason,e.voucherNumber,e.voucherDate,e.totalAmount))
    }

    val headings = List("Sr. No.","Project Name","Category","Name","Reason","Voucher No.",
      "Voucher Date","Total Amount")

    val totals = Row(List("","","","Total","","","",entity.map(_.totalAmount).sum),GreyBackground)

    val table = Table(None,headings,(rows :+ totals).toList)

    val columnWidths = Map(0 -> 8,1 -> 30,2 -> 16,3 -> 25,4 -> 35,5 -> 16)
    val report = ExcelReport("Voucher Report",List(table),columnWidths,List(0,1,2,3))

    excelReportService.printReport(report,"voucher_report.xlsx")
  }

  def createChartData(projectId: Option[Int],report: VoucherListReport) = {

    if(report.vouchers.isEmpty)
      None
    else{
      projectId match {
        case Some(p) => {
          Some(projectChatDataService.createProjectLevelChartData(report.vouchers.map(p => ChartRawDataForProject.createChartRawData(
            p.category,p.paymentDetails.paymentDate,p.totalAmount))))
        }
        case None => Some(companyChatDataService.createAllCompanyLevelChartData(report.vouchers.map(p => ChartRawDataForCompany.createChartRawData(
          p.projectName,p.paymentDetails.paymentDate,p.totalAmount))))
      }
    }
  }
}

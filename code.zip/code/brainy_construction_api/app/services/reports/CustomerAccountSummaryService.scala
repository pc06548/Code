package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.customer.CustomerAccountSummary
import model.reports._
import services.LoggerService
import services.db.customer.{CustomerDbUpdater, ReceiptDbUpdater}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class CustomerAccountSummaryService @Inject()(receiptDbUpdator: ReceiptDbUpdater,
                                              customerDbUpdater: CustomerDbUpdater,
                                              excelReportService: ExcelReportService) extends LoggerService{


  def getReport(companyId:Int,projectId: Int,customerId:Int): Future[Either[ServerError, CustomerAccountSummary]] = {

    val evetualCustomer = customerDbUpdater.getById(projectId,customerId)
    val eventualDetails = customerDbUpdater.getCoOwners(customerId)
    val eventualData = receiptDbUpdator.getAccountSummaryData(companyId, projectId,customerId)

    val report = for{
      data <- eventualData
      c <- evetualCustomer
      details <- eventualDetails
    }yield CustomerAccountSummary(c.map(_.copy(coOwners = Option(details))),data)

    report.map(Right(_)).handleExceptionWithLog
  }

  def generateExcelReport(entity : CustomerAccountSummary):Path = {

    val rows: Seq[Row] = entity.details.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.receiptNumber,e.dateCreated,e.content,e.amount,
        e.cgst,e.sgst,e.totalAmount,e.mode,e.paymentRefNumber.getOrElse("-"),e.paymentDate))
    }

    val headings = List("Sr. No.","Receipt no.","Receipt Date","Details","Installment Amount","CGST",
      "SGST","Net Amount","Mode","Cheque/NEFT No","Cheque/NEFT Date")

    val totals = Row(List("","","","Total",
      entity.details.map(_.amount).sum,
      entity.details.map(_.cgst).sum,
      entity.details.map(_.sgst).sum,
      entity.details.map(_.totalAmount).sum,
      "","",""),GreyBackground)

    val table = Table(None,headings,(rows :+ totals).toList)

    val columnWidths = Map(0 -> 8,1 -> 15,2 -> 16,3 -> 40)

    val report = ExcelReport("Customer Account Summary",List(table),columnWidths)

    excelReportService.printReport(report,"customer_account_summary.xlsx")
  }
}

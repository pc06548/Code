package services.reports


import java.nio.file.Path

import config.DateUtil
import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.Category
import model.customer.CustomerAccountSummary
import model.reports._
import services.LoggerService
import services.db.employee.{LoanDbUpdator, PayslipVoucherDbUpdator}
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try

class AccountSummaryService @Inject()(reportService: VoucherReportService,
                                      payslipVoucherDbUpdator: PayslipVoucherDbUpdator,
                                      loanDbUpdator: LoanDbUpdator,
                                      excelReportService: ExcelReportService,
                                      companyChatDataService: CompanyChartDataService,
                                      projectChatDataService: ProjectChartDataService)extends LoggerService {

  import reportService._

  def getReport(companyId:Int,projectId: Option[Int],name: Option[String],
                startDate:Option[String],endDate:Option[String],
                mayBeCategory: Option[String],onlyOfficeData:Boolean): Future[Either[ServerError, AccountSummary]] = {

    val eventualVouchers: Future[List[AccountSummaryData]] = mayBeCategory match {
      case Some(category) => getSpecificCategoryReport(companyId,projectId,name.getOrElse(""),startDate,endDate,category,onlyOfficeData)
      case None => getGenericReport(companyId,projectId,name.getOrElse(""),startDate,endDate,onlyOfficeData)
    }

    val accountSummary = eventualVouchers.map(vouchers => {
      vouchers.groupBy(
        summaryData => (summaryData.projectName,summaryData.name,summaryData.category,
        summaryData.invoiceNumber,summaryData.invoiceDate,summaryData.invoiceAmount,summaryData.basicAmount,summaryData.cgst,
        summaryData.sgst,summaryData.documentRefNumber,summaryData.isTemporary)
      ).map(
        v => {
          val description = v._2.headOption.map(_.content).getOrElse("")
          AccountSummaryDetails(v._1._1,v._1._2,v._1._3,description,v._1._4,v._1._5,v._1._6,v._1._7,v._1._8,v._1._9,v._1._10,v._1._11,
            getVoucherDetails(v._2))
        }
      ).toList.sortBy(voucher => DateUtil.getDateFromString(voucher.vouchers(0).chequeDate).getTime)
    })
    accountSummary.map(Right(_)).handleExceptionWithLog

    accountSummary.map(summaries => {
      val report = AccountSummary(summaries)
      val chartData = Try(createChartData(projectId,report,mayBeCategory,name)).toOption.flatten
      Right(report.copy(chartData = chartData))
    }).handleExceptionWithLog
  }

  def getSpecificCategoryReport(companyId:Int,projectId: Option[Int],name: String,
                                startDate:Option[String],endDate:Option[String],
                                category: String,onlyOfficeData:Boolean) = {

    category match {
      case Category.employee => getEmployeeAccountSummary(companyId,name,startDate,endDate)
      case _ => getVoucherReportDb(category)
        .getAccountSummaryData(companyId,projectId,name,startDate,endDate,Some(category),onlyOfficeData)
    }

  }

  private def getEmployeeAccountSummary(companyId:Int,name: String,startDate:Option[String],endDate:Option[String]) = {
    for{
      payslips <- payslipVoucherDbUpdator.getAccountSummaryData(companyId,name,startDate,endDate)
      loans <- loanDbUpdator.getAccountSummaryData(companyId,name,startDate,endDate)
    }yield payslips ::: loans
  }

  def getGenericReport(companyId:Int,projectId: Option[Int],name: String,
                       startDate:Option[String],endDate:Option[String],onlyOfficeData:Boolean) = {
    val contractorPR = contractorVouchersDb
      .getAccountSummaryData(companyId,projectId,name,startDate,endDate,None,onlyOfficeData)

    val supplierPR = supplierVouchersDb
      .getAccountSummaryData(companyId,projectId,name,startDate,endDate,None,onlyOfficeData)

    val consultantPR = consultantVouchersDB
      .getAccountSummaryData(companyId,projectId,name,startDate,endDate,None,onlyOfficeData)

    val otherPR = otherVouchersDb
      .getAccountSummaryData(companyId,projectId,name,startDate,endDate,None,onlyOfficeData)

    for{
      contractor <- contractorPR
      supplier <- supplierPR
      consultant <- consultantPR
      other <- otherPR
    }yield contractor ++ supplier ++ consultant ++ other

  }


  def getVoucherDetails(accountSummaryData: Seq[AccountSummaryData]) : Seq[VoucherDetails] = {
    for(acc <- accountSummaryData)yield {
      VoucherDetails(acc.content,acc.voucherNumber,acc.totalAmount,acc.tds,acc.chequeNumber,acc.chequeDate)
    }
  }

  def generateExcelReport(entities : List[AccountSummaryDetails]):Path = {

    val rows: Seq[Row] = entities.zipWithIndex.flatMap{
      case (e,i) => {
        e.vouchers.map(d => {
          Row(List(i+1,e.projectName,e.category,e.description,e.invoiceNumber,e.invoiceDate,e.basicAmount,e.cgst,e.sgst,
            e.invoiceAmount,d.tds,d.totalAmount,d.chequeNumber,d.chequeDate,d.voucherNumber))
        })
      }
    }

    val headings = List("Sr. No.","Project Name","Category","Description","Invoice Number","Invoice date","Basic Amount","CGST",
      "SGST","Invoice Amount","TDS","Released Amount","Cheque/NEFT Date","Cheque Date","Voucher Number")

    val totals = Row(List("","","","Total","","",
      entities.map(_.basicAmount).sum,
      entities.map(_.cgst).sum,
      entities.map(_.sgst).sum,
      entities.map(_.invoiceAmount).sum,
      entities.flatMap(_.vouchers.map(_.tds)).sum,
      entities.flatMap(_.vouchers.map(_.totalAmount)).sum,
      "","",""),GreyBackground)

    val table = Table(None,headings,(rows :+ totals).toList)

    val columnWidths = Map(0 -> 8,1 -> 15,2 -> 16,3 -> 40,4 -> 16,12 -> 16,13 -> 15,14 -> 17)

    val report = ExcelReport("Account Summary",List(table),columnWidths,List(0,1,2,3,4,5,6,7,8,9))

    excelReportService.printReport(report,"account_summary.xlsx")
  }

  def createChartData(projectId: Option[Int],report: AccountSummary,category: Option[String],name:Option[String]) = {

    if(report.details.isEmpty)
      None
    else{
      (category,projectId,name) match {
        case (Some(Category.employee),None,None) => Some(companyChatDataService.createAllCompanyLevelChartData(
          report.details.flatMap(p => {
            p.vouchers.map(r => {
              ChartRawDataForCompany.createChartRawData(
                p.name,r.chequeDate,r.totalAmount)
            })
          })
        ))
        case (Some(Category.employee),None,Some(_)) => Some(companyChatDataService.createAllCompanyLevelChartData(
          report.details.flatMap(p => {
            p.vouchers.map(r => {
              ChartRawDataForCompany.createChartRawData(
                p.name,r.chequeDate,r.totalAmount)
            })
          })
        ).copy(doughnutCharts = List.empty[DoughnutChart]))
        case (_,Some(p),_) => {
          Some(projectChatDataService.createProjectLevelChartData(report.details.flatMap(p => {
            p.vouchers.map(r => {
              ChartRawDataForProject.createChartRawData(
                p.category,r.chequeDate,r.totalAmount)
            })
          })))
        }
        case (_,None,_) => Some(companyChatDataService.createAllCompanyLevelChartData(
          report.details.flatMap(p => {
            p.vouchers.map(r => {
              ChartRawDataForCompany.createChartRawData(
                p.projectName,r.chequeDate,r.totalAmount)
            })
          })
        ))
      }
    }
  }
}

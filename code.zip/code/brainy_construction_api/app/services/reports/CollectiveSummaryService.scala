package services.reports

import java.nio.file.Path

import exceptions.{RuntimeException, ServerError}
import javax.inject._
import model.Category
import model.reports._
import services.LoggerService
import services.reports.charts.{CompanyChartDataService, ProjectChartDataService}
import services.reports.excel.ExcelReportService

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.Try

class CollectiveSummaryService @Inject()(reportService: VoucherReportService,
                                         excelReportService: ExcelReportService) extends LoggerService{

  import reportService._

  def getReport(companyId:Int,projectId: Option[Int],
                       startDate:Option[String],endDate:Option[String],onlyOfficeData:Boolean): Future[Either[ServerError, CollectiveSummary]] = {
    val contractorPR = contractorVouchersDb
      .getCollectiveSummaryData(companyId,projectId,startDate,endDate,onlyOfficeData)

    val supplierPR = supplierVouchersDb
      .getCollectiveSummaryData(companyId,projectId,startDate,endDate,onlyOfficeData)

    val consultantPR = consultantVouchersDB
      .getCollectiveSummaryData(companyId,projectId,startDate,endDate,onlyOfficeData)

    val otherPR = otherVouchersDb
      .getCollectiveSummaryData(companyId,projectId,startDate,endDate,onlyOfficeData)

    val collectiveSummary = for{
      contractor <- contractorPR
      supplier <- supplierPR
      consultant <- consultantPR
      other <- otherPR
    }yield {
      val allSummary = other :+ CollectiveSummaryData.createSummaryFromList(contractor,Category.contractor,projectId) :+
        CollectiveSummaryData.createSummaryFromList(supplier,Category.supplier,projectId) :+
        CollectiveSummaryData.createSummaryFromList(consultant,Category.consultant,projectId)
        CollectiveSummary.createFromData(contractor,supplier,consultant,allSummary)
    }

    collectiveSummary.map(r => {
      val chartData = Try(createChartData(projectId,r)).toOption.flatten
      Right(r.copy(chartData = chartData))
    }).handleExceptionWithLog
  }

  def generateExcelReport(entity : CollectiveSummary) : Path = {
    val contractortableRows = entity.contractors.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.name,e.projectName,e.amount,e.department))
    }

    val contractortableTotals = Row(List("","Total","",entity.contractors.map(_.amount).sum,""),GreyBackground)

    val contractorSummayTable = Table(Some("Contractors Collective Summery / Total Incurred Cost on Contractor"),
      List("Sr. No.","Name","Project Name","Amount","Department"),(contractortableRows :+ contractortableTotals).toList)

    val suppliertableRows = entity.suppliers.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.name,e.projectName,e.amount,e.department))
    }

    val suppliertableTotals = Row(List("","Total","",entity.suppliers.map(_.amount).sum,""),GreyBackground)

    val supplierSummayTable = Table(Some("Suppliers Collective Summery/ Total Incurred Cost on Suppliers"),
      List("Sr. No.","Name","Project Name","Amount","Supplier type"),(suppliertableRows :+ suppliertableTotals).toList)

    val consultanttableRows = entity.consultants.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.name,e.projectName,e.amount))
    }
    val consultanttableTotals = Row(List("","Total","",entity.consultants.map(_.amount).sum),GreyBackground)

    val consultantSummayTable = Table(Some("Consultant Collective Summery/ Total Incurred Cost on Consultant"),
      List("Sr. No.","Name","Project Name","Amount"),(consultanttableRows :+ consultanttableTotals).toList)

    val categorytableRows = entity.categorySummary.zipWithIndex.map{
      case (e,i) => Row(List(i+1,e.name,e.projectName,e.amount))
    }
    val categorytableTotals = Row(List("","Total","",entity.categorySummary.map(_.amount).sum),GreyBackground)

    val categorySummayTable = Table(Some("Total Project Incured Cost Summery by category"),
      List("Sr. No.","Name","Project Name","Amount"),(categorytableRows :+ categorytableTotals).toList)


    val columnWidths = Map(0 -> 8,1 -> 35,2 -> 17, 3-> 17,4 -> 20)
    val report = ExcelReport("Collective Summary",
      List(contractorSummayTable,supplierSummayTable,consultantSummayTable,categorySummayTable),
      columnWidths,List(0,1))

    excelReportService.printReport(report,"collective_summary.xlsx")
  }

  def createChartData(projectId: Option[Int],report: CollectiveSummary) = {

    if(report.categorySummary.isEmpty)
      None
    else{
      projectId match {
        case Some(p) => {
          val pie = DoughnutChart("Project Report",
            report.categorySummary.map(_.name).toList,
            List(DoughnutChartDataSet(report.categorySummary.map(_.amount).toList)))
          Some(ChartData(List.empty[StackedBarChart],List(pie)))
        }
        case None => None
      }
    }
  }
}

package services.customer

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model.EntityId
import model.customer.{ExtraWorkReceipt, ExtraWorkReceiptSearch}
import services.LoggerService
import services.db.CompanyDbUpdator
import services.db.customer.ExtraWorkReceiptDbUpdater

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class ExtraWorkReceiptService @Inject()(extraWorkReceiptDbUpdator: ExtraWorkReceiptDbUpdater,
                                        companyDbUpdator: CompanyDbUpdator)extends LoggerService {

  def saveExtraWorkReceipt(companyId:Int,receipt: ExtraWorkReceipt): Future[Either[ServerError, EntityId]] = {

    extraWorkReceiptDbUpdator.createExtraWorkReceipt(companyId,receipt)
    .map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def getExtraWorkReceipt(id: Int): Future[Either[ServerError, Option[ExtraWorkReceipt]]] = {

    val evetualExtraWorkReceipt = extraWorkReceiptDbUpdator.getById(id)
    val eventualDetials = extraWorkReceiptDbUpdator.getDetails(id)

    val receipt = for{
      invoice <- evetualExtraWorkReceipt
      details <- eventualDetials
    }yield invoice.map(_.copy(details = details))

    receipt.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }

  }

  def searchExtraWorkReceipts(companyId:Int,projectId:Int,name: Option[String],
                              startDate:Option[String],endDate:Option[String],
                              isTemporary:Option[Boolean],receiptNumber:Option[String]):Future[Either[ServerError, List[ExtraWorkReceiptSearch]]]  = {
    extraWorkReceiptDbUpdator.searchExtraWorkReceipts(companyId,projectId,name,startDate,endDate,isTemporary,receiptNumber).map(Right(_)).handleExceptionWithLog
  }

  def deleteExtraWorkReceipt(id: Int): Future[Either[ServerError, Int]] =  {
    extraWorkReceiptDbUpdator.delete(id).map(Right(_)).handleExceptionWithLog
  }
}

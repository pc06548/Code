package services.customer

import exceptions.{IDGenerationFailed, RuntimeException, ServerError}
import javax.inject._
import model._
import model.customer.SaveExtraWorkInvoice
import services.LoggerService
import services.db.customer.{ExtraWorkInvoiceDbUpdater, ExtraWorkReceiptDbUpdater, ReceiptDbUpdater}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future

class ExtraWorkInvoiceService @Inject()(extraWorkInvoiceDbUpdater: ExtraWorkInvoiceDbUpdater,
                                        receiptDbUpdater: ExtraWorkReceiptDbUpdater) extends LoggerService{

  def saveInvoice(invoice: SaveExtraWorkInvoice): Future[Either[ServerError, EntityId]] = {

    val newEntityId = extraWorkInvoiceDbUpdater.createInvoice(invoice).flatMap(
      newInvoiceId => {
        val updatedDetails = invoice.details.map(_.copy(invoiceId = newInvoiceId))
        extraWorkInvoiceDbUpdater.saveDetails(updatedDetails).map(_ => newInvoiceId)
      })
    newEntityId.map(id => id match {
      case Some(id) => Right(EntityId(id))
      case None     => Left(IDGenerationFailed())
    }).handleExceptionWithLog
  }

  def updateInvoice(invoice: SaveExtraWorkInvoice) = {
    val updateRes = for{
      _ <- extraWorkInvoiceDbUpdater.updateDetails(invoice.details)
      update <- extraWorkInvoiceDbUpdater.updateInvoice(invoice)
    }yield update
    updateRes.map(Right(_)).handleExceptionWithLog
  }

  def getInvoice(companyId: Int,id: Int): Future[Either[ServerError, Option[SaveExtraWorkInvoice]]] = {
    val evetualInvoice = extraWorkInvoiceDbUpdater.getById(companyId,id)
    val eventualAmountPaid = receiptDbUpdater.getAmountReceivedForExtraInvoice(id)
    val eventualDetials = extraWorkInvoiceDbUpdater.getDetails(id)

    val invoice = for{
      invoice <- evetualInvoice
      amountPaid <- eventualAmountPaid
      details <- eventualDetials
    }yield invoice.map(_.copy(details = details, amountPaid = Some(amountPaid)))

    invoice.map(c => c match {
      case Some(entity) => Right(Some(entity))
      case None => Right(None)
    }).recover{
      case e: Exception => Left(RuntimeException(e))
    }
  }

  def searchInvoice(name: String,projectId: Int,status : String,
                    startDate:Option[String],endDate:Option[String],
                    isTemporary:Option[Boolean],invoiceNumber:Option[String]) = {

    extraWorkInvoiceDbUpdater.searchInvoices(name,projectId,status,startDate,endDate,isTemporary,invoiceNumber).map(Right(_)).handleExceptionWithLog
  }

  def deleteInvoice(companyId: Int,id: Int): Future[Either[ServerError, Int]] =  {
    extraWorkInvoiceDbUpdater.deleteInvoice(id,companyId).map(Right(_)).handleExceptionWithLog
  }

  def deleteDetail(invoiceId : Int,id: Int): Future[Either[ServerError, Int]] = {
    extraWorkInvoiceDbUpdater.deleteInvoiceDetail(invoiceId,id).map(Right(_)).recover {
      case e: Throwable => Left(RuntimeException(e))
    }
  }
  
}

package controllers

import java.util.Date

import auth.db.AuthInfoExtractorDb
import play.api.mvc.ControllerComponents
import auth.services.{AuthService, BatWithLoginToken}
import controllers.contractor.ContractorController
import model.LoginToken
import org.mockito.Mockito.{verify, when}
import org.mockito.internal.verification.Times
import org.scalatest.concurrent.ScalaFutures
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import org.scalatestplus.play.guice.GuiceOneAppPerSuite
import play.api.http.HeaderNames
import play.api.libs.json.Json
import play.api.test.FakeRequest
import play.api.test.Helpers._
import services.ContractorService

import scala.concurrent.Future

class ContractorControllerTest extends PlaySpec with MockitoSugar with ScalaFutures with GuiceOneAppPerSuite {

  val mockContractorService = mock[ContractorService]
  val mockAuthService = mock[AuthService]
  val mockAuthInfoExtractor = mock[AuthInfoExtractorDb]
  val contractorController = new ContractorController(mockContractorService, mockAuthService, mockAuthInfoExtractor, stubControllerComponents())
  val validToken = "valid"
  val batWithLoginToken = BatWithLoginToken("bat", LoginToken(1, validToken, new Date()))
  val inValidToken = "invalid"
   "Contractor Controller" should {

    "Authenticate" when {
      "auth and process request successfully" in {
        /*when(mockAuthService.auth(validToken)).thenReturn(Some(batWithLoginToken))
        when(mockContractorService.getContractor(1, 1)).thenReturn(Future.successful(Some(Json.parse("{}"))))

        val result = route(app,FakeRequest("GET", "/api/v1/companies/1/contractors/1").withHeaders((HeaderNames.AUTHORIZATION, validToken)))

        result.map(status(_)) mustBe Some(OK)*/
      }

      "should fail auth for invalid token" in {
        /*when(mockAuthService.auth(inValidToken)).thenReturn(None)
        val result = route(app,FakeRequest("GET", "/api/v1/companies/1/contractors/1").withHeaders((HeaderNames.AUTHORIZATION, inValidToken)))
        result.map(status(_)) mustBe Some(UNAUTHORIZED)
        verify(mockContractorService, new Times(0)).getContractor(1)*/
      }

      "should fail auth for no token" in {
        /*when(mockAuthService.auth(inValidToken)).thenReturn(None)
        val result = route(app,FakeRequest("GET", "/api/v1/companies/1/contractors/1"))
        result.map(status(_)) mustBe Some(NOT_FOUND)
        verify(mockContractorService, new Times(0)).getContractor(1)*/

      }
    }

  }
}

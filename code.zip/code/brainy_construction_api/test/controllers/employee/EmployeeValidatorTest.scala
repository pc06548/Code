package controllers.employee

import controllers.employee.validators.EmployeeValidator
import exceptions.NoJsonBodyFound
import org.scalatest.{BeforeAndAfterAll, BeforeAndAfterEach}
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import org.scalatestplus.play.guice.GuiceOneAppPerSuite
import play.api.libs.json.Json

class EmployeeValidatorTest extends PlaySpec with GuiceOneAppPerSuite with MockitoSugar with BeforeAndAfterAll with BeforeAndAfterEach {

  val validator = new EmployeeValidator {}
  "EmployeeValidatorTest" when {
    "should test empty json" in {
      assert(validator.validateCreateEmployeeRequest(None).left.get == NoJsonBodyFound())
    }
  }
}

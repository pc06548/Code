package integration.util

object TestDbHelper {
  def cleanUpTables() = {
    DatabaseUpdatorServiceTestInstance.get.runInsertOrUpdate(
      """
        |TRUNCATE ORG, USERS, LOGIN, LOGIN_TOKEN, ROLE CASCADE;
      """.stripMargin
    )
  }
}

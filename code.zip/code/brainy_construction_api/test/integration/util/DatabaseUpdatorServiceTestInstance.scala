package integration.util

import java.io.File

import play.api.{Environment, Mode}
import services.db.DatabaseUpdatorService

object DatabaseUpdatorServiceTestInstance {
  val classLoader: ClassLoader = classLoader
  def get =
    new DatabaseUpdatorService(environment = new Environment(new File("."), classLoader, Mode.Test))
}

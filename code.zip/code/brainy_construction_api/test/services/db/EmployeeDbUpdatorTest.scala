//
//import auth.db.{LoginDb, OrgDb, RoleDb, UserDb}
//import config.DateHelper
//import integration.util.{DatabaseUpdatorServiceTestInstance, TestDbHelper}
//import model._
//import model.company.Company
//import model.employee.Employee
//import org.scalatest.{BeforeAndAfterAll, BeforeAndAfterEach}
//import org.scalatestplus.mockito.MockitoSugar
//import org.scalatestplus.play.PlaySpec
//import org.scalatestplus.play.guice.GuiceOneAppPerSuite
//import play.api.test.Helpers._
//import services.db.employee.EmployeeDbUpdator
//import services.db.{CompanyDbUpdator, EmployeeDbUpdator}
//
//import scala.concurrent.Await
//import scala.concurrent.duration._
//
//class EmployeeDbUpdatorTest extends PlaySpec with GuiceOneAppPerSuite with MockitoSugar with BeforeAndAfterAll with BeforeAndAfterEach {
//
//  val roleDb = new RoleDb(DatabaseUpdatorServiceTestInstance.get)
//  val orgDb = new OrgDb(DatabaseUpdatorServiceTestInstance.get)
//  val userDb = new UserDb(DatabaseUpdatorServiceTestInstance.get)
//  val loginDb = new LoginDb(DatabaseUpdatorServiceTestInstance.get)
//  val employeeDb = app.injector.instanceOf[EmployeeDbUpdator]
//  val companyDb = app.injector.instanceOf[CompanyDbUpdator]
//
//  //implicit val timeout = Timeout(5 seconds)
//
//  override def afterAll():Unit = {
//    TestDbHelper.cleanUpTables()
//  }
//
//  "EmployeeDbUpdatorTest" when {
//    "perform employee operations" in {
//      val date = DateHelper.nowSqlDate
//      val org = Org(None, "Org1", date, date)
//      val actualOrgId = orgDb.createAndGetOrgId(org)
//      val company = Company(Some(1), "Company1", Some(actualOrgId), "", Some(""), "", Some(""), Some(""), Some(""), Some(date.toString), Some(date.toString))
//      val actualCompanyId: Int = Await.result(companyDb.createCompanyAndGetCompanyId(company), 1.minutes).get
//      val actualUserId: Int = userDb.create("prashant", "9999999999", "test@test.com")
//      val employeeToCreate = Employee(userId = actualUserId, companyId = actualCompanyId,  createTimestamp = date, updateTimestamp = date)
//
//      // create employee with less details
//      await(employeeDb.createEmployeeAndGetEmployeeId(employeeToCreate))
//      val employeeCreated = await(employeeDb.getEmployeeByUserIdAndCompanyId(actualUserId, actualCompanyId)).get
//      employeeCreated.userId must be (actualUserId)
//      employeeCreated.companyId must be (actualCompanyId)
//      employeeCreated.address must be (None)
//      employeeCreated.designation must be (None)
//      employeeCreated.department must be (None)
//      employeeCreated.pfNumber must be (None)
//      employeeCreated.panNumber must be (None)
//      employeeCreated.aadharNumber must be (None)
//      employeeCreated.joiningDate must be (None)
//      employeeCreated.bankDetails must be (None)
//      employeeCreated.activeUntil must be (DateHelper.endOfTimeString)
//
//
//      // create employee with full details
//      val company2 = Company(Some(1), "Company1", Some(actualOrgId), "", Some(""), "", Some(""), Some(""), Some(""), Some(date.toString), Some(date.toString))
//      val actualCompanyId2: Int = Await.result(companyDb.createCompanyAndGetCompanyId(company2), 1.minutes).get
//      val actualUserId2: Int = userDb.create("prashant2", "9999999999", "test@test.com")
//
//      val employeeDetailedToCreate = Employee(actualUserId2, actualCompanyId2, Some("adr1"), Some("desig"), Some("dept"), Some("pfNum"), Some("pan1"), Some("adh1"), Some("joinDate1"),
//        Some(BankDetails(("acNum"), "ifsc", "bankName", "bankAdr")), "endDate1",  date, date)
//      await(employeeDb.createEmployeeAndGetEmployeeId(employeeDetailedToCreate))
//      val employeeDetailedCreated = await(employeeDb.getEmployeeByUserIdAndCompanyId(actualUserId2, actualCompanyId2)).get
//      employeeDetailedCreated.userId must be (actualUserId2)
//      employeeDetailedCreated.companyId must be (actualCompanyId2)
//      employeeDetailedCreated.address.get must be ("adr1")
//      employeeDetailedCreated.designation.get must be ("desig")
//      employeeDetailedCreated.department.get must be ("dept")
//      employeeDetailedCreated.pfNumber.get must be ("pfNum")
//      employeeDetailedCreated.panNumber.get must be ("pan1")
//      employeeDetailedCreated.aadharNumber.get must be ("adh1")
//      employeeDetailedCreated.joiningDate.get must be ("joinDate1")
//      employeeDetailedCreated.bankDetails.get must be (BankDetails("acNum", "ifsc", "bankName", "bankAdr"))
//      employeeDetailedCreated.activeUntil must be ("endDate1")
//
//      // update
//      val employeeToUpdate = employeeDetailedCreated.copy(activeUntil = DateHelper.endOfTimeString, bankDetails = Some(BankDetails("ac2", "ifsc2", "bn2", "ba2")), joiningDate = None)
//      await(employeeDb.updateEmployee(employeeToUpdate))
//
//      val employeeUpdated = await(employeeDb.getEmployeeByUserIdAndCompanyId(actualUserId2, actualCompanyId2)).get
//      employeeUpdated.userId must be (actualUserId2)
//      employeeUpdated.companyId must be (actualCompanyId2)
//      employeeUpdated.address.get must be ("adr1")
//      employeeUpdated.designation.get must be ("desig")
//      employeeUpdated.department.get must be ("dept")
//      employeeUpdated.pfNumber.get must be ("pfNum")
//      employeeUpdated.panNumber.get must be ("pan1")
//      employeeUpdated.aadharNumber.get must be ("adh1")
//      employeeUpdated.joiningDate must be (None)
//      employeeUpdated.bankDetails.get must be (BankDetails("ac2", "ifsc2", "bn2", "ba2"))
//      employeeUpdated.activeUntil must be (DateHelper.endOfTimeString)
//
//      // get employee by company id
//      val employees: Seq[Employee] = await(employeeDb.getEmployeeByCompanyIds(List(actualCompanyId, actualCompanyId2)))
//
//      employees.size must be (2)
//      employees(0).userId must be (actualUserId)
//      employees(1).userId must be (actualUserId2)
//
//      // changing one employee to another company should not be possible
//      val employeeWithChangeCompany = employeeToUpdate.copy(companyId = actualCompanyId)
//      intercept[Exception] {
//        await(employeeDb.updateEmployee(employeeWithChangeCompany))
//      }
//
//      val empWithCompanyChange = await(employeeDb.getEmployeeByUserIdAndCompanyId(actualUserId2, actualCompanyId2)).get
//      empWithCompanyChange.companyId must be (actualCompanyId2)
//
//      val employeesNewSet: Seq[Employee] = await(employeeDb.getEmployeeByCompanyIds(List(actualCompanyId, actualCompanyId2)))
//      employeesNewSet.size must be (2)
//      employeesNewSet(0).userId must be (actualUserId)
//      employeesNewSet(1).userId must be (actualUserId2)
//
//      // same user can be present in two companies as two different employees
//      val user2InCompany1 = employeeWithChangeCompany.copy(companyId = actualCompanyId)
//      await(employeeDb.createEmployeeAndGetEmployeeId(user2InCompany1))
//
//      val employeesNewSet2: Seq[Employee] = await(employeeDb.getEmployeeByCompanyIds(List(actualCompanyId, actualCompanyId2)))
//      employeesNewSet2.size must be (3)
//      employeesNewSet2(0).userId must be (actualUserId)
//      employeesNewSet2(1).userId must be (actualUserId2)
//      employeesNewSet2(1).companyId must be (actualCompanyId2)
//      employeesNewSet2(2).userId must be (actualUserId2)
//      employeesNewSet2(2).companyId must be (actualCompanyId)
//
//      // creating same employee again should not create another entry
//      intercept[Exception] {
//        await(employeeDb.createEmployeeAndGetEmployeeId(user2InCompany1))
//      }
//
//      // get companies by org Id
//      val employeeNewSet3 = await(employeeDb.getEmployeeByOrgId(actualOrgId))
//      employeeNewSet3.size must be (3)
//      employeeNewSet3(0).userId must be (actualUserId)
//      employeeNewSet3(1).userId must be (actualUserId2)
//      employeeNewSet3(1).companyId must be (actualCompanyId2)
//      employeeNewSet3(2).userId must be (actualUserId2)
//      employeeNewSet3(2).companyId must be (actualCompanyId)
//    }
//  }
//}

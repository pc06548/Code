package services

import model.reports.{ExcelReport, Row, Table}
import org.scalatestplus.mockito._
import org.scalatestplus.play.PlaySpec
import org.scalatestplus.play.guice.GuiceOneAppPerSuite
import play.api.Configuration
import services.db.CompanyDbUpdator
import services.db.contractor.ContractorVoucherDbUpdator
import services.reports.DirectorReportService
import services.reports.excel.ExcelReportService

class DirectorReportServiceTest extends PlaySpec with GuiceOneAppPerSuite with MockitoSugar {

  val ContractorVoucherDbUpdator: ContractorVoucherDbUpdator = mock[ContractorVoucherDbUpdator]

  val excel = ExcelReport("name",List(Table(Some("cap"),List("h1","h2"),List(Row(List("1","2"))))))

  "Director report service" when {
    "should generate report" in {

      EmailBodyGenerator.generateEmailBody(excel)

      true
    }

  }

}

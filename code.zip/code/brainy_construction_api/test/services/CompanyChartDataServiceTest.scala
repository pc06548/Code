package services

import model.reports.ChartRawDataForCompany
import services.reports.charts.CompanyChartDataService
import org.scalatestplus.mockito._
import org.scalatestplus.play.PlaySpec
import org.scalatestplus.play.guice.GuiceOneAppPerSuite

class CompanyChartDataServiceTest extends PlaySpec with GuiceOneAppPerSuite with MockitoSugar {


  val service = new CompanyChartDataService()

  "Chart Data service" when {
    "should create chart data" in {

     val data = List(
       ChartRawDataForCompany.createChartRawData("Vihang","15-05-2020",2000),
       ChartRawDataForCompany.createChartRawData("Vihang","17-06-2020",2000),
       ChartRawDataForCompany.createChartRawData("Office","11-09-2019",3000),
       ChartRawDataForCompany.createChartRawData("Vihang","12-01-2019",4000),
       ChartRawDataForCompany.createChartRawData("Malhar","01-12-2020",7000)
     )
     val result = service.createAllCompanyLevelChartData(data)
     println(result)
     true
    }

  }

}

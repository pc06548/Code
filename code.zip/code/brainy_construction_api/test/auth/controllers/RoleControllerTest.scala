package auth.controllers

import java.util.Date

import auth.db.{AuthInfoExtractorDb, RoleNameOrgIdFeatureNameCompaniesId}
import auth.services.{AuthService, BatWithLoginToken}
import consts.Roles
import controllers.RoleController
import model.{GetRoleMapping, RoleMappingsRequest, UpdateRoleMappingsRequest}
import model.{LoginToken, Role, RoleMapping}
import org.mockito.{ArgumentMatcher, ArgumentMatchers, Mockito}
import org.mockito.Mockito.{times, verify, when}
import org.scalatest.BeforeAndAfterEach
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import play.api.libs.json.Json
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers._
import services.RoleService

import scala.concurrent.Future

class RoleControllerTest extends PlaySpec with MockitoSugar with BeforeAndAfterEach {

  val authServiceMock = mock[AuthService]
  val roleServiceMock = mock[RoleService]
  val authInfoExtractorDbMock = mock[AuthInfoExtractorDb]
  val controller = new RoleController(roleServiceMock, authServiceMock, authInfoExtractorDbMock, stubControllerComponents())

  override def beforeEach(): Unit = {
    Mockito.reset(authServiceMock)
    Mockito.reset(roleServiceMock)
    Mockito.reset(authInfoExtractorDbMock)
  }

  "RoleControllerTest" should {

    "test happy flow" should {
      val validBat = "validBat"
      val validToken = "validToken"
      val date = new Date()
      val loginId = 1
      val batWithLoginToken = BatWithLoginToken(validBat, LoginToken(loginId, validToken, date))

      val orgId = 100
      val roleName = Roles.ADMIN
      val featureName = "BASE"
      val companyIds = List(200, 201, 202)
      val userId = 600
      val roleNameOrgIdFeatureNameCompaniesId = RoleNameOrgIdFeatureNameCompaniesId(orgId, List(roleName), featureName, companyIds, userId)
      val role1 = Role(300, Roles.ADMIN)
      val role2 = Role(301, "ACCOUNTANT")

      "get roles" in {
        when(authServiceMock.auth(validBat)).thenReturn(Some(batWithLoginToken))
        when(authInfoExtractorDbMock.getRoleNameOrgIdByLoginId(loginId)).thenReturn(Some(roleNameOrgIdFeatureNameCompaniesId))
        when(roleServiceMock.getRoles()).thenReturn(List(role1, role2))

        val resultF: Future[Result] = controller.getRoles().apply(FakeRequest().withHeaders((AUTHORIZATION, validBat)))
        assert(status(resultF) == OK)
        assert(contentAsString(resultF) == """[{"id":300,"name":"ADMIN"},{"id":301,"name":"ACCOUNTANT"}]""")
      }
    }

    "test request formats" should {
      "successfully create RoleMappingsRequest from json" in {
        val inputJson = Json.parse(
          """
            |{"roleMappings":[{
            |  "roleId":100,
            |  "loginId":200,
            |  "companyId":300
            |},
            |{
            |  "roleId":101,
            |  "loginId":201,
            |  "companyId":301
            |}
            |]}
          """.stripMargin)
        RoleMappingsRequest.createFromJson(inputJson) must be(Some(RoleMappingsRequest(List(RoleMapping(100,200,300), RoleMapping(101,201,301)))))
      }

      "successfully create UpdateRoleMappingsRequest from json" in {
        val inputJson = Json.parse(
          """
            |{"addRoleMappings":[{
            |  "roleId":100,
            |  "loginId":200,
            |  "companyId":300
            |},
            |{
            |  "roleId":101,
            |  "loginId":201,
            |  "companyId":301
            |}
            |],
            |"removeRoleMappings":[{
            |  "roleId":100,
            |  "loginId":200,
            |  "companyId":300
            |},
            |{
            |  "roleId":101,
            |  "loginId":201,
            |  "companyId":301
            |}
            |]}
          """.stripMargin)
        UpdateRoleMappingsRequest.createFromJson(inputJson) must be(Some(UpdateRoleMappingsRequest(List(RoleMapping(100,200,300), RoleMapping(101,201,301)), List(RoleMapping(100,200,300), RoleMapping(101,201,301)))))
      }

      "successfully create UpdateRoleMappingsRequest from json with only addRoleMappings" in {
        val inputJson = Json.parse(
          """
            |{"addRoleMappings":[{
            |  "roleId":100,
            |  "loginId":200,
            |  "companyId":300
            |},
            |{
            |  "roleId":101,
            |  "loginId":201,
            |  "companyId":301
            |}
            |],
            |"removeRoleMappings":[]}
          """.stripMargin)
        UpdateRoleMappingsRequest.createFromJson(inputJson) must be(Some(UpdateRoleMappingsRequest(List(RoleMapping(100,200,300), RoleMapping(101,201,301)), List())))
      }

      "successfully create UpdateRoleMappingsRequest from json with only removeRoleMappings" in {
        val inputJson = Json.parse(
          """
            |{"addRoleMappings":[],
            |"removeRoleMappings":[{
            |  "roleId":100,
            |  "loginId":200,
            |  "companyId":300
            |},
            |{
            |  "roleId":101,
            |  "loginId":201,
            |  "companyId":301
            |}
            |]}
          """.stripMargin)
        UpdateRoleMappingsRequest.createFromJson(inputJson) must be(Some(UpdateRoleMappingsRequest(List(), List(RoleMapping(100,200,300), RoleMapping(101,201,301)))))
      }

      "fail create RoleMappingsRequest from json" in {
        // missing roleId
        val inputJson = Json.parse(
          """
            |{"roleMappings":[{
            |  "loginId":200,
            |  "companyId":300
            |},
            |{
            |  "roleId":101,
            |  "loginId":201,
            |  "companyId":301
            |}
            |]}
          """.stripMargin)
        RoleMappingsRequest.createFromJson(inputJson) must be(None)
      }

      "fail create UpdateRoleMappingsRequest from incomplete json" in {
        val inputJson = Json.parse(
          """
            |{"removeRoleMappings":[{
            |  "roleId":100,
            |  "loginId":200,
            |  "companyId":300
            |},
            |{
            |  "roleId":101,
            |  "loginId":201,
            |  "companyId":301
            |}
            |]}
          """.stripMargin)
        UpdateRoleMappingsRequest.createFromJson(inputJson) must be(None)
      }
    }

    "test negative flow" should {
      val validBat = "validBat"
      val validToken = "validToken"
      val date = new Date()
      val loginId = 1
      val batWithLoginToken = BatWithLoginToken(validBat, LoginToken(loginId, validToken, date))

      val orgId = 100
      val roleName = Roles.ADMIN
      val featureName = "BASE"
      val companyIds = List(200, 201, 202)
      val userId = 600
      val roleNameOrgIdFeatureNameCompaniesId = RoleNameOrgIdFeatureNameCompaniesId(orgId, List(roleName), featureName, companyIds, userId)
      val role1 = Role(300, Roles.ADMIN)
      val role2 = Role(301, "ACCOUNTANT")

      "fail get roles for no authorization header" in {
        val resultF: Future[Result] = controller.getRoles().apply(FakeRequest())

        assert(status(resultF) == NOT_FOUND)
        verify(roleServiceMock, times(0)).getRoles()
        verify(authInfoExtractorDbMock, times(0)).getRoleNameOrgIdByLoginId(ArgumentMatchers.any())
        verify(authServiceMock, times(0)).auth(ArgumentMatchers.any())
      }

      "fail get roles for invalid authorization header" in {
        when(authServiceMock.auth(validBat)).thenReturn(None)
        val resultF: Future[Result] = controller.getRoles().apply(FakeRequest().withHeaders((AUTHORIZATION, validBat)))

        assert(status(resultF) == UNAUTHORIZED)
        verify(roleServiceMock, times(0)).getRoles()
        verify(authInfoExtractorDbMock, times(0)).getRoleNameOrgIdByLoginId(ArgumentMatchers.any())
      }

      "fail get roles for valid authorization header but user is not admin" in {
        when(authServiceMock.auth(validBat)).thenReturn(Some(batWithLoginToken))
        val nonAdminInfo = roleNameOrgIdFeatureNameCompaniesId.copy(roleNames = List("NonAdmin"))
        when(authInfoExtractorDbMock.getRoleNameOrgIdByLoginId(loginId)).thenReturn(Some(nonAdminInfo))
        val resultF: Future[Result] = controller.getRoles().apply(FakeRequest().withHeaders((AUTHORIZATION, validBat)))

        assert(status(resultF) == UNAUTHORIZED)
        verify(roleServiceMock, times(0)).getRoles()
        verify(authInfoExtractorDbMock, times(1)).getRoleNameOrgIdByLoginId(ArgumentMatchers.any())
      }
    }
  }
}

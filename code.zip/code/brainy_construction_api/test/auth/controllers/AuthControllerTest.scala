package auth.controllers

import auth.db.AuthInfoExtractorDb
import auth.services.AuthService
import consts.StringLiterals
import org.mockito.Mockito.when
import org.scalatestplus.mockito.MockitoSugar
import org.scalatestplus.play.PlaySpec
import play.api.libs.json.Json
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers._

import scala.concurrent.Future

class AuthControllerTest extends PlaySpec with MockitoSugar{

  val authServiceMock: AuthService = mock[AuthService]
  val authInfoExtractorDbMock: AuthInfoExtractorDb = mock[AuthInfoExtractorDb]
  val controller = new AuthController(authServiceMock, authInfoExtractorDbMock, stubControllerComponents())

  "AuthControllerTest" should {

    "should fail login with bad request" in {

      val resultF: Future[Result] = controller.login().apply(FakeRequest())

      assert(status(resultF) == BAD_REQUEST)
      assert(header(StringLiterals.BAT, resultF).isEmpty)
    }

    "should fail login with bad request for partial json" in {

      val resultF: Future[Result] = controller.login().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{
          | "userName":"123"
          |}
          |""".stripMargin)))

      assert(status(resultF) == BAD_REQUEST)
      assert(header(StringLiterals.BAT, resultF).isEmpty)
    }


    "should pass login on success" in {
      when(authServiceMock.login("123", "pass")).thenReturn(Some("bat1"))
      val resultF: Future[Result] = controller.login().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{
          | "userName":"123",
          | "password":"pass"
          |}
          |""".stripMargin)))

      assert(status(resultF) == NO_CONTENT)
      assert(header(StringLiterals.BAT, resultF).contains("bat1"))
    }

    "should fail signUp with bad request" in {

      val resultF: Future[Result] = controller.signUp().apply(FakeRequest())

      assert(status(resultF) == BAD_REQUEST)
    }

    "should fail signUp with bad request for partial json" in {

      val resultF: Future[Result] = controller.signUp().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{
          | "userName":"123"
          |}""".stripMargin)))

      assert(status(resultF) == BAD_REQUEST)
    }

    "should pass signUp on success" in {
      when(authServiceMock.setPassword("123", "pass")).thenReturn(Some("bat1"))
      val resultF: Future[Result] = controller.signUp().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{
          | "userName":"123",
          | "password":"pass"
          |}""".stripMargin)))

      assert(status(resultF) == NO_CONTENT)
      assert(header(StringLiterals.BAT, resultF).contains("bat1"))
    }

  }
}

package auth.services

import java.util.Date

import auth.util.{LoginFailure, LoginSuccess, TokenExpired}
import config.AppConstants
import model.LoginToken
import org.mockito.Mockito._
import org.scalatest.{FunSpec, Matchers}
import org.scalatestplus.mockito.MockitoSugar
import play.api.Configuration

class JWTServiceTest extends FunSpec with Matchers with MockitoSugar {

  describe("JWTServiceTest") {
    val mockConf:Configuration = mock[Configuration]
    val jwtService = new JWTService(mockConf)
    it("should create and verify login") {
      // create token
      when(mockConf.getLong(AppConstants.LoginTokenExpirationTimeInSecs)).thenReturn(Some(3L))
      val date = new Date()
      val login1 = LoginToken(1, "token1", date)
      val login2 = LoginToken(2, "token2", date)
      val token = jwtService.createTokenForLogin(login1)
      val token2 = jwtService.createTokenForLogin(login2)
      token.isDefined should be(true)
      token2.isDefined should be(true)

      // decode token
      jwtService.verify(token.get) should be(LoginSuccess)
      jwtService.verify(token2.get) should be(LoginSuccess)

      Thread.sleep(4000)
      // token will be expired
      jwtService.verify(token.get) should be(TokenExpired)
      jwtService.verify(token2.get) should be(TokenExpired)

      // token is wrong
      jwtService.verify(token.get+"s") should be(LoginFailure)
    }

    it ("should decode a given token") {
      when(mockConf.getLong(AppConstants.LoginTokenExpirationTimeInSecs)).thenReturn(Some(10L))
      val date = new Date()
      val login1 = LoginToken(1, "token1", date)
      val token = jwtService.createTokenForLogin(login1)
      token.isDefined should be(true)

      val expected = jwtService.decode(token.get).get
      expected.loginId should be(login1.loginId)
      expected.token should be(login1.token)
      expected.updateTimestamp.toString should be(login1.updateTimestamp.toString)

      // test wrong token decode
      jwtService.decode("scasc") should be(None)
    }

  }
}

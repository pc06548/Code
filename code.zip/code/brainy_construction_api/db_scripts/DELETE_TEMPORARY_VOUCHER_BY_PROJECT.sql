-- FUNCTION: public."DELETE_TEMPORARY_BY_PROJECT"(integer, integer)

-- DROP FUNCTION public."DELETE_TEMPORARY_BY_PROJECT"(integer, integer);

CREATE OR REPLACE FUNCTION public."DELETE_TEMPORARY_VOUCHER_BY_PROJECT"(
	"COMPANY_ID" integer,
	"PROJECT_ID" integer)
    RETURNS void
    LANGUAGE 'sql'

    COST 100
    VOLATILE
AS $BODY$
	-- --------------- Contractor voucher ------------------
    DELETE from contractor_voucher cv
	where cv.company_id = "COMPANY_ID"
	and cv.invoice_id in (
		select id from contractor_invoice ci
		where ci.id = cv.invoice_id
		and ci.project_id = "PROJECT_ID"
		and ci.is_temporary = true);
	-- --------------- Supplier voucher------------------
    DELETE from supplier_voucher cv
	where cv.company_id = "COMPANY_ID"
	and cv.invoice_id in (
		select id from supplier_invoice ci
		where ci.id = cv.invoice_id
		and ci.project_id = "PROJECT_ID"
		and ci.is_temporary = true);
	-- --------------- Consultant voucher------------------
    DELETE from consultant_voucher cv
	where cv.company_id = "COMPANY_ID"
	and cv.invoice_id in (
		select id from consultant_invoice ci
		where ci.id = cv.invoice_id
		and ci.project_id = "PROJECT_ID"
		and ci.is_temporary = true);

$BODY$;

ALTER FUNCTION public."DELETE_TEMPORARY_VOUCHER_BY_PROJECT"(integer, integer)
    OWNER TO sudhakar;

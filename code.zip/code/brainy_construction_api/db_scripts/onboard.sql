 -------------- New Data base ----------------
INSERT INTO public.feature(name) VALUES ('BASE');
INSERT INTO public.feature(name) VALUES ('ADVANCE');
INSERT INTO public.feature(name) VALUES ('COMMERCIAL');
INSERT INTO public.feature(name) VALUES ('CORPORATE');

 ---------------- Roles -----------------------
INSERT INTO public.role(name) VALUES ('ADMIN');
INSERT INTO public.role(name) VALUES ('EMPLOYEE');
INSERT INTO public.role(name) VALUES ('SITE_MANAGER');
INSERT INTO public.role(name) VALUES ('OFFICE_MANAGER');
INSERT INTO public.role(name) VALUES ('ACCOUNTANT');
INSERT INTO public.role(name) VALUES ('CHIEF_ACCOUNTANT');

----------------- Admin Categories -------------

INSERT INTO public.category(category_type, name) VALUES ( 'ADMIN', 'Contractor');
INSERT INTO public.category(category_type, name) VALUES ( 'ADMIN', 'Supplier');
INSERT INTO public.category(category_type, name) VALUES ( 'ADMIN', 'Consultant');
INSERT INTO public.category(category_type, name) VALUES ( 'ADMIN', 'TDS');
INSERT INTO public.category(category_type, name) VALUES ( 'ADMIN', 'Project F.S.I Cost');
INSERT INTO public.category(category_type, name) VALUES ( 'ADMIN', 'Site Maintenance');
INSERT INTO public.category(category_type, name) VALUES ( 'ADMIN', 'Office Maintenance');
----------------- Batch  job -------------

INSERT INTO public.batch_job_status(batch_job_name, last_time_run_date) VALUES ( 'director_report', '12-09-2020');
INSERT INTO public.batch_job_status(batch_job_name, last_time_run_date) VALUES ( 'tds_invoice_creation', '12-09-2020');
INSERT INTO public.batch_job_status(batch_job_name, last_time_run_date) VALUES ( 'expense_invoice_creation', '12-09-2020');
INSERT INTO public.batch_job_status(batch_job_name, last_time_run_date) VALUES ( 'payslip_creation', '12-09-2020');

 --------------- New Org ------------------

INSERT INTO public.org(name, create_timestamp, update_timestamp)
       VALUES ('Brainy software solutions', current_timestamp, current_timestamp);

select * from org;
select * from feature;

insert into ORG_FEATURE_MAPPING(feature_id,org_id) values (3,1)

select * from ORG_FEATURE_MAPPING

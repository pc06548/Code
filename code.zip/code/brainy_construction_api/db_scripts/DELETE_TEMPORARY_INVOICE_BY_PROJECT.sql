-- FUNCTION: public."DELETE_TEMPORARY_BY_PROJECT"(integer, integer)

-- DROP FUNCTION public."DELETE_TEMPORARY_BY_PROJECT"(integer, integer);

CREATE OR REPLACE FUNCTION public."DELETE_TEMPORARY_INVOICE_BY_PROJECT"(
	"COMPANY_ID" integer,
	"PROJECT_ID" integer)
    RETURNS void
    LANGUAGE 'sql'

    COST 100
    VOLATILE
AS $BODY$

	-- --------------- Contractor invoice ------------------
	 DELETE from contractor_invoice_details cv
	 where cv.invoice_id in (
		select id from contractor_invoice ci
		where ci.id = cv.invoice_id
		and ci.COMPANY_ID = "COMPANY_ID"
		and ci.PROJECT_ID = "PROJECT_ID"
		and ci.is_temporary = true);

    DELETE from contractor_invoice ci where ci.COMPANY_ID = "COMPANY_ID" and ci.PROJECT_ID = "PROJECT_ID" and ci.is_temporary = true;
	-- --------------- Supplier invoice------------------
	DELETE from supplier_invoice_details cv
	 where cv.invoice_id in (
		select id from supplier_invoice ci
		where ci.id = cv.invoice_id
		and ci.COMPANY_ID = "COMPANY_ID"
		and ci.PROJECT_ID = "PROJECT_ID"
		and ci.is_temporary = true);
    DELETE from supplier_invoice ci where ci.COMPANY_ID = "COMPANY_ID" and ci.PROJECT_ID = "PROJECT_ID" and ci.is_temporary = true;
	-- --------------- Consultant invoice------------------

	DELETE from consultant_invoice_details cv
	 where cv.invoice_id in (
		select id from consultant_invoice ci
		where ci.id = cv.invoice_id
		and ci.COMPANY_ID = "COMPANY_ID"
		and ci.PROJECT_ID = "PROJECT_ID"
		and ci.is_temporary = true);
    DELETE from consultant_invoice ci
     where ci.COMPANY_ID = "COMPANY_ID" and ci.PROJECT_ID = "PROJECT_ID" and ci.is_temporary = true;

$BODY$;

ALTER FUNCTION public."DELETE_TEMPORARY_INVOICE_BY_PROJECT"(integer, integer)
    OWNER TO sudhakar;

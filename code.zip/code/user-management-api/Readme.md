## User Management Application

Stack
* scala
* sbt
* akka persistence
* akka http
# EV Charge Pricing API

### Technologies
Scala, Akka-http, Slick

### Endpoints



package controllers

import javax.inject.{Inject, Singleton}
import play.api.mvc.{AbstractController, ControllerComponents}
import services.{CustomCollector, PromService}

@Singleton
class HomeController @Inject()(controllerComponents: ControllerComponents) extends AbstractController(controllerComponents) {
  def index = Action {
    PromService.incCounter
    CustomCollector.incCustomCounter
    Ok(views.html.home())
  }
}
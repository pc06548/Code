package controllers

import java.io.StringWriter
import java.time.ZonedDateTime

import io.prometheus.client.CollectorRegistry
import io.prometheus.client.exporter.common.TextFormat
import javax.inject.Inject
import play.api.mvc.{AbstractController, ControllerComponents}
import services.{CustomCollector, CustomRegistry}

class PromController  @Inject()(controllerComponents: ControllerComponents, customRegistry: CustomRegistry, customCollector: CustomCollector) extends AbstractController(controllerComponents) {

  /*def collect  = Action {
    val metricsOutput = new StringWriter
    TextFormat.write004(metricsOutput, CollectorRegistry.defaultRegistry.metricFamilySamples)
    metricsOutput.flush()
    Ok(metricsOutput.toString)
  }*/

  customRegistry.register(customCollector)
  def collect  = Action {
    ZonedDateTime.now().minusHours(78).isBefore(ZonedDateTime.now().minusDays(4))
    val metricsOutput = new StringWriter
    TextFormat.write004(metricsOutput, CollectorRegistry.defaultRegistry.metricFamilySamples) //CollectorRegistry.defaultRegistry
    metricsOutput.flush()
    Ok(metricsOutput.toString)
  }

}
package services

import java.util

import com.typesafe.scalalogging.StrictLogging
import io.prometheus.client.{Collector, Counter}

class CustomCollector extends Collector {
  override def collect(): util.List[Collector.MetricFamilySamples] = {
    CustomCollector.custom.collect()
  }
}

object CustomCollector extends StrictLogging {
  val custom: Counter = Counter.build("custom","Total number of api requests")
    .labelNames("other").create()

  def incCustomCounter = {
    custom.labels("bye").inc()
  }
}
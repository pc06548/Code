package services

import io.prometheus.client.CollectorRegistry

class CustomRegistry extends CollectorRegistry {

}

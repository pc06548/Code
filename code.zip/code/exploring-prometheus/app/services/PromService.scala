package services

import com.typesafe.scalalogging.StrictLogging
import io.prometheus.client.Counter

object PromService extends StrictLogging {
  val counter: Counter = Counter.build("counter","Total number of api requests")
    .labelNames("something")
    .register()


  private val infoCounter = PromService.counter.labels("info")
  private val qCounter = PromService.counter.labels("q")

  def incCounter = {
    logger.error("I am occurred")
    infoCounter.inc()
    qCounter.inc()
  }
}
import CoffeeMachine.GetCoffeeCup
import akka.actor.{ActorSystem, Props}
import akka.pattern.ask
import akka.util.Timeout

import scala.concurrent.Future
import scala.concurrent.duration._

object HelloWorld extends App {
  implicit val timeout = Timeout(10 seconds)
  val actorSystem = ActorSystem("cafe")
  val actorRef = actorSystem.actorOf(Props(new CoffeeMachine(new SimpleCoffeeTank)),"coffee")
  ask(actorRef, GetCoffeeCup)
}

class SimpleCoffeeTank extends CoffeeTank {
  val coffeeCupSize = 50
  var filledIn = 0
  def hasCoffeeCup: Boolean  = filledIn >= coffeeCupSize
  def fetchCoffeeCup: Future[Int] = Future.successful(filledIn - coffeeCupSize)
  def put(millis: Int): Future[Unit] = Future.successful(filledIn += millis)
}
import akka.actor.Actor

import scala.concurrent.Future
import scala.concurrent.duration._

// An actor implementing the CoffeeMachine protocol
class CoffeeMachine(coffeeTank: CoffeeTank) extends Actor {

  import CoffeeMachine._
  import context.dispatcher

  override def receive: Receive = balance(cents = 0)

  context.system.scheduler.scheduleAtFixedRate(
    0 milliseconds,
    1000 milliseconds,
    self,
    BrewedCoffee(amountMl = 10))

  def balance(cents: Int): Receive = {
    case InsertCoin =>
      val newCents = cents + 100
      sender ! Balance(newCents)
      context.become(balance(newCents))

    case GetCoffeeCup if cents < cupPriceCents =>
      throw new RuntimeException("Not enough balance")

    case GetCoffeeCup =>
      while (!coffeeTank.hasCoffeeCup) {
        Thread.sleep(1000L)
      }
      coffeeTank.fetchCoffeeCup
      sender ! CoffeeCup
      context.become(balance(cents - cupPriceCents))

    case BrewedCoffee(amountMl) =>
      coffeeTank.put(amountMl)
  }
}
object CoffeeMachine {
  val cupPriceCents: Int = 200 // coffee cup price in cents

  case object InsertCoin // one coin is worth 100 cents
  case class Balance(cents: Int)
  case object GetCoffeeCup
  case object CoffeeCup
  case class BrewedCoffee(amountMl: Int)
}

trait CoffeeTank {
  def hasCoffeeCup: Boolean
  def fetchCoffeeCup: Future[Int]
  def put(millis: Int): Future[Unit]
}

object CoffeeTank {
  val cupSizeMl: Int = 300
}
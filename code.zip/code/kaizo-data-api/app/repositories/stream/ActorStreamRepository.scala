package repositories.stream

import akka.actor.{Actor, ActorRef}
import akka.pattern.ask
import akka.util.Timeout
import models.{AlreadyExistsResponse, GenericAPIResponse, StreamEntity, SuccessResponse}

import scala.collection.mutable
import scala.concurrent.{ExecutionContext, Future}

class ActorStreamRepository(streamCrudActor: ActorRef) extends StreamRepository {

  override def add( id: Option[String], streamEntity: StreamEntity)(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, GenericAPIResponse]] = {

    ask(streamCrudActor, AddStreamCommand(id, streamEntity)) map {
      case SuccessResponse => Right(SuccessResponse())
      case AlreadyExistsResponse => Right(AlreadyExistsResponse())
      case _ => Left("unexpected error")
    }

  }

  override def remove(id: String)(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, GenericAPIResponse]] = {

    ask(streamCrudActor, RemoveStreamCommand(id)) map {
      case SuccessResponse => Right(SuccessResponse())
      case _ => Left("unexpected error")
    }
  }

  override def get(id: String)(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, Option[StreamEntity]]] = {

    ask(streamCrudActor, GetStreamCommand(id)) map {
      case response: Option[StreamEntity] => Right(response)
      case _ => Left("unexpected error")
    }

  }

  override def getAll()(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, List[StreamEntity]]] = {

    ask(streamCrudActor, GetAllStreamsCommand()) map {
      case response: List[StreamEntity] => Right(response)
      case _ => Left("unexpected error")
    }

  }
}

// Commands to interact with Actor
case class AddStreamCommand(idO: Option[String], stream: StreamEntity)
case class RemoveStreamCommand(id: String)
case class GetStreamCommand(id: String)
case class GetAllStreamsCommand()



class StreamRepositoryActor extends Actor {

  // Map to hold all the streams
  private val streams =  mutable.Map[String, StreamEntity]()

  override def receive: Receive = {

    case AddStreamCommand(idO, stream) =>
      val id = idO.getOrElse(stream.domain)
      streams.get(id) match {
        case Some(_) => sender() ! AlreadyExistsResponse
        case None => {
          streams += (id -> stream)
          sender() ! SuccessResponse
        }
      }

    case RemoveStreamCommand(id) =>
      streams -= id
      sender() ! SuccessResponse

    case GetStreamCommand(id) =>
      sender() ! streams.get(id)

    case GetAllStreamsCommand() =>
      sender() ! streams.values.toList

    case _ =>
  }
}

package repositories.stream

import akka.util.Timeout
import models.{GenericAPIResponse, StreamEntity}

import scala.concurrent.{ExecutionContext, Future}

trait StreamRepository {

  def add( id: Option[String], streamEntity: StreamEntity)(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, GenericAPIResponse]]

  def remove(id: String)(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, GenericAPIResponse]]

  def get(id: String)(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, Option[StreamEntity]]]

  def getAll()(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, List[StreamEntity]]]
}

package repositories.stats

import akka.actor.{Actor, ActorRef}
import akka.pattern.ask
import akka.util.Timeout
import models.{GenericAPIResponse, NotFoundResponse, StreamStats, SuccessResponse}

import scala.collection.mutable
import scala.concurrent.{ExecutionContext, Future}

class ActorStreamStatsRepository(streamStatsActor: ActorRef) extends StreamStatsRepository {

  override def getAllStreamStats()
                                (implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, List[StreamStats]]] = {

    ask(streamStatsActor, GetAllStatsCommand) map {
      case GetAllStreamStatsResponse(allStats) => Right(allStats)
      case _ => Left("unexpected error")
    }

  }

  override def updateStreamStats(streamStats: StreamStats)
                                (implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, GenericAPIResponse]] = {

    ask(streamStatsActor, UpdateStatsCommand(streamStats)) map {
      case SuccessResponse => Right(SuccessResponse())
      case _ => Left("unexpected error")
    }

  }

  override def getCurrentOffsetStream(streamId: String)
                                     (implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, Long]] = {

    ask(streamStatsActor, GetCurrentOffsetCommand(streamId)) map {
      case offset: Long => Right(offset)
      case NotFoundResponse => Left("domain not found")
      case _ => Left("unexpected error")
    }

  }

}

case class UpdateStatsCommand(stats: StreamStats)
case class GetCurrentOffsetCommand(id: String)
object GetAllStatsCommand

case class GetAllStreamStatsResponse(list: List[StreamStats])


class StreamStatsActor extends Actor {
  private val streamStats =  mutable.Map[String, StreamStats]()

  override def receive: Receive = {

    case UpdateStatsCommand(newStats) =>
      streamStats.get(newStats.id) match {
        case Some(prevStats) =>
          streamStats += (newStats.id -> StreamStats(newStats.id, newStats.currentOffset, newStats.numberOfTicketsSeen + prevStats.numberOfTicketsSeen))
          sender() ! SuccessResponse
        case None =>
          streamStats += (newStats.id -> StreamStats(newStats.id, newStats.currentOffset, newStats.numberOfTicketsSeen))
          sender() ! SuccessResponse
      }

    case GetCurrentOffsetCommand(id) =>
      streamStats.get(id) match {
        case Some(stats) => sender() ! stats.currentOffset
        case None => sender() ! NotFoundResponse
      }

    case GetAllStatsCommand =>
      sender() ! GetAllStreamStatsResponse(streamStats.values.toList)

  }
}
package repositories.stats

import akka.util.Timeout
import models.{GenericAPIResponse, StreamStats}

import scala.concurrent.{ExecutionContext, Future}

trait StreamStatsRepository {
  def getAllStreamStats()(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, List[StreamStats]]]

  def updateStreamStats(streamStats: StreamStats)(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, GenericAPIResponse]]

  def getCurrentOffsetStream(streamId: String)(implicit timeout: Timeout, executionContext: ExecutionContext): Future[Either[String, Long]]
}

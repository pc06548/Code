package endpoints.helpers

import akka.util.ByteString
import com.typesafe.scalalogging.StrictLogging
import play.api.http.HttpEntity
import play.api.libs.json.{Json, Writes}
import play.api.mvc.{ResponseHeader, Result}

import scala.concurrent.{ExecutionContext, Future}

object ResponseHelpers extends StrictLogging {

  def eitherToResponse[T](responseF: Future[Either[String, T]], operation: String)
                         (implicit writes: Writes[T], executionContext: ExecutionContext): Future[Result] = {
    responseF map {
      case Right(message) =>
        logger.info(s"Success: ${operation}")
        Result(
          header = ResponseHeader(200, Map.empty),
          body = HttpEntity.Strict(ByteString(Json.toJson(message).toString()), Some("application/json"))
        )
      case Left(message) =>
        logger.error(s"Error: ${operation}")
        Result(
          header = ResponseHeader(500, Map.empty),
          body = HttpEntity.Strict(ByteString(message), Some("text/plain"))
        )
    } recoverWith {
      case ex =>
        logger.error(s"Error while ${operation}: ${ex.getMessage}")
        Future.successful(
          Result(
            header = ResponseHeader(500, Map.empty),
            body = HttpEntity.Strict(ByteString("Something went wrong"), Some("text/plain"))
          )
        )
    }
  }

}

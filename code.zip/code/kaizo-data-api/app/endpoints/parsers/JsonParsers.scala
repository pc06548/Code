package endpoints.parsers

import com.typesafe.scalalogging.StrictLogging
import models.StreamEntity
import play.api.libs.json.{JsValue, Json}

import scala.util.{Failure, Success, Try}

object JsonParsers extends StrictLogging {

  implicit val streamEntityReads = Json.reads[StreamEntity]

  def parseStreamInput(body: Option[JsValue]): Either[String, (Option[String], StreamEntity)] =  {
    body match {
      case Some(json) => {
        val id = Try((json \ "id").as[String]).toOption
        Try((json \ "stream").as[StreamEntity]) match {
          case Success(entity) => Right(id, entity.copy(idO = id))
          case Failure(ex) =>
            logger.error(s"Error parsing input json: ${ex.getMessage}")
            Left("invalid request")
        }
      }
      case None => Left("no json found")
    }
  }


}

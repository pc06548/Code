package endpoints.daos

case class StreamStatsResponse(
                                id: String,
                                currentOffset: Long,
                                noOfTicketsSeen: Long,
                                isRunning: Boolean,
                              )
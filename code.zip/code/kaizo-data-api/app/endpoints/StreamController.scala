package endpoints

import com.typesafe.scalalogging.StrictLogging
import config.SystemModule
import endpoints.daos.StreamStatsResponse
import endpoints.helpers.ResponseHelpers
import endpoints.parsers.JsonParsers
import javax.inject.Inject
import play.api.libs.json.Json
import play.api.mvc.{AbstractController, ControllerComponents}

import scala.concurrent.Future

class StreamController @Inject()(
                                  systemModule: SystemModule,
                                  controllerComponents: ControllerComponents)
  extends AbstractController(controllerComponents) with StrictLogging {

  import models.GenericAPIResponseJsonWrites._
  import systemModule._

  def add = Action.async {
    request => {
      JsonParsers.parseStreamInput(request.body.asJson) match {
        case Right(input) =>
          ResponseHelpers.eitherToResponse(
            streamCrudService.add(input._1, input._2),s"adding stream: ${input._2.id}")
        case Left(message) =>
          Future.successful(BadRequest(message))
      }
    }
  }

  def remove(id: String) = Action.async {
    ResponseHelpers.eitherToResponse(streamCrudService.remove(id), s"removing stream: ${id}")
  }

  def start(id: String) = Action.async {
    ResponseHelpers.eitherToResponse(streamRuntimeService.start(id), s"starting stream: ${id}")
  }

  def stop(id: String) = Action.async {
    ResponseHelpers.eitherToResponse(streamRuntimeService.stop(id), s"stopping stream: ${id}")
  }

  def getAllStreamStats = Action.async {
    implicit val streamStatsWrites = Json.writes[StreamStatsResponse]

    ResponseHelpers.eitherToResponse(streamStatsService.getAllStreamStats(), "getting stats")
  }

}

package services

import com.typesafe.scalalogging.StrictLogging
import config.SystemModule
import endpoints.daos.StreamStatsResponse
import javax.inject.Inject
import models.{GenericAPIResponse, StreamStats}

import scala.concurrent.Future

class StreamStatsService @Inject()(systemModule: SystemModule) extends StrictLogging {

  import systemModule._

  def updateStreamStats(streamStats: StreamStats): Future[Either[String, GenericAPIResponse]] = {
    streamStatsRepository.updateStreamStats(streamStats)
  }

  def getCurrentOffsetStream(streamId: String): Future[Either[String, Long]] = {
    streamStatsRepository.getCurrentOffsetStream(streamId)
  }

  def getAllStreamStats(): Future[Either[String, List[StreamStatsResponse]]] = {
    for {
      runningStreamsE <- streamRuntimeService.getAllRunningStreams()
      statsE <- streamStatsRepository.getAllStreamStats()
    } yield {
      (statsE, runningStreamsE) match {
        case (Right(stats), Right(runningStreams)) =>
          Right(stats.map(stat => {
            val isRunning = runningStreams.exists(el => el == stat.id)
            StreamStatsResponse(stat.id, stat.currentOffset, stat.numberOfTicketsSeen, isRunning)
          }))
        case (_, _) => Left("unable to get stats")
      }
    }
  }

}

package services

import akka.pattern.ask
import com.typesafe.scalalogging.StrictLogging
import config.SystemModule
import javax.inject.Inject
import models.{AlreadyRunningResponse, GenericAPIResponse, NotFoundResponse, SuccessResponse}
import streaming._

import scala.concurrent.Future
import scala.concurrent.duration._

class StreamRuntimeService @Inject()(systemModule: SystemModule) extends StrictLogging {
  import systemModule._

  def start(id: String): Future[Either[String, GenericAPIResponse]] = {
    streamCrudService.get(id) flatMap {

      case Left(error) => Future.successful(Left(error))

      case Right(streamEntityO) => streamEntityO match {
        case Some(streamEntity) =>
          val streamHandler = new StreamHandler(streamEntity, 10 seconds, 30 seconds)(systemModule)

          ask(streamRuntimeActor, message = StartStreamCommand(id, streamHandler, mat))  map {
            case SuccessResponse => Right(SuccessResponse())
            case AlreadyRunningResponse => Right(AlreadyRunningResponse())
            case _ => Left("unexpected error")
          }

        case None =>
          Future.successful(Right(NotFoundResponse()))
      }

    }
  }

  def stop(id: String): Future[Either[String, GenericAPIResponse]] = {
    ask(streamRuntimeActor, StopStreamCommand(id)) map {
      case SuccessResponse => Right(SuccessResponse())
      case NotFoundResponse => Right(NotFoundResponse())
      case _ => Left("unexpected error")
    }
  }

  def getAllRunningStreams(): Future[Either[String, List[String]]] = {
    ask(streamRuntimeActor, GetAllRunningStreamsCommand) map {
      case AllRunningStreamsResponse(list) => Right(list)
      case _ => Left("unexpected error")
    }
  }
}

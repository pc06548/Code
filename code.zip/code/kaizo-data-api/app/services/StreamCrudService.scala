package services

import config.SystemModule
import javax.inject.Inject
import models.{GenericAPIResponse, StreamEntity, StreamStats, SuccessResponse}

import scala.concurrent.Future

class StreamCrudService @Inject()(systemModule: SystemModule) {
  import systemModule._

  def add(id: Option[String], streamEntity: StreamEntity): Future[Either[String, GenericAPIResponse]] =
    streamRepository.add(id, streamEntity) flatMap {
      case Left(error) => Future.successful(Left(error))
      case Right(response) =>
        if (response == SuccessResponse())
          streamStatsService.updateStreamStats(StreamStats(streamEntity.id, streamEntity.begin, 0))
        Future.successful(Right(response))
    }

  def remove(id: String): Future[Either[String, GenericAPIResponse]] =
    streamRuntimeService.stop(id) flatMap { _ =>
      streamRepository.remove(id)
    }

  def get(id: String): Future[Either[String, Option[StreamEntity]]] =
    streamRepository.get(id)

  def getAll(): Future[Either[String, List[StreamEntity]]] =
    streamRepository.getAll()
}

package config

import akka.actor.{ActorSystem, Props}
import akka.stream.ActorMaterializer
import akka.util.Timeout
import com.google.inject.AbstractModule
import play.api.libs.ws.WSClient
import play.api.libs.ws.ahc.{AhcWSClient, StandaloneAhcWSClient}
import repositories.stats.{ActorStreamStatsRepository, StreamStatsActor, StreamStatsRepository}
import repositories.stream.{ActorStreamRepository, StreamRepository, StreamRepositoryActor}
import services.{StreamCrudService, StreamRuntimeService, StreamStatsService}
import streaming.StreamRuntimeActor

import scala.concurrent.ExecutionContext.Implicits
import scala.concurrent.duration._

trait SystemModule {

  implicit val actorSystem = ActorSystem("data-api-actor-system")
  implicit val mat = ActorMaterializer()
  implicit val executionContext = Implicits.global
  implicit val timeout = Timeout(5 seconds)

  val streamRepository: StreamRepository
  val streamStatsRepository: StreamStatsRepository

  private val httpClient: StandaloneAhcWSClient = StandaloneAhcWSClient()
  val wsClient: WSClient = new AhcWSClient(httpClient)

  val streamCrudService = new StreamCrudService(this)

  val streamRuntimeActor = actorSystem.actorOf(Props[StreamRuntimeActor], "stream-runtime-actor")
  val streamRuntimeService = new StreamRuntimeService(this)

  val streamStatsService = new StreamStatsService(this)
}

class DefaultSystemModule extends SystemModule {
  val streamRepoActor = actorSystem.actorOf(Props[StreamRepositoryActor], "stream-repo-actor")
  override val streamRepository: StreamRepository = new ActorStreamRepository(streamRepoActor)

  val streamStatsActor = actorSystem.actorOf(Props[StreamStatsActor], "stream-stats-actor")
  override val streamStatsRepository: StreamStatsRepository = new ActorStreamStatsRepository(streamStatsActor)
}

class BindModule extends AbstractModule {
  override def configure = {
    bind(classOf[SystemModule]).to(classOf[DefaultSystemModule])
  }
}
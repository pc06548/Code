package streaming

import akka.NotUsed
import akka.actor.Cancellable
import akka.stream.scaladsl.{Flow, Keep, RunnableGraph, Sink, Source}
import com.typesafe.scalalogging.StrictLogging
import config.SystemModule
import models.{StreamEntity, StreamStats, Ticket}
import play.api.libs.json.Json
import play.api.libs.ws.{WSRequest, WSResponse}

import scala.concurrent.Future
import scala.concurrent.duration._
import scala.util.{Failure, Success, Try}

class StreamHandler(streamEntity: StreamEntity, initialDelay: FiniteDuration = 10 seconds, interval: FiniteDuration = 20 seconds)(systemModule: SystemModule) extends StrictLogging {
  import systemModule._

  def createNewStream: RunnableGraph[Cancellable] = {

    val url = s"https://${streamEntity.domain}.zendesk.com/api/v2/incremental/tickets.json"

    val request = systemModule.wsClient.url(url)
      .addHttpHeaders("Authorization" -> s"Bearer ${streamEntity.accessToken}")

    val getOffSetFlow: Flow[Any, Future[Option[Long]], NotUsed] = Flow[Any].map(_ => {
      streamStatsService.getCurrentOffsetStream(streamEntity.id) map {
        case Left(_) =>
          logger.error(s"Unable to get offset for ${streamEntity.domain}")
          None
        case Right(offset) => Some(offset)
      } recoverWith {
        case error => {
          logger.error(s"Unexpected error while getting current offset for ${streamEntity.domain}: ${error}")
          Future.successful(None)
        }
      }
    })

    val httpCallFlow: Flow[Future[Option[Long]], Future[Option[StreamStats]], NotUsed] = Flow[Future[Option[Long]]].map(offsetF => {
      offsetF flatMap {
        offsetO => offsetO match {
          case Some(offset) =>
            val responseF: Future[WSResponse] = request.withQueryStringParameters(("start_time" -> offset.toString)).get()
            responseF map { response =>
              if (response.status == 200) {
                parseResponse(request, response)
              } else {
                logger.error(s"Unexpected response status for request: ${request.url}. Code: ${response.status}")
                None
              }
            }
          case None => Future.successful(None)
        }
      }
    })

    val updateStatsFlow: Flow[Future[Option[StreamStats]], Future[Any], NotUsed] = Flow[Future[Option[StreamStats]]].map(streamStatsF =>
        streamStatsF flatMap { streamStatsO =>
          streamStatsO match {
            case Some(streamStats) =>
              streamStatsService.updateStreamStats(streamStats) recoverWith {
                case error => {
                  logger.error(s"Unexpected error while updating stats ${streamStats}: ${error}")
                  Future.successful(None)
                }
              }
            case None => Future.successful(())
          }
    })

    Source.tick(initialDelay, interval, 1)
      .via(getOffSetFlow)
      .via(httpCallFlow)
      .via(updateStatsFlow)
      .toMat(Sink.ignore)(Keep.left)

  }

  private def parseResponse(request: WSRequest, response: WSResponse): Option[StreamStats] = {
    Try(response.json) match {
      case Success(json) => {
        implicit val streamEntityReads = Json.reads[Ticket]

        logger.info(s"Response received: ${Json.stringify(json)}")
        val newOffsetO: Option[Long] = Try((json \ "end_time").as[Long]).toOption
        val noOfTicketsO: Option[Int] = Try((json \ "count").as[Int]).toOption
        for {
          newOffset <- newOffsetO
          noOfTickets <- noOfTicketsO
        } yield StreamStats(streamEntity.id, newOffset, noOfTickets)
      }
      case Failure(error) =>
        logger.error(s"Unexpected response for request: ${request.url}. Error: ${error.getMessage}")
        None
    }
  }
}

package streaming

import akka.actor.{Actor, Cancellable}
import akka.stream.Materializer
import akka.stream.scaladsl.RunnableGraph
import models.{AlreadyRunningResponse, NotFoundResponse, SuccessResponse}

import scala.collection.mutable


case class StartStreamCommand(id: String, streamHandler: StreamHandler, materializer: Materializer)
case class StopStreamCommand(id: String)
case class RemoveStreamStatusCommand(id: String)
object GetAllRunningStreamsCommand

case class AllRunningStreamsResponse(streams: List[String])

class StreamRuntimeActor extends Actor {

  // Map to hold running streams
  private val runningStreams =  mutable.Map[String, Cancellable]()

  override def receive: Receive = {

    // start a new stream
    case StartStreamCommand(id, streamHandler, materializer) =>
      runningStreams.get(id) match {

        case Some(_) => sender() ! AlreadyRunningResponse

        case None =>
          val source: RunnableGraph[Cancellable] = streamHandler.createNewStream
          val handle: Cancellable = source.run()(materializer)
          runningStreams += (id -> handle)
          sender() ! SuccessResponse

      }

    case StopStreamCommand(id) =>
      runningStreams.get(id) match {

        case Some(handle) =>
          handle.cancel()
          runningStreams -= id
          sender() ! SuccessResponse

        case None => sender() ! NotFoundResponse
      }

    case GetAllRunningStreamsCommand =>
      sender() ! AllRunningStreamsResponse(runningStreams.keys.toList)
  }
}

package models

case class StreamEntity(domain: String, accessToken: String, begin: Long, idO: Option[String] = None) {
  def id = idO.getOrElse(domain)
}

package models

case class Ticket(id: Int)

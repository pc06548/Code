package models

import play.api.libs.json.{JsValue, Json, Writes}

sealed trait GenericAPIResponse {
  val message: String
}

case class SuccessResponse() extends GenericAPIResponse { override val message: String = "success" }
case class AlreadyExistsResponse() extends GenericAPIResponse { override val message: String = "already-exists" }
case class AlreadyRunningResponse() extends GenericAPIResponse { override val message: String = "already-running" }
case class NotFoundResponse() extends GenericAPIResponse { override val message: String = "not-found" }

object GenericAPIResponseJsonWrites {
  implicit val genericAPIResponseJsonWrites = new Writes[GenericAPIResponse] {
    override def writes(o: GenericAPIResponse): JsValue = Json.obj("message" -> o.message)
  }
}

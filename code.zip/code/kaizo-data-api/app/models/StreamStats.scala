package models

case class StreamStats(
                        id: String,
                        currentOffset: Long,
                        numberOfTicketsSeen: Long
                      )

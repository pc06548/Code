# Kaizo-data-api

Solution to kaizo assignment

### Technology and tools
* Scala
* SBT
* Play
* Actors and Akka Streams

### Choices/ Assumptions
1. Not ot remove stats after removing the stream. 


### Running Application
#### Test
``sbt test``
#### Start server
``sbt run``
#### Endpoints
1. add stream - [POST] /stream/add
   
   JSON Body: 
   
   ```
   {
        "stream": 
        {
            "domain":"domainName",
            "accessToken":"token1",
            "begin":123
        },
        "id": "someString" // id is optional
     }
     ```
     
2. remove stream - [POST] /stream/remove/:id

   id - is domain name or optional id specified request while adding stream.
   
3. start stream - [POST] /stream/start/:id
 
4. Stop stream - [POST] /stream/stop/:id

5. get stats - [GET] /stream/stats

#### Postman Collections
I have added kaizo.postman_collection.json of all requests mentioned above
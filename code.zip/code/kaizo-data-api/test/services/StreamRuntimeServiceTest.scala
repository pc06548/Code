package services

import config.TestModule
import models.{AlreadyRunningResponse, NotFoundResponse, StreamEntity, SuccessResponse}
import org.mockito.Mockito.when
import org.scalatest.AsyncFunSpec

import scala.concurrent.Future


class StreamRuntimeServiceTest extends AsyncFunSpec {

  describe("StreamRuntimeServiceTest") {

    val service = new StreamRuntimeService(TestModule)

    it("should return error on starting non added stream") {
      when(TestModule.streamCrudService.get("stream1")).thenReturn(Future.successful(Right(None)))
      service.start("stream1") map { response =>
        assert(response == Right(NotFoundResponse()))
      }
    }

    it("should handle error and return error on starting non added stream and failing it") {
      when(TestModule.streamCrudService.get("stream1")).thenReturn(Future.successful(Left("failed")))
      service.start("stream1") map { response =>
        assert(response == Left("failed"))
      }
    }

    it("should start stream and should not restart on starting the same stream and stop the stream and get all the started streams") {
      val streamEntity = StreamEntity("stream1", "token", 1)
      when(TestModule.streamCrudService.get("stream1")).thenReturn(Future.successful(Right(Some(streamEntity))))
      service.start("stream1") flatMap { response =>
        assert(response == Right(SuccessResponse()))

        // starting same should not start it again
        service.start("stream1") flatMap { response =>
          assert(response == Right(AlreadyRunningResponse()))

          // get all streams
          service.getAllRunningStreams() flatMap { response =>
            assert(response == Right(List("stream1")))

            // stop the stream
            service.stop("stream1") map { response =>
              assert(response == Right(SuccessResponse()))
            }
          }
        }
      }
    }

    it("should do nothing for stream which is not started") {
      service.stop("stream2") map { response =>
        assert(response == Right(NotFoundResponse()))
      }
    }

  }

}

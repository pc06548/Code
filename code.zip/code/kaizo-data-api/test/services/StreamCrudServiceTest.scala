package services

import config.TestModule
import models.{AlreadyExistsResponse, StreamEntity, StreamStats, SuccessResponse}
import org.mockito.Mockito
import org.mockito.Mockito.{verify, when, times}
import org.scalatest.{AsyncFunSpec, BeforeAndAfterEach}

import scala.concurrent.Future

class StreamCrudServiceTest  extends AsyncFunSpec with BeforeAndAfterEach {
  import TestModule._

  override protected def beforeEach(): Unit = {
    Mockito.reset(streamRepository)
    Mockito.reset(streamStatsService)
  }

  describe("StreamCrudServiceTest") {
    val service = new StreamCrudService(TestModule)

    it("should add new stream and also add stats") {

      val streamEntity = StreamEntity("domain", "token", 1, Some("id"))
      when(streamRepository.add(Some("id"), streamEntity)(timeout, TestModule.executionContext)).thenReturn(Future.successful(Right(SuccessResponse())))
      when(streamStatsService.updateStreamStats(StreamStats("id", 1, 0))).thenReturn(Future.successful(Right(SuccessResponse())))

      val responseF = service.add(Some("id"), streamEntity)
      Thread.sleep(100)
      verify(streamStatsService).updateStreamStats(StreamStats("id", 1, 0))
      responseF.map(response => {
        assert(response == Right(SuccessResponse()))
      })(executor = TestModule.executionContext)


    }

    it("should not call stats when add new stream results in already existed") {

      val streamEntity = StreamEntity("domain", "token", 1)
      when(streamRepository.add(Some("id"), streamEntity)(timeout, TestModule.executionContext)).thenReturn(Future.successful(Right(AlreadyExistsResponse())))

      val responseF = service.add(Some("id"), streamEntity)
      Thread.sleep(100)
      verify(streamStatsService, times(0)).updateStreamStats(StreamStats("id", 1, 0))
      responseF.map(response => {
        assert(response == Right(AlreadyExistsResponse()))
      })(executor = TestModule.executionContext)

    }

    it("should stop and remove stream") {
      when(streamRuntimeService.stop("id")).thenReturn(Future.successful(Right(SuccessResponse())))
      when(streamRepository.remove("id")(timeout, TestModule.executionContext)).thenReturn(Future.successful(Right(SuccessResponse())))

      val responseF = service.remove("id")
      Thread.sleep(100)
      verify(streamRuntimeService, times(1)).stop("id")
      verify(streamRepository, times(1)).remove("id")(timeout, TestModule.executionContext)
      responseF.map(response => {
        assert(response == Right(SuccessResponse()))
      })(executor = TestModule.executionContext)

    }
  }
}

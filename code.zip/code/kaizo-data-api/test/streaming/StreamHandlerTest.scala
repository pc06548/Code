package streaming

import akka.actor.Cancellable
import akka.stream.scaladsl.RunnableGraph
import ch.qos.logback.classic.Level
import config.{SystemModule, TestModule}
import helper.{LogMessageLevelTimes, MockLogging}
import models.{StreamEntity, StreamStats, SuccessResponse}
import org.mockito.Mockito.{times, verify, when}
import org.mockito.{ArgumentMatchers, Mockito}
import org.scalatest.{BeforeAndAfterEach, FunSpecLike}
import play.api.libs.json.Json
import play.api.libs.ws.{WSClient, WSRequest, WSResponse}
import repositories.stats.StreamStatsRepository
import repositories.stream.StreamRepository
import services.StreamStatsService

import scala.concurrent.Future
import scala.concurrent.duration._

class StreamHandlerTest extends FunSpecLike with BeforeAndAfterEach with MockLogging[StreamHandler] {
  val streamEntity = StreamEntity("myDomain", "my-token", 100)
  val wsClientMock = mock[WSClient]
  val mockStreamStatsRepo = mock[StreamStatsRepository]
  val mockStreamStatsService = mock[StreamStatsService]

  val testModule = new SystemModule {
    override val streamStatsRepository: StreamStatsRepository = mockStreamStatsRepo
    override val streamRepository: StreamRepository = mock[StreamRepository]
    override val wsClient: WSClient = wsClientMock
    override val streamStatsService = mockStreamStatsService
  }

  val streamHandler = new StreamHandler(streamEntity, 0 seconds, 1 seconds)(testModule)

  override protected def beforeEach(): Unit = {
    initMockLogging
    Mockito.reset(wsClientMock)
    Mockito.reset(mockStreamStatsService)
  }

  import testModule._

  describe("StreamHandlerTest") {

    it("should start stream and send http calls, parse json response and stop stream") {
      val requestMock = mock[WSRequest]
      val responseMock = mock[WSResponse]

      when(mockStreamStatsService.getCurrentOffsetStream(streamEntity.id)).thenReturn(Future.successful(Right(4L)))
      when(mockStreamStatsService.updateStreamStats(StreamStats("myDomain", 1, 0))).thenReturn(Future.successful(Right(SuccessResponse())))

      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.addHttpHeaders(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(responseMock.status).thenReturn(200)
      when(responseMock.json).thenReturn(Json.parse(s"""{
                                                       |"random-attr": "value"
                                                       |}""".stripMargin))

      val source: RunnableGraph[Cancellable] = streamHandler.createNewStream
      val handle = source.run()(TestModule.mat)

      verify(wsClientMock, times(1)).url("https://myDomain.zendesk.com/api/v2/incremental/tickets.json")
      Thread.sleep(1000)
      verify(mockStreamStatsService, times(1)).getCurrentOffsetStream("myDomain")
      verify(requestMock, times(1)).get()
      verify(responseMock, times(1)).json
      verify(responseMock, times(1)).status
      // there is no end_time and tickets in response, hence updating stats will not be invoked
      verify(mockStreamStatsService, times(0)).updateStreamStats(StreamStats("myDomain", 100, 0))


      // now reset json to pass start time and it should be passed to update stats service
      when(responseMock.json).thenReturn(Json.parse(s"""{"count": 2,
                                                       |"end_time": 4567,
                                                       |"random-attr": "value"
                                                       |}""".stripMargin))
      Thread.sleep(1000)
      verify(mockStreamStatsService, times(2)).getCurrentOffsetStream("myDomain")
      verify(mockStreamStatsService).updateStreamStats(StreamStats("myDomain", 4567, 2))
      verify(responseMock, times(2)).json
      verify(responseMock, times(2)).status

      // after canceling the stream there should not be interactions with mock
      handle.cancel()
      Thread.sleep(200)
      verify(mockStreamStatsService, times(2)).getCurrentOffsetStream("myDomain")
      verify(responseMock, times(2)).json
      verify(responseMock, times(2)).status
      verifyMultipleMessagesMultipleTimes(
        Seq(
          LogMessageLevelTimes("""Response received: {"random-attr":"value"}""", Level.INFO, 1),
          LogMessageLevelTimes("""Response received: {"count":2,"end_time":4567,"random-attr":"value"}""", Level.INFO, 1)
        )
      )
    }

    it("should start stream and send http calls, and log and ignore non 200 responses") {
      val requestMock = mock[WSRequest]
      val responseMock = mock[WSResponse]

      when(streamStatsService.getCurrentOffsetStream(streamEntity.id)).thenReturn(Future.successful(Right(4L)))

      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.addHttpHeaders(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(responseMock.status).thenReturn(401)
      when(responseMock.json).thenReturn(Json.parse(s"""{
                                                       |"random-attr": "value"
                                                       |}""".stripMargin))

      val source: RunnableGraph[Cancellable] = streamHandler.createNewStream
      val handle = source.run()(TestModule.mat)
      verify(wsClientMock, times(1)).url("https://myDomain.zendesk.com/api/v2/incremental/tickets.json")
      Thread.sleep(500)
      verify(responseMock, times(2)).status
      verify(responseMock, times(0)).json

      handle.cancel()
      verifyMultipleMessagesMultipleTimes(
        Seq(
          LogMessageLevelTimes("Unexpected response status for request: null. Code: 401", Level.ERROR, 1)
        )
      )
    }

    it("should ignore error occurred while getting the offset") {
      val requestMock = mock[WSRequest]
      val responseMock = mock[WSResponse]

      when(streamStatsService.getCurrentOffsetStream(streamEntity.id)).thenReturn(Future.successful(Left("error")))

      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.addHttpHeaders(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(responseMock.status).thenReturn(200)
      when(responseMock.json).thenReturn(Json.parse(s"""{
                                                       |"random-attr": "value"
                                                       |}""".stripMargin))

      val source: RunnableGraph[Cancellable] = streamHandler.createNewStream
      val handle = source.run()(TestModule.mat)
      verify(wsClientMock, times(1)).url("https://myDomain.zendesk.com/api/v2/incremental/tickets.json")
      Thread.sleep(300)
      verify(responseMock, times(0)).status
      verify(responseMock, times(0)).json
      handle.cancel()
      verifyMultipleMessagesMultipleTimes(
        Seq(
          LogMessageLevelTimes("Unable to get offset for myDomain", Level.ERROR, 1)
        )
      )
    }

    it("should handle error occurred while getting the offset") {
      val requestMock = mock[WSRequest]
      val responseMock = mock[WSResponse]

      when(streamStatsService.getCurrentOffsetStream(streamEntity.id)).thenReturn(Future.failed(new Exception("Something bad")))

      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.addHttpHeaders(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(responseMock.status).thenReturn(200)
      when(responseMock.json).thenReturn(Json.parse(s"""{
                                                       |"random-attr": "value"
                                                       |}""".stripMargin))

      val source: RunnableGraph[Cancellable] = streamHandler.createNewStream
      val handle = source.run()(TestModule.mat)
      verify(wsClientMock, times(1)).url("https://myDomain.zendesk.com/api/v2/incremental/tickets.json")
      Thread.sleep(300)
      verify(responseMock, times(0)).status
      verify(responseMock, times(0)).json
      handle.cancel()
      verifyMultipleMessagesMultipleTimes(
        Seq(
          LogMessageLevelTimes("Unexpected error while getting current offset for myDomain: {}", Level.ERROR, 1)
        )
      )
    }

    it("should handle error occurred while updating the offset") {
      val requestMock = mock[WSRequest]
      val responseMock = mock[WSResponse]

      when(mockStreamStatsService.getCurrentOffsetStream(streamEntity.id)).thenReturn(Future.successful(Right(4L)))
      when(mockStreamStatsService.updateStreamStats(StreamStats("myDomain", 4567, 2))).thenReturn(Future.failed(new Exception("something wrong")))

      when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.addHttpHeaders(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(responseMock.status).thenReturn(200)
      when(responseMock.json).thenReturn(Json.parse(s"""{"count": 2,
                                                  |"end_time": 4567,
                                                  |"random-attr": "value"}""".stripMargin))

      val source: RunnableGraph[Cancellable] = streamHandler.createNewStream
      val handle = source.run()(TestModule.mat)
      verify(wsClientMock, times(1)).url("https://myDomain.zendesk.com/api/v2/incremental/tickets.json")
      Thread.sleep(400)
      verify(responseMock, times(1)).status
      verify(responseMock, times(1)).json
      verify(mockStreamStatsService, times(1)).getCurrentOffsetStream("myDomain")
      verify(mockStreamStatsService).updateStreamStats(StreamStats("myDomain", 4567, 2))
      handle.cancel()
      verifyMultipleMessagesMultipleTimes(
        Seq(
          LogMessageLevelTimes("""Response received: {"count":2,"end_time":4567,"random-attr":"value"}""", Level.INFO, 1),
          LogMessageLevelTimes("Unexpected error while updating stats StreamStats(myDomain,4567,2): {}", Level.ERROR, 1)
        )
      )
    }
  }
}

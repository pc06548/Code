package streaming

import akka.Done
import akka.actor.{ActorSystem, Cancellable}
import akka.pattern.ask
import akka.stream.ActorMaterializer
import akka.stream.scaladsl.{Keep, RunnableGraph, Sink, Source}
import akka.testkit.{TestActorRef, TestKit}
import config.TestModule
import models.{AlreadyRunningResponse, NotFoundResponse, SuccessResponse}
import org.mockito.Mockito.when
import org.scalatest.AsyncFunSpecLike
import org.scalatestplus.mockito.MockitoSugar.mock

import scala.concurrent.Future
import scala.concurrent.duration._


class StreamRuntimeActorTest extends TestKit(ActorSystem("stream-running-test-system")) with AsyncFunSpecLike {

  describe("StreamRuntimeActorTest") {

    val actorRef = TestActorRef[StreamRuntimeActor]
    val mat = ActorMaterializer()(system)

    it("should actor stream interactions") {

      // start a stream
      val streamHandlerMock = mock[StreamHandler]
      val source: RunnableGraph[Cancellable] = Source.tick(10 seconds, 10 seconds, Future.successful(1L)).toMat(Sink.ignore)(Keep.left)
      when(streamHandlerMock.createNewStream).thenReturn(source)

      ask(actorRef, StartStreamCommand("streamId", streamHandlerMock, mat))(TestModule.timeout) map {
        case elem => assert(elem == SuccessResponse)
      }

      // start same stream again should not create new
      ask(actorRef, StartStreamCommand("streamId", streamHandlerMock, mat))(TestModule.timeout) map {
        case elem => assert(elem == AlreadyRunningResponse)
      }

      // start another new stream
      ask(actorRef, StartStreamCommand("streamId1", streamHandlerMock, mat))(TestModule.timeout) map {
        case elem => assert(elem == SuccessResponse)
      }

      // verify only one stream is started
      ask(actorRef, GetAllRunningStreamsCommand)(TestModule.timeout) map {
        case elem => assert(elem == AllRunningStreamsResponse(List("streamId", "streamId1")))
      }

      // stop previously started stream
      ask(actorRef, StopStreamCommand("streamId"))(TestModule.timeout) map {
        case elem => assert(elem == SuccessResponse)
      }

      // stopping same stream again should not do anything
      ask(actorRef, StopStreamCommand("streamId"))(TestModule.timeout) map {
        case elem => assert(elem == NotFoundResponse)
      }

      // verify only one started stream exists
      ask(actorRef, GetAllRunningStreamsCommand)(TestModule.timeout) map {
        case elem => assert(elem == AllRunningStreamsResponse(List("streamId1")))
      }

    }
  }

}

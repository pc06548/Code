package endpoints

import config.TestModule
import endpoints.daos.StreamStatsResponse
import models.{StreamEntity, SuccessResponse}
import org.mockito.ArgumentMatchers._
import org.mockito.Mockito
import org.mockito.Mockito.{times, verify, when}
import org.scalatest.BeforeAndAfterEach
import org.scalatestplus.play.PlaySpec
import play.api.libs.json.Json
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers.{status, stubControllerComponents, _}

import scala.concurrent.Future

class StreamControllerTest extends PlaySpec with BeforeAndAfterEach {
  val controller = new StreamController(TestModule, stubControllerComponents())
  import TestModule._

  override protected def beforeEach(): Unit = {
    Mockito.reset(streamCrudService)
    Mockito.reset(streamRuntimeService)
    Mockito.reset(streamStatsService)
  }

  "StreamControllerTest" should {

    "should return ok on successfully adding stream" in {

      val streamEntity = StreamEntity("domainName", "token1", 123)
      when(streamCrudService.add(any(), any())).thenReturn(Future.successful(Right(SuccessResponse())))

      val resultF: Future[Result] = controller.add().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{"stream": {
          |   "domain":"domainName",
          |   "accessToken":"token1",
          |   "begin":123
          | }
          |}
          |""".stripMargin)))
      assert(status(resultF)(TestModule.timeout) == OK)

      assert(contentAsString(resultF)(TestModule.timeout) == """{"message":"success"}""")

      verify(streamCrudService, times(1)).add(None, streamEntity)

    }

    "should return bad request on adding stream with wrong request" in {
      when(streamCrudService.add(any(), any())).thenReturn(Future.successful(Right(SuccessResponse())))

      val resultF: Future[Result] = controller.add().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{"stream": {
          |   "domain":"domainName",
          |   "accessToken":"token1",
          |   "begin":"123"
          | }
          |}
          |""".stripMargin)))
      assert(status(resultF)(TestModule.timeout) == BAD_REQUEST)
      assert(contentAsString(resultF)(TestModule.timeout) == "invalid request")

      verify(streamCrudService, times(0)).add(any(), any())

    }

    "should return internal server error request on error occurred while adding stream" in {
      when(streamCrudService.add(any(), any())).thenReturn(Future.successful(Left("error")))

      val resultF: Future[Result] = controller.add().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{"stream": {
          |   "domain":"domainName",
          |   "accessToken":"token1",
          |   "begin":123
          | }
          |}
          |""".stripMargin)))
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "error")

      verify(streamCrudService, times(1)).add(any(), any())

    }

    "should return internal server error request on complete failure while adding stream" in {
      when(streamCrudService.add(any(), any())).thenReturn(Future.failed(new Exception("error")))

      val resultF: Future[Result] = controller.add().apply(FakeRequest().withJsonBody(Json.parse(
        """
          |{"stream": {
          |   "domain":"domainName",
          |   "accessToken":"token1",
          |   "begin":123
          | }
          |}
          |""".stripMargin)))
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "Something went wrong")

      verify(streamCrudService, times(1)).add(any(), any())

    }

    "should return ok on successfully removing stream" in {

      when(streamCrudService.remove(any())).thenReturn(Future.successful(Right(SuccessResponse())))

      val resultF: Future[Result] = controller.remove("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == OK)

      assert(contentAsString(resultF)(TestModule.timeout) == """{"message":"success"}""")

      verify(streamCrudService, times(1)).remove("id1")

    }

    "should return internal server error request on error occurred while removing stream" in {
      when(streamCrudService.remove(any())).thenReturn(Future.successful(Left("error")))

      val resultF: Future[Result] = controller.remove("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "error")

      verify(streamCrudService, times(1)).remove(any())

    }

    "should return internal server error request on complete failure while removing stream" in {
      when(streamCrudService.remove(any())).thenReturn(Future.failed(new Exception("error")))

      val resultF: Future[Result] = controller.remove("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "Something went wrong")

      verify(streamCrudService, times(1)).remove(any())
    }

    "should return ok on successfully starting stream" in {

      when(streamRuntimeService.start(any())).thenReturn(Future.successful(Right(SuccessResponse())))

      val resultF: Future[Result] = controller.start("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == OK)

      assert(contentAsString(resultF)(TestModule.timeout) == """{"message":"success"}""")

      verify(streamRuntimeService, times(1)).start("id1")

    }

    "should return internal server error request on error occurred while starting stream" in {
      when(streamRuntimeService.start(any())).thenReturn(Future.successful(Left("error")))

      val resultF: Future[Result] = controller.start("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "error")

      verify(streamRuntimeService, times(1)).start(any())

    }

    "should return internal server error request on complete failure while starting stream" in {
      when(streamRuntimeService.start(any())).thenReturn(Future.failed(new Exception("error")))

      val resultF: Future[Result] = controller.start("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "Something went wrong")

      verify(streamRuntimeService, times(1)).start(any())
    }

    "should return ok on successfully stopping stream" in {

      when(streamRuntimeService.stop(any())).thenReturn(Future.successful(Right(SuccessResponse())))

      val resultF: Future[Result] = controller.stop("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == OK)

      assert(contentAsString(resultF)(TestModule.timeout) == """{"message":"success"}""")

      verify(streamRuntimeService, times(1)).stop("id1")

    }

    "should return internal server error request on error occurred while stopping stream" in {
      when(streamRuntimeService.stop(any())).thenReturn(Future.successful(Left("error")))

      val resultF: Future[Result] = controller.stop("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "error")

      verify(streamRuntimeService, times(1)).stop(any())

    }

    "should return internal server error request on complete failure while stopping stream" in {
      when(streamRuntimeService.stop(any())).thenReturn(Future.failed(new Exception("error")))

      val resultF: Future[Result] = controller.stop("id1").apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "Something went wrong")

      verify(streamRuntimeService, times(1)).stop(any())
    }

    "should return list of stats" in {

      val streamStats1 = StreamStatsResponse("id1", 123, 43, true)
      val streamStats2 = StreamStatsResponse("id2", 234, 23, false)

      when(streamStatsService.getAllStreamStats()).thenReturn(Future.successful(Right(List(streamStats1, streamStats2))))

      val resultF: Future[Result] = controller.getAllStreamStats().apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == OK)

      assert(contentAsString(resultF)(TestModule.timeout) == """[{"id":"id1","currentOffset":123,"noOfTicketsSeen":43,"isRunning":true},{"id":"id2","currentOffset":234,"noOfTicketsSeen":23,"isRunning":false}]""")

      verify(streamStatsService, times(1)).getAllStreamStats()

    }

    "should return internal server error request on error occurred while returning stream stats" in {
      when(streamStatsService.getAllStreamStats()).thenReturn(Future.successful(Left("error")))

      val resultF: Future[Result] = controller.getAllStreamStats().apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "error")

      verify(streamStatsService, times(1)).getAllStreamStats()

    }

    "should return internal server error request on complete failure while returning stream stats" in {
      when(streamStatsService.getAllStreamStats()).thenReturn(Future.failed(new Exception("error")))

      val resultF: Future[Result] = controller.getAllStreamStats().apply(FakeRequest())
      assert(status(resultF)(TestModule.timeout) == INTERNAL_SERVER_ERROR)
      assert(contentAsString(resultF)(TestModule.timeout) == "Something went wrong")

      verify(streamStatsService, times(1)).getAllStreamStats()
    }
  }

}

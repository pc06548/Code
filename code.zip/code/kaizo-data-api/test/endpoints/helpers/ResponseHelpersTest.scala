package endpoints.helpers

import akka.util.ByteString
import models.SuccessResponse
import org.scalatest.AsyncFunSpecLike
import play.api.http.HttpEntity
import play.api.libs.json.Json
import play.api.mvc.ResponseHeader

import scala.concurrent.Future

class ResponseHelpersTest extends AsyncFunSpecLike {
  import models.GenericAPIResponseJsonWrites._

  describe("ResponseHelpersTest") {

    it("should handle success response") {

      val responseF = Future.successful(Right(SuccessResponse()))
      val resultF =  ResponseHelpers.eitherToResponse(responseF, "some operation")
      Thread.sleep(10)
      resultF map { result =>
        assert(result.header == ResponseHeader(200, Map.empty))
        assert(result.body == HttpEntity.Strict(ByteString(Json.toJson(SuccessResponse()).toString()), Some("application/json")))
      }
    }

  }

  it("should handle error response") {

    val responseF = Future.successful(Left("Error"))
    val resultF =  ResponseHelpers.eitherToResponse(responseF, "some operation")
    Thread.sleep(10)
    resultF map { result =>
      assert(result.header == ResponseHeader(500, Map.empty))
      assert(result.body == HttpEntity.Strict(ByteString("Error"), Some("text/plain")))
    }
  }


  it("should handle failure in response") {

    val responseF = Future.failed(new Exception("error"))
    val resultF =  ResponseHelpers.eitherToResponse(responseF, "some operation")
    Thread.sleep(10)
    resultF map { result =>
      assert(result.header == ResponseHeader(500, Map.empty))
      assert(result.body == HttpEntity.Strict(ByteString("Something went wrong"), Some("text/plain")))
    }
  }

}

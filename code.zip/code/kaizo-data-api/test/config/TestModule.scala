package config
import org.scalatestplus.mockito.MockitoSugar.mock
import repositories.stats.StreamStatsRepository
import repositories.stream.StreamRepository
import services.{StreamCrudService, StreamRuntimeService, StreamStatsService}

object TestModule extends SystemModule {

  override val streamRepository = mock[StreamRepository]
  override val streamStatsRepository: StreamStatsRepository = mock[StreamStatsRepository]

  override val streamCrudService =  mock[StreamCrudService]
  override val streamRuntimeService =  mock[StreamRuntimeService]
  override val streamStatsService = mock[StreamStatsService]
}

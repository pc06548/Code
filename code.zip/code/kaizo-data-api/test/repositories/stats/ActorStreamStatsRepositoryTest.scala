package repositories.stats

import akka.actor.{ActorSystem, Props}
import akka.testkit.{TestActorRef, TestKit}
import akka.util.Timeout
import models.{StreamStats, SuccessResponse}
import org.scalatest.AsyncFunSpecLike

import scala.concurrent.duration._

class ActorStreamStatsRepositoryTest extends TestKit(ActorSystem("StreamStatsTest")) with AsyncFunSpecLike {
  implicit val timeout = Timeout(5 seconds)

  val props = Props.create(classOf[StreamStatsActor])
  val actorRef = TestActorRef.create(system, props,"stream-stats-test-actor")

  val repo = new ActorStreamStatsRepository(actorRef)

  describe("ActorStreamStatsRepositoryTest") {

    val streamStats = StreamStats("id1", 10, 100)
    it("should update stats and get current offset and all stats") {
      repo.updateStreamStats(streamStats) flatMap { result =>
        assert(result == Right(SuccessResponse()))

        // get current offset
        repo.getCurrentOffsetStream("id1") map { result =>
          assert(result == Right(100))
        }

        // get all stream stats
        repo.getAllStreamStats() map { result =>
          assert(result == Right(List(streamStats)))
        }
      }
    }

    it("should not return offset for non existing stream") {
      repo.getCurrentOffsetStream("id2") map { result =>
        assert(result == Left("domain not found"))
      }
    }
  }

}

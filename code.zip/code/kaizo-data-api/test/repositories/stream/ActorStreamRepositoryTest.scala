package repositories.stream

import akka.actor.{ActorSystem, Props}
import akka.testkit.{TestActorRef, TestKit}
import akka.util.Timeout
import models.{AlreadyExistsResponse, StreamEntity, SuccessResponse}
import org.scalatest.AsyncFunSpecLike

import scala.concurrent.duration._

class ActorStreamRepositoryTest extends TestKit(ActorSystem("StreamTest")) with AsyncFunSpecLike {
  implicit val timeout = Timeout(5 seconds)

  val props = Props.create(classOf[StreamRepositoryActor])
  val actorRef = TestActorRef.create(system, props,"stream-test-actor")

  val repo = new ActorStreamRepository(actorRef)

  describe("ActorStreamRepositoryTest") {

    val streamEntity = StreamEntity("domainName", "token", 123)
    it("should test stream interactions") {
      // add stream without id
      repo.add(None, streamEntity) flatMap { result =>
        assert(result == Right(SuccessResponse()))

        // add stream with id
        repo.add(Some("id1"), streamEntity) flatMap { result =>
          assert(result == Right(SuccessResponse()))

          // should not add duplicate stream
          repo.add(None, streamEntity) flatMap { result =>
            assert(result == Right(AlreadyExistsResponse()))

            // should get stream by id
            repo.get("domainName") map { result =>
              assert(result == Right(Some(streamEntity)))
            }

            // should get all streams
            repo.getAll() map { result =>
              assert(result == Right(List(streamEntity, streamEntity)))
            }

            // should remove stream
            repo.remove("id1") flatMap { result =>
              assert(result == Right(SuccessResponse()))

              // getting removed stream should result in none
              repo.get("id1") map { result =>
                assert(result == Right(None))
              }
            }
          }
        }
      }
    }
  }

}

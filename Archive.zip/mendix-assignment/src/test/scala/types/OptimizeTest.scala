package types

import org.scalatest.{FunSpec, Matchers}
import play.api.libs.json.{JsArray, JsBoolean, JsNull, JsNumber, JsObject, JsString, JsValue, Json}
import types.Optimize._

class OptimizeTest extends FunSpec with Matchers {

  describe("String representation") {
    it("should give string of string and jsString") {
      val json: JsObject = Json.obj(("firstName", JsString("Prashant")))
      json.fields.head.optimizeAndStringify should be(""""firstName" : "Prashant"""")
    }

    it("should give string of string and jsNumber") {
      val json: JsObject = Json.obj(("speed", JsNumber(100.1)))
      json.fields.head.optimizeAndStringify should be(""""speed" : 100.1""")
    }

    it("should give string of string and jsBoolean") {
      val json: JsObject = Json.obj(("isIll", JsBoolean(false)))
      json.fields.head.optimizeAndStringify should be(""""isIll" : false""")
    }

    it("should give string of string and jsNull") {
      val json: JsObject = Json.obj(("danger", JsNull))
      json.fields.head.optimizeAndStringify should be(""""danger" : null""")
    }

    it("should give string of string and jsObject") {
      val json: JsObject = Json.obj(("name", Json.obj(("firstName", "Prashant"))))
      json.fields.head.optimizeAndStringify should be(""""name" : { "firstName" : "Prashant" }""")
    }

    it("should give string of string and jsArray") {
      val json: JsObject = Json.obj(("personal", JsArray(Seq(JsString("password"), Json.obj(("firstName", "Prashant"))))))
      json.fields.head.optimizeAndStringify should be(""""personal" : [ "password" , { "firstName" : "Prashant" } ]""")
    }

    it("should give string of jsObject with primitive first and non primitive later") {
      val json: JsObject = Json.obj(("personal", Json.obj(("name",  Json.obj(("firstName", "Prashant"))), ("password", JsString("hack")))))
      json.optimizeAndStringify should be("""{ "personal" : { "password" : "hack" , "name" : { "firstName" : "Prashant" } } }""")
    }

    it("should give string of jsArray with primitive first and non primitive later") {
      val json: JsArray = JsArray(Seq(Json.obj(("firstName", "Prashant")), JsString("password")))
      json.optimizeAndStringify should be("""[ "password" , { "firstName" : "Prashant" } ]""")
    }
  }
}

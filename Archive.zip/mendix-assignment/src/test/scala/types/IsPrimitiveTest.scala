package types

import org.scalatest.{FunSpec, Matchers}
import play.api.libs.json.{JsArray, JsBoolean, JsNull, JsNumber, JsObject, JsString, Json}
import types.IsPrimitive._

class IsPrimitiveTest extends FunSpec with Matchers {

  describe("Is Primitive") {
    it("should return true for jsString, jsBoolean, jsNull and jsNumber") {
      val json: JsObject = Json.obj(
        ("isString", JsString("something")),
        ("isFalse", JsBoolean(false)),
        ("isNumber", JsNumber(1.1)),
        ("isNull", JsNull)
      )
      json.fields(0)._2.isPrimitive should be(true)
      json.fields(1)._2.isPrimitive should be(true)
      json.fields(2)._2.isPrimitive should be(true)
      json.fields(3)._2.isPrimitive should be(true)
    }

    it("should return false for jsObject and jsArray") {
      val json: JsObject = Json.obj(
        ("jsArray", JsArray(Seq())),
        ("jsObject", Json.obj(("name", JsString("Prashant"))))
      )
      json.fields(0)._2.isPrimitive should be(false)
      json.fields(1)._2.isPrimitive should be(false)
    }
  }

}

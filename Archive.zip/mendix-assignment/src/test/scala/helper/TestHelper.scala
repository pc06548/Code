package helper

object TestHelper {

  def onlyText(string: String) = string.replace("\n", "").replace(" ", "")

}

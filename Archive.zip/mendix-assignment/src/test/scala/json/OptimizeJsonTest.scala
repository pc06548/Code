package json

import java.io.{ByteArrayInputStream, ByteArrayOutputStream}

import org.scalatest.Matchers
import helper.TestHelper

class OptimizeJsonTest extends org.scalatest.FunSpec with Matchers {

  describe("Optimize Json") {

    it("should not output anything for incorrect json") {
      val jsonString = "hi"
      val input = new ByteArrayInputStream(jsonString.getBytes)
      val output = new ByteArrayOutputStream()
      OptimizeJson.optimize(input, output)
      output.toString should be("")
    }

    it("should handle empty json") {
      val jsonString = "{}"
      val input = new ByteArrayInputStream(jsonString.getBytes)
      val output = new ByteArrayOutputStream()
      OptimizeJson.optimize(input, output)
      output.toString should be("{  }")
    }

    it("should handle empty json array") {
      val jsonString = "[]"
      val input = new ByteArrayInputStream(jsonString.getBytes)
      val output = new ByteArrayOutputStream()
      OptimizeJson.optimize(input, output)
      output.toString should be("[  ]")
    }

    it("should optimize json correctly with primitive and non primitive separation") {
      val jsonString =
        """
          |{
          |    "FirstName": "Arthur",
          |    "LastName": "Bertrand",
          |    "Address": {
          |        "StreetName": "Gedempte Zalmhaven",
          |        "Number": "4K",
          |        "City": {
          |            "Name": "Rotterdam",
          |            "Country": "The Netherlands"
          |        },
          |        "ZipCode": "3011 BT"
          |    },
          |    "Age": 35,
          |    "Hobbies" : [
          |         {
          |           "do not like": "exercise"
          |         },
          |         "Rowing"
          |    ],
          |    "Super Nested" : {
          |         "Other Hobbies": [
          |             {
          |                 "do not like": [
          |                     "walking",
          |                     {
          |                         "but like": "running"
          |                     },
          |                     "slow walking"
          |                 ]
          |             },
          |             "Cycling",
          |             null
          |         ],
          |         "let me come": 0
          |    },
          |    "IsNew": false
          |}
        """.stripMargin
      val input = new ByteArrayInputStream(jsonString.getBytes)
      val output = new ByteArrayOutputStream()
      OptimizeJson.optimize(input, output)

      val expected =
        """
          |{
          |   "FirstName" : "Arthur" ,
          |   "LastName" : "Bertrand" ,
          |   "Age" : 35 ,
          |   "IsNew" : false ,
          |   "Address" : {
          |       "StreetName" : "Gedempte Zalmhaven" ,
          |       "Number": "4K" ,
          |       "ZipCode": "3011 BT",
          |       "City": {
          |            "Name": "Rotterdam" ,
          |            "Country": "The Netherlands"
          |        }
          |   },
          |   "Hobbies" : [
          |         "Rowing" ,
          |         {
          |           "do not like": "exercise"
          |         }
          |   ],
          |   "Super Nested" : {
          |         "let me come": 0,
          |         "Other Hobbies": [
          |            "Cycling",
          |             null,
          |             {
          |                 "do not like": [
          |                     "walking",
          |                     "slow walking",
          |                     {
          |                         "but like": "running"
          |                     }
          |                 ]
          |             }
          |         ]
          |    }
          |}
        """.stripMargin.stripLineEnd


      TestHelper.onlyText(output.toString) should be(TestHelper.onlyText(expected))
    }

    it("should handle json array") {
      val jsonString = """[ {"some" : "value"}, null, 10, "hello" ]"""
      val input = new ByteArrayInputStream(jsonString.getBytes)
      val output = new ByteArrayOutputStream()
      OptimizeJson.optimize(input, output)
      TestHelper.onlyText(output.toString) should be(TestHelper.onlyText("""[ null, 10, "hello", { "some": "value"} ]"""))
    }


  }

}

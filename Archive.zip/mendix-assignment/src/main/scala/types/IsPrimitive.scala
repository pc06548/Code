package types

import play.api.libs.json.{JsBoolean, JsNull, JsNumber, JsString, JsValue}

trait IsPrimitive[A] {
  def isPrimitive(a: A): Boolean
}

object IsPrimitive {
  def apply[A](implicit ip: IsPrimitive[A]): IsPrimitive[A] = ip

  implicit class IsPrimitiveOps[A: IsPrimitive](a: A) {
    def isPrimitive = IsPrimitive[A].isPrimitive(a)
  }

  implicit val isJsValuePrimitive: IsPrimitive[JsValue] =
    (jsValue: JsValue) => {
      jsValue match {
        case _@(JsString(_) | JsNumber(_) | JsBoolean(_) | JsNull) => true
        case _ => false
      }
    }

}
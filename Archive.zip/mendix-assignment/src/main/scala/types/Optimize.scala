package types

import play.api.libs.json.{JsArray, JsBoolean, JsNull, JsNumber, JsObject, JsString, JsValue}
import types.IsPrimitive._

trait Optimize[A] {
  def optimizeAndStringify(a: A): String
}

object Optimize {
  def apply[A](implicit sr: Optimize[A]): Optimize[A] = sr

  implicit class StringRepresentationOps[A: Optimize](a: A) {
    def optimizeAndStringify = Optimize[A].optimizeAndStringify(a)
  }

  implicit val stringAndJsValueStringRepresentation: Optimize[(String, JsValue)] =
    stringAndJsValue =>
      s""""${stringAndJsValue._1}" : ${stringAndJsValue._2.optimizeAndStringify}"""

  implicit val jsValueStringRepresentation: Optimize[JsValue] =
    jsValue => jsValue match {
      case b: JsString => b.toString()
      case b: JsNumber => b.toString()
      case b: JsBoolean => b.toString()
      case b: JsObject => b.optimizeAndStringify
      case b: JsArray => b.optimizeAndStringify
      case JsNull => "null"
    }

  implicit val jsObjectStringRepresentation: Optimize[JsObject] =
    jsObject => {
      val (primitive, nonPrimitive) = jsObject.fields.partition(_._2.isPrimitive)
      s"{ ${(primitive.map(_.optimizeAndStringify) ++ nonPrimitive.par.map(_.optimizeAndStringify)).mkString(" , ")} }"
    }

  implicit val jsArrayStringRepresentation: Optimize[JsArray] =
    jsArray => {
      val (primitive, nonPrimitive) = jsArray.value.partition(_.isPrimitive)
      s"[ ${(primitive.map(_.optimizeAndStringify) ++ nonPrimitive.par.map(_.optimizeAndStringify)).mkString(" , ")} ]"
    }
}

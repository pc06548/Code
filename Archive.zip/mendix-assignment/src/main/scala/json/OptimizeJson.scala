package json

import java.io.{InputStream, OutputStream}

import play.api.libs.json._
import types.Optimize._

import scala.util.{Failure, Success, Try}


object OptimizeJson {
  def optimize(input: InputStream, output: OutputStream) = {
    Try(Json.parse(input)) match {
      case Success(json) =>
        output.write(json.optimizeAndStringify.toCharArray.map(_.toByte))
        output.flush()
      case Failure(_) =>
        // todo
        output.flush()
    }
  }
}

* Solution uses Scala, SBT, Play JSON and Scala test.
* Source code location - /src
* Tests location - /test
* With sbt setup on machine, tests can be ran with `sbt test` command.

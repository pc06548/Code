// For this exercise you need to rewrite the `sumSquares` function using different styles:
//   1) combining functions from the standard scala collection library
//   2) using pure scala without any var or standard library function
//   3) write the most efficient implementation of 2)? How can we make sure the implementation
//      is actually efficient?

object Exercise1 extends App {

  val list = List(1, 2, 3, 4, 5)

  // Procedural implementation
  def sumSquares(xs: List[Int]): Int = {
    var acc = 0

    for (i ← 0 until xs.length)
      acc += xs(i) * xs(i)

    acc
  }

  // Implement this using standard library functions on `list`
  val stdlibRes: Int = list.foldLeft(0)((res, elem) => res + elem * elem)

  // Implement this using pure scala, no library function and no var
  // tail recursive implementation
  def sumSquaresPure(xs: List[Int]): Int = {
    def sumSquaresPureR(xs: List[Int], result: Int): Int = xs match {
      case Nil => result
      case head :: tail => sumSquaresPureR(tail, result + (head * head))
    }
    sumSquaresPureR(xs, 0)
  }

  // Implement a function like sumSquaresPure that is also efficient
  def efficientSumSquaresPure(xs: List[Int]): Int = xs.par.map(elem => elem * elem).fold(0)(_ + _)

  println(sumSquares(list))
  println(stdlibRes)
  println(sumSquaresPure(list))
  println(efficientSumSquaresPure(list))
}

package cats

// This exercise is similar to Exercise2, but, instead of having functions returning `Future`s, you
// have akka actors. You can think of `UserLoader` and `PetLoader` as helper actors that, again,
// retrieve information from a database. The task is to implement the `PetOwnerLoader` actor that
// makes use of `UserLoader` and `PetLoader` to return a `PetOwner` instance for a given user id, or
// `None` if the user id does not exist. When implementing the `PetOwnerLoader` actor you can choose
// to load `Pet` data sequentially, in parallel with no limits to the number of concurrent request
// or in parallel with a maximum number of parallel requests (e.g. no more than 2 requests at a
// time). Add a comment to make it explicit which strategy you have chosen. Also add comments on any
// extra requirement or limitation of your implementation you consider worth noting (e.g. which
// usage patterns are supported and which are not). As a bonus, you can provide multiple
// implementations for different `Pet` data loading strategies. Do not modify anything except the
// `PetOwnerLoader` actor, its companion object and the list of imports

import akka.actor.{Actor, ActorRef, ActorSystem, Props}
import akka.pattern.{ask, pipe}
import akka.util.Timeout
import cats.effect.IO
import cats.implicits._

import scala.concurrent.Await
import scala.concurrent.duration._
import scala.util._

object Exercise3 extends App {
  implicit val timeout: Timeout = 5.seconds

  case class User(id: String, name: String, petIds: List[String])
  case class Pet(id: String, name: String)
  case class PetOwner(user: User, pet: List[Pet])

  object UserLoader {
    val props: Props = Props[UserLoader]

    case class Load(id: String)
    case class UserNotFound(id: String)
  }

  class UserLoader extends Actor {
    import UserLoader._

    def receive: Receive = {
      case Load("A") ⇒ sender ! User("A", "Bob", List("1", "2", "3"))
      case Load("B") ⇒ sender ! User("B", "Joe", List("4"))
      case Load("C") ⇒ sender ! User("C", "Fred", List("5", "6", "9"))
      case Load(id)  ⇒ sender ! UserNotFound(id)
    }
  }

  object PetLoader {
    val props: Props = Props[PetLoader]

    case class Load(id: String)
    case class PetNotFound(id: String)
  }

  class PetLoader extends Actor {
    import PetLoader._

    def receive: Receive = {
      case Load("1") ⇒ sender ! Pet("1", "Baldy")
      case Load("2") ⇒ sender ! Pet("2", "Summer")
      case Load("4") ⇒ sender ! Pet("4", "Ruptide")
      case Load("5") ⇒ sender ! Pet("5", "Silver")
      case Load("6") ⇒ sender ! Pet("6", "Chica")
      case Load(id)  ⇒ sender ! PetNotFound(id)
    }
  }

  object PetOwnerLoader {
    val props: Props = Props[PetOwnerLoader]

    case class Load(id: String)
    case class UserNotFound(id: String)
  }

  class PetOwnerLoader(userLoader: ActorRef, petLoader: ActorRef) extends Actor {

    import PetOwnerLoader._
    import context.dispatcher

    def userIO(userId: String): IO[Option[User]] =
      IO.fromFuture(IO((userLoader ? UserLoader.Load(userId))
        .mapTo[User].map(Some(_))
        .recover { case _ => None }))

    def petIO(petId: String): IO[Option[Pet]] = IO.fromFuture(IO(
      (petLoader ? PetLoader.Load(petId))
        .mapTo[Pet].map(Some(_))
        .recover { case _ => None }
    ))

    def receive: Receive = {
      case Load(userId) =>

        val resultIO = for {

          userO <- userIO(userId)

          petOwner <- userO match {
            case Some(user) =>
              val petIds = user.petIds
              val petsIO: IO[List[Pet]] = petIds.map(petId => petIO(petId)).parSequence.map(_.flatten)
              petsIO.map(pets => Some(PetOwner(user, pets)))
            case None =>
              IO.pure(None)
          }

        } yield {
          petOwner
        }

        Try {
          resultIO.unsafeToFuture()
        } match {
          case Success(value) => value.pipeTo(sender())
          case Failure(_) => // handle error
        }
    }
  }

  val system = ActorSystem("exercise3")

  val userLoader = system.actorOf(UserLoader.props, "userLoader")
  val petLoader = system.actorOf(PetLoader.props, "petLoader")
  val petOwnerLoader = system.actorOf(Props(new PetOwnerLoader(userLoader, petLoader)), "petOwnerLoader")

  val response1 = petOwnerLoader ? PetOwnerLoader.Load("A")
  val response2 = petOwnerLoader ? PetOwnerLoader.Load("B")
  val response3 = petOwnerLoader ? PetOwnerLoader.Load("C")
  val response4 = petOwnerLoader ? PetOwnerLoader.Load("D")

  println(Await.result(response1, 5.seconds))
  println(Await.result(response2, 5.seconds))
  println(Await.result(response3, 5.seconds))
  println(Await.result(response4, 5.seconds))

  system.terminate()
}

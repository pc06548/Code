// For this exercise you need to write the getPetOwner function, that, given a user id, returns a
// `PetOwner` instance with the `User` and the list of its `Pet`s. If the user id does not exist,
// the function must return `None`. Moreover, if a pet does not exist, it must not appear in the
// `PetOwner` pet list. The `getUser` and `getPet` function are already implemented, you can think
// of them as functions accessing a database to retrieve information (hence the `Future` in the type
// signature). You also need to implement code to transform `petOwnersL` to `petOwnersF`. Do not
// change anything else, apart from adding missing type signatures if you need them. You can use the
//  `cats` library if you want (add imports as needed)

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration._
import scala.concurrent.{Await, Future}

object Exercise2 extends App {
  case class User(id: String, name: String, petIds: List[String])
  case class Pet(id: String, name: String)
  case class PetOwner(user: User, pet: List[Pet])

  def getUser(id: String): Future[Option[User]] = Future.successful(id match {
    case "A" ⇒ Some(User("A", "Bob", List("1", "2", "3")))
    case "B" ⇒ Some(User("B", "Joe", List("4")))
    case "C" ⇒ Some(User("C", "Fred", List("5", "6")))
    case _   ⇒ None
  })

  def getPet(id: String): Future[Option[Pet]] = Future.successful(id match {
    case "1" ⇒ Some(Pet("1", "Baldy")) 
    case "2" ⇒ Some(Pet("2", "Summer")) 
    case "3" ⇒ None
    case "4" ⇒ Some(Pet("4", "Ruptide")) 
    case "5" ⇒ Some(Pet("5", "Silver")) 
    case "6" ⇒ Some(Pet("6", "Chica")) 
    case _   ⇒ None
  })

  // Implement this
  def getPetOwner(userId: String): Future[Option[PetOwner]] =
    for {
      userOption <- getUser(userId)
      petIds = userOption.map(user => user.petIds).getOrElse(List.empty)
      pets <- Future.sequence(petIds.par.map(petId => getPet(petId)).toList).map(_.flatten)
    } yield {
      userOption.map(user => PetOwner(user, pets))
    }

  val petOwnersL = List("A", "B", "C", "D") map getPetOwner

  // Implement this
  val petOwnersF: Future[List[Option[PetOwner]]] = Future.sequence(petOwnersL)

  println(Await.result(petOwnersF, 5.second))
}

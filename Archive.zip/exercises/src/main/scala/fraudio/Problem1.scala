import java.io._
import java.math._
import java.security._
import java.text._
import java.util._
import java.util.concurrent._
import java.util.function._
import java.util.regex._
import java.util.stream._
import scala.collection.immutable._
import scala.collection.mutable._
import scala.collection.concurrent._
import scala.concurrent._
import scala.io._
import scala.math._
import scala.sys._
import scala.util.matching._
import scala.reflect._

class SinglyLinkedListNode(nodeData: Int) {
  val data = nodeData
  var next: SinglyLinkedListNode = null
}

class SinglyLinkedList(
                        var head: SinglyLinkedListNode = null,
                        var tail: SinglyLinkedListNode = null
                      ) {
  def insertNode(nodeData: Int): Unit = {
    val node = new SinglyLinkedListNode(nodeData)

    if (this.head == null) {
      this.head = node
    } else {
      this.tail.next = node
    }

    this.tail = node
  }

  def nodeExists(nodeData: Int): Boolean = {
    nodeExistsR(nodeData, this.head)
  }

  private def nodeExistsR(nodeData: Int, currNode: SinglyLinkedListNode): Boolean = {
    if (currNode == null) {
      false
    } else if (nodeData == currNode.data) {
      true
    } else {
      nodeExistsR(nodeData, currNode.next)
    }
  }
}

object SinglyLinkedListPrintHelper {
  def printList(head: SinglyLinkedListNode, sep: String, printWriter: PrintWriter): Unit = {
    var node = head

    while (node != null) {
      printWriter.print(node.data)

      node = node.next

      if (node != null) {
        printWriter.print(sep)
      }
    }
  }
}



object Result {

  /*
   * Complete the 'condense' function below.
   *
   * The function is expected to return an INTEGER_SINGLY_LINKED_LIST.
   * The function accepts INTEGER_SINGLY_LINKED_LIST head as parameter.
   */

  /*
   * For your reference:
   *
   * SinglyLinkedListNode {
   *     data: Int
   *     next: SinglyLinkedListNode
   * }
   *
   */

  def condense(head: SinglyLinkedListNode): SinglyLinkedListNode = {
    // Write your code here
    condenseR(head, new SinglyLinkedList()).head
  }

  def condenseR(currNode: SinglyLinkedListNode, result: SinglyLinkedList): SinglyLinkedList = {
    if (currNode == null) {
      result
    } else {
      if (!result.nodeExists(currNode.data)){
        result.insertNode(currNode.data)
      }
      condenseR(currNode.next, result)
    }
  }

}

object Solution {
  def main(args: Array[String]) {
    val printWriter = new PrintWriter(sys.env("OUTPUT_PATH"))

    val head = new SinglyLinkedList()

    val headCount = StdIn.readLine.trim.toInt

    for (_ <- 0 until headCount) {
      val headItem = StdIn.readLine.trim.toInt
      head.insertNode(headItem)
    }

    val result = Result.condense(head.head)

    SinglyLinkedListPrintHelper.printList(result, "\n", printWriter)
    printWriter.println()

    printWriter.close()
  }
}
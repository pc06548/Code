import java.io._
import java.math._
import java.security._
import java.text._
import java.util._
import java.util.concurrent._
import java.util.function._
import java.util.regex._
import java.util.stream._

import scala.Predef.Map
import scala.collection.immutable.{IndexedSeq, _}
import scala.collection.mutable._
import scala.collection.concurrent._
import scala.concurrent._
import scala.io._
import scala.math._
import scala.sys._
import scala.util.matching._
import scala.reflect._



object Result2 {

  /*
   * Complete the 'longestVowelSubsequence' function below.
   *
   * The function is expected to return an INTEGER.
   * The function accepts STRING s as parameter.
   */

  def longestVowelSubsequence(s: String): Int = {

    val vowels = "aeiou"

    def rec(index: Int, sub: String): String = {
      if (index >= s.length) {
        sub
      } else if (sub.isEmpty) {
        if (s(index) == 'a') {
          rec(index + 1, "a")
        } else {
          rec(index + 1, sub)
        }
      } else if (sub(sub.length - 1) == s(index)) {
        rec(index + 1, sub + s(index))
      } else {
        val currChar = sub(sub.length - 1)
        val nextCharIndex = if (vowels.indexOf(currChar) < 4) vowels.indexOf(currChar) + 1 else 4
        val nextChar = vowels(nextCharIndex)
        if (s(index) == nextChar) {
          val n1 = rec(index + 1, sub + s(index))
          val n2 = rec(index + 1, sub)
          val n1Length = if (n1.last == 'u') n1.length else 0
          val n2Length = if (n2.last == 'u') n2.length else 0
          if (n1Length > n2Length)  n1
          else  n2
        } else {
          rec(index + 1, sub)
        }
      }
    }

    val sub = rec(0, "")

    if (sub.last == 'u') sub.length
    else 0
  }

}

object Solution1 {
  def main(args: Array[String]) {
    val printWriter = new PrintWriter(sys.env("OUTPUT_PATH"))

    val s = StdIn.readLine

    val result = Result2.longestVowelSubsequence(s)

    printWriter.println(result)

    printWriter.close()
  }
}

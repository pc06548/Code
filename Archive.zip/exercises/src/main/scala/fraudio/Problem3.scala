import java.io._
import java.math._
import java.security._
import java.text._
import java.util.Arrays
import java.util.concurrent._
import java.util.function._
import java.util.regex._
import java.util.stream._
import scala.collection.immutable._
import scala.collection.concurrent._
import scala.concurrent._
import scala.io._
import scala.math._
import scala.sys._
import scala.util.matching._
import scala.reflect._


object Result1 {

  /*
   * Complete the 'connectedSum' function below.
   *
   * The function is expected to return an INTEGER.
   * The function accepts following parameters:
   *  1. INTEGER n
   *  2. STRING_ARRAY edges
   */

  def connectedSum(n: Int, edges: Array[String]): Int = {
    // Write your code here
    val initialGroup: List[Set[Int]] = Range(1, n+1).map(e => Set(e)).toList
    formGroupsR(edges.toList, initialGroup).map(_.size).map(e => {
      math.ceil(math.sqrt(e)).toInt
    }).sum
  }

  def formGroupsR(edges: List[String], group: List[Set[Int]]): List[Set[Int]] = {
    edges match {
      case Nil => group
      case h :: tail => {
        val nodes = h.split(" ").map(_.trim.toInt).toList
        val node1 = nodes(0)
        val node2 = nodes(1)
        val group1 = group.find(_.contains(node1)).get
        val group2 = group.find(_.contains(node2)).get
        val newGroup = if (group1 != group2) {
          group.filterNot(e => e == group1 || e == group2) :+ (group1 ++ group2)
        } else {
          group
        }
        formGroupsR(tail, newGroup)
      }
    }
  }

}

object Solution3 {
  def main(args: Array[String]) {


    val n = StdIn.readLine.trim.toInt

    val edgesCount = StdIn.readLine.trim.toInt

    val edges = Array.ofDim[String](edgesCount)

    for (i <- 0 until edgesCount) {
      val edgesItem = StdIn.readLine
      edges(i) = edgesItem
    }

    val result = Result1.connectedSum(n, edges)

    println(result)

  }
}

package helper

import ch.qos.logback.classic.spi.ILoggingEvent
import ch.qos.logback.classic.{Level, Logger}
import ch.qos.logback.core.Appender
import org.mockito.Mockito.verify
import org.mockito.{ArgumentCaptor, Mockito}
import org.scalatest.Matchers
import org.scalatest.exceptions.TestFailedException
import org.scalatestplus.mockito.MockitoSugar
import org.slf4j.LoggerFactory

import scala.collection.JavaConverters._
import scala.reflect.Manifest

case class LogMessageLevelTimes(message : String, level : Level, times : Int)

trait MockLogging[T] extends MockitoSugar with Matchers {
  var appender = mock[Appender[ILoggingEvent]]

  def initMockLogging(implicit m: Manifest[T]) = {
    appender = mock[Appender[ILoggingEvent]]
    supers(m.runtimeClass).foreach(claz => {
      val logger = LoggerFactory.getLogger(claz).asInstanceOf[Logger]
      logger.setAdditive(false)
      logger.setLevel(Level.DEBUG)
      logger.addAppender(appender)
    })
  }

  def verifyMultipleMessagesMultipleTimes(messages: Seq[LogMessageLevelTimes]) = {
    val captor: ArgumentCaptor[ILoggingEvent] = ArgumentCaptor.forClass(classOf[ILoggingEvent])
    val times = messages.foldLeft(0)((sum, m) => sum + m.times)
    verify(appender, Mockito.times(times)).doAppend(captor.capture())
    val allValues = captor.getAllValues.asScala
    val result = messages.find(message => {
      allValues.count(p => p.getFormattedMessage == message.message && p.getLevel == message.level) != message.times
    })
    result match {
      case Some(mismatch) => throw new TestFailedException(s"Expected log: $mismatch \nnot found in actual Logs: ${allValues.mkString("\n")}", 1)
      case None => true shouldBe true
    }
  }

  def supers(cl: Class[_]): List[Class[_]] = {
    if (cl == null) Nil else cl :: supers(cl.getSuperclass)
  }

}

package services

import akka.actor.{ActorSystem, Props}
import akka.testkit.TestKit
import clients.dtos.ShipmentResponseDto
import clients.http.{PricingClient, ShipmentClient, TrackingClient}
import config.SystemModule
import org.mockito.ArgumentMatchers
import org.mockito.Mockito.{reset, times, verify, verifyZeroInteractions, when}
import org.scalatest.{BeforeAndAfterEach, FunSpecLike}
import org.scalatestplus.mockito.MockitoSugar._

import scala.collection.mutable.ListBuffer
import scala.concurrent.Future
import scala.concurrent.duration._

class ThrottlerActorTest  extends TestKit(ActorSystem("throttler-test-system")) with FunSpecLike with BeforeAndAfterEach {

  val trackingClientMock = mock[TrackingClient]
  val shipmentClientMock = mock[ShipmentClient]
  val pricingClientMock = mock[PricingClient]

  val testModule = new SystemModule {
    override val pricingClient: PricingClient = pricingClientMock
    override val shipmentClient: ShipmentClient = shipmentClientMock
    override val trackingClient: TrackingClient = trackingClientMock
    override val FORCE_SEND_REQ_TIME: FiniteDuration = 1 seconds
  }


  override protected def beforeEach(): Unit = {
    reset(shipmentClientMock)
  }


  describe("ThrottlerActorTest") {

    it("should not send shipment request when count is less than CAP") {
      val service = new AggregationThrottleService(testModule)
      val actor = testModule.actorSystem.actorOf(Props(new service.ThrottlerActor))

      val shipmentQueries = ListBuffer("1", "2")

      actor ! service.ExecuteCommand(shipmentQueries, ListBuffer.empty, ListBuffer.empty)

      Thread.sleep(500)
      verifyZeroInteractions(shipmentClientMock)

    }

    it("should send shipment request when count is more than or equal to CAP") {
      val service = new AggregationThrottleService(testModule)
      val actor = testModule.actorSystem.actorOf(Props(new service.ThrottlerActor))

      val shipmentQueries = ListBuffer("1", "2", "3", "4")
      val shipmentQueries1 = ListBuffer("4", "5", "6", "7")
      val shipmentQueries2 = ListBuffer("9", "8", "1", "11")

      when(shipmentClientMock.getShipments(ArgumentMatchers.any())(ArgumentMatchers.any())).thenReturn(Future.successful(ShipmentResponseDto(Left("Error"))))

      actor ! service.ExecuteCommand(shipmentQueries, ListBuffer.empty, ListBuffer.empty)
      actor ! service.ExecuteCommand(shipmentQueries1, ListBuffer.empty, ListBuffer.empty)
      actor ! service.ExecuteCommand(shipmentQueries2, ListBuffer.empty, ListBuffer.empty)

      Thread.sleep(500)
      verify(shipmentClientMock, times(1)).getShipments(Seq("1", "2", "3", "4", "5"))(testModule.executionContext)
      verify(shipmentClientMock, times(1)).getShipments(Seq("6", "7", "9", "8", "1"))(testModule.executionContext)

    }

    it("should send request when count is low but force resend time is reached") {
      val service = new AggregationThrottleService(testModule)
      val actor = testModule.actorSystem.actorOf(Props(new service.ThrottlerActor))

      val shipmentQueries = ListBuffer("1", "2", "3", "4")

      when(shipmentClientMock.getShipments(ArgumentMatchers.any())(ArgumentMatchers.any())).thenReturn(Future.successful(ShipmentResponseDto(Left("Error"))))

      actor ! service.ExecuteCommand(shipmentQueries, ListBuffer.empty, ListBuffer.empty)

      Thread.sleep(500)
      verify(shipmentClientMock, times(0)).getShipments(Seq("1", "2", "3", "4"))(testModule.executionContext)

      Thread.sleep(600)
      verify(shipmentClientMock, times(1)).getShipments(Seq("1", "2", "3", "4"))(testModule.executionContext)
    }
  }

}

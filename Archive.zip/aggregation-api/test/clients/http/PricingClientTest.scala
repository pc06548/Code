package clients.http

import ch.qos.logback.classic.Level
import helper.{LogMessageLevelTimes, MockLogging}
import org.mockito.Mockito.when
import org.mockito.{ArgumentMatchers, Mockito}
import org.scalatest.{AsyncFunSpec, BeforeAndAfterEach}
import play.api.libs.json.Json
import play.api.libs.ws.{WSClient, WSRequest, WSResponse}

import scala.concurrent.Future


class PricingClientTest extends AsyncFunSpec with BeforeAndAfterEach with MockLogging[PricingClient]  {
  val wsClientMock = mock[WSClient]
  val requestMock = mock[WSRequest]
  when(wsClientMock.url(ArgumentMatchers.any())).thenReturn(requestMock)

  val host = "localhost"

  val client = new PricingClient(host, wsClientMock)

  override protected def beforeEach(): Unit = {
    initMockLogging
    Mockito.reset(wsClientMock)
  }

  describe("PricingClientTest") {
    it("should getPricing for queries and ignore all other responses") {
      val responseMock = mock[WSResponse]

      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(responseMock.status).thenReturn(200)
      when(responseMock.json).thenReturn(Json.parse(s"""{
                                                       "NL": 14.242090605778, "IN":1.2}""".stripMargin))

      val responseF = client.getPricing(Seq("NL", "CN"))

      responseF.map(response => {
        assert(response.errorOrResult == Right(Map(("NL", Some(BigDecimal(14.242090605778))), ("CN", None))))
      })
    }

    it("should handle error for non 200 status code") {
      val responseMock = mock[WSResponse]

      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(requestMock.url).thenReturn("/tracking?q=NL,CN")
      when(responseMock.status).thenReturn(500)

      val responseF = client.getPricing(Seq("NL", "CN"))

      responseF.map(response => {
        verifyMultipleMessagesMultipleTimes(
          Seq(
            LogMessageLevelTimes("Unexpected response status for request: /tracking?q=NL,CN. Code: 500", Level.ERROR, 1),
          )
        )
        assert(response.errorOrResult == Right(Map(("NL", None), ("CN", None))))
      })
    }

    it("should handle non json responses") {
      val responseMock = mock[WSResponse]

      when(requestMock.withQueryStringParameters(ArgumentMatchers.any())).thenReturn(requestMock)
      when(requestMock.get()).thenReturn(Future.successful(responseMock))
      when(requestMock.url).thenReturn("/tracking?q=NL,CN")
      when(responseMock.status).thenReturn(200)
      when(responseMock.json).thenThrow(new RuntimeException)


      val responseF = client.getPricing(Seq("NL", "CN"))

      responseF.map(response => {
        verifyMultipleMessagesMultipleTimes(
          Seq(
            LogMessageLevelTimes("Non json response for request: /tracking?q=NL,CN. Error: null", Level.ERROR, 1),
          )
        )
        assert(response.errorOrResult == Right(Map(("NL", None), ("CN", None))))
      })
    }
  }
}

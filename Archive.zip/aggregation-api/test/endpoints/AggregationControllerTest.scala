package endpoints

import config.SystemModule
import models.{AggregationResult, PricingResult, ShipmentResult, TrackingResult}
import org.mockito.Mockito.when
import org.scalatestplus.mockito.MockitoSugar.mock
import org.scalatestplus.play.PlaySpec
import play.api.mvc.Result
import play.api.test.FakeRequest
import play.api.test.Helpers.{status, stubControllerComponents, _}
import services.AggregationService

import scala.concurrent.Future


class AggregationControllerTest extends PlaySpec {

  val serviceMock = mock[AggregationService]

  val testModule = new SystemModule {
    override val aggregationService: AggregationService = serviceMock
  }

  val controller = new AggregationController(testModule, stubControllerComponents())

  "AggregationControllerTest" should {

    "should return ok on successfully getting the response" in {

      val shipmentQueries = Seq("123", "456")
      val pricingQueries = Seq("CN", "NL")
      val trackingQueries = Seq("123", "456")

      val aggregationResult = AggregationResult(
        ShipmentResult(Map("123" -> List("box", "box", "pallet"), "456" -> List())),
        TrackingResult(Map("123" -> Some("NEW"), "456" -> None)),
        PricingResult(Map("NL" -> Some(BigDecimal(1.2)), "CN" -> None)))

      when(serviceMock.execute(shipmentQueries, trackingQueries, pricingQueries)).thenReturn(Future.successful(Right(aggregationResult)))

      val resultF: Future[Result] = controller.aggregate("123,456", "123, 456", " CN,  NL ").apply(FakeRequest())

      assert(status(resultF)(testModule.timeout) == OK)

      assert(contentAsString(resultF)(testModule.timeout) == """{"pricing":{"NL":1.2,"CN":null},"track":{"123":"NEW","456":null},"shipments":{"123":["box","box","pallet"],"456":null}}""")
    }
  }

  "should return 500 on error" in {

    val shipmentQueries = Seq("123", "456")
    val pricingQueries = Seq("CN", "NL")
    val trackingQueries = Seq("123", "456")

    when(serviceMock.execute(shipmentQueries, trackingQueries, pricingQueries)).thenReturn(Future.failed(new Exception("some error")))

    val resultF: Future[Result] = controller.aggregate("123,456", "123, 456", " CN,  NL ").apply(FakeRequest())

    assert(status(resultF)(testModule.timeout) == INTERNAL_SERVER_ERROR)

    assert(contentAsString(resultF)(testModule.timeout) == "Something went wrong")
  }
}

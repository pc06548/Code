package clients.http

import clients.dtos.ShipmentResponseDto
import com.typesafe.scalalogging.StrictLogging
import javax.inject.Inject
import play.api.libs.ws.{WSClient, WSResponse}

import scala.concurrent.{ExecutionContext, Future}
import scala.util.{Failure, Success, Try}

class ShipmentClient (host: String, @Inject wsClient: WSClient) extends StrictLogging {
  val url = s"http://${host}/shipments"

  def getShipments(queries: Seq[String])(implicit executionContext: ExecutionContext): Future[ShipmentResponseDto] = {
    if(queries.nonEmpty) {
      val request = wsClient.url(url)
      val responseF: Future[WSResponse] = request.withQueryStringParameters(("q" -> queries.mkString(","))).get()

      responseF map { response =>
        if (response.status == 200) {
          ShipmentResponseDto(Right(parseResponse(response, queries, request.url)))
        } else {
          logger.error(s"Unexpected response status for request: ${request.url}. Code: ${response.status}")
          ShipmentResponseDto(Right(emptyResponse(queries)))
        }
      } recover {
        case ex =>
          logger.error(s"Unexpected error occurred for request: ${request.url}. $ex")
          ShipmentResponseDto(Left("Unexpected error occurred while getting shipment information"))
      }
    } else {
      logger.debug(s"Empty shipment response sent")
      Future.successful(ShipmentResponseDto())
    }
  }

  private def parseResponse(response: WSResponse, queries: Seq[String], url: String): Map[String, Seq[String]] = {
    Try(response.json) match {
      case Success(json) =>
        queries.map(query => {
          (json \ query).asOpt[Seq[String]] match {
            case Some(products) =>
              query -> products
            case None =>
              query -> Seq.empty
          }
        }).toMap
      case Failure(error) =>
        logger.error(s"Non json response for request: ${url}. Error: ${error.getMessage}")
        emptyResponse(queries)
    }
  }

  private def emptyResponse(queries: Seq[String]) = queries.map(query => query -> Seq.empty).toMap

}

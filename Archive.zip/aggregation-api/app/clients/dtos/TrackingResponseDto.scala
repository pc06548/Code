package clients.dtos

case class TrackingResponseDto(errorOrResult: Either[String, Map[String, Option[String]]] = Right(Map.empty)) extends ResponseDto

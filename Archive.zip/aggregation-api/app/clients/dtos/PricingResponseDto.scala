package clients.dtos

case class PricingResponseDto(errorOrResult: Either[String, Map[String, Option[BigDecimal]]] = Right(Map.empty)) extends ResponseDto

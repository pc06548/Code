package clients.dtos

case class ShipmentResponseDto(errorOrResult: Either[String, Map[String, Seq[String]]] = Right(Map.empty)) extends ResponseDto

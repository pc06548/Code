package services.converters

import clients.dtos._
import models._

trait ResponseDtoToModelConverter[In <: ResponseDto, Out <: ApiResult] {
  def convert(input: In): Out
}

object ResponseDtoToModelConverterInstances {

  implicit val shipmentConverter = new ResponseDtoToModelConverter[ShipmentResponseDto, ShipmentResult] {
    def convert(responseDto: ShipmentResponseDto): ShipmentResult = {
      responseDto.errorOrResult match {
        case Right(map) =>
          ShipmentResult(map)
        case Left(ex) =>
          // todo fix me
          throw new Exception
      }
    }
  }

  implicit val pricingConverter = new ResponseDtoToModelConverter[PricingResponseDto, PricingResult] {
    def convert(responseDto: PricingResponseDto): PricingResult = {
      responseDto.errorOrResult match {
        case Right(map) => PricingResult(map)
        case Left(ex) =>
          // todo fix me
          throw new Exception
      }
    }
  }

  implicit val trackingConverter = new ResponseDtoToModelConverter[TrackingResponseDto, TrackingResult] {
    def convert(responseDto: TrackingResponseDto): TrackingResult = {
      responseDto.errorOrResult match {
        case Right(map) =>
          TrackingResult(map)
        case Left(ex) =>
          // todo fix me
          throw new Exception
      }
    }
  }

  implicit val converter = new ResponseDtoToModelConverter[ResponseDto, ApiResult] {
    override def convert(input: ResponseDto): ApiResult = {
      // todo think and fix
      input match {
        case i: ShipmentResponseDto => shipmentConverter.convert(i)
        case i: PricingResponseDto => pricingConverter.convert(i)
        case i: TrackingResponseDto => trackingConverter.convert(i)
        case _ => throw new Exception // todo fix
      }
    }
  }

}

object ResponseDtoToModelConverter {

  def convert[In <: ResponseDto, Out <: ApiResult](a: In)(implicit instance: ResponseDtoToModelConverter[In, Out]): Out = {
    instance.convert(a)
  }
}
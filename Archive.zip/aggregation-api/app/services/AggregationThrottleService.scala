package services

import akka.actor.{Actor, ActorRef, Cancellable, Props}
import akka.pattern.{ask, pipe}
import clients.dtos._
import com.typesafe.scalalogging.StrictLogging
import config.SystemModule
import models._
import services.converters.ResponseDtoToModelConverter

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.concurrent.Future
import scala.util._

class AggregationThrottleService(systemModule: SystemModule) extends AggregationServiceT with StrictLogging {

  import systemModule._

  private val throttlerActor = actorSystem.actorOf(Props(new ThrottlerActor))

  override def execute(shipmentQueries: Seq[String], trackingQueries: Seq[String], pricingQueries: Seq[String]): Future[Either[String, AggregationResult]] = {
    ask(throttlerActor, ExecuteCommand(shipmentQueries, trackingQueries, pricingQueries)).mapTo[AggregationResult] map {
      result =>
        Right(result)
    } recover {
      case ex =>
        logger.error(s"Unexpected error occurred while getting API responses, ${ex}")
        Left("Unexpected error while getting api responses")
    }
  }

  case class ExecuteCommand(shipmentQueries: Seq[String], trackingQueries: Seq[String], pricingQueries: Seq[String])
  case class ForceSendCommand(queueName: String)

  class ThrottlerActor extends Actor {

    private val responseHandlerActor = actorSystem.actorOf(Props(new ResponseHandlerActor))

    private var shipmentQueries = ListBuffer.empty[String]
    private var trackingQueries = ListBuffer.empty[String]
    private var pricingQueries = ListBuffer.empty[String]

    private var shipmentReqHandle: Option[Cancellable] = None
    private var pricingReqHandle: Option[Cancellable] = None
    private var trackingReqHandle: Option[Cancellable] = None

    override def receive: Receive = {

      case ExecuteCommand(s, t, p) if(s.isEmpty && t.isEmpty && p.isEmpty) =>
        sender() ! AggregationResult.empty

      case ExecuteCommand(s, t, p) =>
        shipmentQueries ++= s.distinct.diff(shipmentQueries)
        trackingQueries ++= t.distinct.diff(trackingQueries)
        pricingQueries ++= p.distinct.diff(pricingQueries)

        responseHandlerActor ! AddRequestCommand(
          RequestResponse(sender(),
            AggregationResult(
              ShipmentResult(shipmentQueries.toList),
              TrackingResult(trackingQueries.toList),
              PricingResult(pricingQueries.toList)
            )))

        if (shipmentQueries.length >= REQUEST_CAP_COUNT) {
          shipmentClient.getShipments(shipmentQueries.take(REQUEST_CAP_COUNT)).pipeTo(responseHandlerActor)
          shipmentQueries = shipmentQueries.drop(REQUEST_CAP_COUNT)
        }

        if (trackingQueries.length >= REQUEST_CAP_COUNT) {
          trackingClient.getTracking(trackingQueries.take(REQUEST_CAP_COUNT)).pipeTo(responseHandlerActor)
          trackingQueries = trackingQueries.drop(REQUEST_CAP_COUNT)
        }

        if (pricingQueries.length >= REQUEST_CAP_COUNT) {
          pricingClient.getPricing(pricingQueries.take(REQUEST_CAP_COUNT)).pipeTo(responseHandlerActor)
          pricingQueries = pricingQueries.drop(REQUEST_CAP_COUNT)
        }

        if(shipmentQueries.length > 0 && (!shipmentReqHandle.isDefined || shipmentReqHandle.get.isCancelled)) {
          shipmentReqHandle = Some(actorSystem.scheduler.scheduleOnce(FORCE_SEND_REQ_TIME, self, ForceSendCommand("shipment")))
        }

        if(pricingQueries.length > 0 && (!pricingReqHandle.isDefined || pricingReqHandle.get.isCancelled)) {
          pricingReqHandle = Some(actorSystem.scheduler.scheduleOnce(FORCE_SEND_REQ_TIME, self, ForceSendCommand("pricing")))
        }

        if(trackingQueries.length > 0 && (!trackingReqHandle.isDefined || trackingReqHandle.get.isCancelled)) {
          trackingReqHandle = Some(actorSystem.scheduler.scheduleOnce(FORCE_SEND_REQ_TIME, self, ForceSendCommand("tracking")))
        }

      case ForceSendCommand(msg) =>

        msg match {
          case "shipment" =>
            shipmentClient.getShipments(shipmentQueries).pipeTo(responseHandlerActor)
            shipmentQueries = ListBuffer.empty
            shipmentReqHandle.map(h => if(!h.isCancelled) h.cancel())
            shipmentReqHandle = None

          case "pricing" =>
            pricingClient.getPricing(pricingQueries).pipeTo(responseHandlerActor)
            pricingQueries = ListBuffer.empty
            pricingReqHandle.map(h => if(!h.isCancelled) h.cancel())
            pricingReqHandle = None

          case "tracking" =>
            trackingClient.getTracking(trackingQueries).pipeTo(responseHandlerActor)
            trackingQueries = ListBuffer.empty
            trackingReqHandle.map(h => if(!h.isCancelled) h.cancel())
            trackingReqHandle = None

          case _ =>
        }

    }
  }

  case class RequestResponse(originalReq: ActorRef, var result: AggregationResult) {
    import services.converters.ResponseDtoToModelConverterInstances._

    def addApiResponse(dto: ResponseDto) = {

      val apiResult: ApiResult = ResponseDtoToModelConverter.convert(dto)
      result = result.addResult(apiResult)
    }
  }

  case class AddRequestCommand(requestOwner: RequestResponse)

  class ResponseHandlerActor extends Actor {

    var requests = mutable.ListBuffer.empty[RequestResponse]

    override def receive: Receive = {

      case AddRequestCommand(reqOwner) =>
        requests += reqOwner

      case response: ResponseDto =>
        requests.map(req => req.addApiResponse(response))
        sendResults
    }

    private def sendResults: Unit = {
      requests = requests.foldLeft(requests)((result, reqOwner) => {
        if (reqOwner.result.isResultComplete) {
          reqOwner.originalReq ! reqOwner.result
          result - reqOwner
        } else result
      })
    }
  }

}
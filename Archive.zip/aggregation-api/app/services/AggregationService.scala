package services

import com.typesafe.scalalogging.StrictLogging
import config.SystemModule
import models.{AggregationResult, PricingResult, ShipmentResult, TrackingResult}

import scala.concurrent.Future

class AggregationService (systemModule: SystemModule) extends AggregationServiceT with StrictLogging {
  import systemModule._

  override def execute(shipmentQueries: Seq[String], trackingQueries: Seq[String], pricingQueries: Seq[String]): Future[Either[String, AggregationResult]] = {
    val shipmentCall = shipmentClient.getShipments(shipmentQueries)
    val trackingCall = trackingClient.getTracking(trackingQueries)
    val pricingCall = pricingClient.getPricing(pricingQueries)
    (for {
      shipmentResponse <- shipmentCall
      trackingResponse <- trackingCall
      pricingResponse <- pricingCall
    } yield {
      Right(AggregationResult(
        ShipmentResult( shipmentResponse.errorOrResult.getOrElse(Map.empty)),
        TrackingResult( trackingResponse.errorOrResult.getOrElse(Map.empty)),
        PricingResult( pricingResponse.errorOrResult.getOrElse(Map.empty))))
    }) recover {
      case ex =>
        logger.error(s"Unexpected error occurred while getting API responses, $ex")
        Left("Unexpected error while getting api responses")
    }
  }

}
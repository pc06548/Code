package services

import models.AggregationResult

import scala.concurrent.Future

trait AggregationServiceT {
  def execute(shipmentQueries: Seq[String], trackingQueries: Seq[String], pricingQueries: Seq[String]): Future[Either[String, AggregationResult]]
}

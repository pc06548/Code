package models

case class PricingResult(value: Map[String, Option[BigDecimal]], pendingQueries: Seq[String]) extends ApiResult {

  def addResult(newResult: Map[String, Option[BigDecimal]]) = {
    val filteredMap = newResult.filter((keyValue) => pendingQueries.contains(keyValue._1))
    val newPendingQueries = pendingQueries.diff(newResult.keys.toSeq)
    val newMap = value ++ filteredMap
    PricingResult(newMap, newPendingQueries)
  }

  def isResultComplete = pendingQueries.isEmpty

}

object PricingResult {
  def empty = PricingResult(Seq.empty)

  def apply(queries: Seq[String]): PricingResult = new PricingResult(Map.empty, queries)

  def apply(map: Map[String, Option[BigDecimal]]): PricingResult = new PricingResult(map, Seq.empty)
}

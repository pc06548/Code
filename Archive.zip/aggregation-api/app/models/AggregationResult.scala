package models

import play.api.libs.json.{JsValue, Json, Writes}

case class AggregationResult( shipments: ShipmentResult,
                              track: TrackingResult,
                              pricing: PricingResult) {

  def addResult[T](result: ApiResult)= {
    result match {
      case ShipmentResult(map, _) =>
        this.copy(shipments = shipments.addResult(map))

      case PricingResult(map, _) =>
        this.copy(pricing = pricing.addResult(map))

      case TrackingResult(map, _) =>
        this.copy(track = track.addResult(map))
    }
  }

  def isResultComplete =
    shipments.isResultComplete && pricing.isResultComplete && track.isResultComplete
}

object AggregationResult {
  def empty = AggregationResult(ShipmentResult.empty, TrackingResult.empty, PricingResult.empty)

  def apply(shipments: ShipmentResult,
            track: TrackingResult,
            pricing: PricingResult): AggregationResult = new AggregationResult(shipments, track, pricing)

  def apply(shipmentQueries: Seq[String],
            trackingQueries: Seq[String],
            pricingQueries: Seq[String]): AggregationResult =
    new AggregationResult(
      ShipmentResult(shipmentQueries),
      TrackingResult(trackingQueries),
      PricingResult(pricingQueries))
}


object AggregationResultJsonWrites {
  implicit val writes = new Writes[AggregationResult] {
    override def writes(o: AggregationResult): JsValue = {
      Json.obj(
        "pricing" -> o.pricing.value,
        "track" -> o.track.value,
        "shipments" -> o.shipments.value.map((keyValue) => if (keyValue._2.isEmpty) (keyValue._1 -> None) else keyValue._1 -> Some(keyValue._2))
      )
    }
  }
}